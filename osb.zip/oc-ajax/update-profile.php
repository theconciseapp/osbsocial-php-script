<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['new_name'])
/* ||empty($_POST['new_email'] ) */ || empty($_POST['new_phone']) || empty($_POST['password']) || empty($_POST['username']) || empty($_POST['version'])) 
  {
    die('{"error":"One or more parameters empty."}');
  }
else if (!validUsername($_POST['username'], true)) 
  {
    die('{"error":"Invalid username."}');
  }
else if (!validName($_POST['new_name'])) 
  {
    die('{"error":"Enter a good display name."}');
  }
/*

else if (!filter_var( $_POST['new_email'], FILTER_VALIDATE_EMAIL) ) {

  die('{"error":"Invalid email address."}');

}

*/
else if (!preg_match("/^[0-9+() -]{5,30}$/i", $_POST['new_phone'])) 
  {
    die('{"error":"Enter a valid phone number."}');
  }
else if (!validPassword($_POST['password'])) 
  {
    die('{"error":"Invalid password."}');
  }
$username = test_input($_POST['username']);
$name     = test_input($_POST['new_name']);
//$email=test_input( strtolower( $_POST['new_email']) );
$phone    = test_input($_POST['new_phone']);
$pass     = test_input($_POST['password']);
$version  = test_input($_POST['version']);
require ("../oc-includes/server.php");
$table = _TABLE_USERS_;
$stmt  = $conn->prepare("SELECT password, email FROM $table WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $username) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
if ($res->num_rows < 1) 
  {
    $stmt->close();
    $conn->close();
    die('{"error":"Account not found."}');
  }
$row      = $res->fetch_assoc();
$password = $row["password"];
$iemail   = $row["email"];
if (!password_verify($pass, $password)) 
  {
    $stmt->close();
    $conn->close();
    die('{"error":"Invalid password."}');
  }
$stmt->close();
/*

if( $email!=$iemail){



$stmt=$conn->prepare("SELECT id FROM $table WHERE email=? LIMIT 1");



if(!$stmt||!$stmt->bind_param('s', $email) ||! $stmt->execute() ){

  $conn->close();

 die('{"error":"Please try again."}');

}



$res=$stmt->get_result();



if( $res->num_rows>0 ){

 $stmt->close();

 $conn->close();

   die('{"error":"Email address already in use."}');



}



$stmt->close();



}

*/
$stmt = $conn->prepare("UPDATE $table SET fullname=?, phone=? WHERE username=? LIMIT 1");
if ($stmt && $stmt->bind_param('sss', $name, $phone, $username) && $stmt->execute()) 
  {
    $stmt->close();
    $conn->close();
    $data   = array();
    $data["username"]        = $username;
    $data["email"]        = $iemail;
    $data["fullname"]        = $name;
    $data["phone"]        = $phone;
    $data["version"]        = $version;
    $result = array();
    $result["status"]        = "success";
    $result["result"]        = $data;
    die(json_encode($result));
  }
$stmt->close();
$conn->close();
die('{"error":"Failed to change"}');
