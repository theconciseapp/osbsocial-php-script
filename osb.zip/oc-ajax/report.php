<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Invalid security token.","ecode":"-1"}');
  }
if ($force_login != "YES") 
  {
    $_POST["username"] = "anonymous";
  }
if (empty($_POST['username']) || empty($_POST["report_id"]) || empty($_POST["message"]) || empty($_POST["section"]) || empty($_POST["version"])) 
  {
    die('{"error":"Missing parameters."}');
  }
$version  = test_input($_POST['version']);
$username = test_input(strtolower($_POST['username']));
$meta     = $message  = "";
$message  = trim($_POST["message"]);
$plen     = strlen($message);
if ($plen < 2 || $plen > 150) 
  {
    die('{"error":"Report too long. Max: 150 hharacters"}');
  }
$rid     = test_input($_POST["report_id"]);
$message = test_input($message);
$section = test_input($_POST["section"]);
if (!empty($_POST["meta"])) 
  {
    $meta    = htmlspecialchars(trim($_POST['meta']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
  }
$rtime   = time();
require ('../oc-includes/server.php');
$table  = _TABLE_REPORTS_;
$result = array();
$stmt   = $conn->prepare("INSERT INTO $table ( report_id, report_by, report, report_section, meta, report_time, date_time )  VALUES( ?,?,?,?,?,?,NOW() )");
if ($stmt && $stmt->bind_param('isssss', $rid, $username, $message, $section, $meta, $rtime) && $stmt->execute()) 
  {
    $stmt->close();
    $result["status"] = "success";
    $result["result"] = "Reported successfully.";
    $conn->close();
    die(json_encode($result));
  }
$conn->close();
die('{"error":"Sending failed."}');
