<?php if (isset($_COOKIE['OSB__USERNAME__'])) 
  {
    unset($_COOKIE['OSB__USERNAME__']);
    setcookie('OSB__USERNAME__', '', time() - 3600, '/');
  }
if (isset($_COOKIE['OSB__TOKEN__'])) 
  {
    unset($_COOKIE['OSB__TOKEN__']);
    setcookie('OSB__TOKEN__', '', time() - 3600, '/');
  }
die('{"status":"success","result":"Logged out"}');
