<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
else if (empty($_POST['username'])) 
  {
    die('{"error":"Empty parameters."}');
  }
$dir = _CHAT_FILES_DIR_ . '/stats/' . date('Y') . '/' . date('m');
if (!make_dir($dir)) 
  {
    logIt("Could not make dir: {$dir}");
    die('{"error":"Failed to create directory."}');
  }
$dayfile   = $dir . '/' . date('d') . '.txt';
$monthfile = $dir . '/' . date('M') . '.txt';
require ('../oc-includes/server.php');
$table       = _TABLE_USERS_;
$last_online = time();
$username    = test_input($_POST['username']);
$stmt        = $conn->prepare("UPDATE $table SET last_online=? WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('is', $last_online, $username) || !$stmt->execute()) 
  {
    logIt("Failed to update last_online field in users table for user: {$username}");
  }
if (!file_exists($dayfile)) 
  {
    if (file_put_contents($dayfile, '1')) 
      {
        die('{"status":"success","result":"Recorded successfully"}');
      }
  }
else
  {
    $day = (int)file_get_contents($dayfile);
    $day++;
    if (file_put_contents($dayfile, $day)) 
      {
        if (file_exists($monthfile)) 
          {
            $month = (int)file_get_contents($monthfile);
            $month++;
            file_put_contents($monthfile, $month);
          }
        else
          {
            file_put_contents($monthfile, '2');
          }
        die('{"status":"success","result":"Recorded successfully."}');
      }
  }
die('{"error":"Failed to record."}');
