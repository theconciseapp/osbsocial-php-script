<?php require ('../oc-includes/bootstrap.php');
$file = _PROJECT_DIR_ . "/oc-admin/settings-files/app-upgrade-data.txt";
if (!is_readable($file)) 
  {
    die("Mobile app not available yet");
  }
$data = file_get_contents($file);
$json = json_decode($data, true);
if (!$json) 
  {
    die("Could not get info");
  }
$link = $json["version_url"];
$code = $json["version_code"];
$info = $json["version_info"];
if (preg_match("/coming-soon/i", $link)) 
  {
    echo '<div class="bg-light pt-3 pb-3 text-center" style="max-width: 95%; margin: 0 auto;">Mobile app coming Soon!</div>';
  }
else
  {
    echo '<div class="container">
   <div>' . $info . '</div>
   <div class="text-center">
 <form action="' . $link . '" target="blank_">
<input class="mt-5 btn btn-xl btn-primary" type="submit" value="Download Our App v' . $code . '" />
</form>
</div>
 </div>';
  }
