<?php
/**
 * Class and Function List:
 * Function list:
 * Classes list:
 */
header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version']) || empty($_POST['lock_status'])) 
  {
    die('{"error":"Parameters missing."}');
  }
$username = test_input(strtolower($_POST['username']));
$gpin     = test_input(strtolower($_POST['group_pin']));
if ($gpin == "gv_pofficials") 
  {
    die('{"status":"success","result":"1"}');
  }
$lock        = test_input(strtolower($_POST['lock_status']));
$app_version = test_input($_POST['version']);
if ($username == $gpin) 
  {
    die('{"error":"Sorry, not allowed"}');
  }
$meta = array();
require "../../oc-includes/server.php";
require "group-functions.php";
$table = _TABLE_GROUPS_;
$stmt  = $conn->prepare("SELECT group_admins FROM $table WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) 
  {
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    die('{"error":"Group pin not found"}');
  }
$row    = $res->fetch_assoc();
$admins = $row['group_admins'];
if (!preg_match("/\b{$username}\b,/", $admins)) 
  {
    die('{"error":"Permission denied"}');
  }
$glockdir = getGroupDir($gpin);
if ($lock == 'lock') 
  {
    if (!is_dir($glockdir)) 
      {
        die('{"error":"Unable to alter"}');
      }
    if (file_put_contents($glockdir . "/lock.md", $admins)) 
      {
        $message = "lock-group|$gpin";
        customGroupMessage($conn, $gpin, "", $message, "act");
        $message2 = "_?smSettings changed to allow *only admins* to send messages?sm_";
        if (is_page($gpin)) 
          {
            $message2 = "_?smSettings changed to allow *only admins* to send posts?sm_";
          }
        $preview  = str_replace('_', '', $message2);
        customGroupMessage($conn, $gpin, $preview, $message2, $username . "~");
        $conn->close();
        die('{"status":"success","result":"1"}');
      }
    die('{"error":"Unable to alter"}');
  }
else
  {
    if (!is_dir($glockdir)) 
      {
        die('{"error":"Failed to change group status."}');
      }
    if (!file_exists($glockdir . '/lock.md') || unlink($glockdir . '/lock.md')) 
      {
        $message = "unlock-group|$gpin";
        customGroupMessage($conn, $gpin, "", $message, "act");
        $message2 = "_?smSettings changed to allow *all members* to send messages?sm_";
        if (is_page($gpin)) 
          {
            $message2 = "_?smSettings changed to allow *all members* to send posts?sm_";
          }
        $preview  = str_replace('_', '', $message2);
        customGroupMessage($conn, $gpin, $preview, $message2, $username . "~");
        $conn->close();
        die('{"status":"success","result":"2"}');
      }
    die('{"error":"Could not change"}');
  }
