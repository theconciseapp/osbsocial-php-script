<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Token not valid."}');
  }
else if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input(strtolower($_POST['username']));
$gpin     = test_input(strtolower($_POST['group_pin']));
if (!validUsername($gpin, true)) 
  {
    die('{"error":"Sorry, not allowed."}');
  }
$app_version = test_input($_POST['version']);
$file        = getGroupDir($username) . "/groups.txt";
if ($username == $gpin) 
  {
    die('{"error":"You can\'t delete"}');
  }
require ('../../oc-includes/server.php');
require ('group-functions.php');
$group          = is_group($gpin);
$table          = _TABLE_GROUPS_;
$table_messages = $table . '_messages';
$stmt           = $conn->prepare("SELECT username, group_admins, group_members, created_by, total_members FROM $table WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    $conn->close();
    die('{"status":"success","result":"Left group."}');
  }
$row           = $res->fetch_assoc();
$cby           = strtolower($row["created_by"]);
$total_members = (int)$row["total_members"];
$members       = $row["group_members"];
$admins        = $row["group_admins"];
$exp_admins    = explode(",", trim($admins));
$total_admins  = count($exp_admins);
$save_admins   = preg_replace("/\b{$username}\b,/", "", $admins);
$save_members  = preg_replace("/\b{$username}\b,/u", "", $members, 1, $replaced);
if ($group && $replaced < 1) 
  {
    $conn->close();
    die('{"success":"success","result":"Left group."}');
    //Not a group member
    
  }
$gdir = getGroupDir($gpin);
try
  {
    if ($cby == $username) 
      {
        if (@deleteTree($gdir)) 
          {
            //Delete group if creator leaves
            $stmt = $conn->prepare("DELETE FROM $table  WHERE username=? LIMIT 1");
            if ($stmt && $stmt->bind_param('s', $gpin) && $stmt->execute()) 
              {
                $stmt->close();
                $conn->close();
                $ajgfile   = _ADMIN_DIR_ . "/settings-files/auto-join-groups.txt";
                if (file_exists($ajgfile)) 
                  {
                    $ajgroups  = @file_get_contents($ajgfile);
                    if (!empty($ajgroups)) 
                      {
                        $regex     = "/^$gpin\|.*?\n/mi";
                        if (preg_match($regex, $ajgroups)) 
                          {
                            $ajgroups_ = preg_replace($regex, "", $ajgroups);
                            @file_put_contents($ajgfile, $ajgroups_);
                          }
                      }
                  }
              }
          }
        die('{"status":"success","result":"Left group."}');
      }
    if ($group) 
      {
        $stmt = $conn->prepare("UPDATE $table SET group_members ='$save_members', group_admins = '$save_admins' , total_members=total_members-1 WHERE username=? LIMIT 1");
        $stmt->bind_param('s', $gpin);
        $stmt->execute();
      }
    else
      {
        $stmt = $conn->prepare("UPDATE $table SET group_admins='$save_admins', total_members=total_members-1 WHERE username=? LIMIT 1");
        $stmt->bind_param('s', $gpin);
        $stmt->execute();
      }
  }
catch(Exception $e) 
  {
    //ignore error
    
  }
if ($stmt->affected_rows > 0) 
  {
    $stmt->close();
    $table_users = _TABLE_USERS_;
    $rgpin       = "{$gpin} ";
    try
      {
        mysqli_query($conn, "UPDATE $table_users SET groups=REPLACE( groups, '$rgpin', '') WHERE username='$username' LIMIT 1");
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
      }
    if ($group) 
      {
        $meta    = array();
        $msg     = '_?sm' . str_replace(array(
            'vf_',
            'gp_'
        ) , '', ucfirst($username)) . ' left?sm_';
        $preview = str_replace('_', '', $msg);
        customGroupMessage($conn, $gpin, $preview, $msg);
      }
    $conn->close();
    die('{"status":"success","result":"Left group."}');
  }
$conn->close();
die('{"error":"Failed to leave."}');
