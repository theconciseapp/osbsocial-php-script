<?php function groupMessages($conn, $chat_to) 
  {
    $result = array(
        "group_messages" => array() ,
        "invalid_groups" => "",
        "members_typing" => "",
        "glock_status" => array()
    );
    if (empty($_POST['groups_pins'])) 
      {
        return $result;
      }
    $gpins          = preg_replace("/[^a-zA-Z0-9|_ ]/", "", $_POST['groups_pins']);
    $gmessage       = $invalid_groups = $members_typing = $lock_status    = "";
    $gpins          = explode(" ", $gpins);
    $total_gpins    = count($gpins);
    if ($total_gpins > 8) 
      {
        $gpins          = array_slice($gpins, 0, 8);
      }
    $conditions     = "";
    $cnt            = 0;
    $glocks         = $invalid_groups = array();
    foreach ($gpins AS $gdata_) 
      {
        $gdata          = explode("|", $gdata_);
        $gpin           = mysqli_real_escape_string($conn, trim($gdata[0]));
        $glastid        = preg_replace('/[^0-9]/', '', $gdata[1]); //Group's last message id
        $gdir           = getGroupDir($gpin);
        /*
        
        Update group's lastseen...i.e last group message check by a member
        
        $lsfile="{$gdir}/lastseen.txt";
        
        file_put_content( $lsfile, time() );
        
        */
        $cnt++;
        if ($cnt > 1) 
          {
            $conditions.= " OR ";
          }
        $conditions.= "( id > $glastid AND message_to='$gpin' ) ";
        if ($gpin == "gv_pofficials" || is_file($gdir . '/lock.md')) 
          {
            //Group lock status-Only admin can send message
            $glock[$gpin]      = "locked";
          }
        else
          {
            $glock[$gpin]      = "unlocked";
          }
        // $members_typing.=friendTyping( $gdir ) . "\n";
        
      }
    $data = fetch_group_message($conn, $conditions, $chat_to);
    $result["group_messages"]      = $data;
    $result["invalid_groups"]      = $invalid_groups;
    $result["glock_status"]      = $glock;
    $result["members_typing"]      = trim($members_typing);
    return $result;
  }
function fetch_group_message($conn, $conditions, $fetcher) 
  {
    $iresult = array();
    if (empty($conditions)) 
      {
        return $iresult;
      }
    $table = _TABLE_GROUPS_ . '_messages';
    $sql   = "SELECT id, message_id, message_time, message_from, message_to, message_preview, message, meta FROM {$table} WHERE ( {$conditions} ) AND ( message_from !='$fetcher' ) ORDER BY id ASC LIMIT 50";
    try
      {
        $query = mysqli_query($conn, $sql);
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
        return $iresult;
      }
    $total = mysqli_num_rows($query);
    if ($total < 1) 
      {
        return $iresult;
      }
    while ($row = mysqli_fetch_assoc($query)) 
      {
        $iresult[]     = $row;
      }
    return $iresult;
  }
//FETCH GROUP INFO
function getGroupInfos($conn, $gpin, $username) 
  {
    $app_version = test_input($_POST['version']);
    $gdir        = getGroupDir($gpin);
    // $file        = getGroupDir( $username) . "/groups.txt";
    $table       = _TABLE_GROUPS_;
    $stmt        = $conn->prepare("SELECT*FROM $table WHERE username=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) 
      {
        //$conn->close();
        return '{"error":"Failed. Try again."}';
      }
    $res = $stmt->get_result();
    $stmt->close();
    if ($res->num_rows < 1) 
      {
        if ($gpin == 'gv_pofficials') 
          {
            return '{"error":"Official"}';
          }
        else
          {
            remove_group($conn, $gpin);
          }
        //$conn->close();
        return '{"error":"Group not found."}';
      }
    $result    = $info      = $full_info = array();
    //$conn->close();
    $row       = $res->fetch_assoc();
    $cby       = strtolower($row["created_by"]);
    $gmembers  = $row["group_members"];
    if (!empty($gmembers)) 
      {
        $toarray   = explode(",", $gmembers);
        sort($toarray);
        $gmembers    = implode(" ", $toarray);
      }
    $lock_status = "unlocked";
    if (is_file($gdir . '/lock.md')) 
      {
        $lock_status = "locked";
      }
    $row["group_lock"]             = $lock_status;
    if ($cby == $username) 
      {
        $row["owner"]             = $cby;
      }
    $row["app_version"]             = $app_version;
    $row["group_members"]             = "";
    $full_info   = $row;
    $full_info["group_members"]             = trim($gmembers);
    $fresult["status"]             = "success";
    $fresult["short_info"]             = "{$gpin}|" . str_replace("|", "?", $row["fullname"]);
    $fresult["full_info"]             = $full_info;
    return json_encode($fresult);
  }
function groupLockStatus($gpin, $status) 
  {
    //lock or unlock
    if ($status == "unlocked") 
      {
        $lfile = getGroupDir($gpin) . "/lock.md";
        if (file_exists($lfile)) 
          {
            unlink($lfile);
          }
      }
    else
      {
        file_put_contents($lfile, 'locked');
      }
  }
function get_group_data($conn, $gpin, $check_admin = false) 
  {
    $table       = _TABLE_GROUPS_;
    $stmt        = $conn->prepare("SELECT * FROM $table WHERE username=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) 
      {
        return "-1";
      }
    $res = $stmt->get_result();
    $stmt->close();
    if ($res->num_rows < 1) 
      {
        return "0";
      }
    $row    = $res->fetch_assoc();
    if ($check_admin) 
      {
        $admins = $row['group_admins'];
        if (!preg_match("/\b{$check_admin}\b,/", $admins)) 
          {
            return "00";
          }
      }
    return $row;
  }
function add_group_admin($conn, $gpin, $fuser, $username) 
  {
    $table = _TABLE_GROUPS_;
    $fdir  = getGroupDir($fuser);
    if (!is_dir($fdir)) 
      {
        return ('{"error":"Pin not found."}');
      }
    $row = get_group_data($conn, $gpin, $username);
    if ($row === "-1") 
      {
        return ('{"error":"Please try again"}');
      }
    else if ($row === "0") 
      {
        return ('{"error":"Group pin not found"}');
      }
    else if ($row === "00") 
      {
        return ('{"error":"Permission denied"}');
      }
    $gtitle       = $row['fullname'];
    $cby          = $row['created_by'];
    $gmembers     = $row["group_members"];
    $admins       = $row['group_admins'];
    $meta         = array();
    $check        = $fuser . ',';
    if (!empty($admins)) 
      {
        $total_admins = count(explode(',', $admins));
        if ($total_admins > 5) 
          {
            return ('{"error":"Maximum admins reached."}');
          }
      }
    $gdir    = getGroupDir($gpin);
    if (file_exists($gdir . "/lock.md")) 
      {
        $ladmins = file_get_contents($gdir . "/lock.md");
        if (!preg_match("/\b{$fuser}\b,/", $ladmins)) 
          {
            file_put_contents($gdir . "/lock.md", $fuser . ",", FILE_APPEND | LOCK_EX);
          }
      }
    if (preg_match("/\b{$fuser}\b,/", $admins)) 
      {
        return ('{"status":"success","type":"added","result":"Successful."}');
      }
    $upd  = $admins . $fuser . ","; //e.g admin1,newadmin,
    $stmt = $conn->prepare("UPDATE $table SET group_admins=? WHERE username=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('ss', $upd, $gpin) || !$stmt->execute()) 
      {
        return ('{"error":"Failed to add"}');
      }
    $stmt->close();
    $message = "add-as-group-admin|{$gpin}";
    inboxUser($conn, $fuser, "", $message, "act");
    return ('{"status":"success","type":"added","result":"Successful."}');
  }
function remove_group_admin($conn, $gpin, $fuser, $username) 
  {
    if (strtolower($fuser) == "av_official") 
      {
        return ('{"error":"Permission denied"}');
      }
    $table = _TABLE_GROUPS_;
    $row   = get_group_data($conn, $gpin, $username);
    if ($row == "-1") 
      {
        return ('{"error":"Please try again."}');
      }
    else if ($row == "0") 
      {
        return ('{"error":"Group pin not found."}');
      }
    else if ($row == "00") 
      {
        return ('{"error":"Permission denied."}');
      }
    $gtitle   = $row['fullname'];
    $cby      = $row['created_by'];
    $gmembers = $row["group_members"];
    $admins   = $row['group_admins'];
    if ($fuser == $cby) 
      {
        return ('{"error":"Sorry, you cannot remove group creator"}');
      }
    $gdir    = getGroupDir($gpin);
    if (file_exists($gdir . "/lock.md")) 
      {
        $ladmins = file_get_contents($gdir . "/lock.md");
        $ladmins = preg_replace("/\b{$fuser}\b,/", "", $ladmins);
        file_put_contents($gdir . "/lock.md", $ladmins, LOCK_EX);
      }
    $rep  = preg_replace("/\b{$fuser}\b,/", "", $admins);
    $stmt = $conn->prepare("UPDATE $table SET group_admins =? WHERE username=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('ss', $rep, $gpin) || !$stmt->execute()) 
      {
        return ('{"error":"Failed to remove."}');
      }
    $stmt->close();
    $message = "remove-from-group-admin|{$gpin}";
    inboxUser($conn, $fuser, "", $message, "act");
    return ('{"status":"success","type":"removed","result":"Successful."}');
  }
function remove_group_member($conn, $gpin, $fuser, $username) 
  {
    $table = _TABLE_GROUPS_;
    $row   = get_group_data($conn, $gpin, $username);
    if ($row === "-1") 
      {
        return ('{"error":"Please try again."}');
      }
    else if ($row === "0") 
      {
        return ('{"error":"Group pin not found."}');
      }
    else if ($row === "00") 
      {
        return ('{"error":"Permission denied."}');
      }
    $gtitle   = $row['fullname'];
    $cby      = $row['created_by'];
    $gmembers = $row["group_members"];
    $admins   = $row["group_admins"];
    if ($fuser == $cby) 
      {
        return ('{"error":"Sorry, you cannot remove group creator"}');
      }
    $repl_admins  = preg_replace("/\b{$fuser}\b,/", "", $admins);
    $repl_members = preg_replace("/\b{$fuser}\b,/", "", $gmembers);
    $stmt         = $conn->prepare("UPDATE $table SET group_admins =?, group_members=?, total_members=total_members-1 WHERE username=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('sss', $repl_admins, $repl_members, $gpin) || !$stmt->execute()) 
      {
        return ('{"error":"Please try again."}');
      }
    $message = "remove-from-group|{$gpin}";
    inboxUser($conn, $fuser, "", $message, "act");
    return ('{"status":"success","type":"removedm","result":"Successful."}');
  }
function remove_group($conn, $gpin) 
  {
    $message = "remove-from-group|{$gpin}";
    @customGroupMessage($conn, $gpin, "", $message, "act");
  }
function customGroupMessage($conn, $message_to      = "", $message_preview = "", $message, $message_from    = "uv_admin", $meta            = array() , $can_comment     = "") 
  {
    $table_messages  = _TABLE_GROUPS_MESSAGES_;
    $time            = time();
    $message_id      = randomNumbers(15);
    $mdata           = array();
    $mdata["can_comment"]                 = $can_comment;
    if (!empty($meta)) 
      {
        $mdata           = array_merge($mdata, $meta);
      }
    $mdata["time"]                 = $time;
    $mdata["ver"]                 = "0";
    $mdata["sver"]                 = _SITE_VERSION_;
    $mdata["is_admin"]                 = "1";
    $meta            = json_encode($mdata);
    try
      {
        $stmt            = $conn->prepare("INSERT INTO {$table_messages}(  message_time, message_id, message_to, message_from,message_preview, message, meta, date_time) VALUES (?,?,?,?,?,?,?, NOW() )");
        if ($stmt && $stmt->bind_param('iisssss', $time, $message_id, $message_to, $message_from, $message_preview, $message, $meta) && $stmt->execute()) 
          {
            $stmt->close();
            //Do not close connection here
            //Connection should be closed by script
            //that called this function
            return 1;
          }
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
        return 0;
      }
    return 0;
  }
function all_post_comments($IN_          = array()) 
  {
    global $conn;
    $final_result = $result_      = array();
    $table        = _TABLE_GROUPS_COMMENTS_;
    $IN           = "";
    if (count($IN_)) 
      {
        $IN           = "WHERE post_id IN (" . implode(',', $IN_) . ")";
      }
    $sql          = "SELECT COUNT(`post_id`) as `total_comment`, `post_id` FROM $table $IN
 GROUP BY `post_id` ";
    $result       = $conn->query($sql);
    $conn->close();
    if ($result->num_rows > 0) 
      {
        while ($comm = $result->fetch_assoc()) 
          {
            $result_[]      = $comm;
          }
        $final_result["status"]      = "success";
      }
    $final_result["result"]      = $result_;
    return json_encode($final_result);
  }
//This will get you total comments for a specific post.  You have to pass post id when calling the function.
function comment_count($postId) 
  {
    global $conn;
    $final_result = $result_      = array();
    $table        = _TABLE_GROUPS_COMMENTS_;
    $sql          = "SELECT COUNT(`post_id`) as `total_comment` FROM $table WHERE `post_id` = $postId";
    $result       = $conn->query($sql);
    if ($result->num_rows > 0) 
      {
        $result_[]              = $result->fetch_assoc();
      }
    $final_result["status"]              = "success";
    $final_result["result"]              = $result_;
    return json_encode($final_result);
  }
