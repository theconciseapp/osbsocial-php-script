<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['group_info']) || empty($_POST['type']) || empty($_POST['version'])) 
  {
    die('{"error":"Parameters missing."}');
  }
$type = $_POST['type'];
$info = test_input($_POST['group_info']);
if ($type == 'group-info') 
  {
    $type = 'group_info';
    if (strlen($info) < 4) 
      {
        die('{"error":"Not descriptive."}');
      }
  }
else if ($type == 'group-title') 
  {
    $type = 'fullname';
    if (strlen($info) < 1) 
      {
        die('{"error":"Title too short."}');
      }
    $info = preg_replace("/(\s+|\|)/", " ", $info);
  }
else
  {
    die('{"error":"Type not found."}');
  }
require ('../../oc-includes/server.php');
require "group-functions.php";
$gpin     = test_input($_POST['group_pin']);
$username = test_input($_POST['username']);
$table    = _TABLE_GROUPS_;
$stmt     = $conn->prepare("SELECT group_members, group_admins FROM {$table} WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $gpin) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    die('{"error":"Group or page not found."}');
  }
$row      = $res->fetch_assoc();
$admins   = $row["group_admins"];
$gmembers = $row["group_members"];
//check if is group admin
if (!preg_match("/\b{$username}\b,/", $gmembers) || !preg_match("/\b{$username}\b,/", $admins)) 
  {
    die('{"error":"You are not permitted"}');
  }
$stmt    = $conn->prepare("UPDATE $table SET {$type}=? WHERE username=? LIMIT 1");
if ($stmt && $stmt->bind_param('ss', $info, $gpin) && $stmt->execute()) 
  {
    if (is_group($gpin)) 
      {
        $msg     = '_?smGroup info updated?sm_';
      }
    else
      {
        $msg     = '_?smPage info updated?sm_';
      }
    $meta    = array();
    $preview = str_replace('_', '', $msg);
    customGroupMessage($conn, $gpin, $preview, $msg, $username . "~");
    $stmt->close();
    $conn->close();
    die('{"status":"success","result":"Updated successfully."}');
  }
$conn->close();
die('{"error":"Could not update."}');
