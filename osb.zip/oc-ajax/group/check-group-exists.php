<?php
/**
 * Class and Function List:
 * Function list:
 * Classes list:
 */
header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version'])) 
  {
    die('{"error":"Parameters missing."}');
  }
$settings__        = getSettings();
$enable_addcontact = isset($settings__["enable_add_contact"]) ? $settings__["enable_add_contact"] : 'YES';
if ($enable_addcontact != 'YES') 
  {
    die('{"error":"Sorry, feature currently disabled."}');
  }
$userName    = test_input(strtolower($_POST['username']));
$pin         = test_input(strtolower($_POST['group_pin']));
$app_version = test_input(strtolower($_POST['version']));
if ($userName == $pin) 
  {
    die('{"error":"Sorry, not allowed."}');
  }
else if (!validUsername($pin, true)) 
  {
    die('{"error":"Group pin not found."}');
  }
require "../../oc-includes/server.php";
$table = _TABLE_GROUPS_;
$stmt  = $conn->prepare("SELECT fullname, group_info,created_by, created_on FROM $table WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $pin) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
$conn->close();
if ($res->num_rows < 1) 
  {
    die('{"error":"Group pin not found."}');
  }
$row = $res->fetch_assoc();
$row["status"]     = "success";
die(json_encode($row));
