<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES" && empty($_POST["username"])) 
  {
    $_POST["username"] = "anonymous";
  }
else if (empty($_POST['post_id']) || empty($_POST['username'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input($_POST['username']);
$pid      = test_input($_POST['post_id']);
require ('../../oc-includes/server.php');
$table       = _TABLE_SOCIAL_POSTS_;
$table_users = _TABLE_USERS_;
$ftable      = _TABLE_SOCIAL_FOLLOWERS_;
$result      = array();
$stmt        = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.birth, U.added_on AS joined_on, F.status AS me_following, P.* FROM {$table} AS P 
INNER JOIN {$table_users} AS U ON U.username=P.post_by 
LEFT JOIN {$ftable} AS F ON ( F.following=P.post_by AND F.follower=? ) WHERE ( P.id=? AND P.post_status=1)
 LIMIT 1");
if ($stmt && $stmt->bind_param('si', $username, $pid) && $stmt->execute()) 
  {
    $res         = $stmt->get_result();
    $stmt->close();
    if ($res->num_rows < 1) 
      {
        $del_msg = "<br>*This post is not available right now.*<br>_Might have been deleted by the owner._<br><br>";
        if (!empty($_POST["cpost_id"])) 
          {
            $cpid    = test_input($_POST["cpost_id"]);
            $stmt    = $conn->prepare("SELECT post_meta FROM $table WHERE id=? LIMIT 1");
            if (!$stmt || !$stmt->bind_param('i', $cpid) || !$stmt->execute()) 
              {
              }
            $res     = $stmt->get_result();
            $stmt->close();
            if ($res->num_rows < 1) 
              {
              }
            $row   = $res->fetch_assoc();
            $pm    = $row["post_meta"];
            $pm    = json_decode($pm, true);
            $pm["opost_preview"]       = $del_msg;
            //$pm["opbf"]="No name";
            $pm["odeleted"]       = 1;
            $pmeta = json_encode($pm);
            $stmt  = $conn->prepare("UPDATE $table SET post_meta=? WHERE id=? LIMIT 1");
            if ($stmt && $stmt->bind_param('si', $pmeta, $cpid) && $stmt->execute()) 
              {
                //Updated
                
              }
            $stmt->close();
          }
        $conn->close();
        die('{"error":"Post is unavailable","error_message":"' . $del_msg . '"}');
      }
    $row = $res->fetch_assoc();
    $result["status"]     = "success";
    $result["me_following"]     = $row["me_following"];
    $result["post"][]     = $row;
    $result["settings"]     = $settings__;
    die(json_encode($result));
  }
$conn->close();
die(json_encode('{"error":"Not known"}'));
