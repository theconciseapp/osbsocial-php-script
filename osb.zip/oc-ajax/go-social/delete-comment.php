<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['username']) || empty($_POST['comment_id']) || empty($_POST['cauthor']) || empty($_POST['post_id']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input(strtolower($_POST['username']));
//Comment author can delete his/her message
$author   = $username;
$post_id  = test_input($_POST['post_id']);
$cid      = test_input($_POST['comment_id']);
if (go_admin($username)) 
  {
    //Admin can delete any commemt
    $author   = test_input(strtolower($_POST['cauthor']));
  }
$version  = test_input($_POST['version']);
require ('../../oc-includes/server.php');
require ('comment-functions.php');
if (delete_comment($conn, $cid, $post_id, $author)) 
  {
    $conn->close();
    die('{"status":"success","result":"Succesful."}');
  }
$conn->close();
die('{"error":"Please try again."}');
