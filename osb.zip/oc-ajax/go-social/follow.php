<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['pin'])) 
  {
    die('{"error":"Missing parameters"}');
  }
$result   = array();
$username = test_input(strtolower($_POST["username"]));
$pin      = test_input(strtolower($_POST['pin']));
if (!validUsername($pin, true) || $username == $pin) 
  {
    die('{"error":"Already following"}');
  }
$settings__ = getSettings();
$go_cpost   = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "1"; //
if ($go_cpost == "1" && !go_page($pin)) 
  {
    die('{"error":"Currently not allowed"}');
  }
else if ($go_cpost == "2" && !userVerified($pin)) 
  {
    die('{"error":"Currently not allowed"}');
  }
$max_follow = 500;
require ('../../oc-includes/server.php');
$table       = _TABLE_SOCIAL_FOLLOWERS_;
$table_users = _TABLE_USERS_;
//GET TOTAL FOLLOWING/CHECK IF ALREADY FOLLOWING
$stmt        = $conn->prepare("SELECT U.total_following, F.follower FROM $table_users AS U
LEFT JOIN $table AS F ON( U.username=F.follower AND F.following=?)
WHERE U.username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param("ss", $pin, $username) || !$stmt->execute()) 
  {
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    $conn->close();
    die('{"error":"Please try again"}');
  }
$row             = $res->fetch_assoc();
$total_following = $row["total_following"];
$following       = $row["follower"];
if ($following) 
  {
    $conn->close();
    die('{"status":"success","result":"Following"}');
  }
else if ($total_following >= _MAX_FOLLOWING_) 
  {
    $conn->close();
    die('{"error":"You reached maximum number  you can follow."}');
  }
$stmt = $conn->prepare("INSERT $table( following, follower, date_time) VALUES(?,?,NOW() )");
if ($stmt && $stmt->bind_param('ss', $pin, $username) && $stmt->execute()) 
  {
    $stmt->close();
    try
      {
        $conn->query("UPDATE $table_users SET total_following=total_following+1 WHERE username='$username' LIMIT 1");
        $conn->query("UPDATE $table_users SET total_followers=total_followers+1 WHERE username='$pin' LIMIT 1");
      }
    catch(Exception $e) 
      {
        //Ignore
        
      }
    //NOTIFICATION
    require ('go-functions.php');
    $meta    = array();
    $meta["author"]         = $username;
    $meta["action"]         = "open";
    $meta["action_type"]         = "follow";
    $meta["action_id"]         = $username;
    try
      {
        $send_to = $pin;
        sendNotification($conn, $send_to, "@{$username}@ followed you", $meta, "force-send");
      }
    catch(Exception $e) 
      {
        // logIt( $e->getMessage());
        //Just Ignore
        
      }
    $conn->close();
    die('{"status":"success","result":"Following"}');
  }
$conn->close();
die('{"error":"Could not follow"}');
