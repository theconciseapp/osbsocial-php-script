<?php @ini_set('memory_limit', '72M');
@ini_set('upload_max_filesize', '36M');
@ini_set('post_max_size', '37M');
@ini_set('max_execution_time', 100);
@ini_set('max_input_time', 100);
require '../../oc-includes/bootstrap.php';
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}'); //invalid token
    
  }
else if (empty($_POST['username']) || !validUsername($_POST["username"], true) || empty($_POST["base64"])) 
  {
    die('{"error":"Missing parameters.","ecode":"52"}');
  }
$username        = test_input($_POST['username']);
$settings__      = getSettings();
$sadmin          = site_admin($username);
$enable_upload   = isset($settings__["enable_file_upload"]) ? $settings__["enable_file_upload"] : "YES";
$max_upload_size = isset($settings__["max_upload_size"]) ? (int)$settings__["max_upload_size"] : 5;
if (!$sadmin && $enable_upload != "YES") 
  {
    die('{"error":"Currently disabled"}');
  }
$enable_vid_doc = isset($settings__["go_allow_video"]) ? $settings__["go_allow_video"] : "YES";
$go_cpost       = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "1"; //1: Only admins, 2: Admins & Verified users, 3: Everyone
if ($go_cpost == "1" && !$sadmin) 
  {
    die('{"error":"Permission denied"}');
  }
else if ($go_cpost == "2" && !userVerified($username)) 
  {
    die('{"error":"Permission denied"}');
  }
require '../../oc-includes/chat_functions.php';
require 'go-functions.php';
define('__ALLOW__', '1');
if (empty($_POST['file_ext'])) 
  {
    die('{"error":"Unsupported file","ecode":"2"}'); //Unsupported file
    
  }
$file_type = strtolower($_POST['file_ext']);
if ($file_type == 'jpg') 
  {
    include ('upload-image.php');
  }
else if ($file_type == 'mp4') 
  {
    if (!site_admin($username) && $enable_vid_doc == "NO") 
      {
        die('{"error":"Video upload currently disabled","ecode":"54"}');
      }
    include ('upload-video.php');
  }
else
  {
    die('{"error":"Unsupported file.","ecode":"2"}');
  }
