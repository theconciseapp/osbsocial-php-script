<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['username']) || empty($_POST["post_by"]) || empty($_POST["fullname"]) || empty($_POST["true_author"]) || !isset($_POST["post"]) || empty($_POST["post_id"])) 
  {
    die('{"error":"Missing parameters"}');
  }
require ('go-functions.php');
$version      = test_input($_POST['version']);
$username     = test_input(strtolower($_POST['username']));
$fullname     = test_input(strtolower($_POST['fullname']));
$true_author  = test_input(strtolower($_POST['true_author']));
$post_id      = test_input($_POST['post_id']);
$post         = $post_preview = "";
if (isset($_POST["post"]) && $plen         = strlen($_POST["post"])) 
  {
    if ($plen > 10240) 
      {
        die('{"error":"Post exceed limit: 10kb"}');
      }
    $post         = format_post($_POST["post"]);
  }
$settings__   = getSettings();
$admin        = site_admin($username);
$epost_title  = isset($sJson["enable_post_title"]) ? $sJson["enable_post_title"] : "NO";
$post_preview = mb_substr($post, 0, 250, 'utf-8');
$post_title   = $meta         = $post_files   = "";
if (!empty($_POST["post_meta"])) 
  {
    $meta         = htmlspecialchars(trim($_POST['post_meta']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
    $meta         = str_replace("&lt;br&gt;", "<br>", $meta);
    $meta         = str_replace("&amp;", "&", $meta);
  }
if (!empty($_POST["post_files"])) 
  {
    $post_files   = htmlspecialchars(trim($_POST['post_files']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
    $post_files   = str_replace("&lt;br&gt;", "<br>", $post_files);
    $post_files   = str_replace("&amp;", "&", $post_files);
  }
if (isset($_POST["post_title"])) 
  {
    $post_title   = test_input(mb_substr($_POST["post_title"], 0, 150, "utf-8"));
  }
if ($admin && go_page($_POST['post_by']) && $username == $true_author) 
  {
    //If admin, if is page, if this admin is the author
    $post_by      = test_input(strtolower($_POST['post_by']));
  }
else
  {
    $post_by      = $username;
  }
require ('../../oc-includes/server.php');
$table  = _TABLE_SOCIAL_POSTS_;
$result = array();
$stmt   = $conn->prepare("UPDATE $table SET post_title=?, post=?, post_preview=?, post_files=?, post_meta=? WHERE id=? AND post_by=? LIMIT 1");
if ($stmt && $stmt->bind_param('sssssis', $post_title, $post, $post_preview, $post_files, $meta, $post_id, $post_by) && $stmt->execute()) 
  {
    $stmt->close();
    $conn->close();
    $result["status"] = "success";
    $result["result"] = "Post edited.";
    $result["post_preview"] = $post_preview;
    $result["settings"] = $settings__;
    die(json_encode($result));
  }
$conn->close();
die('{"error":"Sending failed."}');
