<?php function format_comment($post = "") 
  {
    $post = htmlspecialchars(trim($post));
    return preg_replace('#&lt;(/?(?:br))&gt;#', '<\1>', $post);
  }
function add_comment($conn, $fullname, $post_id, $post_by, $author, $message, $post_files = "", $meta       = "", $version    = "1.0", $likes      = 0) 
  {
    $table      = _TABLE_PREFIX_ . "go_social_comments";
    $table_post = _TABLE_SOCIAL_POSTS_;
    $result     = $error      = 0;
    $likes      = (int)$likes;
    $status     = 1;
    try
      {
        $stmt       = $conn->prepare("INSERT INTO $table( post_id, post_by, comment_author, message, post_files, meta, likes, status, date_time)VALUES(?,?,?,?,?,?,?,?, NOW() )");
        if ($stmt && $stmt->bind_param('isssssii', $post_id, $post_by, $author, $message, $post_files, $meta, $likes, $status) && $stmt->execute()) 
          {
            $result     = mysqli_stmt_insert_id($stmt);
            $stmt->close();
            try
              {
                if ($stmt = $conn->prepare("UPDATE $table_post SET total_comments=total_comments+1 WHERE id=? LIMIT 1")) 
                  {
                    $stmt->bind_param('i', $post_id);
                    $stmt->execute();
                    $stmt->close();
                  }
              }
            catch(Exception $e) 
              {
                //Ignore
                
              }
          }
        else
          {
            $result = 0;
          }
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
        return 0;
      }
    return $result;
  }
function add_comment_reply($conn, $fullname, $post_id, $post_by, $parent_id, $author, $message, $post_files = "", $meta       = "", $version    = "1.0", $likes      = 0) 
  {
    $table      = _TABLE_PREFIX_ . "go_social_comments";
    $table_post = _TABLE_SOCIAL_POSTS_;
    $result     = $error      = 0;
    $likes      = (int)$likes;
    $status     = 1;
    try
      {
        $stmt       = $conn->prepare("INSERT INTO $table( post_id, parent_id, post_by, comment_author, message, post_files, meta, likes, status, date_time )VALUES(?,?,?,?,?,?,?,?,?, NOW() )");
        if ($stmt && $stmt->bind_param('iisssssii', $post_id, $parent_id, $post_by, $author, $message, $post_files, $meta, $likes, $status) && $stmt->execute()) 
          {
            $result     = mysqli_stmt_insert_id($stmt);
            $stmt->close();
            try
              {
                if ($stmt = $conn->prepare("UPDATE $table_post SET total_comments=total_comments+1 WHERE id=? LIMIT 1")) 
                  {
                    $stmt->bind_param('i', $post_id);
                    $stmt->execute();
                    $stmt->close();
                  }
                if ($stmt = $conn->prepare("UPDATE $table SET has_replies=has_replies+1 WHERE id=? LIMIT 1")) 
                  {
                    $stmt->bind_param('i', $parent_id);
                    $stmt->execute();
                    $stmt->close();
                  }
              }
            catch(Exception $e) 
              {
                //Ignore
                
              }
          }
        else
          {
            $result = 0;
          }
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
        return 0;
      }
    return $result;
  }
function delete_comment($conn, $cid, $post_id, $author   = "", $is_admin = "") 
  {
    $table    = _TABLE_PREFIX_ . "go_social_comments";
    if (!empty($is_admin)) 
      {
        $stmt     = $conn->prepare("DELETE FROM $table WHERE id=? LIMIT 1");
        if ($stmt && $stmt->bind_param('i', $cid) && $stmt->execute()) 
          {
            $stmt->close();
            return true;
          }
      }
    else
      {
        $stmt     = $conn->prepare("DELETE FROM $table WHERE id=? AND comment_author=? LIMIT 1");
        if ($stmt && $stmt->bind_param('is', $cid, $author) && $stmt->execute()) 
          {
            $aff_rows = $stmt->affected_rows;
            $stmt->close();
            if ($aff_rows > 0) 
              {
                $table_post = _TABLE_SOCIAL_POSTS_;
                try
                  {
                    if ($stmt       = $conn->prepare("UPDATE $table_post SET total_comments=total_comments-1 WHERE id=? LIMIT 1")) 
                      {
                        $stmt->bind_param('i', $post_id);
                        $stmt->execute();
                        $stmt->close();
                      }
                  }
                catch(Exception $e) 
                  {
                    //ignore
                    // logIt($e->getMessage());
                    
                  }
              }
            return true;
          }
      }
    return false;
  }
function fetch_comments($conn, $post_id, $post_by, $username) 
  {
    $table            = _TABLE_PREFIX_ . "go_social_comments";
    $ftable           = _TABLE_SOCIAL_FOLLOWERS_;
    $result           = $data             = array();
    if (!empty($_GET["page"])) 
      {
        $page_number      = (int)$_GET["page"];
      }
    else
      {
        $page_number      = 1;
      }
    $item_per_page    = 10;
    $item_per_page_ex = $item_per_page + 1;
    $previous_page    = 0;
    $next_page        = 0;
    $page_position    = (($page_number - 1) * $item_per_page);
    $table_users      = _TABLE_USERS_;
    $stmt             = $conn->prepare("SELECT C.has_replies, U.fullname, C.id, C.post_id, C.comment_author, C.message, C.post_files, C.meta, C.likes, C.date_time FROM $table AS C 
INNER JOIN {$table_users} AS U ON (C.comment_author=U.username) 
 WHERE 
C.post_id=? AND C.parent_id=0 AND C.status='1' ORDER BY C.id DESC LIMIT $page_position, $item_per_page_ex");
    if ($stmt && $stmt->bind_param('i', $post_id) && $stmt->execute()) 
      {
        $res              = $stmt->get_result();
        $stmt->close();
        $total         = $res->num_rows;
        $total_to_send = $total;
        if ($total < 1) 
          {
            $result["no_comment"]               = "No comment yet.";
          }
        else
          {
            if ($page_number > 1) 
              {
                $previous_page = $page_number - 1;
              }
            if ($total > $item_per_page) 
              {
                $next_page     = $page_number + 1;
                $total_to_send = $item_per_page;
              }
            $i             = 0;
            while ($row           = $res->fetch_assoc()) 
              {
                $i++;
                if ($i <= $total_to_send) 
                  {
                    $data[]               = $row;
                  }
              }
            $result["result"]               = $data;
            $result["post_id"]               = $post_id;
            $result["prev_page"]               = $previous_page;
            $result["next_page"]               = $next_page;
            $result["item_per_page"]               = $item_per_page;
            $result["status"]               = "success";
          }
      }
    return $result;
  }
function fetch_replies($conn, $parent_id, $post_by, $username) 
  {
    $table            = _TABLE_PREFIX_ . "go_social_comments";
    $ftable           = _TABLE_SOCIAL_FOLLOWERS_;
    $result           = $data             = array();
    if (!empty($_GET["page"])) 
      {
        $page_number      = (int)$_GET["page"];
      }
    else
      {
        $page_number      = 1;
      }
    $item_per_page    = 10;
    $item_per_page_ex = $item_per_page + 1;
    $previous_page    = 0;
    $next_page        = 0;
    $page_position    = (($page_number - 1) * $item_per_page);
    $table_users      = _TABLE_USERS_;
    $stmt             = $conn->prepare("SELECT U.fullname, C.id, C.post_id, C.comment_author, C.message, C.post_files, C.meta, C.likes, C.date_time FROM $table AS C 
INNER JOIN {$table_users} AS U ON ( C.comment_author=U.username ) 
WHERE C.parent_id=? AND C.status='1' ORDER BY C.id DESC LIMIT $page_position, $item_per_page_ex");
    if ($stmt && $stmt->bind_param('i', $parent_id) && $stmt->execute()) 
      {
        $res              = $stmt->get_result();
        $stmt->close();
        $total         = $res->num_rows;
        $total_to_send = $total;
        if ($total < 1) 
          {
            $result["no_comment"]               = "No replies yet.";
          }
        else
          {
            if ($page_number > 1) 
              {
                $previous_page = $page_number - 1;
              }
            if ($total > $item_per_page) 
              {
                $next_page     = $page_number + 1;
                $total_to_send = $item_per_page;
              }
            $i             = 0;
            while ($row           = $res->fetch_assoc()) 
              {
                $i++;
                if ($i <= $total_to_send) 
                  {
                    $data[]               = $row;
                  }
              }
            $result["result"]               = $data;
            $result["parent_id"]               = $parent_id;
            $result["prev_page"]               = $previous_page;
            $result["next_page"]               = $next_page;
            $result["item_per_page"]               = $item_per_page;
            $result["status"]               = "success";
          }
      }
    return $result;
  }
