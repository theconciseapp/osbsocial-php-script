<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['username']) || empty($_POST["fullname"]) || empty($_POST["post_id"]) || empty($_POST["share_pid"]) || empty($_POST["notify"]) || empty($_POST["version"])) 
  {
    die('{"error":"Missing parameters."}');
  }
$version         = test_input($_POST['version']);
$adm             = site_admin($_POST["username"]);
if ($adm && validUsername($_POST["post_by"])) 
  {
    $username        = test_input(strtolower($_POST['post_by']));
  }
else
  {
    $username        = test_input(strtolower($_POST['username']));
  }
$sharer_username = test_input(strtolower($_POST['username']));
$fullname        = test_input($_POST['fullname']);
$post_id         = test_input($_POST['post_id']);
$spid            = test_input($_POST['share_pid']);
$notify          = test_input(strtolower($_POST['notify']));
$settings__      = getSettings();
$allow_share     = isset($settings__["go_allow_share"]) ? $settings__["go_allow_share"] : "YES"; //
$can_post        = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "YES"; //
if (!$adm && $allow_share == "NO") 
  {
    die('{"error":"Disabled"}');
  }
else if (!$adm && $can_post == "1") 
  {
    die('{"error":"Not allowed"}');
  }
else if ($can_post == "2" && !userVerified($sharer_username)) 
  {
    die('{"error":"Permission denied"}');
  }
$go_approve_post = isset($settings__["go_auto_approve_post"]) ? $settings__["go_auto_approve_post"] : "1";
if ($adm) 
  {
    $go_approve_post = "1";
  }
require ('../../oc-includes/server.php');
require ('go-functions.php');
$table  = _TABLE_SOCIAL_POSTS_;
$result = array();
$stmt   = $conn->prepare("SELECT*FROM $table WHERE id=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('i', $spid) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Please try again"}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    die('{"error":"Post not found"}');
  }
$row   = $res->fetch_assoc();
$pd    = $row["post_date"];
$pb    = $row["post_by"];
$pt    = $row["post_title"];
$pprev = $row["post_preview"];
$ppf   = $row["post_files"];
$pm    = $row["post_meta"];
$pm    = json_decode($pm, true);
if (!$pm) 
  {
    die('{"error":"Post deleted or not found"}');
  }
$p           = $post_title  = $pp          = "";
$ptime       = time();
$post_bg     = "";
$commentable = $shareable   = 0;
if (!empty($_POST["post_bg"])) 
  {
    $post_bg     = test_input($_POST["post_bg"]);
  }
if (!empty($_POST["commentable"])) 
  {
    $commentable = (int)$_POST["commentable"];
  }
if (!empty($_POST["shareable"])) 
  {
    $shareable   = (int)$_POST["shareable"];
  }
if (isset($_POST["post"]) && $plen        = strlen($_POST["post"])) 
  {
    if ($plen > 10240) 
      {
        die('{"error":"Post too long. limit: 10kb"}');
      }
    $p           = format_post($_POST["post"]);
    $pp          = mb_substr($p, 0, 250, 'utf-8');
  }
if (!empty($_POST["post_title"])) 
  {
    $post_title  = test_input(mb_substr($_POST["post_title"], 0, 150, "utf-8"));
  }
if ($pb == 'cv_drafts') 
  {
    //IF POST IS FROM DRAFT, IT SHOULD POSTED AS THE PERSON DOING THE REPOST.
    $append      = "";
    if (!empty($p)) 
      {
        //Post can add more post to draft
        $append      = "\n" . $p;
      }
    $p           = $row["post"] . $append;
    if (empty($post_title)) 
      {
        $post_title  = $pt;
      }
    $pp          = mb_substr($p, 0, 250, 'utf-8');
    $pm["true_author"]             = $sharer_username; //$username;
    $pm["post_owner"]             = $username;
    $pm["pbf"]             = $fullname;
    $pm["post_time"]             = $ptime;
    $pm["post_bg"]             = $post_bg;
    if (!empty($pm["post_bg"])) 
      {
        $pm["post_bg"]             = $pm["post_bg"];
      }
    $pm["commentable"]             = $commentable;
    $pm["shareable"]             = $shareable;
  }
else
  {
    $pm["repost"]             = true;
    $pm["otrue_author"]             = $pm["true_author"];
    $pm["true_author"]             = $sharer_username; //$username;
    $pm["opost_owner"]             = $pb;
    $pm["opbf"]             = $pm["pbf"];
    $pm["pbf"]             = $fullname;
    $pm["opost_time"]             = $pd; //Original post time
    $pm["optitle"]             = $pt;
    $pm["opost_preview"]             = mb_substr($pprev, 0, 120);
    $pm["opost_id"]             = $spid;
    $pm["opost_bg"]             = "";
    if (isset($pm["post_bg"])) 
      {
        $pm["opost_bg"]             = $pm["post_bg"];
      }
    $pm["post_bg"]             = $post_bg;
    $pm["commentable"]             = $commentable;
    $pm["shareable"]             = $shareable;
  }
$pmeta       = json_encode($pm);
$rstring     = randomString(10);
if (!empty($post_title)) 
  {
    $slug_title  = mb_substr($post_title, 0, 150, "utf-8");
  }
else if (!empty($pp)) 
  {
    $slug_title  = mb_substr($pp, 0, 150, "utf-8");
  }
else
  {
    $slug_title  = $rstring;
  }
$slug_title  = slugify($slug_title, "-", $rstring);
if (slugExists($conn, $slug_title)) 
  {
    $slug_title  = $slug_title . "-" . $rstring;
  }
$stmt        = $conn->prepare("INSERT INTO $table ( post_date, post_by, post_title, post_name, post, post_preview, post_files, post_meta, post_status, date_time)  VALUES( ?,?,?,?,?,?,?,?,?, NOW() )");
if ($stmt && $stmt->bind_param('isssssssi', $ptime, $username, $post_title, $slug_title, $p, $pp, $ppf, $pmeta, $go_approve_post) && $stmt->execute()) 
  {
    $stmt->close();
    try
      {
        $stmt = $conn->prepare("UPDATE $table  SET total_shares=total_shares+1 WHERE id=? LIMIT 1");
        $stmt->bind_param('i', $post_id);
        $stmt->execute();
        $stmt->close();
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
      }
    //NOTIFICATION
    if ($notify != $username && $notify != 'cv_drafts') 
      {
        $meta    = array();
        $meta["author"]         = $username;
        $meta["contributors"]         = "";
        $meta["action"]         = "open";
        $meta["action_type"]         = "post";
        $meta["action_id"]         = $post_id;
        $excerpt = str_replace('@', '&#64;', mb_substr($pprev, 0, 30));
        try
          {
            $send_to = $notify;
            sendNotification($conn, $send_to, "@{$fullname}@ shared your post\"{$excerpt}...\"", $meta);
          }
        catch(Exception $e) 
          {
            // logIt( $e->getMessage());
            //Just Ignore
            
          }
      }
    $conn->close();
    $result["status"] = "success";
    if ($go_approve_post == "0") 
      {
        $result["awaiting_approval"] = "Awaiting approval";
      }
    $result["result"] = $row;
    $result["settings"] = $settings__;
    die(json_encode($result));
  }
$conn->close();
die('{"error":"Repost failed."}');
