<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES" && empty($_POST["username"])) 
  {
    $_POST["username"] = "anonymous";
  }
if (empty($_POST['fullname']) || empty($_POST['post_id']) || empty($_POST['post_by']) || empty($_POST['comment_by']) || empty($_POST['comment_id']) || empty($_POST['type']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input($_POST['username']);
$post_id  = test_input($_POST['post_id']);
$fullname = test_input($_POST['fullname']);
$post_by  = test_input($_POST['post_by']);
$cby      = test_input(strtolower($_POST['comment_by']));
$cid      = test_input($_POST['comment_id']);
$type     = test_input($_POST['type']);
$version  = test_input($_POST['version']);
require ('../../oc-includes/server.php');
require ('go-functions.php');
$table = _TABLE_PREFIX_ . "go_social_comments";
$liked = false;
try
  {
    if ($type == 1) 
      {
        $liked = true;
        $stmt  = $conn->prepare("UPDATE $table SET likes=likes+1 WHERE id=? LIMIT 1");
      }
    else
      {
        $stmt  = $conn->prepare("UPDATE $table SET likes=likes-1 WHERE id=? LIMIT 1");
      }
    if ($stmt && $stmt->bind_param('i', $cid) && $stmt->execute()) 
      {
        $stmt->close();
        if ($liked && $cby != $username) 
          {
            $meta      = array();
            $meta["author"]           = $username;
            $meta["action_id"]           = $post_id;
            $meta["action"]           = "open";
            $meta["action_type"]           = "post";
            if (!empty($_POST['parent_id'])) 
              {
                $parent_id = test_input($_POST['parent_id']);
                $meta["action_type"]           = "comment-reply";
                $meta["action_id_2"]           = $parent_id;
                $meta["post_by"]           = $post_by;
              }
            sendNotification($conn, $cby, "@{$fullname}@ liked your comment.", $meta);
          }
        $conn->close();
        die('{"status":"success"}');
      }
  }
catch(Exception $e) 
  {
    logIt($e->getMessage());
  }
$conn->close();
die('{"error":"Failed to alter."}');
