<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['username']) || !isset($_POST["last_check_nid"])) 
  {
    die('{"error":"Missing parameters"}');
  }
$time     = time();
$username = test_input($_POST["username"]);
require ('../../oc-includes/server.php');
$table   = _TABLE_SOCIAL_NOTIFICATIONS_;
if ($_POST["last_check_nid"] == "fresh") 
  {
    //  $last_check = $time;
    $nresult = mysqli_query($conn, "SELECT id FROM $table ORDER BY id DESC LIMIT 1");
    if (!$nresult) 
      {
        $conn->close();
        die('{"error":"Could not get last NID"}');
      }
    $nrow    = mysqli_fetch_row($nresult);
    $lastnid = array(
        "fresh_nid" => 1,
        "last_nid" => (!empty($nrow[0]) ? $nrow[0] : 0)
    );
    die(json_encode($lastnid));
  }
$results    = array(
    "server_time"            => $time
);
$last_check = (int)$_POST["last_check_nid"];
$stmt       = $conn->prepare("SELECT id, message_time,  message, meta FROM {$table} WHERE id>? AND  ( message_to=? OR message_to='general' ) 
ORDER BY id ASC LIMIT 5");
if (!$stmt || !$stmt->bind_param('is', $last_check, $username) || !$stmt->execute()) 
  {
    $conn->close();
    $results["error"] = "Server fault.";
    die(json_encode($results));
  }
$res = $stmt->get_result();
$conn->close();
$stmt->close();
if ($res->num_rows < 1) 
  {
    $results["no_noti"] = 1;
    die(json_encode($results));
  }
$result = array();
while ($row    = $res->fetch_assoc()) 
  {
    $result[]        = $row;
  }
$results["status"]        = "success";
$results["result"]        = $result;
die(json_encode($results));
