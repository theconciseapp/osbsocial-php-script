<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['post_by']) || empty($_POST["fullname"])) 
  {
    die('{"error":"Missing parameters."}');
  }
if (empty($_POST["has_files"]) && !isset($_POST["post"])) 
  {
    die('{"error":"Post is empty."}');
  }
require ('go-functions.php');
$version    = test_input($_POST['version']);
$username_  = $_POST['username'];
if (go_admin($username_) && validUsername($_POST["post_by"])) 
  {
    $username   = test_input(strtolower($_POST['post_by']));
  }
else
  {
    $username   = test_input(strtolower($username_));
  }
$settings__ = getSettings();
$go_cpost   = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "1"; //1: Only admins, 2: Admins & Verified users, 3: Everyone
if ($go_cpost == "1" && !site_admin($username_)) 
  {
    die('{"error":"Permission denied"}');
  }
else if ($go_cpost == "2" && !userVerified($username_)) 
  {
    die('{"error":"Permission denied"}');
  }
$go_approve_post = isset($settings__["go_auto_approve_post"]) ? $settings__["go_auto_approve_post"] : "1";
if (go_admin($username_)) 
  {
    $go_approve_post = "1";
  }
$fullname        = test_input($_POST['fullname']);
$meta            = $post            = $post_preview    = "";
if (isset($_POST["post"]) && $plen            = strlen($_POST["post"])) 
  {
    if ($plen > 20480) 
      {
        die('{"error":"Post too long. limit: 20kb"}');
      }
    $post            = format_post($_POST["post"]);
    $post_preview    = mb_substr($post, 0, 250, "utf-8");
  }
$post_title      = $meta            = $post_files      = "";
if (!empty($_POST["post_meta"])) 
  {
    $meta            = htmlspecialchars(trim($_POST['post_meta']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
  }
if (!empty($_POST["post_files"])) 
  {
    $post_files      = htmlspecialchars(trim($_POST['post_files']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
  }
if (!empty($_POST["post_title"])) 
  {
    $post_title      = test_input(mb_substr($_POST["post_title"], 0, 150, "utf-8"));
  }
$ptime           = time();
$rstring         = randomString(10);
require ('../../oc-includes/server.php');
if (!empty($post_title)) 
  {
    $slug_title = mb_substr($post_title, 0, 150, "utf-8");
  }
else if (!empty($post_preview)) 
  {
    $slug_title = mb_substr($post_preview, 0, 150, "utf-8");
  }
else
  {
    $slug_title = $rstring;
  }
$slug_title = slugify($slug_title, "-", $rstring);
if (slugExists($conn, $slug_title)) 
  {
    $slug_title = $slug_title . "-" . $rstring;
  }
//(microtime(true) * 10000);
$table      = _TABLE_SOCIAL_POSTS_;
$result     = array();
$stmt       = $conn->prepare("INSERT INTO $table ( post_date, post_by, post_title,  post, post_preview, post_files, post_meta, post_name, post_status, date_time)  VALUES(?,?,?,?,?,?,?,?,?, NOW() )");
if ($stmt && $stmt->bind_param('isssssssi', $ptime, $username, $post_title, $post, $post_preview, $post_files, $meta, $slug_title, $go_approve_post) && $stmt->execute()) 
  {
    $stmt->close();
    $result["status"] = "success";
    if ($go_approve_post == "1") 
      {
        $result["result"] = "Uploading your post";
      }
    else
      {
        $result["result"] = "Awaiting approval";
      }
    $result["id"] = mysqli_insert_id($conn);
    $result["settings"] = $settings__;
    die(json_encode($result));
  }
die('{"error":"Sending failed."}');
