<?php function home_posts() 
  {
    $settings__  = getSettings();
    $force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
    if ($force_login != "NO" && !verifyToken()) 
      {
        return array(
            "error" => "Invalid security token.",
            "ecode" => "-1"
        );
      }
    if ($force_login != "YES" && empty($_POST["username"])) 
      {
        $_POST["username"] = "anonymous";
      }
    if (empty($_POST["username"]) || !isset($_POST["load_count"])) 
      {
        return array(
            "error"            => "Missing parameters"
        );
      }
    $load_count = (int)$_POST["load_count"];
    $username   = test_input($_POST["username"]);
    require (_PROJECT_DIR_ . "/oc-includes/server.php");
    $time             = time();
    $item_per_page    = isset($settings__["go_ppl"]) ? $settings__["go_ppl"] : "5"; //
    $go_cpost         = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "1"; //1: Only admins, 2: Admins & Verified users, 3: Everyone
    $post_order       = isset($settings__["go_posts_order"]) ? $settings__["go_posts_order"] : "DESC";
    if (!empty($_POST['post_order'])) 
      {
        $porder           = preg_replace("/[^A-Z]+$/", "", $_POST['post_order']);
        if ($porder == 'DESC' || $porder == 'ASC') 
          {
            $post_order       = $porder;
          }
      }
    $go_follow_btn    = isset($settings__["go_enable_follow_btn"]) ? $settings__["go_enable_follow_btn"] : "YES";
    $go_pymk          = isset($settings__["go_suggest_pymk"]) ? $settings__["go_suggest_pymk"] : "1"; //People you may know
    $go_homepage      = isset($settings__["go_homepage_posts"]) ? $settings__["go_homepage_posts"] : "1"; //1: Latest posts, 0: Static page enabled
    $go_static_page   = isset($settings__["go_static_page"]) ? $settings__["go_static_page"] : "";
    if ($go_homepage == "0" && !empty($go_static_page)) 
      {
        $posts            = loadPagePosts($conn, $username, $go_static_page, $go_follow_btn, $post_order, $item_per_page);
      }
    else
      {
        $posts            = loadPosts($conn, $username, $go_follow_btn, $post_order, $item_per_page);
      }
    $pymk_            = array();
    if ($load_count === 0) 
      {
        if ($go_pymk == "1") 
          {
            $pymk_            = pymk($conn, $username, 10, $go_cpost, $go_homepage);
          }
      }
    $sidebar_         = $sponsored_posts_ = array();
    if ($load_count === 0) 
      {
        $sidebar_         = loadSidebarPages($conn);
      }
    if ($load_count === 0) 
      {
        $sponsored_posts_ = sponsored_posts($conn);
      }
    $posts["pymk"]                  = $pymk_;
    $posts["sidebar_pages"]                  = $sidebar_;
    $posts["sponsored_posts"]                  = $sponsored_posts_;
    $posts["server_time"]                  = $time;
    $posts["settings"]                  = $settings__;
    $conn->close();
    return $posts;
  }
function loadPosts($conn, $username, $follow_btn       = "YES", $post_order       = "DESC", $item_per_page    = 5) 
  {
    $result           = $final_result     = array();
    $single_post      = "";
    $role             = "AND U.role='5'";
    if (!empty($_POST["post_id"]) && preg_match("/^[a-z0-9-]+$/i", $_POST["post_id"])) 
      {
        $pid              = $_POST["post_id"];
        $role             = "";
        if (is_numeric($pid)) 
          {
            $single_post      = "AND P.id='$pid'";
          }
        else
          {
            $single_post      = "AND P.post_name='$pid' ";
          }
      }
    $table            = _TABLE_SOCIAL_POSTS_;
    if (!empty($_POST["page"])) 
      {
        $page_number      = (int)$_POST["page"];
      }
    else
      {
        $page_number      = 1;
      }
    $item_per_page_ex = $item_per_page + 1;
    $previous_page    = 0;
    $next_page        = 0;
    $page_position    = (($page_number - 1) * $item_per_page);
    $ftable           = _TABLE_SOCIAL_FOLLOWERS_;
    $table_users      = _TABLE_USERS_;
    if ($follow_btn === "YES") 
      {
        $stmt             = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, P.id, P.post_title, P.post_name, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status
FROM 
 {$table} AS P
INNER JOIN $table_users AS U ON P.post_by=U.username
LEFT JOIN $ftable AS F ON ( P.post_by=F.following AND F.follower=? AND F.status=1 ) 
WHERE ( P.post_by=? OR F.follower=? ) 
AND P.post_status=1 
$single_post
ORDER BY P.id $post_order 
LIMIT $page_position, $item_per_page_ex");
        if (!$stmt || !$stmt->bind_param('sss', $username, $username, $username) || !$stmt->execute()) 
          {
            $final_result["error"]                  = "Please try again";
            return $final_result;
          }
      }
    else
      {
        $stmt = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, P.id, P.post_title,P.post_name, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status
FROM 
 {$table} AS P
INNER JOIN $table_users AS U ON P.post_by=U.username
WHERE P.post_status=1 
$single_post
$role
ORDER BY P.id $post_order 
LIMIT $page_position, $item_per_page_ex");
        if (!$stmt || !$stmt->execute()) 
          {
            $final_result["error"]      = "Please try again";
            return $final_result;
          }
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total_posts   = $total_to_send = $res->num_rows;
    if ($total_posts < 1) 
      {
        $final_result["status"]               = "success";
        $final_result["no_post"]               = "No more posts";
        return $final_result;
      }
    if ($total_posts > $item_per_page) 
      {
        $next_page     = $page_number + 1;
        $total_to_send = $item_per_page;
      }
    $i             = 0;
    while ($row           = $res->fetch_assoc()) 
      {
        $i++;
        if ($i <= $total_to_send) 
          {
            $result[]               = $row;
          }
      }
    $final_result["status"]               = "success";
    $final_result["total_posts"]               = $total_posts;
    $final_result["next_page"]               = $next_page;
    $final_result["result"]               = $result;
    return $final_result;
  }
function loadPagePosts($conn, $username, $page             = "my_firstpage", $follow_btn, $post_order       = "DESC", $item_per_page    = 5) 
  {
    $result           = $final_result     = array();
    $table            = _TABLE_SOCIAL_POSTS_;
    $ftable           = _TABLE_SOCIAL_FOLLOWERS_;
    $table_users      = _TABLE_USERS_;
    if (!empty($_POST["page"])) 
      {
        $page_number      = (int)$_POST["page"];
      }
    else
      {
        $page_number      = 1;
      }
    $single_post      = "";
    if (!empty($_POST["post_id"]) && preg_match("/^[a-z0-9-]+$/i", $_POST["post_id"])) 
      {
        $pid              = $_POST["post_id"];
        if (is_numeric($pid)) 
          {
            $single_post      = "AND P.id='$pid'";
          }
        else
          {
            $single_post      = "AND P.post_name='$pid' ";
          }
      }
    $item_per_page_ex = $item_per_page + 1;
    $previous_page    = 0;
    $next_page        = 0;
    $page_position    = (($page_number - 1) * $item_per_page);
    if (!empty($single_post)) 
      {
        $stmt             = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, P.id, P.post_title, P.post_name, P.post_date, P.post_by, P.post_preview,   P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status
FROM 
 {$table} AS P
INNER JOIN $table_users AS U ON P.post_by=U.username
WHERE P.post_status=1
$single_post
ORDER BY P.id $post_order 
LIMIT 1");
        if (!$stmt || !$stmt->execute()) 
          {
            $final_result["error"]                  = "Please try again";
            return $final_result;
          }
      }
    else if ($follow_btn == "YES") 
      {
        $stmt = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, P.id, P.post_title, P.post_name, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status
FROM 
 {$table} AS P
INNER JOIN {$table_users} AS U ON ( P.post_by=U.username )
LEFT JOIN {$ftable} AS F ON ( P.post_by=F.following AND F.follower=? AND F.status=1 ) 
WHERE ( P.post_by=? OR F.follower=?  )
AND P.post_status=1 
AND U.role=5 
 $single_post
ORDER BY P.id $post_order 
LIMIT $page_position, $item_per_page_ex");
        if (!$stmt || !$stmt->bind_param('sss', $username, $page, $username) || !$stmt->execute()) 
          {
            $final_result["error"]      = "Please try again";
            return $final_result;
          }
      }
    else
      {
        $stmt = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, P.id, P.post_title, P.post_name, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status
FROM 
 {$table} AS P
INNER JOIN $table_users AS U ON P.post_by=U.username

WHERE  P.post_by=? AND P.post_status=1
 $single_post 
ORDER BY P.id $post_order 
LIMIT $page_position, $item_per_page_ex");
        if (!$stmt || !$stmt->bind_param('s', $page) || !$stmt->execute()) 
          {
            $final_result["error"]      = "Please try again";
            return $final_result;
          }
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total_posts   = $total_to_send = $res->num_rows;
    if ($total_posts < 1) 
      {
        $final_result["status"]               = "success";
        $final_result["no_post"]               = "No more posts";
        return $final_result;
      }
    if ($total_posts > $item_per_page) 
      {
        $next_page     = $page_number + 1;
        $total_to_send = $item_per_page;
      }
    $i             = 0;
    while ($row           = $res->fetch_assoc()) 
      {
        $i++;
        if ($i <= $total_to_send) 
          {
            $result[]               = $row;
          }
      }
    $final_result["status"]               = "success";
    $final_result["total_posts"]               = $total_posts;
    $final_result["next_page"]               = $next_page;
    $final_result["result"]               = $result;
    return $final_result;
  }
function pymk($conn, $username, $limit    = 10, $go_cpost = 1, $homepage = 1) 
  {
    //If $homepage==0, then it's a static page
    $table    = _TABLE_USERS_;
    $ftable   = _TABLE_SOCIAL_FOLLOWERS_;
    $result   = $results  = array();
    if ($homepage != 1) 
      {
        $role     = "U.role=5";
      }
    else if ($go_cpost == "1") 
      {
        $role     = "U.role=5";
      }
    else if ($go_cpost == "2") 
      {
        $role     = "U.role IN(4,5)";
      }
    else
      {
        $role     = "U.role IN(3,4,5)";
      }
    $stmt     = $conn->prepare("SELECT U.username, U.fullname FROM $table AS U WHERE U.username NOT IN ( SELECT following FROM $ftable WHERE follower= ?)  
AND {$role} ORDER BY RAND() LIMIT $limit");
    if (!$stmt || !$stmt->bind_param('s', $username) || !$stmt->execute()) 
      {
        $result["error"]          = "Server fault";
        return $result;
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total = $res->num_rows;
    if ($total < 1) 
      {
        return $result;
      }
    while ($row = $res->fetch_assoc()) 
      {
        $results[]     = $row;
      }
    $result["status"]     = "success";
    $result["total"]     = $total;
    $result["data"]     = $results;
    return $result;
  }
function loadSidebarPages($conn) 
  {
    $table   = _TABLE_USERS_;
    $result  = $results = array();
    $stmt    = $conn->prepare("SELECT username, fullname FROM $table WHERE role=6 ORDER BY fullname ASC");
    if (!$stmt || !$stmt->execute()) 
      {
        $result["error"]         = "Server fault";
        return $result;
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total = $res->num_rows;
    if ($total < 1) 
      {
        return $result;
      }
    //$exception=array("cv_drafts","cv_sponsoredposts");
    while ($row = $res->fetch_assoc()) 
      {
        //  if(  !in_array($row["username"], $exception) ){
        $results[]     = $row;
        /*  }
        else{
        
        $total--;
        
        }
        */
      }
    $result["status"]     = "success";
    $result["total"]     = $total;
    $result["data"]     = $results;
    return $result;
  }
function format_post($post = "") 
  {
    $post = htmlspecialchars(trim($post));
    return preg_replace("/(\r?\n){2,}/", "\n\n", $post);
  }
function sponsored_posts($conn) 
  {
    $user         = "cv_sponsoredposts";
    $result       = $final_result = array();
    $table_users  = _TABLE_USERS_;
    $table        = _TABLE_SOCIAL_POSTS_;
    $stmt         = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, U.total_following, U.total_followers, P.*
FROM $table_users AS U 
LEFT JOIN $table AS P ON ( U.username=P.post_by )
WHERE P.post_by=?
ORDER BY RAND() LIMIT 10");
    if (!$stmt || !$stmt->bind_param('s', $user) || !$stmt->execute()) 
      {
        $final_result["error"]              = "Something went wrong";
        return $final_result;
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total_posts   = $total_to_send = $res->num_rows;
    if ($total_posts < 1) 
      {
        $final_result["no_post"]               = "No sponsored post yet";
        return $final_result;
      }
    $i   = 0;
    while ($row = $res->fetch_assoc()) 
      {
        $result[]     = $row;
      }
    $final_result["status"]     = "success";
    $final_result["sponsored_post"]     = 1;
    $final_result["total_posts"]     = $total_posts;
    $final_result["result"]     = $result;
    return $final_result;
  }
function sendNotification($conn, $message_to, $message = "", $meta    = array() , $force   = false) 
  {
    $rand    = rand(0, 5);
    if (!$force && $rand < 3) return "";
    if (empty($message_to) || empty($message)) 
      {
        return "";
      }
    $message = str_replace("??", "", $message);
    $mtime   = time();
    $version = _SITE_VERSION_;
    $mdata   = array();
    if (!empty($meta)) 
      {
        $mdata   = array_merge($mdata, $meta);
      }
    $mdata["time"]         = $mtime;
    $mdata["status"]         = "??";
    $mdata["sver"]         = $version;
    $meta    = json_encode($mdata);
    $table   = _TABLE_SOCIAL_NOTIFICATIONS_;
    $stmt    = $conn->prepare("INSERT INTO {$table}( message_time, message_to, message, meta, date_time) VALUES (?,?,?,?, NOW() )");
    if ($stmt && $stmt->bind_param('isss', $mtime, $message_to, $message, $meta) && $stmt->execute()) 
      {
        $stmt->close();
        return true;
      }
    else
      {
        return false;
      }
  }
function uploadBase64Image($save_to, $file_data, $folder, $dir, $filename) 
  {
    $f                    = finfo_open();
    $mime_type            = finfo_buffer($f, $file_data, FILEINFO_MIME_TYPE);
    $file_type            = explode('/', $mime_type) [0];
    $extension            = explode('/', $mime_type) [1];
    $acceptable_mimetypes = allowedImages();
    if (in_array($mime_type, $acceptable_mimetypes)) 
      {
        if ($file_data === false) 
          {
            die('{"error":"Upload failed.","ecode":"00"}'); //Failed
            
          }
        if ($result    = masterImageUpload($file_data, $filename, ["folder"           => $folder, "dir"           => $dir])) 
          {
            $file_size = filesize($result["saved_to"]);
            $width     = $result["width"];
            $height    = $result["height"];
            $file_path = $result["file_path"] . "?ocwh={$width}_{$height}";
            $folder    = $result["folder"];
            die('{"status":"success","file_size":"' . $file_size . '","file_folder":"' . $folder . '","file_path":"' . $file_path . '","ext":"jpg","width":"' . $width . '","height":"' . $height . '"}'); //Successful
            
          }
        else die('{"error":"Upload failed.","ecode":"00"}'); //Failed
        
      }
    else
      {
        die('{"error":"Unsupported file.","ecode":"2"}'); //Unsupported
        
      }
    die('{"error":"Upload failed.","ecode":"00"}'); //Failed
    
  }
function uploadBase64Video($save_to, $file_data, $folder, $filename, $poster, $vwidth               = 500, $vheight              = 250) 
  {
    $f                    = finfo_open();
    $mime_type            = finfo_buffer($f, $file_data, FILEINFO_MIME_TYPE);
    $file_type            = explode('/', $mime_type) [0];
    $extension            = explode('/', $mime_type) [1];
    $acceptable_mimetypes = allowedVideos();
    if (in_array($mime_type, $acceptable_mimetypes)) 
      {
        if (file_put_contents($save_to, $file_data)) 
          {
            $file_size            = filesize($save_to);
            $file_path            = _CHAT_FILES_PATH_ . "/{$folder}/{$filename}.mp4?ocwh={$vwidth}_{$vheight}";
            die('{"status":"success","file_size":"' . $file_size . '","file_folder":"' . $folder . '","file_path":"' . $file_path . '","ext":"mp4","poster":"' . $poster . '","width":' . $vwidth . ',"height":' . $vheight . '}'); //Successful
            
          }
        else die('{"error":"Upload Failed.","ecode":"00"}'); //Failed
        
      }
    else
      {
        die('{"error":"File unsupported","ecode":"2"}'); //Unsupported
        
      }
    die('{"error":"Upload failed","ecode":"00"}'); //Failed
    
  }
