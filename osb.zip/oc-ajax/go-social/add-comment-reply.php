<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['post_id']) || empty($_POST['fullname']) || empty($_POST["post_by"]) || empty($_POST["parent_id"]) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
if (empty($_POST["has_files"]) && empty($_POST["message"])) 
  {
    die('{"error":"Comment is empty."}');
  }
require ('comment-functions.php');
require ('go-functions.php');
$author    = test_input(strtolower($_POST['username']));
$post_id   = test_input($_POST['post_id']);
$parent_id = test_input($_POST['parent_id']);
if (!is_numeric($parent_id)) 
  {
    die('{"error":"Number expected"}');
  }
$fullname   = test_input($_POST['fullname']);
$post_by    = test_input(strtolower($_POST['post_by']));
$meta       = $message    = $post_files = "";
if (!empty($_POST["message"])) 
  {
    $message    = format_comment($_POST["message"]);
  }
if (strlen($message) > 1124) 
  {
    die('{"error":"Make your comment short and concise."}');
  }
if (!empty($_POST["meta"])) 
  {
    $meta = htmlspecialchars($_POST["meta"], ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
  }
else if (strlen($meta) > 2048) 
  {
    die('{"error":"Excess comment meta."}');
  }
if (!empty($_POST["post_files"])) 
  {
    $post_files = htmlspecialchars($_POST["post_files"], ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');
  }
$version    = test_input($_POST['version']);
require ('../../oc-includes/server.php');
$force_notification = false;
$send_to            = $post_by;
$tagged_name        = "";
if (!empty($_POST['tagged']) && !empty($_POST['tagged_name'])) 
  {
    $force_notification = true;
    $send_to            = test_input($_POST["tagged"]);
    $tagged_name        = test_input($_POST["tagged_name"]);
  }
$result             = add_comment_reply($conn, $fullname, $post_id, $post_by, $parent_id, $author, $message, $post_files, $meta, $version);
if ($result) 
  {
    //Send notification
    if ($post_by != $author || !empty($tagged_name)) 
      {
        $meta               = array();
        $meta["author"]                    = $author;
        $meta["contributors"]                    = "";
        $meta["action"]                    = "open";
        $meta["action_type"]                    = "comment-reply";
        $meta["action_id"]                    = $post_id;
        $meta["action_id_2"]                    = $parent_id;
        $meta["post_by"]                    = $post_by;
        //Strip tag pattern i.e @[::...::]
        $pattern            = "/@\[::(.*?)::\]/";
        $notif_message      = preg_replace($pattern, "", $message);
        $rep                = array(
            '@',
            '<br>'
        );
        $repw               = array(
            '&#64;',
            ' '
        );
        $excerpt            = str_replace($rep, $repw, mb_substr(trim($notif_message) , 0, 60));
        sendNotification($conn, $send_to, "@{$fullname}@ replied \"{$excerpt}...\" on your comment.", $meta, $force_notification);
      }
    $conn->close();
    die('{"status":"success","result":"' . $result . '"}');
  }
$conn->close();
die('{"error":"Failed."}');
