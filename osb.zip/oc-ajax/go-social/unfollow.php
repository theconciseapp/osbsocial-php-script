<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['pin'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$result   = array();
$username = test_input($_POST["username"]);
$pin      = preg_replace("/[^a-zA-Z0-9 _-]/", "", test_input($_POST['pin']));
if (empty($pin)) 
  {
    die(json_encode($result));
  }
require ('../../oc-includes/server.php');
$table       = _TABLE_SOCIAL_FOLLOWERS_;
$table_users = _TABLE_USERS_;
$stmt        = $conn->prepare("DELETE FROM $table WHERE follower=? AND following=? LIMIT 1");
if ($stmt && $stmt->bind_param('ss', $username, $pin) && $stmt->execute()) 
  {
    try
      {
        $conn->query("UPDATE $table_users SET total_following=total_following-1 WHERE username='$username' LIMIT 1");
        $conn->query("UPDATE $table_users SET total_followers=total_followers-1 WHERE username='$pin' LIMIT 1");
      }
    catch(Exception $e) 
      {
        //Ignore
        
      }
    $stmt->close();
    $conn->close();
    die('{"status":"success","result":"Unfollowed"}');
  }
$conn->close();
die('{"error":"Failed to unfollow."}');
