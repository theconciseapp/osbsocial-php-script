<?php if (!defined('__ALLOW__')) 
  {
    die('{"error":"Method not allowed.","ecode":"51"}'); //Method not allowed
    
  }
else if (empty($_POST['base64'])) 
  {
    die('{"error":"File rejected.","ecode":"51"}');
  }
$base64    = test_input($_POST['base64']);
$bfilesize = strlen($base64) / 1024;
$bfilesize = $bfilesize / 1024;
if ($bfilesize > $max_upload_size) 
  {
    die('{"error":"File is too large.","ecode":"3"}');
  }
$base64         = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $base64));
$filename       = (microtime(true) * 10000) . randomNumbers(3);
$filename       = "OSB_IMG_{$filename}";
$comment_folder = "";
if (defined('__COMMENT_UPLOAD__')) 
  {
    $comment_folder = "comments/";
  }
$folder         = "images/social/{$comment_folder}" . _CHAT_FILES_STRUCTURE_;
$dir            = _CHAT_FILES_DIR_ . "/{$folder}";
if (!make_dir($dir)) 
  {
    die('{"error":"Server error: dirE","ecode":"53"}'); //Unable to create directory
    
  }
$file = $dir . '/' . $filename . '.jpg';
uploadBase64Image($file, $base64, $folder, $dir, $filename);
