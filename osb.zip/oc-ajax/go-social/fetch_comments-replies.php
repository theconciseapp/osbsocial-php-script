<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES" && empty($_POST["username"])) 
  {
    $_POST["username"] = "anonymous";
  }
if (empty($_POST['parent_id']) || empty($_POST['username']) || empty($_POST["post_by"]) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username  = test_input(strtolower($_POST['username']));
$parent_id = test_input($_POST['parent_id']);
$post_by   = test_input($_POST['post_by']);
$version   = test_input($_POST['version']);
require ('../../oc-includes/server.php');
require ('comment-functions.php');
$result = fetch_replies($conn, $parent_id, $post_by, $username);
$conn->close();
die(json_encode($result));
