<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES" && empty($_POST["username"])) 
  {
    $_POST["username"] = "anonymous";
    $_POST["fullname"] = "anonymous";
  }
if (empty($_POST['username']) || empty($_POST["fullname"]) || empty($_POST["post_id"]) || empty($_POST["post_by"]) || empty($_POST["reaction"]) || empty($_POST["type"])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username      = test_input($_POST['username']);
$fullname      = test_input($_POST['fullname']);
$post_by       = test_input($_POST['post_by']);
$pid           = test_input($_POST['post_id']);
$reaction      = test_input($_POST['reaction']);
$type          = (int)$_POST['type'];
$reactions_arr = ["like", "love", "laugh", "wow", "sad", "angry"];
if (!in_array($reaction, $reactions_arr)) 
  {
    die('{"error":"Invalid reaction"}');
  }
require ('../../oc-includes/server.php');
require ('go-functions.php');
$table = _TABLE_SOCIAL_POSTS_;
$liked = false;
try
  {
    $stmt  = $conn->prepare("SELECT reactions FROM {$table} WHERE    
id=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('i', $pid) || !$stmt->execute()) 
      {
        $conn->close();
        die('{"error":"Try again"}');
      }
    $res = $stmt->get_result();
    $stmt->close();
    if ($res->num_rows < 1) 
      {
        die('{"error":"Post unavailable"}');
      }
    $row            = $res->fetch_assoc();
    /*
    
    *result*
    
    {"like":1000,"love":10000,"laugh":100,"wow":800,"sad":0,"angry":0}
    
    */
    $reactions      = json_decode($row['reactions'], true);
    $rcount         = (int)$reactions[$reaction];
    $noupdate       = false;
    if (!empty($_POST["preaction"])) 
      {
        /*Get previous user reaction to a post if available
        
         *This is determined by user device, if it has an already saved reaction
        
        */
        $prev_reaction  = $_POST["preaction"];
        if (in_array($prev_reaction, $reactions_arr)) 
          { //Validate
            $pr             = (int)$reactions[$prev_reaction] - 1;
            if ($pr < 0) 
              {
                $pr             = 0;
                $noupdate       = true; //If for some reasons, we got a negative value, then don't increament new reaction status - Check below
                
              }
            $reactions[$prev_reaction]                = $pr;
          }
      }
    if ($type == 1) 
      {
        if (empty($_POST["preaction"])) 
          {
            $liked          = true;
          }
        if (!$noupdate) 
          {
            $reactions[$reaction]                = $rcount + 1;
          }
      }
    else
      {
        $c              = $rcount - 1;
        if ($c < 0) 
          {
            $c              = 0;
          }
        $reactions[$reaction]                = $c;
      }
    $save_reactions = json_encode($reactions);
    $stmt           = $conn->prepare("UPDATE $table SET reactions='$save_reactions' WHERE id=? LIMIT 1");
    if ($stmt && $stmt->bind_param('i', $pid) && $stmt->execute()) 
      {
        $stmt->close();
        if ($liked && $post_by != $username) 
          {
            $meta    = array();
            $meta["author"]         = $username;
            $meta["contributors"]         = "";
            $meta["action"]         = "open";
            $meta["action_type"]         = "post";
            $meta["action_id"]         = $pid;
            $send_to = $post_by;
            if ($username != "anonymous") 
              {
                @sendNotification($conn, $send_to, "@{$fullname}@ liked your post.", $meta);
              }
          }
        $conn->close();
        $final_result = array();
        $final_result["status"]              = "success";
        $final_result["type"]              = $type;
        $final_result["result"]              = $reactions;
        die(json_encode($final_result));
      }
  }
catch(Exception $e) 
  {
    logIt($e->getMessage());
  }
die('{"error":"Please try again."}');
