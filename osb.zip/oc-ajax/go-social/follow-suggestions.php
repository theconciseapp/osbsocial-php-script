<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['pin'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$result = array();
$pin    = preg_replace("/[^a-zA-Z0-9 _-]/", "", test_input($_POST['pin']));
if (empty($pin)) 
  {
    die(json_encode($result));
  }
$pin    = mb_substr($pin, 0, 50);
$search = "{$pin}%";
require ('../../oc-includes/server.php');
$table       = _TABLE_USERS_;
$settings__  = getSettings();
$go_homepage = isset($settings__["go_homepage_posts"]) ? $settings__["go_homepage_posts"] : "1"; //1. User posts
$go_cpost    = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "1"; //
if ($go_homepage != "1" || $go_cpost == "1") 
  {
    $role        = "role=5";
  }
else if ($go_cpost == "2") 
  {
    $role        = "role IN(4,5)";
  }
else
  {
    $role        = "role>2";
  }
$stmt        = $conn->prepare("SELECT username, fullname FROM $table WHERE {$role} AND ( username LIKE ? OR fullname LIKE ? ) ORDER BY username LIMIT 5");
if (!$stmt || !$stmt->bind_param('ss', $search, $search) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Please try again"}');
  }
$res = $stmt->get_result();
$stmt->close();
$conn->close();
$total = $res->num_rows;
if ($total < 1) 
  {
    die('{"no_record":"Nothing found"}');
  }
$results_ = array();
while ($row      = $res->fetch_assoc()) 
  {
    $results_[]          = $row;
  }
$result["status"]          = "success";
$result["suggestions"]          = $results_;
die(json_encode($result));
