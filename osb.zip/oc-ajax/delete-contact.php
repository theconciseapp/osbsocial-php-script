<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid security token."}');
  }
else if (empty($_POST['username']) || empty($_POST['friend_username']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$userName       = test_input(strtolower($_POST['username']));
$friendUsername = test_input(strtolower($_POST['friend_username']));
$app_version    = test_input(strtolower($_POST['version']));
$file           = getUserDir($userName) . "/contacts.txt";
if ($userName == $friendUsername) 
  {
    die('{"error":"You can\'t delete yourself."}');
  }
else if (!is_file($file)) 
  {
    die('{"status":"success","result":"deleted"}');
  }
$data = @file_get_contents($file);
if (empty($data)) 
  {
    die('{"status":"success","result":"deleted"}');
  }
$data = preg_replace("/^" . $friendUsername . "\\|.*\n/mi", "", $data);
if (empty($data)) 
  {
    @unlink($file);
    die('{"status":"success","result":"deleted"}');
  }
if (file_put_contents($file, $data)) 
  {
    die('{"status":"success","result":"deleted"}');
  }
