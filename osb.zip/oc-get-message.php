<?php header('Content-type:application/json;charset=utf-8');
define('_NO_CONNECT_ERROR_EXIT_', 'True');
require ('oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"invalid_token":"Invalid token."}');
  }
else if (!isset($_POST["gms_count"])) 
  {
    die('{"error":"Missing parameters"}');
  }
$settings__ = array();
if (isset($_POST['fetch_settings']) && $_POST['fetch_settings'] == "1") 
  {
    $settings__ = getSettings();
  }
$aud        = array();
if (empty($_POST["gms_count"])) 
  {
    $aud        = appUpgradeData();
  }
$gms_count  = (int)$_POST["gms_count"];
require ('oc-includes/chat_functions.php');
require ('oc-ajax/group/group-functions.php');
require_once "oc-includes/server.php";
updateLastSeen();
$ajgfile  = _ADMIN_DIR_ . "/settings-files/auto-join-groups.txt";
$ajgroups = "";
if ($gms_count == 0 && file_exists($ajgfile)) 
  {
    $ajgroups = file_get_contents($ajgfile);
  }
die(json_encode(getMessage($conn, $settings__, $ajgroups, $aud)));
