var GO_UPLOAD_FILE_PATHS=[]; 
var GO_UPLOADED_FILE_PATHS=[];
var POST_FILES_EDIT={};
var ADS___;
var SERVER_SETTINGS=[];
//var loaded_ad=[];
var adPosMin=0;

var commentAjax,fsuggestionsAjax=false,fsuggestionsTimeout=false;
var commentTimeout,lspTimeout,lspLoading,lspAjax;
var loadingPosts,loadingGoPages,tloadingGoPages,searchingPosts,loadingProfilePosts,loadingNotificationAjax,loadingNotificationsPosts;
var loadingFullPost=false;
var connCounts=0;
var WAIT_FOR_ME=false;
var composingTimeout=false;
var imgcache_=imgcache();
var postEditMeta;

var GO_FOLDER="";

localStorage.setItem('go_social_opened','true');
//This lStorage is removed at app launch. Check control menu.js

function loginRequired(){
  return localStorage.getItem("login_required");
  }
  
function loggedIn(){
  if( !localStorage.getItem("logged_in")
  ||!localStorage.getItem("__TOKEN__")
  ||!localStorage.getItem("username") )
  return false;
  else return true;
  }  
  

function storedPostLikes_(){
	var sl=localStorage.getItem("POSTS_SAVED_LIKES")||"";
var len=sl.length;
if( len> 3000){
	localStorage.removeItem("POSTS_SAVED_LIKES");
	sl=null;
}
	return sl?JSON.parse(sl):{}
}

var POSTS_SAVED_LIKES= storedPostLikes_();

function postLiked(pid){
	return POSTS_SAVED_LIKES[pid];
}
	
function storePostLike(lid, reaction){
 POSTS_SAVED_LIKES[lid]=reaction;
 localStorage.setItem("POSTS_SAVED_LIKES", JSON.stringify( POSTS_SAVED_LIKES));
}

function removePostLike( lid){
  delete POSTS_SAVED_LIKES[lid];
		localStorage.setItem("POSTS_SAVED_LIKES", JSON.stringify( POSTS_SAVED_LIKES) );
	}

function stackOrder(value_){
 var stacksDiv=$('#go-stack-order');
  if( value_){
   return stacksDiv.prepend( value_ + ',');
  }                          
  var stacks= stacksDiv.text()||"";
  var next="";
  if( stacks) {
    next=stacks.split(',')[0]||"";
    stacksDiv.text( stacks.replace(next + ",","") );
   return next;
  }
  else return "";
 }

function AE(time_){
  if( !go_config_.aet) return;
  time_=time_||moment().unix();
 var it=+localStorage.getItem('Aet');
  if(!it ){
   it= time_;
   localStorage.setItem('Aet', it ); 
  }
 var mejila= time_- 43200;
  if( it< mejila){
    // android.control.execute("AE(1);");
  }
}

function openMessage(){
  downloadApp();
  
  $('#total-new-messages').attr('data-total',0).text(0).css('display','none');
  localStorage.removeItem( "xxxx_total_new_messages");
 
}

if( MS__=='m'){
  openMessage();
  quitLoading(); //Non existent function
}


function zindex(){
  var zindex=$("#z-index");
  var zi=+zindex.val()||40;
  zindex.val( zi+10)
   return zi;
 }

function osb_permalink(id, slug){
   var burl=$("#base-url").attr("href");
   return burl + "post/" +  (slug?slug:id );
}

function showSiteTagline(){
	$("#OSB-SITE-TAGLINE").fadeIn().fadeOut(10000);
}
	
function toggleLeftSidebar(){
	var sbar=$('.side-bar-container');
    var mcont=$('.main-content-container');

  if( mcont.hasClass("main-content-marginLeft")){
    return toggleRightSidebar();
  }
  
  var oWidth_=+sbar.attr("data-width");
  var oWidth=oWidth_||sbar.width();
  
  if( !oWidth_) {
   sbar.attr("data-width", oWidth);
 }
  
  if( !sbar.hasClass("hide-left-sidebar") ){
	 sbar.animate({
            width: 0
        }, 100,function(){
   sbar.css({"width": oWidth,"display":"none"});
   sbar.addClass("hide-left-sidebar");
   sbar.css("display","");
});
 $(".main-content-shadow").fadeOut(100);
  }else{
  	changeHash("");
    sbar.removeClass("hide-left-sidebar").css({"width":0, "display":"inline-block"});
        
     sbar.animate({
        width: oWidth
     }, 100 );

     $(".main-content-shadow").fadeIn(200);
}
	}

function toggleRightSidebar(){

  var mcont=$('.main-content-container');
  var sbar=$('.right-side-bar-container');

 if( !$(".side-bar-container").hasClass("hide-left-sidebar") ){
   return toggleLeftSidebar();
 }
  
   var oWidth=sbar.width();
	if( !sbar.hasClass("hide-right-sidebar") ){
	//Close
      mcont.animate({
           marginLeft: 0
        }, 100, function(){
   mcont.removeClass("main-content-marginLeft");
   sbar.addClass("hide-right-sidebar");
   mcont.css("margin-left","");
});
      
 $(".main-content-shadow").fadeOut(100);
		
 }else{
   //Open
   changeHash("");
	sbar.removeClass("hide-right-sidebar");
    mcont.animate({
       marginLeft: -oWidth
   },100, function(){
     mcont.addClass("main-content-marginLeft");
     mcont.css("margin-left","");
    });
 $(".main-content-shadow").fadeIn(200);
  }
}

function go_user_icon( user ,class_, picture ){
	var cache_id=imgcache_;
	if( user==username) cache_id=randomString(3);
	
  class_=class_||'friend-picture';
  var real_path=picture||config_.users_path + '/' + strtolower( user[0]+'/' + user[1] + '/' + user[2] + '/' + user ) + '/profile_picture_small.jpg?i=' + cache_id;
  var avatar=__THEME_PATH__ + '/assets/go-icons/avatar-grey.png';
  return '<img class="lazy ' + class_ + '" alt="" onerror="go_imgIconError(this);" src="' + avatar + '" data-src="' + real_path + '" data-id="' + strtolower(user ) + '">';
}

function go_user_photo( user, class_){
  class_=class_||'friend-picture';
  var real_path=config_.users_path + '/' + strtolower( user[0]+'/' + user[1] + '/' + user[2] + '/' + user ) + '/profile_picture_full.jpg?' + imgcache_;
  var avatar=__THEME_PATH__ + '/assets/go-icons/avatar-grey.png';
  return '<img class="lazy ' + class_ + '" alt="" onerror="go_imgIconError(this,\'' + user + '\');" src="' + avatar + '" data-src="' + real_path + '" data-id="' + strtolower(user ) + '">';
}


function go_user_mphoto( user, class_,avatar){
  //medium photo
  class_=class_||'friend-picture';
   avatar=avatar||"avatar.png";
 
  var real_path=config_.users_path + '/' + strtolower( user[0]+'/' + user[1] + '/' + user[2] + '/' + user ) + '/profile_picture_medium.jpg?' + imgcache_;
  var avatar_=__THEME_PATH__ + "/assets/go-icons/" + avatar;
  return '<img class="lazy ' + class_ + '" alt="" onerror="go_imgIconError(this,\'' + user + '\',\'' + avatar + '\');" src="' + avatar_ + '" data-src="' + real_path + '" data-id="' + strtolower(user ) + '">';
}



function go_imgIconError(image,user,avatar) {
	avatar=avatar||"avatar.png";
  var src= __THEME_PATH__ + '/assets/go-icons/' + avatar;
  image.src = src;
  image.onerror=null;
}


function go_postImgError(image, bg,cnt_) {

  bg=bg||'transparent2';
  cnt_=cnt_||3;
 if ( !image.hasOwnProperty('retryCount')){
      image.retryCount = 0;
  }
 var cnt=image.retryCount;
  if ( cnt < cnt_){ 
  image.src = image.src + '?' + +new Date;
  image.retryCount += 1;
  }else{
   image.onerror=null;
   return image.src =__THEME_PATH__ +  '/assets/go-icons/bg/' + bg + '.png';
  }
}


function go_imgError(image,bg) {
    image.onerror = null;
  setTimeout( function (){
     image.src += '?' + +new Date;
   }, 1000);
}


function goFetchPhoto(path, callback){
  var img = document.createElement('img');
     img.onload = function(){     
       var canvas = document.createElement('canvas');
       var ctx = canvas.getContext('2d');

       var width=img.width;
       var height=img.height;
       
       canvas.width=width;
       canvas.height=height;
 
     ctx.drawImage(this,0,0,width, height);
     callback( canvas.toDataURL('image/jpeg', 0.8) );
  };
      img.src = path;
     img.addEventListener('error', function(e){
      callback('','error'); 
      });
}
  
function go_videoPlayerLayout( data, fdload, poster, reposted, from_comm){
  
 var sourceUrl= data.path;
 var fsize= data.size;
 var width=  data.width;
 var height= data.height;

  var vid =randomString(10 );
 
  var dsourceUrl=sourceUrl; //Download source url
  
 //sourceUrl="http://www.jplayer.org/video/m4v/Big_Buck_Bunny_Trailer.m4v";  

/*
  if( sourceUrl.match(/localhost:8080/) ){
sourceUrl=sourceUrl.replace("http://localhost:8080", "storage/emulated/0/Icode-Go/data_files/www");
}*/


  if(!width){
  var dim_=getParameterByName("ocwh", sourceUrl)||"";
  var dim=dim_.split("_");
  var width=+dim[0]||500;
  var height=+dim[1]||0;
  }
  
  var dW=$(window).width();
  var maxW=dW<500?dW:500;
  
 if( from_comm) maxW=200;
 
  if( height){
 var size=imageScale( width , height, maxW, 700);
  
  var imgheight= Math.ceil(size*height) + "px";
  var imgwidth= Math.ceil( size*width ) + "px";
  
}else{
  
    imgwidth= maxW + "px";
    imgheight="auto";

}
   var data='<div class="go-video-poster-container go-post-photo-container">';
     data+='<img class="go-video-poster go-post-photo lazy" style="height:' + imgheight + '; width: ' + imgwidth + ';" src="' + __THEME_PATH__ + '/assets/go-icons/white-bg.png" data-src="' + poster + '" onerror="go_postImgError(this,\'black\');">';
     data+='<img class="go-video-play-icon" data-vid="' + vid + '" src="' + __THEME_PATH__ + '/assets/chat-icons/play.png">';
     data+='<div onclick="goOpenVideo(this);" data-fdload="' + fdload + '" class="' + ( reposted? 'reposted':'go-open-video') + '" data-vid="' + vid + '" data-durl="' + dsourceUrl + '" data-fsize="' + fsize + '" data-source-url="' + sourceUrl + '" data-poster="' + poster + '"></div>';
     data+='</div>';
   
  return data;    
}

 

function go_photoLayout(data, fdload, reposted, from_comm){
 var file_path=data.path;
 var fsize=  data.size;
 var width=  data.width;
 var height= data.height;
 
if(!width){
  var dim=getParameterByName("ocwh", file_path)||"";
      dim=dim.split("_");
  var width=+dim[0]||500;
  var height=+dim[1]||0;
}
  
 
  var dW=$(window).width();
  var maxW=dW<500?dW:500;
  var maxH=700;
 if( from_comm ){
   maxW=200; 
   maxH=300;
 }
  
 if(height){
  var size=imageScale( width, height, maxW, maxH);
  var imgheight= Math.ceil(size*height) + "px";
  var imgwidth= Math.ceil( size*width ) + "px";
 }
  else{
    
    imgwidth= maxW + "px";
    imgheight="auto";
  }
  
  var data='<img class="lazy go-post-image go-post-photo ' + (reposted?'reposted':'') + '" style="height: ' + imgheight + '; width: ' + imgwidth + '" data-original-height="' + height + '" data-original-width="' + width + '" alt="" data-fsize="' + fsize + '" data-fdload="' + fdload + '"  src="' + __THEME_PATH__ + '/assets/go-icons/bg/post-white-bg.png" data-src="' + file_path + '" onerror="go_postImgError(this);">';  
  
  return '<div class="go-post-image-container go-post-photo-container">' + data + '</div>'; 

}


function go_formatFiles(data, fdload, reposted, full, from_comment ) {
 if(!data  ) return "";
  
  try{
data=JSON.parse( data);
}catch(e){
return "";
}

  var total=data.length;
  var file_result="";
  var cnt=0;
  
 $.each( data, function(i,data_){
     cnt++;
   var ext   = data_.ext;
   
 if ( !full && cnt > 4) {
   file_result+='<span class="go-more-photos">+ More</span>';
  return false;
 } 
   
   if( ext=='jpg'){
  file_result+= go_photoLayout( data_, fdload, reposted,from_comment);
 }else if ( ext=='mp4') {
  var poster=data_.poster||"data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";
  file_result+= go_videoPlayerLayout( data_, fdload, poster,reposted, from_comment );
    }
  });

  return file_result; 
  }


function goOpenGallery(event,type){
  //Type: image, video
  var allow_vid=false;   
// try{
//  var settings= JSON.parse( localStorage.getItem("server_settings") );
 
 if( siteAdmin( username) || SERVER_SETTINGS.enable_vid_doc=="YES"  ){
   allow_vid=true;
  } 
    
    /*
 }catch(e){ 
  return toast("Loading settings...", { type:"info"});
 }
 */
 
    $('#go-upload-preview-container').empty();
   GO_UPLOAD_FILE_PATHS=[]; //Empty paths
   GO_UPLOADED_FILE_PATHS=[]; //Empty uploaded paths
  var this_=$(event);
      this_.prop('disabled',true);  
    
    setTimeout(function(){
    this_.prop('disabled', false);
  }, 1500);

 var pformat= $('#selected-photo-format').val();
 
 var isVerified= userVerified( username);

var cont=$('#go-upload-preview-container');

// alert( JSON.stringify( event))
try{
	
	var imageTypes = ["jpg", "jpeg", "gif","png"];
   var videoTypes=["mp4"]; 

for(let i=0;i<event.files.length;++i){
	var ext= event.files[i].name.split('.').pop().toLowerCase();  //file extension from input file
    var reader = new FileReader();
    
    reader.onload = function(e){
    var data=	this.result; 
      var type=data.match(/(video|image)/);
 
  if( !type ) return toast("One or more file unsupported");
  
   type=type.toString();
   
 if(   type.match(/image/) ){
 
    image_( i, data); 
 }
   else{
  video_( i, data);   
 }
    };
    reader.readAsDataURL(event.files[i]);
  }
}catch(e){ toast(e); }
    
  $('#open-compose-page-btn').click(); 
 }

function image_( i, image_data){
	
	resizeImage( image_data, {quality: 0.8, width: 1000, height: 600 }, function( v, error){
 if( error) return toast( error);
 
 var cid=randomString(10);
	var filename=cid;
	var fpath=filename + ".jpg"; 
	
	GO_UPLOAD_FILE_PATHS.push( fpath );
	
	var cont=$('#go-upload-preview-container');
  
     var data='<div id="uppc-' + cid + '" data-swid="' + i + '" onclick="swapIt(this)" data-fpath="' + fpath + '" class="go-upload-photo-preview-container">';
         data+='<img class="go-upload-photo-preview" src="' + v + '">';
         data+='<span data-findex="' + i + '" data-fpath="' + fpath + '" data-cid="uppc-' + cid + '" class="go-remove-upload-preview" id="close-upbtn-' + cid + '">x</span>';
         data+='<span id="go-up-progress-container-' + filename + '" class="go-up-progress-container">';
         data+='<span id="go-up-progress-' + filename + '" class="go-up-progress"></span>';
         data+='</span>';
         data+='<textarea class="d-none image-data" id="base64-data-' + filename + '">' + v + '</textarea>';
         data+='</div>';
     cont.append( data);     
   });
}

function video_(i, v) {
	var cid=randomString(10);
	var filename=cid;
	var fpath=filename + ".mp4"; 
	
    GO_UPLOAD_FILE_PATHS.push( fpath );
   
  var cont=$('#go-upload-preview-container');
  
   var data='<div id="uppc-' + cid + '" data-swid="' + i + '" data-fpath="' + fpath + '" class="go-upload-video-preview-container">';
         data+='<div id="uppc-cover-' + cid + '" class="go-video-preview-cover"><img class="w-16 h-16" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>';
         
         data+='<div class="go-video-preview-child-cont" id="vid-child-cont-' + cid + '">';
         data+='<img src="' + __THEME_PATH__ + '/assets/go-icons/video.png" class="w-30" style="position: absolute; bottom: 0; left: 0; z-index: 10;">';
         data+='<video id="vid-' + cid + '" data-cid="' + cid + '" data-src="' + v + '" class="go-upload-video-preview" preload="auto"';
         data+=' src="' + v + '" oncanplay="goVideoPreviewLoaded(this);" onerror="goVideoPreviewError(this);" autoplay muted>';
         data+='</video>';
         data+='</div>';
         data+='<span data-findex="' + i + '" data-fpath="' + fpath+ '" data-cid="uppc-' + cid + '" class="go-remove-upload-preview" id="close-upbtn-' + cid + '">x</span>';
         data+='<span id="go-up-progress-container-' + filename + '" class="go-up-progress-container">';
         data+='<span id="go-up-progress-' + filename + '" class="go-up-progress"></span>';
         data+='</span>';
         data+='<textarea class="d-none video-data" id="base64-data-'+ filename + '">' + v + '</textarea>';
         data+='<input type="hidden" id="vid-poster-' + cid + '" />';
         data+='</div>';
         
         cont.append( data);
      var vid= document.getElementById("vid-"  + cid );
      
 }
	
	
function display_post( post, full, single_post, sponsored_post ){
 
   var result="";
   var adm=goAdmin( username );
   
    $.each( post, function(i,v){ 
      var me=false;
  
   var post_id=v.id;
   var post_title=v.post_title||"";
   var post_by=v.post_by||"";
   var email=v.email;
   var country=v.country;
   var bio=v.bio;
   var birth=v.birth;
   var joined=v.joined_on;
   var fullname=v.real_name;
   var phone=v.phone;
   var fstatus=v.follow_status||"";
   var post_files=v.post_files||"";
   var post_name= v.post_name;
         
 // save_user_profile( post_by, fullname, email, phone, country,bio,birth, joined);
   var post_link=osb_permalink( post_id, post_name );
   
   var post_type=v.post_type;
   var ppic =v.poster_pic||"";
    
     var post_preview= ( v.post_preview||"")
//.replace(/</g,'&lt;');
     
     var time_= timeSince( +v.post_date);
     var time= time_;
      
    var sponsored=false;
   
    if ( sponsored_post ){
    sponsored=true;
    time='Sponsored';
  
 if( adm ) time+=' &bull; ' + time_;
   
  }
      
     var meta= v.post_meta||'{""}';
   //  var total_likes= +(v.total_likes||0);
     var total_comments= +(v.total_comments||0);
     var total_shares= +( v.total_shares||0);
     var reactions=v.reactions||"{}";
     var reactions_={};
      try{
      reactions_= JSON.parse( reactions);
      }catch(e){}; 
      
  var veri=checkVerified( post_by, fullname);
  var verified=veri.icon;
  var fullname_= veri.name;
      fullname=fullname_ + ' ' + verified;

  var data=parseJson( meta );
  
  var true_author=data.true_author||"";
  var post_length=+data.plen;
  var can_comment=data.can_comment;
  var shareable= data.shareable;
  var commentable= data.commentable;
  var reposted= data.repost||"";
  var otrue_author=data.otrue_author;
  var op_by= data.opost_owner||"";
  var optitle=data.optitle||"";
  var op_name_= data.opbf||op_by;
  var odeleted= data.odeleted||0;
      
      if( username ){
  if(  username==true_author ||
   ( goPage( username) && post_by==username)  ){
    me=true;
  }
}
  var op_name="";     
  
   if( reposted){
 var op_v=checkVerified( op_by, op_name_);
     op_name= op_v.name + ' ' + op_v.icon;
    }
    
  var op_time= timeSince( data.opost_time);
  var op_id= data.opost_id||"";
  var op_preview= data.opost_preview||"";
   
  if( op_preview.length > 100){
    op_preview=op_preview.substr(0,100) + '...';
   }

  var version= data.ver;
  var hasFile=data.has_files;
  var bsize=data.size||0;
  var size= hasFile?readableFileSize( +bsize, true, 0):'';
  var meta_="";
 // var post_files=data.post_files||"";     
  var plink=data.link;
  var plinkText=data.link_title;
  var fdload=data.fdload||"";
      
  var total_files=+( data.total_files||0)
  var post_bg_=data.post_bg||"";
  var opost_bg_=data.opost_bg||"";
  
   var opost_bg="";
   var post_bg="";
      
  if( post_bg_){
      post_bg=post_bg_ + ' go-pbg' + ( post_length<60?' go-pbg-font':'');
    }
     
  if( post_preview.length > 200 ){
  	
     post_preview=	post_preview.substring(0, 200);
     
  var  highlight='<div data-pid="' + post_id + '" data-post-by="' + post_by + '" data-true-author="' + true_author + '" class="go-load-full-post">' + post_preview + ' <span class="go-post-more-link">...See more</span></div>';
  }else{
  var highlight=post_preview;
      	
  }

  if(!full){
  
     highlight= '<div class="go-post-preview go-post-preview-' + post_id + ' ' + ( highlight?post_bg:'') + '">' + go_textFormatter( highlight) + '</div>';
   }
    else{
     highlight= '<div class="go-post-preview go-post-preview-' + post_id + ' ' + post_bg + '">' + go_textFormatter( v.post||"" ) + '</div>'; 
   }
   
var open_file=false;
   
 if( reposted||
      ( total_files > 4 && !full ) ){ 
     open_file=true;
 }

 
 var format="";
 var format_= go_formatFiles(post_files , fdload, open_file, full );

   if(!odeleted){ 
   	
 format='<div class="go-post-files-container ' + ( total_files >1?'go-post-files-container-m go-multiple-images go-multiple-images-' + total_files:'') + '">' + format_ + '</div>';
 }
   var hide_author=SERVER_SETTINGS.go_hide_author_name;
     
   var p='<div class="go-post-container go-post-container-' + post_id  + '">';
       p+='<div class="go-post-header">';
       p+='<div class="row">';
      
  if( sponsored || hide_author==="NO"){
       p+='<div class="col go-post-by-icon-col">';
       p+='<div class="go-post-by-icon-container">' + go_user_icon( post_by,  'go-post-author-icon go-post-author-icon-' + post_by, ppic) + '</div>';
       p+='</div>';
   }
      
       p+='<div class="col go-post-fullname-' + post_by + ( sponsored && !adm?' go-sponsored-profile':' go-open-profile') + '" data-hide-author="' + hide_author + '" data-user="' + post_by + '" data-user-fullname="' + fullname_ + '">';
   
   if( sponsored || hide_author==="NO" ){
      
  p+='<div><span class="go-post-fullname go-puser-fullname-' + post_by + '">' + fullname + '</span></div>';
  
    }
        
  if( sponsored ||  SERVER_SETTINGS.go_hide_post_time==="NO"){
  	
       p+='<div class="go-post-date">' + time  + ' &bull; <img class="icon-small" src="' + __THEME_PATH__ + '/assets/go-icons/world.png"></div>';    
   } 
      p+='</div>';
       p+='<div class="col-2 p-0 text-center">';
       p+='<div class="go-post-options-btn" data-hide-author="' + hide_author + '" data-pid="' + post_id + '" data-post-by="' + post_by + '" data-true-author="' + true_author + '" data-post-type="' + post_type + '" data-pbf="' + fullname_ + '" data-post-link="' + post_link + '">';
      
     if( me ){
       p+='<img width="30" height="30" class="w-30" src="' + __THEME_PATH__ + '/assets/go-icons/3dots-green.png">';
       
      }else{
       p+='<img width="30" height="30" class="w-30" src="' + __THEME_PATH__ + '/assets/go-icons/3dots.png">'; 
      }
       p+='</div>';
       p+='</div></div></div>';
   
      p+='<div class="' + ( total_files > 4 && !reposted && !full?' go-open-single-post':'') + '" data-post-by="' + post_by + '" data-pid="' + post_id + '">';     
               
 if(  post_title && SERVER_SETTINGS.enable_post_title=="YES" ){
  
 p+='<a class="d-block go-post-title" href="' + post_link + '">' + post_title + '</a></a>';
 }

      p+='<div class="go-post-highlight go-post-highlight-' + post_id + '">' + highlight + '</div>';
   

   if ( reposted ){
       if( opost_bg_ && op_preview ){
       opost_bg=opost_bg_ + ' go-pbg' + ( op_preview.length<60?' go-pbg-font':'');
     }
    
       p+='<div class="container go-opost-container go-open-single-post" data-odeleted="' + odeleted + '" data-post-by="' + op_by + '" data-cpid="' + post_id + '" data-pid="' + op_id + '">';
    
    if( !odeleted){
    	
       p+='<div class="row">';
       p+='<div class="col go-opost-by-icon-col">';
       p+='<div class="go-opost-by-icon-container">' + go_user_icon( op_by, 'go-opost-by-icon') + '</div>';
       p+='</div><div class="col p-0">';
       p+='<div class="go-opost-fullname">' + op_name + '</div>';
       p+='<div class="go-opost-date">' + op_time  + ' &bull; <img class="icon-small" src="' + __THEME_PATH__ + '/assets/go-icons/world.png"></div>';
       p+='</div></div>';
    }  
    
if( optitle) {
  p+='<div class="go-post-title">' + optitle + '</div>';
  }
  
     p+='<div id="go-opost-preview-' + op_id + '" class="go-opost-preview ' + opost_bg + '">' + go_textFormatter( op_preview ) + '</div>';
   }
       p+='<div class="go-post go-post-' + post_id + '">' + ( format||"") + '</div>';
     
  p+='<div class="post-link-container" id="post-link-container-'+ post_id + '">';

if( !odeleted && plink){
	plinkText=plinkText.split("...");
	
	  p+='<div class="container-fluid go-nice-link-container">';
        p+='<div class="row"><div class="col"><a href="' + plink + '" class="go-nice-link" data-repost="' + reposted + '" target="_blank">' +  plinkText[0] + '<div class="form-text">' + ( plinkText[1]||"") + '</div></a></div><div class="col-2 text-center go-nice-link-info" data-link="' + plink + '"><img class="mt-1 w-16 h-16" src="' + __THEME_PATH__ + '/assets/go-icons/info.png"></div></div></div>'; 
       }
       
   p+='</div>';
     
   if( reposted){
     
      p+='</div>';
     
     }
      p+='</div>';
      
    var total_r=0;
    var remoji='';
   
  $.each( reactions_, function(i, rcount){
       var rv=+rcount;
        total_r=total_r+ ( +rv);
     if( rv){
       remoji+='<img class="go-like-post-iconx-' + post_id + ' icon-normal w-18 h-18" src="' + __THEME_PATH__ + '/assets/chat-icons/reactions/' + i + '.png">';
     }
      });
      
  var reacted=false;
  var liked="like-empty";

var plike=postLiked( post_id);

if( plike ){
     var reacted=true;
     liked=plike;
 }
 
  var allow_reactions=SERVER_SETTINGS.go_allow_reactions;
   
 var force_login=SERVER_SETTINGS.force_user_login;
  
  var licon=__THEME_PATH__ + '/assets/chat-icons/reactions/' + liked + '.png';
     
     var total_reactions= abbrNum(total_r, 1);
     var total_likes=+reactions_["like"]||0;
     
      p+='<div class="go-post-footer">';
      p+='<div class="reactions-box-container reactions-box-container-' + post_id + '"></div>';
  
  if(allow_reactions==="YES"){
     p+='<div style="padding: 5px 5px 10px 20px;" class="reacted-icons-container reacted-icons-container-' + post_id + '" data-reactions=\'' + reactions + '\'> ' + remoji + ' <span class="total-likes-' + post_id + '" data-total-reactions="' + total_r + '">' + (total_reactions ||"") + '</span></div>';
   }
      p+='<div class="row">';
      
    if( allow_reactions==="YES" && post_by!='cv_drafts' && fstatus!="0"){
        p+='<div class="col text-center"><button data-reactions=\'' + reactions + '\' data-post-by="' + post_by + '" data-pid="' + post_id + '" class="go-like-post-btn-' + post_id + ' go-like-post-btn' + ( reacted?' go-post-liked':'') + '"><img src="' + licon + '" class="osb-post-footer-icon go-like-post-icon-' + post_id + '"> <span class="total-likes-' + post_id + '" data-total-reactions="' + total_r + '">' + total_reactions + '</span></button></div>';
    }
      
   if( SERVER_SETTINGS.go_allow_comment=="YES" && post_by!='cv_drafts' && fstatus!="0" && commentable){
      p+='<div class="col text-center"><button data-pid="' + post_id + '" data-post-by="' + post_by + '" class="go-open-comments-box"><img class="icon-normal" src="' + __THEME_PATH__ + '/assets/go-icons/comment.png"> <span id="total-comments-' + post_id + '">' + abbrNum(total_comments,1) + '</span></button></div>';
   }
 
   var can_post=SERVER_SETTINGS.go_can_post;
   var can_share=SERVER_SETTINGS.go_allow_share;
    
   if( ( can_post=="1" ||can_share!="YES" ) && !siteAdmin( username) ){
         can_post=false;
      }
      
   if( !odeleted && can_post && fstatus!="0" && shareable ){
    
      p+='<div class="col text-center"><button data-pid="' + post_id + '" data-share-pid="' +( reposted?op_id:post_id) + '" data-notify="' + post_by + '" data-cpid="' + post_id + '" data-pbn="' + fullname_ + '" data-spbn="' + op_name_ + '" class="go-share-post-btn">';
      p+='<img class="icon-normal" src="' + __THEME_PATH__ + '/assets/go-icons/share.png"> <span id="total-shares-' + post_id + '">' + abbrNum( total_shares, 1) + '</span></button>';
      p+='</div>';  
   
   }
       p+='</div>';
       p+='</div>';
      
       p+='</div>';
    result+=p; 
    });
   return result;
  }

function no_post(can_post){
  $('#gnp').remove();
var data='<div id="gnp" class="go-no-post text-center">';
  
  if( ( can_post=="1" && goAdmin( username ) )
     || ( can_post=="2" && userVerified( username) )
     || can_post=="3"){
    data+='<Label for="goUploadFirstPhoto"><img src="' + __THEME_PATH__ + '/assets/go-icons/camera.png"></label><form class="d-none"><input type="file" id="goUploadFirstPhoto" name="file[]" accept="image/*" onchange="goOpenGallery(this, \'image\');" multiple /></form> ';
  }
    data+='<div>No posts yet!</div>';
   data+='<div class="mt-2"><small>You may follow one or more suggested pages and refresh</small></div>';
   data+='<div class="text-center mt-2 text-primary" onclick="home();">Refresh</div>';
    data+='</div>';
 return data;
}

var toast_once=false, lpFails=0;
var loadCount=0;
var lpostAjax,lpostTimeout;


function __( result, singlePostId, loadCount, refresh){
	var loader=$('#post-loading-indicator');
	var pnElem=$('#go-next-page-number');
	var profileElem=$("#load-profile-id");

     var is_profile=profileElem.val();
  
   lpFails=0;
   
   loadingPosts=false;  
   localStorage.removeItem('go-social-posts-loading');
 
  if( result.ecode ){
localStorage.setItem('login_required','YES');
localStorage.removeItem("logged_in");
location.href=config_.domain + "/oc-login.php";
  return;
}
 else if( result.error ){
 return toast( result.error );
}else if( result.pymk ){
   pymk_( result.pymk.data);
}
 
 SERVER_SETTINGS=result.settings;
 
if( result.sidebar_pages){
	 sidebarPages( result.sidebar_pages);
	}
	
 localStorage.setItem("server_settings", JSON.stringify( SERVER_SETTINGS) );
 
 var force_login=SERVER_SETTINGS.force_user_login;
 var adm= siteAdmin( username);
 var logged_in=loggedIn();
   
 var cache_reset=( SERVER_SETTINGS.cache_reset||"0|0").split("|");
 
var  img_chr= +cache_reset[0]||rand_;
var  file_chr=  +cache_reset[1]||rand_;

   localStorage.setItem("img_cache_reset",  img_chr );
   localStorage.setItem("file_cache_reset", file_chr);
   
   if( SERVER_SETTINGS.enable_login!=="YES" ){
   	$("#OSB-SIGNIN-BTN").remove();
   }
   
   if( !logged_in){
   
   localStorage.removeItem("username");
   	localStorage.removeItem("__TOKEN__");
     	$("#settings-btn").remove();
   }

  if( !logged_in|| SERVER_SETTINGS.go_enable_follow_btn!="YES" ){
    $(".follow-feature").remove();
  }

  if(!logged_in ||  ( !adm && SERVER_SETTINGS.enable_file_upload!="YES") ){
    $(".file-upload-feature").remove();
  }
 var ept=SERVER_SETTINGS.enable_post_title||"";
  if( ept=="YES"  ){
  	$("#go-create-post-title").removeClass("d-none");
  }
   loader.css('visibility','hidden');
     
   if(!logged_in) {
$(".go-open-my-profile,.go-change-account,#admin-panel-btn").remove();
$(".go-signin-btn").removeClass("d-none");
}

  var can_post=SERVER_SETTINGS.go_can_post||1;
 
 if( logged_in && ( siteAdmin(username)|| can_post=="3") ){
    $('#go-express-your-mind').css('display','block'); 
      }
 
    if( refresh ){
     closeDisplayData('.home_refresh'); 
    } 
     
 if( result.no_post){
   $('#go-the-posts').append( no_post(can_post) );
    pnElem.val("0");
 } 
   else if( result.status=='success' ){
    
    var posts= result.result;
    
    var nextPage=result.next_page;
    pnElem.val( nextPage );

 if( refresh ){
   $('#go-the-posts').html( display_post(  posts, false, singlePostId ) );      
     
 }else{

   $('#go-the-posts').append( display_post( posts, false, singlePostId ) ); 
 }

}
   else if(result.error){
      toast(result.error );
  }
  else toast('No more post to load.',{type:'info'});
  
   setTimeout( function(){
   	
   if( $("#bootstrap-loaded").is(":visible")||
 $("#main-css-loaded").is(":visible") ){
 
  setTimeout( function(){
  	location.reload();
	}, 10000);
	
 return  toast("Please be patient. You have a slow network");
 
   }else{
 
   if( is_profile){
     profileElem.click();	
  }
  
    $('#go-initializing-container').css('display','none');
    
    }
  },1000);

 if( loadCount===1 && result.sponsored_posts){
 	ADS___=result.sponsored_posts;
 
	//sponsoredPosts( result.sponsored_posts );
	}
	
	showAds( loadCount);
}

function loadPosts(refresh ){
   clearTimeout( lpostTimeout);

  var pnElem=$('#go-next-page-number');
  var pageNum=pnElem.val();
    
 if( refresh ){
    toast_once=false;
    pageNum="";
    
   var ttag=$("title");
   var tdata=ttag.data("title");
   ttag.html( tdata);
  
  $("#single-post-id,#load-profile-id").val("");
    
    displayData('<div class="text-center" style="padding-top: 30px;"><img class="w-40 h-40" style="border:0; border-radius: 4px;" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading5-bgwhite.png"></div>',
      { bground: 'rgba(0,0,0,0);', data_class:'.home_refresh', no_cancel: true, hash: false});
      window.history.pushState("data",  "null",  DOMAIN_);
   
  }
   
  if( !refresh && pageNum=="0"){
   if( !toast_once ){
     toast_once=true;
     toast('That is all for now', {type: 'info'});
   }
    return;
   }
  loadingPosts=true;
     
  localStorage.setItem('go-social-posts-loading','1');
 
  var loader=$('#post-loading-indicator');
  loader.css('visibility','visible');
   
  
 var rand_=randomString(5);
 
   WAIT_FOR_ME='load-posts';
  var singlePostId= $("#single-post-id").val();
var profileElem=$("#load-profile-id");
 var is_profile=profileElem.val();
    
    if( singlePostId){
    	var data=$("#osb-single-post-data").val();    
     var result=JSON.parse( data);
     __( result, singlePostId, 1, refresh);
    
 return;
    }
    
 lpostTimeout=setTimeout(  function(){
   clearTimeout( lspTimeout); //Load Sponsored posts timeout

connCounts++;
      
  lpostAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/posts.php',
    type: 'POST',
   //timeout: 15000,
     dataType: "json",
    data: {
      "username": username,
      "page": pageNum,
      "post_id": singlePostId,
      "load_count": loadCount,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){
//  alert( JSON.stringify(result));
    WAIT_FOR_ME=false;
    loadCount++;
    connCounts--;
     __( result, singlePostId, loadCount,refresh);
     
 }).fail( function(e,txt,xhr){
   WAIT_FOR_ME=false;
   // alert( JSON.stringify(e));
   loadingPosts=false;
    connCounts--;
   localStorage.removeItem('go-social-posts-loading');
  //loader.css('display','none');
  if(!lpFails && xhr!='timeout') toast('Check your connection. ' + xhr);
 lpFails=1;
 if( refresh ){
  closeDisplayData('.home_refresh');
  return;
    }
       setTimeout(function(){
       loadPosts(); }, 10000);
  });
    
  },1000);
}
  
//SEARCH POSTS

var toast_s_once=false,spTimeout,spAjax;

function goOpenSearchBox(){
  $('#go-search-container').css('display','block');
  changeHash("search");
 }
  
function searchPosts( fresh){
 
  var pnElem=$('#go-search-next-page-number');
  var searchDiv=$('#go-searched-posts');
  
  clearTimeout( spTimeout);
  
  if( spAjax){
    spAjax.abort();
  }
 
  
 if( fresh){
    toast_s_once=false;
    pnElem.val("");
    searchDiv.empty();
  }
  
  var pageNum=pnElem.val();
 
 // if( searchingPosts ) return;
  
  if( !fresh && pageNum=="0"){
  	
   if( !toast_s_once){
     toast_s_once=true;
     toast('That is all for now.',{type: 'info'});
   } 
    return;
  }
    
  var s=$('#go-search-box');
  var text=$.trim( s.val());
  
  if ( !text ||text.length<3){
  return  toast('Search term too small.',{ type:'info'});
  }
    
  searchingPosts=true
var loader=$('#search-loading-indicator');
      loader.css('display','block');
     
 localStorage.setItem('go-social-posts-loading','1');
  WAIT_FOR_ME='search-post';
  
  connCounts++;
  
 spTimeout=setTimeout( function(){  
    spAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/search-post.php',
    type:'POST',
 //  timeout: 10000,
    dataType: "json",
    data: {
      "username": username,
      "s": text,
      "page": pageNum,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
   //alert(JSON.stringify(result))
      localStorage.removeItem('go-social-posts-loading');
     WAIT_FOR_ME=false;
      connCounts--;
      
      searchingPosts=false;
      loader.css('display','none');
  
  if( result.no_post ){
   return toast( result.no_post,{type:'info'});
  }
 else if( result.status=='success' ){
  // var settings=result.settings;   
   var nextPage=result.next_page;
   pnElem.val( nextPage);
 
     var posts= result.result;
    searchDiv.append( display_post(  posts) );            
  }
   else if(result.error){
      toast(result.error );
  }
   else toast('No more post.',{type:'info'});
      
 
 }).fail(function(e,txt,xhr){
     localStorage.removeItem('go-social-posts-loading');
     WAIT_FOR_ME=false;
     
     connCounts--;
     searchingPosts=false;
      
     loader.css('display','none');
  //toast('Connection error. ' + xhr, {type:'light',color:'#333'});
    if( $("#go-search-container").is(":visible")){
      spTimeout=setTimeout( function(){
     searchPosts(); },5000);
    }
  });
  },1000); 
  
  
}
 
 function sanitizeLink(link, link_title){
 	var link_=new Object();
   link_.link="";
   link_.link_title="";
   
if( link &&  link.indexOf("https://")==0)  {
    link=link.replace(/\s+/g,' ').substr(0,200) .replace(/</g,'&lt;').replace(/"/g,'&quot;');
    link_title=( link_title||link).substr(0,100).replace(/</g,'&lt;').replace(/"/g,'&quot;');
    link_.link=link;
    link_.link_title=link_title;
    return link_;
  }
  else{
     return link_;
  }
 }
 
 
function sendPost( post_title, post, post_by, fullname, post_bg){
	try{
		
  var is_sending=localStorage.getItem('go_is_sending_post');
  
 if( is_sending  ) return;

  var commentable=""; 
  var shareable="";
  var fdload="";
 if( $('#go-post-commentable').is(':checked')){
    commentable="1";
 }  
  if( $('#go-post-shareable').is(':checked')){
    shareable="1";
 }
  if( $('#go-file-downloadable').is(':checked')){
    fdload="1";
 }
  
 var rd= $('#go-repost-data').val();
  
  if( rd.length ){
    return go_repost( post, post_by, fullname, commentable, shareable, post_bg);
  }
    
  var fpaths=GO_UPLOADED_FILE_PATHS;
   var fpaths_="";
   var post_files="";
   var total_files=fpaths.length;
   var hasFiles=0;
  
  if( total_files){
   post_files= JSON.stringify( fpaths)
   hasFiles=1;
  }
  
 var link=$.trim( $('#go-link-input').val() );
 var linkTitle=$.trim($('#go-link-title-input').val());
  
 var link_=sanitizeLink(link, linkTitle);
  
  link=link_.link;
  linkTitle=link_.link_title;
  
  var post_preview=(post + "").substr(0, 250);
  var post_length=post.length;
  
  var meta=new Object();
      meta.pbf=fullname;
      meta.true_author= username;
      meta.plen=post_length;
      meta.shareable=shareable;
      meta.commentable=commentable;
      meta.total_files=total_files;
      meta.has_files=hasFiles;
      meta.post_bg=post_bg;
      meta.link=link;
      meta.link_title=linkTitle;
      meta.fdload=fdload;
  
 var meta_string=JSON.stringify( meta);
 var tbox=$("#post-title-box");
 
      connCounts++;
      localStorage.setItem('go_is_sending_post','TRUE')
      
 setTimeout( function(){
    
  $.ajax({
    url: config_.domain + '/oc-ajax/go-social/insert-post.php',

  type:'POST',
  // timeout: 45000,
    // dataType: "json",
    data: {
      "username": username,
      "post_by": post_by,
      "fullname": fullname,
      "post_title": post_title,
      "post": post,
      "post_meta": meta_string,
      "post_files": post_files,
      "has_files": hasFiles,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
   //alert(JSON.stringify(result))
   connCounts--;
  localStorage.removeItem('go_is_sending_post');
   $('#go-send-post-btn').prop('disabled',false);
   
  if( result.status=='success'){
 
 $('#go-link-input,#go-link-text-input,#post-title-box').val("");
 
   var pid=result.id;
 //  var settings=result.settings;

   var data=build_post( pid, post_title, post, post_by, fullname, post_preview, post_files, meta_string.replace(/</g,'&lt;') );
   
    $('.go-no-post').remove();
    
    $('#go-the-posts').prepend( display_post( data) );
    
   closeComposePage(true);
  toast( result.result,{type:'success'});
 }
  else if(result.error){
    toast( result.error );
  }
   else toast('Unknown error');
  closeDisplayData('.dummy-dummy');
  $('#post-progress').empty();
      
 }).fail(function(e, txt, xhr){
 	connCounts--;
  closeDisplayData('.dummy-dummy');
  $('#post-progress').empty()
   localStorage.removeItem('go_is_sending_post');
 $('#go-send-post-btn').prop('disabled',false);
  toast("Something went wrong");
  report__('Error "sendPost() in go-social.js"', JSON.stringify(e),true );

  });
  },1000);
  }catch(e){
  	toast(e)
  }
}


//REPOST

function go_repost( post, post_by, fullname, commentable, shareable, post_bg){
	
  var rd= $('#go-repost-data');
var pid=+rd.attr('data-pid');
var spid=+rd.attr('data-spid');
var notify=rd.attr('data-notify');
  
  if(!pid||!spid){
    closeComposePage(true);
   return toast('Id not found');
  }
 /*
 try{
  var settings= JSON.parse( localStorage.getItem("server_settings") );
  var adm= siteAdmin( username);
  
 }catch(e){ 
  return toast("Loading settings...", { type:"info"});
 }
 */
 
 var adm=siteAdmin( username);
 
var tbox=$("#post-title-box");
 
var post_title=$.trim( tbox.val() );

  if( SERVER_SETTINGS.enable_post_title=="YES"  ){
   
 if(!adm && !post_title ){
   	return toast("Input post title");
    }
   else if( post_title.length>150){
 return toast("Post title exceeded 150 characters");
    }
  }
  
   connCounts++;
   
 setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/repost.php',
    type:'POST',
  // timeout: 20000,
     dataType: "json",
    data: {
      "username": username,
      "post_by": post_by,
      "fullname": fullname,
      "post_title": post_title,
      "post": post,
      "post_id": pid,
      "share_pid": spid,
      "notify": notify,
      "post_bg": post_bg,
      "commentable": commentable,
      "shareable": shareable,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
 //  alert( JSON.stringify( result ) );
 connCounts--;
 
  $('#go-send-post-btn').prop('disabled',false);
  closeDisplayData('.dummy-dummy');
  $('#post-progress').empty();
 localStorage.removeItem('go_is_sending_post');
      
 if( result.status=='success' ){
   tbox.val("");
   closeComposePage(true);
   return toast("You reposted a post", {type:"success"});   
   
 }
    else if( result.error){
    toast( result.error);
  }else{
     toast('Unknown error occured.'); 
 }
  }).
    fail(function(e,txt,xhr){
    //alert(	JSON.stringify(e))
    connCounts--;
   closeDisplayData('.dummy-dummy');
  $('#post-progress').empty()
   localStorage.removeItem('go_is_sending_post');
 $('#go-send-post-btn').prop('disabled',false);
  toast("Something went wrong");     
  report__('Error "go_repost() in go-social.js"', JSON.stringify(e),true );
 
    
    });
    },1000);
      
 }
  


 var ajaxSinglePost,spTimeout;

function fetchSinglePost( pid, cpid, pby, callback){
	
 // cpid- Current post id: if the post is a shared post, pid is,
  //the shared post id while cpid is the id of current post that shared it
  
  if( ajaxSinglePost) ajaxSinglePost.abort();
   if( spTimeout) clearTimeout( spTimeout);
 
 connCounts++;
 
 spTimeout=setTimeout( function(){
   
   ajaxSinglePost=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/single-post.php',
    type:'POST',
  // timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "post_id": pid,
      "cpost_id": (cpid||""),
      "post_by": pby,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  	connCounts--;
  return callback( result);
 }).fail(function(e,txt,xhr){
 	connCounts--;
   callback(null, true, xhr);
   });
 },1000); 
  
  
}

var deleting_post=false;

function deletePost(pid, post_by, true_author){
 
 if(!pid||!post_by){
   return  toast('Missing parameters');
  }
 else if( deleting_post){
   return toast("Please wait",{type:"info"});
 }

     deleting_post=true;
          
     connCounts++;
  delpTimeout=setTimeout( function(){
   
    delpAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/delete-post.php',
    type:'POST',
   timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "post_by": post_by,
      "true_author": true_author,
      "post_id": pid,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  // alert(JSON.stringify(result));
   connCounts--;
   
      deleting_post=false;
  if( result.status=='success'){
   $('.go-post-container-' + pid).remove();
 }
  else if(result.error){
      toast( result.error );
  }
   else toast('Unknown error'); 
 }).fail(function(e,txt,xhr){
 	connCounts--;
      deleting_post=false;
 $('#go-send-post-btn').prop('disabled',false);
 toast("Something went wrong");     
  report__('Error "deletePost()" in go-social.js', JSON.stringify(e),true );
 
    
    });
  },1000); 
  
  
}
 

function build_post(pid, post_title, post, post_by, fullname,  post_preview, post_files, meta){
  var arr=[];
  var obj=new Object();
   obj.id=pid;
   obj.post=post;
   obj.reactions='{"like":0,"love":0,"laugh":0,"wow":0, "sad":0,"angry":0}';
   obj.post_title=post_title||"";
   obj.post_preview=post_preview;
   obj.post_by=post_by;
   obj.real_name= fullname;
   obj.post_date=moment().unix();
   obj.post_files=post_files;
   obj.post_meta=meta||"";
   
  arr.push(obj );
   return arr;
 }

function buildPostOptions( options){
 var data="";
  $.each(options, function(i,v){
 if( !v.display){ }
    else{
  data+='<div id="' + v.id + '" data-pid="' + v.pid + '" data-true-author="' + v.true_author + '" data-post-by="' + v.post_by+ '" data-pbf="' + v.pbf + '" class="container-fluid" style="font-weight: normal; padding: 10px 0; border-bottom: 1px solid rgba(0,0,0,0.16);overflow: hidden!important;">';
  data+='<div class="row">';
  data+='<div class="col h-50" style="max-width: 50px; text-align: center;">';
  data+='<img class="icon-medium" src="' + __THEME_PATH__ + '/assets/go-icons/' + v.icon + '">';
  data+='</div>';
  data+='<div class="col h-50">' + v.info + '</div>';
  data+='</div></div>';
 }
    });
return data;    
}


function home(){
    loadPosts(true);
}


function closeTopPageList(){
  clearTimeout( tloadingGoPages);
  if( loadingGoPages){
    loadingGoPages.abort();
  }
}


function openPages( reload){
 
function openPages_( result){
  var div='';
 
  $.each( result,  function(i, v){   
    var u=v.username;
    var n=v.fullname;
    
   var cv=checkVerified(u, n);
   var n_= cv.name + " " +  cv.icon;
 
  div+='<div class="container-fluid mt-1">';
  div+='<div class="row">';
  div+='<div class="col" style="padding-left:0; max-width: 60px;">';
  div+= go_user_icon( u, 'go-followers-user-icon');     
  div+='</div>';
  div+='<div class="col" style="padding-left: 0;">';
  div+='<div class="go-pages-lists-item go-open-profile" data-user="' + u + '" data-user-fullname="' + n + '">';
  div+= n_ ;
  div+='</div>';
  div+='</div>';
  div+='</div>';
  div+='</div>';
 
 });
  
return div;
   } 
  
  var data='<div class="center-header">';
      data+='<div class="container-fluid">';
      data+='<div class="row">';
      data+='<div class="col">';
    
  if( goAdmin( username) ){
      data+='<div class="mt-2" style="font-weight: normal; padding-left: 16px; font-family: gidole;"> Pages <button id="go-create-page" class="btn btn-sm btn-success" onclick="goOpenCreatePageForm();">+</button></div>';
    }else{
     data+='<div class="mt-2 pl-3">Pages</div>';
    }
  data+='</div>';
  
  data+='<div class="col pe-3 text-end">';
  data+='<img id="fetching-page-indicator" class="mt-2 mr-3 w-30 h-30" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png">';
  data+='</div>' 
  data+='</div>';
  data+='</div>';
  data+='</div>';
  
      data+='<div class="center_text_div text-left bg-white text-dark" style="border-radius: 5px; width: 100%; font-size: 14px; font-weight: bold; padding: 0 15px 0 15px;">';
      data+='<div id="go-top-pages-lists" class="text-left" style="padding-bottom: 50px;">';
      data+='</div>';
      data+='</div>';
  
 if( !reload) {
   displayData( data,
      { osclose: true, oszindex: 20, data_class:'.top-pages-lists', on_close:'closeTopPageList'});
     // changeHash("pages");
      
 }
  
  
 var elem=$('#go-top-pages-lists');
  
    var ind=$("#fetching-page-indicator");
  
 fetchPages( function(res,error){
   // alert( JSON.stringify(res))
   ind.remove();
  if( error){
    if ( res=='timeout' && $('.top-pages-lists').length){
       openPages( true);
  }else{
     if( res!='abort') toast('Check your network. ' + res);
    closeDisplayData('.top-pages-lists');
 }
  }else{   
  if( res.no_pages ){
    elem.html('<div class="text-center">No pages yet</div>');
    
 }else if( res.status=='success'){
   var result_=res.result;
   var settings=res.settings;

  var div=openPages_(result_)
      elem.html(div);
   
    } else if( result.error){
  toast( result.error );
 } 
  else{
   toast('Unknown error')       
    } 
    
   }    
  }, "ignore_static_page");
}


function goOpenCreatePageForm(){
  closeDisplayData('.top-pages-lists');
  $('#go-create-page-form-container').css('display','block');
  changeHash("create-page");
}


function fetchPages( callback, ignore_static){
  ignore_static=ignore_static||"";
  tloadingGoPages=setTimeout(function(){    
 
  loadingGoPages = $.ajax({
    url: config_.domain + '/oc-ajax/go-social/load-pages.php',   
   type:'POST',
  // timeout: 30000,
    dataType: "json",
    data: {
      "ignore_static_page": ignore_static,
      "username": username,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function( result){
   if( typeof callback=='function') {
     callback( result);
   }
  }).fail(function(e,txt,xhr){
 
 if( typeof callback=='function') {
   callback( xhr, e);
 }
 
 // android.toast.show("Something went wrong");     
  report__('Error "fetchPages()" in go-social.js', JSON.stringify(e),true );
   
    
});
 
  },1000);
}
  
  

function loadMenus(){
//  $('.app-label').html(APPLABEL);
  loadOthers();

if( goAdmin(username) ){
   $('#admin-panel-btn,#go-open-drafts-btn,#selected-photo-format').css('display','block');
 }
}


function loadOthers(){
	var first_launch=localStorage.getItem("first_site_launch");
	
  if(!first_launch){
	localStorage.setItem("xxxx_total_new_messages","1/1");
	localStorage.setItem("first_site_launch",1);
	}
	
  var fullname=userData('fullname');
  var v=checkVerified( username, fullname );
  var verified=v.icon;
  var fullname_= v.name + " " + verified;
  
  var Veri= verified; //userVerified( username);
 var can_uv=go_config_.upload_video;
 var can_up=go_config_.upload_photo;
  
 
 if(!can_uv && !can_up && !Veri){
  $('.go-upload-post-media-btn').css('display','none');
 }
  else if( !can_uv && !Veri){
  $('#go-up-vtext').css('display','none');
}
else if( !can_up && !Veri){
  $('#go-up-ptext').css('display','none');
}
    
  $('.go-user-fullname').html( fullname_ );  
  var path=config_.users_path + '/' + strtolower( username[0]+'/' + username[1] + '/' + username[2] + '/' + username ) + '/profile_picture_small.jpg?i=' + randomString(3)
  
  $('.go-user-icon-container').html( go_user_icon( username, 'my-photo-icon', path) ); 
  $('.go-user-open-profile').attr('data-user', username)
  .attr('data-user-fullname', fullname)

  var tnn= localStorage.getItem(username + '_total_new_notifications');
  if( tnn){
    tnn=tnn.split('/');
  $('#total-new-notifications').attr('data-total', tnn[0]).text( tnn[1] ).css('display','inline-block');
  }
 var tnm= localStorage.getItem("xxxx_total_new_messages");
  if( tnm){
    tnm=tnm.split('/');
  $('#total-new-messages').attr('data-total', tnm[0]).text( tnm[1] ).css('display','inline-block');
  }

 setTimeout(  function(){
  fetchNotifications();
 } , 20000);
  
 //  custom_pymk(); //DEFAULT PEOPLE YOU MAY KNOW
  
}

  function format_pymk(data, custom){
    custom=custom||"";
    
   var result='<div class="go-people-you-may-know bg-white">';
        result+='<div class="go-pymk-title follow-featur">Suggested for you</div>';
    result+='<div class="go-pymk-container">';
  var pymk_cnt=0;
    
    $.each( data, function(i,v){
    var user=v.username;
    var fullname=v.fullname;
 if( user!=username ){
    pymk_cnt++;
   var v=checkVerified( user, fullname);
   result+='<div class="go-pymk go-pymk-' + user + '">';
   result+='<div class="go-pymk-name-container">';
   result+= fullname;
   result+='</div><div class="go-pymk-vicon-container">' + v.icon + '</div>';
   result+='<div class="go-pymk-photo-container go-open-profile" data-user="' + user + '" data-user-fullname="' + fullname + '">';

  /*
  var path=config_.users_path + '/' + strtolower( user[0]+'/' + user[1] + '/' + user[2] + '/' + user ) + '/profile_picture_medium.jpg';
     
   result+='<div class="go-pymk-bg" style="background-image: url(' + path + '), linear-gradient(rgba(141,153,174,0.1), rgba(141,123,174,0.6) );"></div>';
 */

   result+=go_user_mphoto( user,  "go-pymk-image","pymk2.jpeg");
   
   result+='</div>';
   result+='<div class="go-pymk-follow-btn-container follow-feature">';
   result+='<button class="go-follow-btn go-sugg-follow-btn ' + custom + '" data-pin="' + user +'">Follow</button>';
   result+='</div>';
   result+='</div>';
   
 }
  });
  
  result+='</div>';
  result+='</div>';
    if( pymk_cnt<1 ){
   return "";
    }else
 return result;
  }


function custom_pymk(){
  var x= localStorage.getItem(username + '_custom_pymk');
  if( x) return;
  var data=[
    {"username":"pv_gosports","fullname":"Go Sports"},
    {"username":"pv_golaughs","fullname":"Go Laughs"},
    {"username":"pv_golove","fullname":"Go Love"},
    {"username":"pv_goentertain","fullname":"Go Entertainment"}
    ]
  var result=format_pymk( data, 'custom');
  $('#go-pymk-container').html( result);
}
  
function pymk_( data){
  if( !data ) return;

 var result=format_pymk( data);
 $('#go-pymk-container').html( result);
  
}


/*
function pymk(){
  //Stop if at least one custom pymk is not followed
    if( !localStorage.getItem(username + '_custom_pymk') ) return;
  
  if( loadingPosts ){
   setTimeout(function(){
     pymk();
   },2000);
    return;
  }
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/people-you-may-know.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "username": username,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
    // alert( JSON.stringify( result))
      
      if( result.total>0){
      pymk_( result.data);
      }
    }).fail(function(e,txt,xhr){
      //alert( JSON.stringify(e));
 //android.toast.show("Something went wrong");     
  report__('Error "pymk()" in go-social.js', JSON.stringify(e),true );
 
    });
    
  },2000);
  
}

*/

function openRightMenu(){
  $('#go-rmenus-container').removeClass('hide-rmenus');
}


$(function(){
 /*LOAD MENUS*/
  loadMenus()
  loadPosts();
  
  $('body').on('click','.go-show-follow-form-btn',function(){
  $('#go-follow-container').fadeIn();
       changeHash("follow-form");
   });
   
 $("#go-the-posts").on("click",".go-post-title", function(){
 	return false;
 });
 
  $("#go-the-posts").on("click",".ext-social-button", function(){
  	var this_=$(this);
   var site=this_.data("site");
   var account=this_.data("account");
 
if( site.match(/whatsapp/i)){
  var href="https://wa.me/" + account;
  }
  else  if( site.match(/telegram/i)){
  var href="https://t.me/" + account;
  }
  else  if( site.match(/tiktok/i)){
  var href="https://tiktok.com/@" + account;
  }
  else  if( site.match(/youtube/i)){
  var href="https://youtube.com/@" + account;
  }
  
  else{
 var href="https://" + site + ".com/" + account;
 }
   var data='<div class="center-header pt-2 ps-3"><small><img class="w-16 h-16" src="' + __THEME_PATH__ + '/assets/go-icons/info.png"> Social link</small></div><div class="pt-1 pb-3 ps-3 pe-3 center-text-div">';
  data+='<i class="fa fa-2x text-secondary fa-'+ site + '"></i> <a href="' + href + '" style="font-size: 13px; font-weight: bold;" target="_blank">  ' + href + '</a>';
  data+='</div>';
  
   displayData(data, { width: '80%', max_width:'500px',data_class: '.preview-link-div', osclose:true});
  
   
  });
 
/*
const ptr = PullToRefresh.init({
  mainElement: '#go-posts-column',
  onRefresh() {
    android.toast.show('fine')
  },
  shouldPullToRefresh(){
  var t=$('#go-posts-column').scrollTop();
    return !t;
}
});
*/
   
   
 $('#go-posts-column').on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() + $(this).innerHeight();
   
  if( !loadingPosts && scr >=  $(this)[0].scrollHeight-500) {
  
    loadingPosts=true;
    loadPosts();
    }
 });
  
  //SCROLL SEARCH PAGE
  $('#go-search-content').on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() + $(this).innerHeight();
   if( !searchingPosts && scr >=  $(this)[0].scrollHeight - 500) {
   searchingPosts=true;
     searchPosts();
   }
  });
  
 //SCROLL FOLLOWERS PAGE
 $('#go-followers-container .u-content').on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() +
 $(this).innerHeight();
   if( !loadingFollowers && scr >=  $(this)[0].scrollHeight-500) {
     loadingFollowers=true;
     loadFollowers();
    }
  }); 
  
   //SCROLL FOLLOWING PAGE
$('#go-following-container .u-content').on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() + $(this).innerHeight();
   if( !loadingFollowing && scr >=  $(this)[0].scrollHeight-500) {
     loadingFollowing=true;
     loadFollowing();
    }
  }); 
  
   //SCROLL BLOCKED FOLLOWERS PAGE
 $('#go-blocked-followers-container .u-content').on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() +
 $(this).innerHeight();
   if(!loadingBFollowers && scr >=  $(this)[0].scrollHeight-500) {
    loadingBFollowers=true;
     loadBlockedFollowers();
    }
  });
  
  
  //SCROLL NOTIFICATION PAGE
 $('#go-notifications-container .u-content').on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() +
 $(this).innerHeight();
   if(!loadingNotificationsPosts && scr >=  $(this)[0].scrollHeight-500) {
    loadingNotificationsPosts=true;
     openNotifications();
    }
  });
  
  
  
  //GO NICE LINK
  
$('body').on('click','.go-nice-link',function(e){
 
 var this_=$(this);  
 var link=this_.attr('href');
 var repost=this_.data("repost");
 
  if(!link){
    toast("Invalid link");
    return false;
  }
  else if( repost || link.indexOf("https://")<0){
 	return false;
 }
  
});
  
  
$('body').on('click press', '.go-nice-link-info', function(e) {
    var href=$(this).attr("data-link");
   var reg=new RegExp(DOMAIN_,"i");
  var  etype=e.type;
  if( etype=="press"){
 copyToClipboard(href.replace(/"/g,"") );
   }else{
   var data='<div class="center-header pt-2 ps-3"><small>' + ( href.match(reg)?'':'<img class="w-16 h-16" src="' + __THEME_PATH__ + '/assets/go-icons/info.png"> External link') + '</small></div><div class="pt-1 pb-3 ps-3 pe-3 center-text-div">';
  data+='<div style="font-size: 19px; font-weight: bold;">' + href + '</div>';
  data+='</div>';
  
   displayData(data, { width: '80%', max_width:'500px',data_class: '.preview-link-div', osclose:true});
  
   }
   return false;
});  
  
 //COPY POST CODES 
   
$('body').on('click','code',function(e){
 var this_=$(this);
  var target_=$(e.target);
  if(  target_.is("span")
     ||target_.is("a") ) {
    return;
  }
  
  var text_=( this_.html()||"").replace(/<br>/g,"\n");
  var code_=$("<div></div>").html(text_).text()||"";

    if(!code_) {
      return toast('Nothing to copy');
    }
    
    copyToClipboard(code_);
  /*  toast("Copied",{type:"success"});*/
   
   
  });
  
 $('body').on('input','#compose-post-box',function(){ 
  clearTimeout(composingTimeout);
   var this_=$(this);
   var txt=$.trim( this_.val() );
   var plen=txt.length;
 
 if( plen>100 ) {
   this_.removeClass('go-pbg-1 go-pbg-2 go-pbg-3 go-pbg-4 go-pbg-5 go-pbg-6 go-pbg-7 go-pbg-8 go-pbg-9 go-pbg-10');
   this_.attr("data-bg","");
  $('#go-post-bg-container').css('visibility','hidden');
  }
 else{
   $('#go-post-bg-container').css('visibility','visible');
    } 
   
composingTimeout= setTimeout( function(){
   localStorage.setItem("draft", txt);
   },1500);
 }); 
  
  
  //SEND POSTS
  
$('body').on('click','#go-send-post-btn',function(){
  var box=$('#compose-post-box');
  var post=$.trim( box.val()||"");
  var plen=( post.length+1)/1024;
  var mpl=go_config_.mpl;
  if( plen> mpl){
   return toast('Maximum post length exceeded (' + mpl + 'Kb)'); 
  }
  var post_bg=box.attr('data-bg'); //Post background
  var this_=  $(this);
     
 var post_by=username;
 var fullname=userData('fullname');
  
  if( goAdmin( username) ){
  post_by=$.trim( $('#go-post-by-pages').val())
  fullname=$("#go-post-by-pages option:selected").text();
  } 
 
 if(!post_by ){      
  return toast('Select page');
  } 
  
/*  try{
  var settings= JSON.parse( localStorage.getItem("server_settings") );
  var adm= siteAdmin( username);
  
 }catch(e){ 
  return toast("Loading settings...", { type:"info"});
 }
 */
 var adm= siteAdmin( username);
 
var post_title=$.trim( $("#post-title-box").val());
  if( SERVER_SETTINGS.enable_post_title=="YES"  ){
   	if(!adm && !post_title ){
   	return toast("Input post title");
    }
   else if( post_title.length>150){
 return toast("Post title exceeded 150 characters");
    }
 }
   
function progress(){
  if( !$('.dummy-dummy').length){
  setTimeout(function(){
  displayData("",{ dummy: true, data_class:'.dummy-dummy',osclose: false,no_cancel:true});
  $('#post-progress').html('<div id="post-progress-slider"></div>');
   },500);
  } 
 }
  
 if( GO_UPLOAD_FILE_PATHS.length>0 ){
   progress();
    this_.prop('disabled',true);  
  return goUploadFiles();
  }
  
  var rp=$('#go-repost-data').val();
   
 if( GO_UPLOADED_FILE_PATHS.length<1 && !post && !rp.length){
     closeDisplayData('.dummy-dummy');
   return toast('Nothing to send');
 }
   this_.prop('disabled',true);  
  progress();
    sendPost( post_title, post,  post_by, fullname, post_bg);
 });
   
  
  
  //OPEN SINGLE POST

$('body').on('click','.go-open-single-post',function(){
 var this_= $(this);
  
  if( this_.data("odeleted")){
    return toast("This content is not available");
  }
  var cpid=this_.data("cpid"); //Current post id,
  //- if the post is shared post, pid is id of the shared post while,
  //cpid is the id of the  post  that shared

  var pid= this_.data('pid');
  var pby= this_.data('post-by');
  
 this_.prop('disabled', true);
  
  var loader=$('#single-post-loading-indicator');
  loader.css('display','block');
 var cont=$('#go-single-post');
  cont.empty();
  var zi=zindex();
  $('#go-single-post-container').css({'display':'block', 'z-index': zi}); //z-index previous: 42
 // changeHash("post");
 
 var plink= osb_permalink(pid);
 
  window.history.pushState("data",  "null",  plink);
  
 fetchSinglePost( pid, cpid, pby, function( result,error,xhr){
   this_.prop('disabled', false );
   loader.css('display','none');
  // alert( JSON.stringify(result));
 if( error){
   cont.html('<div class="text-center"><button class="btn btn-small btn-secondary go-open-single-post" data-pid="' + pid + '" data-post-by="' + pby + '">Reload</button></div>');
  if( xhr!='timeout' && xhr!='abort') toast('Check your connection. ' + xhr);
  return;
 }else if( result.status=='success'){
 //  var settings=result.settings;

    var mf=result.me_following;
  
if( mf=="0"){     
 return  cont.html('<div class="text-center">Post is unavailable</div>');
 }
 
    cont.html( display_post( result.post, 'full') );
 }
  else if(result.error){
   var err_msg= result.error_message
   if( err_msg ){
      cont.html('<div class="container"><div class="alert alert-warning text-center">' + go_textFormatter( err_msg ) + '</div></div>' );
    }else toast( result.error );
  }
   else toast('Unknown error'); 
  });
  
});
  
   //POST PHOTO FULL
  
 $('body').on('click','.go-post-image',function(){
 var this_=$(this);
   if( this_.hasClass('reposted') ) {
   //This let original post to load first before any image is viewable
     return;
   }
   
  var allow_download=false;
  
  try{
    var settings= JSON.parse( localStorage.getItem("server_settings") );
 if( siteAdmin( username) || SERVER_SETTINGS.go_enable_download=="YES"){
      allow_download=true;
  }
  
 }catch(e){} 
   
   var parent=this_.parents(':eq(1)');
   var photos=parent.find('.go-post-image');
  var total= photos.length;
   
 // var sicont=$('#go-save-img-btn-cont');
 //  sicont.empty();
   var saveable= this_.attr('data-fdload');
  
  function savePhotoBtn(saveable, src, fsize, allow_dl){    
    if( saveable!='1' || !allow_dl) return "";
    
  return '<div class="mt-2 mb-2 text-center"><a href="' + src + '" class="save-media-btn save-image-btn" target="_blank" download>'  + readableFileSize( +fsize, true, 0) +  ' <img src="' + __THEME_PATH__ + '/assets/go-icons/save-media.png"></a></div>';
  }
   
   var height=this_.attr("height");
   var width=this_.attr("width");
   var fsize= this_.data("fsize");
   
  var img= this_.attr('src');
  var imgCont=$('#go-full-photo-div');
  var photo='<img onerror="go_postImgError(this);" alt="" class="lazy go-full-photo" height="' + height + '" src="' + __THEME_PATH__ + '/assets/go-icons/bg/transparent.png" data-src="' + img + '">';
 
   imgCont.html('<div id="go-fpd" class="absolute-center" style="min-width:100%; max-height: 100%; overflow-y: auto;"></div>');
   var imgCont2=$('#go-fpd');
   
   imgCont2.html( photo + savePhotoBtn( saveable, img, fsize, allow_download ));
   
  if(  total>1 ){
    photos.each( function(){
      var img_=this.src;
      if( img_!=img ){
   var height=this.getAttribute("height");
   var width= this.getAttribute("width");
   
    photo='<img onerror="go_postImgError(this);" alt="" class="lazy go-full-photo" height="' + height + '" src="' + __THEME_PATH__ + '/assets/go-icons/bg/transparent.png" data-src="' + img_ + '">';
    imgCont2.append( photo + savePhotoBtn(saveable,img_, fsize, allow_download) );
      }    
   });
  }
   
   var zi=zindex();
   $("#go-full-photo-container").css({"display":"block","z-index": zi});
   changeHash("photo");
  // android.webView.enableZoom(true);
   
 });
  
  
 $('body').on('click','.go-post-author-image',function(){
 var this_=$(this);
   
  var img= this_.attr('src');
   $('#go-full-photo-div').html('<img onerror="go_postImgError(this);" alt="" class="lazy go-full-photo" src="' + __THEME_PATH__ + '/assets/go-icons/bg/transparent.png" data-src="' + img + '">');
   var zi=zindex();
   $('#go-full-photo-container').css({"display":"block","z-index": zi});
   changeHash("photo");
 });
  
  //POST AUTHOR ICON FULL
  
$('body').on('click','.go-post-author-icon',function(){
   var this_=$(this);
   if( this_.hasClass('reposted') ) {
   //This let original post to load first before any image is viewable
     return;
   }
  var img= this_.attr('src');
   if(!img) return;
   var img   = replaceLast( img,'_small','_full');
   $('#go-full-photo-div').html('<div class="absolute-center" style="min-width: 100%;"><img onerror="go_postImgError(this);" alt="" class="lazy go-full-photo" src="' + __THEME_PATH__ + '/assets/go-icons/bg/transparent.png" data-src="' + img + '"></div>');
  $('#go-full-photo-container').css('display','block');
  changeHash("photo");
// android.webView.enableZoom(true);
});
  
  

//OPEN COMPOSE POST PAGE
  
$('body').on('click', '#open-compose-page-btn',function(){
 var zi=zindex();
 // $('#go-single-post-container') .css({'display':'block', 'z-index': zi}); //z-index previous: 42
  var fullname=userData('fullname');
  $('#compose-post-container').css({'display':'block','z-index': zi});
  changeHash("compose");
  var this_=$(this);
  
 if( siteAdmin(  username) ){
  var gpElem=$('#compose-post-container .go-pages');
 
if( !$('#compose-post-container #go-post-by-pages').length){
 var sdata='<div style="position: relative;">';
     sdata+='<div class="mt-1"><strong>Select page </strong></div>';
     sdata+='<select class="form-control mb-1 mt-1" id="go-post-by-pages"><option disabled selected>--Select a page--</option></select>';
     sdata+='<img id="go-cpage-loader" class="w-20 h-20" style="position: absolute; top: 35px; left: 45%;" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading3.png">';
     sdata+='</div>';
    
  gpElem.html( sdata);  
}
    var elem= $('#go-post-by-pages');  
  if( elem.hasClass('go-pages-loaded') ) return;
  
   $('#go-cpage-loader').css('display','block');
  
  if( elem.hasClass('go-pages-loading') ) return;
   elem.addClass('go-pages-loading');
   fetchPages( function(result, error){
       
  if( error ){
  
 setTimeout(function(){
   elem.removeClass('go-pages-loading');
   if( $('#compose-post-container').is(':visible') ){
        this_.click();
     }
 },5000);  
  
    
 }
     else{
  elem.removeClass('go-pages-loading');
       
 var o="";  
  if( result.no_pages ){
    $('#go-cpage-loader').css('display','none')
  toast('No pages yet')
   }
    else if( result.status=='success'){
      $('#go-cpage-loader').css('display','none');
      
      var static_page='<option value="" disabled>Static Pages</option>';
      
 $.each( result.result,  function(i, v){  
 	var puser=v.username;
 
if( goStaticPage( puser) ){
	static_page+='<option value="' + puser + '">' + v.fullname + ' *</option>';
	}else{
		
   o+='<option value="' + puser + '">' + v.fullname + '</option>';
   }
  });
 
  o+=static_page;
elem.addClass('go-pages-loaded').append( o);
  } else if( result.error){
  toast( result.error );
 } 
  else{
   toast('Unknown error')       
    }
  }
   });    
     
 }
 
  }); 
  
 $('body').on('click','.go-post-bg',function(){
 var this_=$(this);
  var bg=this_.data('bg');
  var box=$('#compose-post-box');
   box.removeClass('go-pbg-1 go-pbg-2 go-pbg-3 go-pbg-4 go-pbg-5 go-pbg-6 go-pbg-7 go-pbg-8 go-pbg-9 go-pbg-10');
  if( bg=='go-pbg-1') {
   return box.attr("data-bg","");
  }
   box.addClass(bg).attr('data-bg', bg);
 
 });
 
  
/*
  $("body").on("pointerdown","img",function(e){
 return false;
  });
  */
  
  /*POST OPTIONS*/
  
$('body').on('click','.go-post-options-btn', function(){
 var this_=$(this);
 var pid= this_.data('pid');
 var post_by=$.trim( this_.data('post-by'));
 var true_author=$.trim( this_.data('true-author') );
 
 var post_link=$.trim( this_.data("post-link") );

 var ptype=this_.data('post-type');
 var pbf=this_.data('pbf');
 var hide_author=this_.data('hide-author');
  
   var show=false;
   var fshow=true;
   var ashow=true; //Always show

if(username ){
  if( username==strtolower(true_author) ||
    (  goPage(username) && post_by==username) ){
    show=true; //Show if it's my post
    fshow=false; //Dont show if it's my post
  }
}
  
  if(ptype=='sponsored'){
    ashow=false;
    show=false;
  }
  
  var options=[
     {id:"go-show-edit-post-form-btn",icon:"edit.png",pid:pid,info:"Edit post", true_author: true_author, post_by: post_by, pbf: pbf, display: show }
    ,{id:"go-delete-post-btn",icon:"delete2.png",pid:pid, info:"Delete post", post_by: post_by, true_author: true_author,  pbf: pbf, display: show }
    ,{id:"osb-copy-post-link", icon:"link.png",pid:pid, info: "Copy link", post_by: post_by, true_author: true_author,  pbf: pbf, display: ashow }
    ,{id:"go-report-post", icon:"report.png",pid:pid, info: "Report post", post_by: post_by, true_author: true_author,  pbf: pbf, display: fshow }
    //,{id:"go-copy-post-btn", icon:"copy-b.png",pid:pid, info:"Copy post", post_by: post_by, true_author: true_author, pbf: pbf, display: ashow }
   ];
  
 if( hide_author=="NO"){
 
/*  options.unshift({ id:"go-save-post-btn",icon:"save.png",pid:pid,info:"Save post", post_by: post_by, true_author: true_author, pbf:pbf, display: ashow });
*/

  }

  var data='<div id="osb-post-option-data" data-post-link="' + post_link + '" class="center_text_div" style="width:100%; margin-top: 0; padding: 10px;">';
      data+=buildPostOptions( options);  
      data+='</div>';
  
  displayData(data, { width: '100%', max_width:'500px', oszindex:200,pos:'100',data_class: '.post-options-div', osclose:true});
  
 // changeHash("options");
 });
  
  $('body').on('click','#osb-copy-post-link', function(){
 var elem= $("#osb-post-option-data");
 var post_link=elem.data("post-link");
 
 var this_=  $(this);
 var pid= this_.data('pid');
 var post_by= this_.data('post-by');
 var true_author= this_.data('true-author');
  copyToClipboard( post_link );
   closeDisplayData('.post-options-div'); 
  });
  
  
  //OPEN EDIT POST FORM
  
$('body').on('click','#go-show-edit-post-form-btn', function(){
 var this_=  $(this);
 var pid= this_.data('pid');
 var post_by= this_.data('post-by');
 var true_author= this_.data('true-author');
  
 closeDisplayData('.post-options-div'); 
  
  var data='<div class="center-header">';
      data+='<div class="container-fluid"><div class="row">';
      data+='<div class="col p-0">';
      data+='<div style="width: 100%; white-space: nowrap; overflow-x: auto;"><button class="btn btn-sm btn-warning"  onclick="switchPostEditLayer(this);" data-layer="edit-post-text-div">Post</button> <button class="btn btn-sm btn-warning"  onclick="switchPostEditLayer(this);" data-layer="edit-post-title-div">Title</button>  ';
      
      data+='<button class="btn btn-sm btn-warning" onclick="switchPostEditLayer(this);" data-layer="edit-post-files-div">Media</button> ';
     data+='<button class="btn btn-sm btn-warning" onclick="switchPostEditLayer(this);" data-layer="edit-post-links-div">Link</button>'; 
      
data+='</div></div>';
data+='<div class="col p-0 text-end" style="max-width: 140px;"><img class="w-16 h-16" id="go-edit-post-loader" style="margin-right: 8px;" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"> <button id="go-edit-post-btn" class="btn btn-sm btn-info" data-pid="' + pid + '" data-post-by="' + post_by + '" data-true-author="' + true_author + '" style="border-radius: 0; width: 60px;" disabled="disabled">Save</button> ';

data+=' <button class="btn btn-sm btn-danger" onclick="closeDisplayData(\'.post-edit-div\');" style="border-radius: 0; width: 40px;">X</button> ';

data+='</div>';

data+='</div></div></div>';
  
      data+='<div id="edit-post-container" class="center-text-div bg-white" style="min-height: 220px; width:100%; margin-top: 0; padding: 10px;">';
      
      
     data+='<div class="post-edit-layer"  style="height: 200px; overflow: auto; display: none; position: relative;" id="edit-post-files-div"></div>';

     data+='<div class="post-edit-layer" style="height: 200px; overflow-x: auto; display: none; position:  relative;" id="edit-post-links-div">'
     
  data+='<div class="input-group mb-2"> <div class="input-group-prepend">  <span class="input-group-text bg-light text-center">Link</span></div> <input class="form-control" type="text" id="edit-post-link-box"> </div>';
  
  data+='<div class="input-group mb-2"> <div class="input-group-prepend">  <span class="input-group-text bg-light text-center">Title</span></div> <input class="form-control" type="text" id="edit-post-link-title-box"> </div>';
  
data+='</div>';

 data+='<div class="post-edit-layer" style="position: relative;" id="edit-post-text-div"><textarea id="go-post-edit-box" style="height: 200px; padding-bottom: 70px;" class="form-control" disabled="disabled"></textarea></div>';
 
 data+='<div class="post-edit-layer" style="height: 200px; overflow-x: auto; display: none; position:  relative;" id="edit-post-title-div">'
     
  data+='<div class="input-group mb-2"> <div class="input-group-prepend">  <span class="input-group-text bg-light text-center">Title</span></div> <input class="form-control" type="text" id="go-post-title-edit-box"> </div>';
    
data+='</div>';
 data+='</div>';
      
  displayData(data,{ width: '100%', max_width: '500px', oszindex:200, pos: '100', data_class:'.post-edit-div', osclose: false});
   //changeHash("edit-post");
  var loader=$('#go-edit-post-loader');
  loader.css('display','inline-block');
  
  setTimeout( function(){
    
  fetchFullPost( pid, post_by, true_author, function(s,e,xhr){
     loader.css('display','none');
 if (e){
   closeDisplayData('.post-edit-div');
  toast('Check your connection. ' + xhr);
 }else if( s && s.status=='success'){
  
   var box=$('#go-post-edit-box');
   var title_box=$('#go-post-title-edit-box');
 
   box.prop('disabled', false);
   $("#go-edit-post-btn").prop("disabled", false);
  var post= $('<div/>').html( s.post).text();
      box.val( post); 
     title_box.val( s.post_title.replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&amp;/g,"&")    );
     
 POST_FILES_EDIT=new Object();
      
 try{
  var post_files=s.post_files;
  var meta_= s.post_meta;

if(post_files){
  post_files= JSON.parse( post_files);
 
  var files="";
  
  $.each( post_files,function(i,v){
 var ext=v.ext;
var path=v.path;
var poster=v.poster;

var fid=randomString(7);
if( ext=="jpg"){

	POST_FILES_EDIT[fid]=v;
	files+='<div class="deep-edit-post-file d-inline-block mt-1" style="position: relative; margin-right: 5px; height: 100px; width: 100px;" data-fid="' + fid + '" onclick="goEditPostFile(this);">';
	files+='<div style="border: 0; border-radius: 5px; background: yellow;background-image:url(' + path + '); background-size: cover;  background-position: center; width: 100%; height: 100%;"></div></div>';
	
} else if( ext=="mp4" && poster){
	POST_FILES_EDIT[fid]=v;
	
    files+='<div class="deep-edit-post-file d-inline-block mt-1" style="position: relative; margin-right: 5px; height: 100px; width: 100px;" data-fid="' + fid + '" onclick="goEditPostFile(this);">';files+='<div style="border: 0; border-radius: 5px; background: yellow;background-image:url(' + poster + '); background-size: cover;  background-position: center; width: 100%; height: 100%;"></div><img src="' + __THEME_PATH__ + '/assets/go-icons/video.png" class="w-30" style="position: absolute; bottom: 0; left: 0; z-index: 10;"></div>';
  }
	
  });
 
$("#edit-post-files-div").html( files );
  
}       
         meta= JSON.parse( meta_);
  var smeta=JSON.stringify( meta);

  if( meta.repost ){
 $("#edit-post-files-div,#edit-post-links-div").addClass("d-none");
 }

  $("#edit-post-link-box").val( meta.link||"");
  $("#edit-post-link-title-box").val( meta.link_title||"");
  
var mdiv='<div class="bg-white" style="white-space: nowrap; border: 1px solid #f2f2f2; padding: 5px 10px; position: absolute; bottom: 0; width: 100%; overflow-x: auto;">';
    mdiv+='<div class="text-left" style="font-size: 11px; font-weight: bold;">Enable/disable buttons</div>';
   mdiv+='<textarea class="d-none" id="edit-post-meta-datas">' + smeta + '</textarea>';
   
   postEditMeta=smeta.replace(/&amp;/g, "&");
   
   var meta_editable={
     "commentable":"Comment",
     "shareable":"Share",
     "fdload":"File download"
   };
   
 $.each(meta,function(i,v){
   
   if(i in meta_editable){
     mdiv+='<div class="d-inline-block w-100 text-center">';   
     
     mdiv+='<div class="custom-control custom-checkbox" style="margin: 6px 12px;">';
     mdiv+='<input type="checkbox" class="custom-control-input go-edit-post-meta" id="go-edit-post-meta-' + i + '" data-key="' + i + '"' + ( v?' checked="checked"':'') + '">';
     mdiv+='<label class="custom-control-label" for="go-edit-post-meta-' + i + '">';
     mdiv+='<span class="d-block" style="font-weight: bold; font-size: 12px;">' + meta_editable[i] + '</span></label>';
     mdiv+='</div>';
     
     mdiv+='</div>';
     }   
  });
   
 mdiv+='</div>';
  $("#go-post-edit-box").after( mdiv);
 
 }catch(e){}
   
 }
  else if( s.error){
     toast(s.error);
    closeDisplayData('.post-edit-div');
 }else {
   closeDisplayData('.post-edit-div');
   toast('Unknown error occured.');
 }
    
  });
  },1000);
});
  

    //EDIT POST
  
$('body').on('click','#go-edit-post-btn',function(){
	
	
 var this_=  $(this);
 var pid= this_.data('pid');
 var post_by=this_.data('post-by');
 var true_author=this_.data('true-author');
  
  if( !pid ||!post_by){
    return toast('Missing parameters');
  }
  
 var box= $('#go-post-edit-box');
  
  var post_title=$.trim( $("#go-post-title-edit-box").val()||"");
  
/*  try{
  var settings= JSON.parse( localStorage.getItem("server_settings") );
  var adm= siteAdmin( username);
  
 }catch(e){ 
  return toast("Loading settings...", { type:"info"});
 }
 */
 var adm=siteAdmin( username);
 
if( SERVER_SETTINGS.enable_post_title=="YES"){ 

   if(!adm && !post_title){
	return toast("Input post title");
}
else if(  post_title.length>150){
 return toast("Post title exceed 150 characters");
}
  
  }
  var text=$.trim( box.val());
  var plen=text.length;
  
// var meta=$.trim( $("#edit-post-meta-datas").val() );
 var  meta=( postEditMeta||"{}");
  
  try{
    meta= JSON.parse(meta);
var has_files=meta.has_files;

var melem= $("#edit-post-container .go-edit-post-meta"); 
   
    melem.each( function(){
     var this_=$(this);
     var key=this_.data("key");
     meta[key]=this_.is(':checked')?1:0;
   });
    
    
  if( !("commentable" in meta)){
  	return toast("Something went wrong");
  }
   var link=$.trim( $("#edit-post-link-box").val()||"");
  var link_title=$.trim( $("#edit-post-link-title-box").val()||link );
  
  var link_=sanitizeLink(link, link_title);
  link=link_.link;
  link_title=link_.link_title;
 
   meta["link"]= link
   meta["link_title"]=link_title;
   meta["plen"]=plen ;
 
  }catch(e){
    return toast("Could not edit");
  }
  
  if( !plen && !has_files){
    return toast('Enter text')
  }
  
  var loader=$('#go-edit-post-loader');
  loader.css('display','inline-block');
  
  this_.prop('disabled',true);
  var fullname=userData('fullname');
  box.prop('disabled', true);
  
var post_files=[];
 var total_files=0;
 
if( !POST_FILES_EDIT.length ){
    
  $.each( POST_FILES_EDIT, function(key,value_){
	post_files.push( value_);
  });
  total_files=post_files.length;
  post_files=JSON.stringify( post_files);
  
}else{
   post_files="";
}
 
meta["total_files"]=total_files;
   var meta_string= JSON.stringify(meta);
 
  connCounts++;
   
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/edit-post.php',
    type:'POST',
  // timeout: 10000,
   dataType: "json",
   data: {
      "username": username,
      "post_by": post_by,
      "true_author": true_author,
      "post_id": pid,
      "post_title": post_title,
      "post": text,
      "post_files": post_files,
      "post_meta": meta_string,
      "fullname": fullname,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  //  alert(JSON.stringify(result))
  connCounts--;
  
 loader.css('display','none')
 this_.prop('disabled', false);
   box.prop('disabled', false);
  if( result.status=='success' ){

 var settings=result.settings;
 var post_preview=result.post_preview;

 closeDisplayData('.post-edit-div');

 var fullname=meta.pbf;
 
 var data=build_post( pid,  post_title, "" , post_by, fullname, post_preview,  post_files, meta_string.replace(/</g,'&lt;') );
 
    $('.go-post-container-' + pid ).html( display_post( data)  );   
 
 
 }
   else if(result.error){
      toast(result.error );
  }
   else{
    toast('Unknown error occured.', {type:'info'});
  }
 }).fail(function(e,txt,xhr){
 	connCounts--;
   loader.css('display','none');
  this_.prop('disabled', false);
   box.prop('disabled', false);
  toast("Something went wrong");     
  report__('Error "go-edit-post-btn" in go-social.js', JSON.stringify(e),true );
 
    });
    
  },1000);
  
 });
  
 $("body").on("press",".deep-edit-post-file",function(){
 
    if(!siteAdmin(username)) return;
   
   var this_=$(this);
   var fid=this_.data("fid");
 
 if(!fid) return;
   
  var file_data=POST_FILES_EDIT[fid];
   
 var data='<div class="center-text-div bg-white" style="width:100%; margin-top: 0; padding: 10px;">';
 
  $.each( file_data, function(key,v){
    data+='<div class="mb-2">' + key + '<textarea class="deep-edit-post-file-input form-control" data-key="' + key + '">' + v + '</textarea></div>';
   });
   
   data+='</div><div class="center-footer"><div class="mt-2" style="padding-left: 20px;"> <button data-fid="' + fid + '" id="save-deep-edit-post-file" class="btn btn-sm btn-primary">Done</button></div></div>';
  
 displayData(data,{ width: '100%', max_width: '500px', oszindex:250, pos: '100', data_class:'.deep-post-edit-div', osclose: true});
   //changeHash("deep-edit");
});
  
  
$('body').on('click','#save-deep-edit-post-file', function(){
  var this_=$(this);
  var fid=this_.data("fid");
 var obj=new Object(); 
 
  $(".deep-edit-post-file-input").each(function(){
   var v=$.trim( $(this).val()||"").replace(/"/g,"");
   var key=$(this).data("key");
   obj[key]=v;
 });
  
  POST_FILES_EDIT[fid]=obj
 
 toast("Done", {type:"success"});
 closeDisplayData(".deep-post-edit-div");
});

  //DELETE POST
  
$('body').on('click','#go-delete-post-btn',function(){
 var this_=  $(this);
 var pid= this_.data('pid');
 var post_by=this_.data('post-by');
 var true_author=this_.data('true-author');
  
  if( !confirm('Delete now') ) return;
  closeDisplayData('.post-options-div');
   deletePost(pid ,post_by, true_author );  
 });
  
    
$('body').on('click','.go-remove-upload-preview',function(){
   var this_=$(this);
   var fpath= this_.data('fpath');
   var contId=this_.data('cid');
   var findex= +this_.data('findex');
  
 GO_UPLOAD_FILE_PATHS =$.grep( GO_UPLOAD_FILE_PATHS, function(value) {
   return value != fpath;
 });
   
   $('#' + contId).remove();
   
  });
  
 
  //LOAD FULL POST
  
  $('body').on('click','.go-load-full-post', function(e){
  var this_=$(this);
  var pid=this_.data('pid');
  var post_by=this_.data('post_by');
  var true_author=this_.data('true_author');
    
    if( loadingFullPost) {
      return toast('Please wait.');
    }
 
   var target_=$(e.target);
    
   if(  target_.is("code")
      || target_.is("span")
      || target_.is("a")
 || target_.is("img")
 || target_.is("video")
  || target_.is("audio")  ){
     return; 
   }
 
  if( this_.hasClass("full-loaded") ) {
   
    var hdata= removebbCode( this_.html() );
    this_.html( go_textFormatter( hdata.substring(0, 200) ) + ' <span class="go-post-more-link">...See more</span>');
    this_.removeClass("full-loaded");
    return;
  }
    this_.prop('disabled',true);
  
    loadingFullPost=true;
   this_.addClass('go-load-full-post-loading');
    
 setTimeout( function(){
   
    fetchFullPost( pid, post_by, true_author, function(s,e,xhr){
    this_.prop('disabled', false);
      loadingFullPost=false;
      this_.removeClass('go-load-full-post-loading')
 if (e){
  if(xhr!='timeout'){
    toast('Check your connection');
  }
toast("Something went wrong");     
  report__('Error ".go_load-full_post" in go-social.js', JSON.stringify(e),true );
   
   
 }else if( s && s.status=='success' ){
    this_.html( go_textFormatter(s.post) );
    this_.addClass('full-loaded');
  }
   else if(s.error){
      toast(result.error );
  }
   else toast('Unknown error occured.');
   });
},1000);
 
  });
  
  
  //SHARE POST or REPOST
  
  $('body').on('click','.go-share-post-btn',function(){
  var this_=$(this);
  var pid=+this_.data('pid');
  var spid=+this_.data('share-pid')||0;
  var notify=this_.data('notify');
  var pbn=this_.data('pbn')||"";
  var spbn=this_.data('spbn')||"";
 
    var hl='<img src="' + __THEME_PATH__ + '/assets/go-icons/share.png" style="height: 20px; width: 20px; margin-right: 10px;">';
   
   if( spbn ){
     hl+="Repost " + pbn.toUpperCase() + "'s shared post";
   }
    else{
    hl+="Repost " + pbn.toUpperCase() + "'s post";  
   }
    
 if(  !pid ) return toast('Not an id.');
   
  var rdiv=$('#go-repost-highlight').html('<strong>' + hl + '</strong>') 
    $('#grh-container').css('display','block');
 
  $('#go-repost-data').attr('data-pid', pid)
   .attr('data-spid', spid).
   attr('data-notify', notify)
   .val('1');
    
  
 $('#compose-post-container .go-repost-hide').css('display','none');
// $('#compose-post-container').fadeIn();
  $('#open-compose-page-btn').click();
 
});
  
  //LIKE POST
  
$('body').on('click','.go-like-post-btn',function(){

 var isRunning=$("#is-running");
  
 if( isRunning.hasClass("liking-post") ){
   return toast('Please wait');
 }
  
  
  var this_=$(this);
  var pid=+this_.data('pid');
  var post_by=this_.data('post-by');
  var reacted_icons= $(".reacted-icons-container-" + pid);
  var rbc=$(".reactions-box-container-" + pid);

  rbc.empty();
  
  if( this_.hasClass("close")){
    return;
  }
               
  var reaction=this_.data("reaction")||"like";
  this_.prop('disabled',true);

  likePost(pid, post_by, reaction, function(result,error){
    this_.prop('disabled', false);
    
 if( error){
   return toast( error );
 }else if (result.status && result.status=='success'){
    reacted_icons.attr('data-reactions', JSON.stringify( result.result ) );
  }
   rbc.empty();
  });
});
  
$("body").on("click",".reacted-icons-container", function(){
  var data=$(this).attr("data-reactions");
  try{
 var json= JSON.parse( data);
  }catch(e){
   return toast("Not available");  
  }
  
    var div="";
 $.each( json, function(i,count_){
  if(count_){
    div+='<div class="container-fluid mt-2 ml-2 mr-2 mb-2">';
    div+='<div class="row">';
    div+='<div class="col-3"><strong>' + i.toUpperCase() + '</strong></div>';
    div+='<div class="col-5 text-center">';
    div+='<img class="w-18" src="' + __THEME_PATH__ + '/assets/chat-icons/reactions/' + i + '.png">';
    div+='<img class="w-18" src="' + __THEME_PATH__ + '/assets/chat-icons/reactions/' + i + '.png">';
    div+='<img class="w-18" src="' + __THEME_PATH__ + '/assets/chat-icons/reactions/' + i + '.png">';
    div+='</div>';
    div+='<div class="col-4 text-center"><strong>' + abbrNum( (+count_), 1) + '</strong></div>';
    div+='</div>';
    div+='</div>';
  }
});
  
  
  displayData( div,{ max_width:'300', data_class:'.view-reactions-div', osclose: true});
  
});
  
  $("body").on('press', '.go-like-post-btn', function(e) {
    //finger.js
    var this_=$(this);
  var pid=+this_.data('pid');
  var post_by=this_.data('post-by');
  var btn=$(".go-like-post-btn-" + pid);
  $(".reactions-box-container-" + pid).html( reactionsBox(pid, post_by) );
  changeHash("react");
  });
      
//PROFILE
  
$('body').on('click','.go-profile-cover-photo',function(){
 //View full cover photo
    var this_=$(this);
  if( !this_.hasClass('img-loaded')) return;

  var img= this_.attr('src');
  var cont=$('#go-full-cover-photo-container');
 var elem=$("#go-full-cover-photo");
  
  var bg=this_.attr('data-bg')||"rgba(0,0,0);";
 cont.attr("style","background-color:" + bg); 

  var rid=randomString(3);
 elem.html('<img id="' + rid + '" class="absolute-center w-30 h-30" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading3.png" data-src="' + img + '">')
  
cont.css('display','block');
changeHash("profile-photo");

  goFetchPhoto(img, function(idata,error){
    $('#' + rid).remove();
    if( idata) elem.html('<div style="min-width: 100%;" class="absolute-center"><img alt="" class="go-full-photo" src="' + idata + '"></div>');
 });
 
});
  
  
$('body').on('click','.go-open-profile, .go-user-open-profile', function(){
   var this_=$(this );
   var post_by=this_.data('user');
   var fullname=this_.attr('data-user-fullname');
   var hide_author=this_.data('hide-author');
  
//  if( hide_author==="YES") return;
  
 $('#go-current-opened-profile').val( post_by).attr('data-fullname', fullname);

  var zi=zindex();
  
setTimeout( function(){
  
  $('#go-profile-container').css({'display':'block','z-index': zi}); //44
  window.history.pushState("data",  "null",  DOMAIN_ +"/" + post_by);
  
//  changeHash("profile");
  
  $('#go-comment-container').css('z-index', zi-10);
  $('#go-rcomment-container').css('z-index', zi-5);
 
  //stackOrder('#go-profile-container');
 },200);
 
  $('#go-single-post-container').css('z-index', zi-15 );
 closeDisplayData('.top-pages-lists');
  
  if( $('#go-profile-page-' + post_by).length ){
 var ucont= $('#go-profile-page-' + post_by);

    go_profile(ucont,  post_by, fullname, 'no-load');   
   goLoadProfilePhoto(ucont, post_by)
   
      return;
    }
  
   this_.prop('disabled',true);
 
 var result=$("#go-profile-html-data").html();

   var ppage=$('<div class="go-profile-page" id="go-profile-page-' + post_by + '" data-t-once="0"></div>')
           .append( result);
           
   $('#go-profile-container') 
.append('<div class="u-shadow" onclick="goCloseProfile();"></div>')
     .append( ppage);
  
   var ucont= $('#go-profile-page-' + post_by );
      go_profile( ucont, post_by, fullname, 'load-once');
   goLoadProfilePhoto(ucont, post_by)
      this_.addClass('loaded');
      this_.prop('disabled', false);
//try{
//    var settings= JSON.parse( localStorage.getItem("server_settings") );
    var sa=siteAdmin( username)
  
 if(  !sa && SERVER_SETTINGS.go_enable_follow_btn=="NO"){
      ucont.find(".follow-feature").remove();
    }
 if( !sa && SERVER_SETTINGS.enable_chat=="NO"){
    ucont.find(".messenger-feature").remove();
  }
if( !sa && SERVER_SETTINGS.enable_send_chat=="NO" && !siteAdmin( post_by ) ){
   ucont.find(".messenger-feature").remove();  
  }
  
// }catch(e){}
    
  }); 
  

$('body').on('click','.post-chat-user,.group-chat-from', function(){
  //Check bbcode.js, displayMessage(group chat_from)
  var this_=$(this);
  var fuser= this_.data('fuser');
 if(!fuser) return;
      fuser=strtolower(fuser.replace('~','') );
  var fullname=fuser;

var pc= go_config_.page_contact;
  if( goPage( fuser) && pc){
    fuser= pc;
    fullname='Official';
  }
  
 
  if( fuser==strtolower( username) ){
     return toast("This is your account");
  }
  this_.prop("disabled", true);

   setTimeout( function(){
    openMessage();
   this_.prop('disabled', false);
 },500);
  
});
  

$('body').on('click','.go-profile-message-btn',function(){
 var this_=$(this);
  var elem=$('#go-current-opened-profile');
  var curr_user=elem.val();
  var fullname=elem.attr('data-fullname');
  
     
  if(!curr_user) {
     return toast('Account not found.');
   }
  
 var fuser= strtolower( curr_user);
  
  var pc= go_config_.page_contact;
  if( goPage( fuser) && pc){
    fuser= pc;
    fullname='Official';
  }  
  
  if( fuser==strtolower( username) ){
     return toast('This is your account.');
  }
  this_.prop('disabled', true);
  

   setTimeout( function(){
    openMessage();
   this_.prop('disabled', false);
 },500);
  
  });
  
  
  
//REPORT POST
  
  $('body').on('click','#go-report-post',function(){
 var this_=  $(this);
 var pid= this_.data('pid');
   
  var data='<div class="center-header">Why are you reporting this?</div>';
      data+='<div class="center_text_div bg-white" style="width:100%; padding: 10px;">';
      data+='<div class="form-text">E.g Fraud, Terrorism, False infomation, Spam, Impersonation, Nudity, Violence, Harassment, Hate speech e.t.c.</div>';
      data+='<div><textarea id="go-report-post-box" style="height: 100px;" class="form-control" placeholder="Tell us why it\'s inappropriate..."></textarea></div>';
      data+='<div class="mt-3 text-right">';
    //  data+='<img class="w-20 h-20" id="go-edit-post-loader" style="margin-right: 16px;" src="file:///android_asset/loading-indicator/loading2.png">';
      data+='<button id="go-report-post-btn" class="btn btn-sm btn-info" data-rid="' + pid + '" data-section="post">Report</button></div>';
      data+='</div>';
  closeDisplayData('.post-options-div');
  displayData(data,{ width: '100%', max_width:'500px', oszindex:200, data_class:'.report-post-div', osclose: false});  
});
   
  
  //SEND REPORT
  
$('body').on('click','#go-report-post-btn',function(){
 var this_=$(this);
  
  var fullname=userData('fullname')||username;
  var box=$('#go-report-post-box');
  var rid=this_.data('rid');
  var section=this_.data('section');
  var report=$.trim(box.val())
  if( report.length<2){
   return toast('Report not concise enough.');
  }
  report=report.replace(/[\r\n]{2,}/g," ");
 var total_words= report.split(' ');
  
  if( total_words.length > 15||report.length>150){
   return toast('Report too long. At most 15 words or 150 characters.');
  }
    
  this_.prop('disabled', true);
  box.prop('disabled', true);
  
  buttonSpinner(this_);
  connCounts++;
  
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/report.php',
    type:'POST',
   timeout: 40000,
     dataType: "json",
    data: {
      "username": username,
      "message": report,
      "report_id": rid,
      "section": section,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  //  alert(JSON.stringify(result))
  connCounts--;
 buttonSpinner(this_, true);
 this_.prop('disabled',false);
 box.prop('disabled', false);
  if( result.status=='success' ){
  toast( result.result,{type:"success"});
 closeDisplayData('.report-post-div');
 }
   else if(result.error){
      toast(result.error );
  }
   else{
    toast('Unknown error occured.', {type:'info'});
  }
 }).fail(function(e,txt,xhr){
 	connCounts--;
   buttonSpinner(this_, true);
  this_.prop('disabled', false);
   box.prop('disabled', false);
 toast("Something went wrong");     
  report__('Error "go_report_post_btn" in go-social.js', JSON.stringify(e),true );
 
    
  });
    
  },1000);
  
 }); 
  
  
  //FOLLOW
  
  $('body').on('click','.go-follow-btn',function(){
 var this_=$(this);
 
  var pin= $.trim( this_.attr('data-pin'));
  if(!pin){
    return toast('Pin not found.');
  }
   
    else if( go_config_.can_follow=='v' && !userVerified( pin)){
    return toast('Not allowed');
  }
    
    buttonSpinner(this_);
 this_.prop('disabled', true);
    
     connCounts++;
     
    setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/follow.php',
    type:'POST',
   timeout: 40000,
     dataType: "json",
    data: {
      "username": username,
      "pin": pin,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
    //alert(JSON.stringify(result))
    connCounts--
 buttonSpinner(this_, true);
 this_.prop('disabled',false);

  if( result.status=='success' ){
  toast( result.result,{type:"success"});
$('.go-follow-btn-' + pin)
   .removeClass('go-follow-btn')
   .addClass('go-unfollow-btn')
   .text('Following');
  $('.go-pymk-' + pin).remove();
  if( this_.hasClass('custom')){
    localStorage.setItem( username + '_custom_pymk','true')
  }
 }
   else if(result.error){
      toast(result.error );
  }
   else{
    toast('Unknown error occured.', {type:'info'});
  }
 }).fail(function(e,txt,xhr){
 	connCounts--;
   buttonSpinner(this_, true);
  this_.prop('disabled', false);
 // android.toast.show('Check your connection. ' + xhr);
  toast("Something went wrong");     
  report__('Error ".go-follow-btn" in go-social.js', JSON.stringify(e),true );
 
    });
      
    },1500);
    
  });
  
  //UNFOLLOW
  
$('body').on('click','.go-unfollow-btn',function(){
  var this_=$(this);
  var pin= $.trim( this_.attr('data-pin'));
  
  if(!pin){
    return toast('Pin not found.');
  }
    
    buttonSpinner(this_);
 this_.prop('disabled', true);
 
    connCounts++;
    
    setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/unfollow.php',
    type:'POST',
   timeout: 40000,
     dataType: "json",
    data: {
      "username": username,
      "pin": pin,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  //  alert(JSON.stringify(result))
  
  
  connCounts--;
 buttonSpinner(this_, true);
 this_.prop('disabled',false);

  if( result.status=='success' ){
  toast( result.result,{type:"success"});
 this_
   .removeClass('go-unfollow-btn')
   .addClass('go-follow-btn')
   .text('Follow');
 }
   else if(result.error){
      toast(result.error );
  }
   else{
   toast('Unknown error occured.');
  }
 }).fail(function(e,txt,xhr){
 	connCounts--;
   buttonSpinner(this_, true);
  this_.prop('disabled', false);
  toast("Something went wrong");     
  report__('Error ".go-unfollow-btn" in go-social.js', JSON.stringify(e),true );
 
    });
      
    },1500);
   });
 
 $('body').on('change','#go-page-post-order', function(){
 	 var this_=$(this);
 
  var uElem= $('#go-current-opened-profile');
   var user=uElem.val();
   var fullname=uElem.attr('data-fullname');
   
  var ucont= $('#go-profile-page-' + user);
   var pnElem=ucont.find('.go-profile-next-page-number');
  var pageNum=pnElem.val("");
      ucont.find('.go-profile-posts').empty();
   
  go_profile( ucont, user, fullname, 'load');
  });
  
   //FOLLOW BOX - SUGGESTION
$('body').on('input','#go-follow-box',function(){
    clearTimeout( fsuggestionsTimeout);
    
  var text=$.trim( $(this).val());
  if(!text||text.length<2) {
  $('#go-follow-suggestions').empty();
    return;
  }
  
  if( fsuggestionsAjax) fsuggestionsAjax.abort();
  
   var loader=$("#follow-suggestion-loader");
   loader.removeClass("d-none");
   
   
   connCounts++;
   
  fsuggestionsTimeout=setTimeout( function(){
  
  fsuggestionsAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/follow-suggestions.php',   
   type:'POST',
   timeout: 15000,
    dataType: "json",
    data: {
      "username": username,
      "pin": text,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  // alert( JSON.stringify(result) );
  connCounts--;
     var scont= $('#go-follow-suggestions');
  loader.addClass("d-none");
  if( result.error){
     toast( result.error);
   }
    else if( result.no_record){
     scont.html('<span class="d-block" style="margin-left: 16px;">"' +  result.no_record + '"</span>'); 
    }
    else if( result.status=='success'){
     
      var data='<div class="go-suggestions-container">';
           data+='<ul>';
      $.each(result.suggestions, function(i,v){
        var pin=v.username;
        var fullname=v.fullname;
         data+='<li>';
         data+='<div class="container-fluid"><div class="row go-open-profile" data-user="' + pin + '" data-user-fullname="' + fullname + '">';
         data+='<div class="col p-0" style="max-width: 50px;">';
         data+='<div class="go-follow-sugg-icon-container middle">' + go_user_icon(pin, 'go-follow-sugg-icon') + '</div>';
         data+='</div>';
         data+='<div class="col">';
         data+='<div class="go-follow-suggested-name">' + fullname + '</div>';
         data+='<div class="go-follow-suggested-pin"><span>' + pin + '</span></div>';
         data+='</div>';
         data+='</div></div>';
          data+='</li>';
        });
        data+='</ul>';
        data+='</div>';
   scont.html(data);
      
 }else{
   scont.empty();
 }
      
  }).fail( function(e,txt,xhr){
  	connCounts--;
  	loader.addClass("d-none");
  toast("Something went wrong");     
  report__('Error "#go-follow-box" in go-social.js', JSON.stringify(e),true );
 
  });
    
  },1500);
});

//Save Post
  
  $("body").on("click","#go-save-post-btn", function(){
       goSavePost(this); 
    
  });  
  
$("body").on('click', '#go-settings-container .dropdown-menu', function (e) {
	  e.stopPropagation();
});
  
$('body').on('click','#show-console-log',function(){
   var opacity=+$(this).css("opacity");
   if(opacity<1) return;
   var cl=$('.console-log');
  
    if(cl.is(':visible') ) {
      cl.hide();
      $(this).css("opacity",0);
    }
    else{
 cl.fadeIn();
  changeHash("console");
 }
  });
     
 $('#show-console-log').on('press', function(e) { 
      $(this).css("opacity",1);
});
   
 
});

function switchPostEditLayer(t){
	var layer=$(t).data("layer");
	$("#edit-post-container .post-edit-layer").css("display","none");
 $("#" + layer).css("display","block");
}

function goEditPostFile(t){
	var this_=$(t);
	var fid=this_.data("fid");
	if(!fid)  return toast("File id not found");
	if(!confirm("Remove file?")) return;
	
 delete POST_FILES_EDIT[fid];
	this_.remove();
}
	
function likePost(pid, post_by, reaction, callback){
  
  if(!pid ) {
    return callback("", "Not an id.");
  }
  
  var isRunning=$("#is-running");
  
 if( isRunning.hasClass("liking-post") ){
   return toast('Please wait.');
 }


 var likes=$('.total-likes-' + pid);
 var likes2=$('.top-total-likes-' + pid);
  
 var curr_likes=+likes.attr('data-total-reactions');
 var curr_icon_= $('.go-like-post-icon-' + pid);
 
var curr_icon=curr_icon_.attr('src');
      
  var type=1;
  var clikes=curr_likes+1;
  var reaction_="";
 
 var pliked=postLiked( pid);

 if(  pliked){
   //If file exists, then post is previously liked 
    type=2;
    reaction_=pliked;
 
 if( reaction_ ==reaction){ 
  var clikes=curr_likes-1;
  curr_icon_.attr("src", __THEME_PATH__ + "/assets/chat-icons/reactions/like-empty.png");
   //curr_icon.replace('liked.png','like.png'));
 }else{
   type=1;
   clikes=curr_likes;
   curr_icon_.attr('src', __THEME_PATH__ + '/assets/chat-icons/reactions/' + reaction + '.png');
  } 
}
else{
   curr_icon_.attr('src', __THEME_PATH__ + '/assets/chat-icons/reactions/' + reaction + '.png');
}
 
 
   likes.text( abbrNum(clikes, 1) );
  likes.attr("data-total-reactions", clikes);
    
  var fullname=userData("fullname");
  isRunning.addClass("liking-post");

    connCounts++;
  
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/like-post.php',
    type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
      "username": username,
      "fullname": fullname,
      "post_id": pid,
      "post_by": post_by,
      "preaction": reaction_,
      "reaction": reaction,
      "type": type,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
 // alert(JSON.stringify(result))
 connCounts--;
      isRunning.removeClass("liking-post");
     
     callback( result, result.error);     
 
 if( result.status=='success' ){
 	
 if( type==2){
      removePostLike(pid);
   $(".go-like-post-btn-" + pid).removeClass("go-post-liked");
   }else{
  storePostLike(pid, reaction); 
  $(".go-like-post-btn-" + pid).addClass("go-post-liked");
      }
 }
   else if(result.error){
  
  likes.text( abbrNum( curr_likes, 1) );
  likes.attr("data-total-reactions", curr_likes)
  curr_icon_.attr("src", curr_icon);
      
  }
   else{
    curr_icon_.attr('src', curr_icon);
     toast('Unknown error occured.',{type:'info'});
   }
 }).fail(function(e,txt,xhr){
 	connCounts--;
   isRunning.removeClass("liking-post");

  callback("", "Something went wrong");
  // clikes=clikes-1;
  likes.text( abbrNum(curr_likes, 1) );
  likes.attr('data-total-reactions', curr_likes);
  curr_icon_.attr('src', curr_icon);
             
  report__('Error "likePost()" in go-social.js', JSON.stringify(e),true );
 
  });
    
  },1000);
  
  
}



function reactionsBox(pid, post_by){
  var reactions=["like","love","wow","laugh","sad","angry"];
  $(".reactions-box").remove();
  var data='<div class="container reactions-box">';
  data+='<div class="row">';
  data+='<div class="col go-like-post-btn close" data-pid="' + pid + '"><img class="h-20 w-20" src="' + __THEME_PATH__ + '/assets/chat-icons/reactions/hide.png"></div>';
  $.each( reactions, function(i,v){
  	
  data+='<div class="col go-like-post-btn" data-reaction="' + v + '" data-pid="' + pid + '" data-post-by="' + post_by + '">';
  data+='<img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/chat-icons/reactions/' + v +  '.png">';
  data+='</div>';
  });
  data+='</div>';
  data+='</div>';
  
  return data;
  }    
  
  
  function fetchFullPost( pid, post_by, true_author, callback){
  
  connCounts++;
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/open-full-post.php',
    type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
      "username": username,
      "post_by": ( post_by||""),
      "true_author": ( true_author||""),
      "post_id": pid,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
 // alert(JSON.stringify(result))
      connCounts--;
   if(callback) callback( result);  
     
 }).fail(function(e,txt,xhr){
 	connCounts-
    callback(false,true,xhr);
//  android.toast.show("Something went wrong");     
  report__('Error "fetchFullPost()" in go-social.js', JSON.stringify(e),true );
 
  });
}    
  
function viewOriginalPost(){
  var cpi=$('#current-post-id');
  var pid=cpi.val();
    cpi.val("");
 
 if( !pid){ 
    return toast('Post id not found');
 }
  var elem=$('<div/>').addClass('go-open-single-post')
      .attr('data-pid', pid);
    elem.appendTo('body').click();
 goCloseCommentReply();
}



function goChangePageType(t){
	var this_=$(t);
	var selected=this_.val();
$('#create-page-selected-type').text( selected);
$('.page-type-info').css('display','none');
$('#' + selected + 'info').css('display','block');
	
}


//Create page

function goCreatePage(t){   
    var this_=$(t);
      
 try{
  var type= $('#go-create-page-type').val();
if( type.length<3) {
	return toast('Select page type');
	}
   
   var cppin= $.trim($('#cp-pin').val()||"" );
  var cpemail= randomString( 15) + '@gmail.com';

 var cpfullname= $.trim( $('#cp-fullname').val());
var cpbio= $.trim($('#cp-bio').val() );

var cpphone=$.trim( $('#cp-phone').val() );
var cppassword=$.trim($('#cp-password').val() );
     
  if( !cppin || cppin.length<4 || cppin.length>20) {
    return toast('Page pin too long or short. Max: 20');

   }else if( !validUsername(cppin) ) {
   return toast('Invalid pin. Alphanumerics, an underscore supported and must start with a letter.');
   }

else if(!cpfullname || cpfullname.length<2 || cpfullname.length>60) {
     return toast('Enter a valid display name or title.');
   }
else if( !validName(cpfullname) ){
     return toast('Enter a good display name or title. Must start and end with a letter.');    
    }
else if( !cpbio ){
     return toast('About page should not be empty.');    
    }

  else if( !cpemail || cpemail.length<5 ) {
     return toast('Enter a valid email address.');    
   }
   
else if( cpphone && !cpphone.match(/^[0-9+() -]{4,50}$/) ) {
     return toast('Enter a valid phone number.');    
  }

  else if(!cppassword ||cppassword.length<6) {
   return toast('Password should contain at least 6 characters.');    

  }
    else if(cppassword.length>50) {
    return toast('Password too long. Max: 50.');    
    }    
    else if( !validPassword(cppassword) ){
     return toast('Passwords can only contain the following characters: a-z 0-9 ~@#%_+*?-');
    }
    $('input,button').prop('disabled',true);
   buttonSpinner(this_);
 var elem=$('#go-create-page-form input,#cp-bio');

  connCounts++;

    $.ajax({
      'url': config_.domain + '/oc-ajax/go-social/add-new-page.php',
    type:'POST',
   dataType: 'json',
      'data':
      {
       "username": username,
       "type": type,
       "pin": cppin,
       "email": cpemail,
       "fullname": cpfullname,
       "bio": cpbio,
       "phone": cpphone,
       "password": cppassword,
       "token": __TOKEN__,
      },
      type:'POST'
    }).done(function(result){
 // alert(result)
 connCounts--;
   buttonSpinner( this_, true);
   $('input,button').prop('disabled', false);
      
  if(result.error){

 toast(result.error);
}
 else if( result.status ){
  elem.val('');
 $('#go-post-by-pages').removeClass('go-pages-loaded');
 $('#compose-post-container .go-pages').empty();
   
   toast( result.result ,{type:'success'});
 
   } else{
    toast('Unknown error occured.');
      }
            
    }).fail(function(e, txt, xhr){
    connCounts--;	
      $('input,button').prop('disabled',false);
      buttonSpinner(this_,true);   
   toast("Something went wrong");     
  report__('Error "goCreatePage()" in go-social.js', JSON.stringify(e),true );
 
    });
}catch(e){ toast(e); }
  
}


function goLoadProfilePhoto(ucont, user){
	
var ptoken=randomString(15);
  //Photo token changes when user photo is uploaded
   
var pimg_path=config_.users_path + '/' + strtolower( user[0] + '/' +user[1] +'/' + user[2] + '/' + user )+ '/profile_picture_full.jpg?i=' + ptoken;

  var coverImg= ucont.find('.go-profile-cover-photo');
  var coverImgCont=ucont.find('.go-profile-cover-photo-container');
  var img=ucont.find('.go-profile-photo');
 
 if(!img.hasClass('img-loading') && !img.hasClass('loaded') ){  
  var imgCont=ucont.find('.go-profile-photo-container');
      imgCont.attr('data-user', user);
    
 img.on('load', function(){
   var rgb=getAverageRGB( this);
   $(this).addClass('img-loaded').removeClass('img-loading');  
   coverImg.attr('data-bg', rgb);
   coverImgCont.attr('style','background-color: ' + rgb);
 }).on('error', function(){
   $(this).removeClass('img-loading');
 });
 
 img.addClass('img-loading');
 img.attr('src', pimg_path.replace('_full.jpg','_small.jpg') )
}
    
 if( !coverImg.hasClass('img-loading') && !coverImg.hasClass('img-loaded')){
   var rid=randomString(3);
   coverImgCont.append('<img id="' + rid + '" class="absolute-center w-30 h-30" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading3.png">');
 
coverImg.addClass('img-loading');
 connCounts++;

 setTimeout(function(){
  
 goFetchPhoto( pimg_path, function(idata,e){
 	connCounts--;
    $('#' + rid).remove();
    coverImg.removeClass('img-loading');
   if( idata){
     coverImg.attr('src', idata).addClass('img-loaded'); 
     
  return;
   }
   
var reloadBtn=$('<button id="go-pphoto-reload-btn-' + user + '" class="btn btn-sm  absolute-center bg-none"><img src="' + __THEME_PATH__ + '/assets/go-icons/refresh2.png" class="w-30 h-30"></button>')
   .on('click', function(){
   localStorage.setItem('go_photo_token', rid);
  
     goLoadProfilePhoto(ucont, user);
     $(this).remove();
   });
    
 coverImgCont.append(reloadBtn);
    
   });
  },2000);
 
 }
}


var gpAjax,gpTimeout;

function go_profile(ucont,  user, fullname_, type){
  clearTimeout( gpTimeout);
 var adm=siteAdmin(username);
 fullname=fullname_||user;
 
  $(".go-profile-page").css("display","none");
  var toast_p_once= +ucont.attr("data-t-once");

  var veri=checkVerified(user, fullname);
  var verified=veri.icon;
     fullname= veri.name;
  var fullname_=fullname + " " + verified;
  
 var nameCont=ucont.find(".go-profile-fullname");
  nameCont.html( fullname_ ).attr("data-name", fullname);
 
 var fbtn= ucont.find('.go-profile-follow-btn');
 
 ucont.find(".go-profile-user-pin").text( user);
 
 fbtn.addClass("go-follow-btn-" + user).attr("data-pin", user);
  
  var me=false;
  
 if( user==username){
    me=true;
  }
 
  var static_page=goStaticPage( user);
  
  if( static_page){
  	ucont.find(".followership-info").remove();
  }
  
  var uformBtn=ucont.find('.go-profile-update-form-btn');
  var fmCont=ucont.find('.go-profile-message-follow-btn-container');
  
  var emailElem=ucont.find('.go-profile-email');
  var countryElem=ucont.find('.go-profile-country');
  var bioElem= ucont.find('.go-profile-bio');
  var joinedElem=ucont.find('.go-profile-joined' );
  var phoneElem=ucont.find('.go-profile-phone');
  var birthElem=ucont.find('.go-profile-birth');  
 
  var totalFgElem=ucont.find('.go-total-following');  
  var totalFwElem=ucont.find('.go-total-followers');  
  

 if( me || (adm && goPage( user) ) ){
    uformBtn.css("display","inline-block");
 }

   ucont.css('display','block');
  
  var pnElem=ucont.find('.go-profile-next-page-number');
  var pageNum=pnElem.val();

  if( pageNum=="0"){
     if(!toast_p_once){
  ucont.attr('data-t-once','1');
 //  toast('No more posts!',{type: 'info'});
 }
   return;
  }
  
//  try{
//  var settings= JSON.parse( localStorage.getItem("server_settings") );
 
 if( SERVER_SETTINGS.go_can_post!="3" && !goPage( user)  ){
   fbtn.remove();
  } 
    
/* }catch(e){ 
  return toast("Loading settings...", { type:"info"});
 }
*/
  
 if ( type=='load'||
     type=='load-once'||
    type=='load-failed-reload'||
    pageNum==""){

   loadingProfilePosts=true;
 
    WAIT_FOR_ME='profile';
   
 var loader=ucont.find('.profile-posts-loading-indicator');
  loader.css('display','block');
   
   if( gpAjax){
     gpAjax.abort();
   }
  
  var post_order=$('#go-page-post-order').val();
   
    connCounts++;
   
   gpTimeout=setTimeout( function(){  
  gpAjax= $.ajax({
    url: config_.domain + '/oc-ajax/go-social/profile.php',
    type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
      "username": username,
      "user": user,
      "page": pageNum,
      "post_order": post_order,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
//   alert(JSON.stringify(result)) 
  connCounts--;
 loadingProfilePosts= false;
 WAIT_FOR_ME=false;
   loader.css('display','none');
   
 if( result.not_found ){
      pnElem.val("0");
   return toast( result.not_found, {type:'info'});
  }
    else if( result.no_post ){
   pnElem.val("0");
 
  if( me){
  
	ucont.find(".go-profile-camera-icon").css("display","block");
    uformBtn.prop('disabled', false);
} 
else if( adm && goPage(user ) ) {
	
   ucont.find(".go-profile-camera-icon").css("display","block");
 }         
   return toast( result.no_post, {type:'info'});      }
 else if( result.status=='success' ){
   var settings=result.settings;

   var real_name=result.real_name||"";
   nameCont.html( real_name ).attr("data-name", real_name);

   var country=result.country||"";
   var birth= result.birth||"";
   var bio=result.bio||"";
   var email=result.email||"";
   var phone=result.phone||"";
   var joined=result.joined_on||"";
   
  if( country){
    countryElem.text( country ).css('display','block');
  }
 
if( email){
   emailElem.text( email );
  }  
   
 if( bio){
   bioElem.html( bio ).css('display','block');
 }
   
 if( joined){
   var date=new Date( joined);
  joinedElem.attr('data-joined', joined).text( date.format("mmmm yyyy") );
   if(!goPage(user) ){
     joinedElem.css('display','block');
   }
 }
 
  if( phone) {
    phoneElem.text(  phone).css('display','block');
  }
   
   if( birth){
    var birth_=new Date( birth);
   birthElem.attr('data-birth', birth).text(  birth_.format("mmmm dd") ).css('display','block');
   }
     
 totalFgElem.html('<strong>' + abbrNum( +result.total_following,1) + '</strong><small> following</small>');
 totalFwElem.html('<strong>' + abbrNum( +result.total_followers,1) + '</strong><small> followers</small>');
  
   var following=result.me_following;
  
 if( me){
	ucont.find(".go-profile-camera-icon").css("display","block");
   uformBtn.prop('disabled', false);
}
 else
 {
  
  if( following=="1"){    
  fbtn.removeClass('go-follow-btn').addClass('go-unfollow-btn').text('Following').prop('disabled',false);
   }else if(following==null ){
  fbtn.removeClass('go-unfollow-btn').addClass('go-follow-btn').text('Follow').prop('disabled',false);
 
  if( goAdmin( user) ||goStaticPage( user) ) {
    fbtn.css('display','none');
  }
   
 if( adm && goPage(user ) ) {
 ucont.find(".go-profile-camera-icon").css("display","block");
 }

   }
 
 if( following!="0"){
     //If not blocked
   fmCont.css('display','block');
  }
 
 if( adm && goPage(user)){
   uformBtn.prop('disabled', false);
  }  
 }
   var posts_stadium=ucont.find('.go-profile-posts');
   
 if( following=="0"){
    posts_stadium.html('<div class="text-center">No post to display</div>');
  ucont.find('.go-profile-message-btn').css('display','none');
     return pnElem.val("0");
 }
 
  var has_post=result.has_post;
  
if( has_post && has_post >0 ){
  
  var nextPage=result.next_page;
   pnElem.val( nextPage);
   var posts= result.result;
     posts_stadium.append( display_post(  posts) ); 
   }else{   
   pnElem.val("0");
   return toast('No post yet', {type:'info'});
  }
      
if(type=='load-once' ){

  $('#go-profile-page-' + user).on('touchstart scroll mouseover', function() {
   var scr=$(this).scrollTop() + $(this).innerHeight();
   if(!loadingProfilePosts &&scr >=  $(this)[0].scrollHeight-500) {
      loadingProfilePosts=true;
    go_profile( ucont, user, fullname, 'load' );
    }
  });
}
 
 }
   else if(result.error){
     toast(result.error );
  }
   else{
     toast('No more post.');
   }
      
 
 }).fail(function(e,txt,xhr){
 	connCounts--;
      loadingProfilePosts =false;
    WAIT_FOR_ME=false;
      loader.css('display','none')
  //toast('Connection error. ' + xhr, {type:'light',color:'#333'});
  if( txt!='abort'){
    gpTimeout=setTimeout(function(){
       go_profile( ucont,user, fullname_, 'load-failed-reload' );
     }, 4000);
  }
  });
  
 },1500);
  }
 }

function viewProfileUpdateForm(){ 
  var zi=zindex();
 $('#go-profile-update-container').css({'display':'block','z-index': zi}); 
 changeHash("edit-profile");
 
  var user=$('#go-current-opened-profile').val();
  if(!user){
    return toast('Profile not found');
  }
 var cont=$('#go-profile-page-' + user);
  var bio=$.trim(cont.find('.go-profile-bio').text());
  var location=$.trim( cont.find('.go-profile-country').text());
  var phone=$.trim( cont.find('.go-profile-phone').html() );
  var birthElem= cont.find('.go-profile-birth');
  var birth=birthElem.attr('data-birth');
  var name= $.trim( cont.find('.go-profile-fullname').attr('data-name') );
  //userData('fullname');
  
  if( birth){
    birth=birth.split(' ')[0];
  }
  
  $('#go-update-name-box').val( name );
  $('#go-update-bio-box').val(bio);
  $('#go-update-location-box').val(location);
  $('#go-update-phone-box').val(phone);
  $('#go-update-birth-box').val( birth||"");

}

var upAjax;

function goProfileUpdate(t){
 var this_=$(t);
  var name=$.trim( $('#go-update-name-box').val());
  var bio=$.trim( $('#go-update-bio-box').val());
  var location=$.trim( $('#go-update-location-box').val());
  var phone=$.trim( $('#go-update-phone-box').val());
  var birth=$.trim( $('#go-update-birth-box').val() );
  
 bio= bio.replace(/\s+/g,' '); 
  
  if( !validName( name)){
  return toast('Enter a good name.');
  }
  else if( bio.length>200){
    return toast('Bio too long. Max 200 characters.')
  }
  else if(phone.length>0 && !phone.match(/^[\+\d]?(?:[\d-.\s()]*)$/) ){
    return toast('Invalid phone number.');
 }
  else if( location.length> 100){
  return toast('Location too long.');  
  }
  else if ( birth.length && !birth.match(/^[0-9\/_-]+$/)){
  return toast('Invalid date of birth.');                                     
  }
 
  var pin=$.trim( $('#go-current-opened-profile').val());
  
  if(!pin){
    return toast('Profile not found');
  }
  
 var cont=$('#go-profile-page-' + pin);
  this_.prop("disabled", true);
  
  buttonSpinner( this_);
  
  connCounts++;
  setTimeout( function(){
  	
  upAjax= $.ajax({
    url: config_.domain + '/oc-ajax/go-social/update-profile.php',
    type:'POST',
   //timeout: 40000,
    dataType: "json",
    data: {
      "username": username,
      "pin": pin,
      "name": name,
      "bio": bio,
      "location": location,
      "phone": phone,
      "birth": birth,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  //alert(JSON.stringify(result))
  connCounts--;
  this_.prop("disabled", false);
    buttonSpinner( this_, true);
 
  if( result.status=='success'){
    
 var veri=checkVerified( pin, name);
  var verified=veri.icon;
     fullname= veri.name;
  var fullname_=fullname + verified;
      
  cont.find('.go-profile-fullname').attr('data-name', name).html( fullname_ );
  cont.find('.go-profile-bio').text(bio).css('display','block');
  cont.find('.go-profile-country').text(location);
  cont.find('.go-profile-phone').html( phone);
 
 var email=$.trim( cont.find('.go-profile-email').text() );
 var joined=$.trim( cont.find('.go-profile-joined').attr('data-joined') );

    
 if( birth){
   var birth_= ( new Date(birth) ).format("mmmm dd")
   cont.find('.go-profile-birth').attr('data-birth', birth).text( birth_).css('display','block');
 }
    else{
      cont.find('.go-profile-birth').css('display','none');
    }

 $('.go-post-fullname-' + pin).attr('data-user-fullname', name);
 $('.go-puser-fullname-' + pin ).html( fullname_);
 
 if( pin==username){
    localStorage.setItem('fullname', name );
   localStorage.setItem('phone', phone );
   localStorage.setItem('location', location);
    $('.go-user-open-profile').attr('data-user-fullname', fullname);
   $('.go-user-fullname').html( fullname_);
  }
  
   $('#go-post-by-pages').removeClass('go-pages-loaded');
   $('#compose-post-container .go-pages').empty();
     
  toast('Updated',{type:'success'});
    
 }else if( result.error){
     toast( result.error); 
    }
    else{
     toast('could not save')
    }
   }).fail(function(e,txt,xhr){
    //alert(JSON.stringify(e))
    connCounts--;
    this_.prop("disabled", false);
    buttonSpinner( this_, true);
    toast("Something went wrong");     
  report__('Error "goProfileUpdate()" in go-social.js', JSON.stringify(e),true );
 
  });
  }, 2000);
  
}


function goUploadProfilePicture(event,type){
  //Type: image
//    var pin=$.trim( $('#go-current-opened-profile').val()); 
 var this_=$(event);
  var user= this_.data("user");
  closeDisplayData('.go-profile-camera-option-div'); 
 
try{
	
	var imageTypes = ["jpg", "jpeg", "gif","png"];
	
	var ext= event.files[0].name.split('.').pop().toLowerCase();  //file extension from input file
	
    var reader = new FileReader();
    
    reader.onload = function(e){
    var data=	this.result; 
      var type=data.match(/(image)/);
 
  if( !type ) return toast("File unsupported");
 
 resizeImage( e.target.result, { quality: 0.8, width: 1000, height: 600 },  function(base64, error){
   if(error){
  return toast("Could not upload");
}
  upload_profile_picture_(  base64, user); 
});


    };
    reader.readAsDataURL(event.files[0]);
}catch(e){
 toast(e);
 }
 }
 
 
 function resizeImage( image, options, callback){
 	var quality=options.quality||0.8;
  var img=document.createElement("img");
  
   $(img).attr('src', image);
      
   img.onload=function(){
   	
   var MAX_WIDTH = options.width||700;
   var MAX_HEIGHT = options.height||400;
       
        var width = img.width;
        var height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        var canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        canvas.getContext("2d").drawImage(this, 0, 0, width, height);
        

var result=canvas.toDataURL('image/jpeg', quality );

if(callback) {
  if( result)  callback(  result    , null);
  else callback(  null  , "Could not generate image");
}

 }

}
 
 

function upload_profile_picture_( base64, user){

   if(!user) return toast("User not found");
  //Pin is set if upload is from go-social.js
   toast("Uploading",{  type:"info", hide:10000});
  
      sessionStorage.setItem('DELAY','1');
    $('#profile-picture-loading').css('display','block');    
    
     connCounts++;
     
    $.ajax({
         'url': config_.domain + '/oc-upload/upload-profile-picture.php',
         'type': 'POST',
        'dataType':'json',
         'data':{
           'base64': base64,
           'username': username,
           'pin': user,
           'token': __TOKEN__,
           'version': config_.APP_VERSION,
      }
  }).done(function(result){
  	connCounts--;
  
      sessionStorage.removeItem('DELAY');
   
  $('#profile-picture-loading').css('display','none');   
   
  if( result.status ){
   goProfilePhotoUploaded();
        toast( result.result,{type:'success'});

   return report__('Profile picture updated successfully.');
 
  }else if( result.error){
    toast('Couldn\'t update profile picture.');
   report__('Profile picture update failed-2.', result.error);    
  }
 }).fail(function(e, txt,xhr){
 	connCounts--;
    sessionStorage.removeItem('DELAY');
      $('#profile-picture-loading').css('display','none');
      toast('Something went wrong' + xhr);
     report__('Error: "processProfilePicture_()"', JSON.stringify(e));    
       });
	
	}

function goUploadFiles(){
  var fpaths=GO_UPLOAD_FILE_PATHS;
 
 if( fpaths.length<1) return;
 
   var v=fpaths[0];
   var v_=v.split(".")
var ext=v_[1];
var filename=v_[0];

  var pElem=$('#vid-poster-' + filename);
  var base64=$("#base64-data-" + filename).val();
  
 var file_size= base64.length;
 
  var pCont=$('#go-up-progress-container-' + filename);
  $('#go-up-progress-' + filename).css({ width: "0%"});
  
  setTimeout(function(){
    
  var poster=pElem.val()||"";
  var pDim=  pElem.data("dim");
    
  $.ajax({
   xhr: function() {
      var xhr = new window.XMLHttpRequest();
    // Upload progress     
    xhr.upload.addEventListener("progress", function(evt){
        if (evt.lengthComputable) {
     var percent= (evt.loaded / evt.total)*100;
  
   $('#go-up-progress-' + filename).css({ width: "" + percent + "%"});
    pCont.css('display','block');
   
  if( percent==100){
    $('#go-up-progress-' + filename).css({width:'100%'});
   }
  }
 }, false); 
       return xhr;
    },
    
    "url": config_.domain + '/oc-ajax/go-social/upload-post-file.php',
    "dataType":"json",
    "data":{
     "username" : username,
     "token": __TOKEN__,
     "version": config_.APP_VERSION,
     "base64": base64,
     "video_poster": poster,
     "video_dimension": pDim,
     "file_ext": ext,
 },
 
 type:'POST'
}).done( function(result){
 //alert( JSON.stringify( resp) )
    $('#go-send-post-btn').prop('disabled',false);
  if( result.status=='success'){
    
  var file_obj=new Object();
    file_obj["path"]=result.file_path;
    file_obj["ext"]=result.ext;
    file_obj["width"]=result.width||500;
    file_obj["height"]=result.height||150;
    file_obj["poster"]=result.poster||"";
    file_obj["size"]=result.file_size||file_size;
    
  // var push_=result.file_path + '|' + result.ext +  (result.poster? '|' + result.poster:'');
  
   GO_UPLOADED_FILE_PATHS.push( file_obj)
   GO_UPLOAD_FILE_PATHS =$.grep( GO_UPLOAD_FILE_PATHS, function(value) {
   return value != v;
 });
   
  $('#go-send-post-btn').click();
    
  }else if( result.error){
   var ecode=result.ecode;
  
 //if( ecode==="3" || ecode==="2"||ecode==="0"){
   $("#close-upbtn-" + filename).click();
 // }
    toast( result.error);
    closeDisplayData(".dummy-dummy");
    $("#post-progress").empty();
  }
  else{
     toast("Unknown error occured");
    $("#post-progress").empty();
  }
    
  }).fail(function(e,txt,xhr){
     //alert( JSON.stringify(e));
    $("#go-send-post-btn").prop("disabled", false);
     closeDisplayData(".dummy-dummy");
    $("#post-progress").empty();
   toast("Something went wrong");     
  report__('Error "goUploadFiles()" in go-social.js', JSON.stringify(e),true );
 
  });
  },2000); 
  
}

function togglePostLinkForm(){
 $('#go-post-link-form').toggle();
}


function goOpenVideo(t){
  var this_= $(t);
   var vid=this_.data('vid');
   var fdload=this_.data('fdload');
  var sourceUrl=$.trim(this_.data('source-url') );
  var dUrl=$.trim(this_.data('durl'));
  var fsize=$.trim( this_.data('fsize'));
  
  var poster=this_.data('poster');
 
 var data='<figure style="display: none;" id="' + vid + '-video-container" class="go-video-container" data-chatid="' + vid + '">';
     data+='<video id="' + vid + '-video" class="video-tag" data-chatid="' + vid + '" poster="' + poster + '" controls preload="true" data-fsize="' + fsize + '" data-durl="' + dUrl + '" src="' + sourceUrl + '#t=0.1">';
     data+='</video>';
     data+='</figure>';

 $('.go-video-container').css('display','none');
  
 if( !$('#' + vid + '-video-container').length) {
    $('#go-video-element-container').append(data);
    go_mediaplayer_( $('#' + vid + '-video'), fdload );
  }
    
  $('#' + vid + '-video').trigger('play');
setTimeout(function(){
  $('#go-video-element-container, #' + vid + '-video-container').css('display','block');
  changeHash("watching-video");
 },150);
 
}

function go_mediaplayer_($elem, fdload){

  $elem.mediaelementplayer({
  defaultVideoWidth: "100%",
  defaultVideoHeight: "100%",
   videoWidth: 250, /*250,*/
  videoHeight: 230, /*230*/
  hideVideoControlsOnLoad: true,
  clickToPlayPause: true,
  controlsTimeoutDefault: 2000,
  features: ["playpause","current", "progress", "duration"],
  enableKeyboard: false,
  stretching: "none",
  pauseOtherPlayers: true,
  ignorePauseOtherPlayersOption: false,
  hideVolumeOnTouchDevices:true,
  
  success: function(media, originalNode, instance) {
   var node=$(originalNode);
   var chatid=node.data("chatid");
     go_enableVideoFullScreen( node, chatid, fdload);
    
 media.addEventListener('loadedmetadata',function(){
  //go_enableVideoFullScreen( node);
 });
    
  media.addEventListener('play',function(e){
    go_enableVideoFullScreen( node, chatid, fdload);
  });  
   
 },
  error: function(){
 setTimeout(    function(){
go_exitVideoFullScreen(true);
 },500);
 
    toast("Unable to load");
  }
});
}


function go_enableVideoFullScreen(node_,chatid, fdload){ 
  var allow_download=false;
//   try{
//    var settings= JSON.parse( localStorage.getItem("server_settings") );
  
  if( siteAdmin( username) || SERVER_SETTINGS.go_enable_download=="YES"){
      allow_download=true;
  }
  
// }catch(e){}
  
  if( node_.hasClass('video-tag') ){
    
    var vsrc=node_.attr('src');
    var durl=node_.attr('data-durl');
    var fsize=node_.attr('data-fsize');
    
    var cont=node_.parent().closest('.mejs__container');
    cont.addClass('mejs__custom-fullscreen go-watching-video watching-video-' + chatid)
 //   readableFileSize( +bsize, true, 0):'
    
  cont.append('<a href="' + vsrc + '" class="save-media-btn save-video-btn" target="blank_" download>' + readableFileSize(  fsize, true, 0) + ' <img src="' + __THEME_PATH__ + '/assets/go-icons/save-media.png"></a><button class="save-media-btn" style="position: fixed; left:5%; top: 16px;" onclick="go_exitVideoFullScreen(true);"><img src="' + __THEME_PATH__ + '/assets/go-icons/back-red.png"></button>');
  
      cont.removeAttr('style');
      cont.attr('data-wvchatid',chatid);
      cont.find('.mejs__overlay,.mejs__layer').css({width:'100%',height:'100%'});
  }  
}


function go_exitVideoFullScreen(remove_){
  $("video").trigger("pause");
 
  $("#go-video-element-container,.go-video-container").css("display","none");
 
 var fs=$('.mejs__custom-fullscreen');
 var vid=fs.attr('data-wvchatid');  
  /*
  fs.find('.mejs__overlay,.mejs__layer').css({width:340,height:160});
   fs.css({height:160}).removeClass('mejs__custom-fullscreen go-watching-video watching-video-' + vid);
  */
if( remove_){
   $('#' + vid + '-video-container').remove();
 }
  
}


function notifications_(results_) {  
   var total_results= results_.length;
     if( !total_results  ) return;
   
    $.each( results_,function(i,v){
     var nid=v.id;
   localStorage.setItem( SITE_UNIQUE__ + "_" + username + '_last_notification_check_id',  nid);
   
  });
  
  var elem=$('#total-new-notifications');
  var curr=+elem.attr('data-total');

   var total= total_results+curr;
   var tt=total;
    if( tt>99){
      tt='99+'; }
  localStorage.setItem( username + '_total_new_notifications', total + '/' + tt);
  elem.attr('data-total', total).text( tt ).css('display','inline-block');
}


function fetchNotifications(){  
 
  var check_freq= 180000;
//go_config_.notif_check_freq;
       
  var last_check=localStorage.getItem( SITE_UNIQUE__ + "_" +username + "_last_notification_check_id")||"fresh";
   loadingNotificationsPosts=true;
  
  connCounts++;
  
  loadingNotificationAjax = $.ajax({
    url: config_.domain + '/oc-ajax/go-social/notifications.php',
    type:'POST',
   timeout: 15000,
    dataType: "json",
    data: {
      "username": username,
      "last_check_nid": last_check,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  // alert(JSON.stringify(result))  
  connCounts--;
    loadingNotificationsPosts= false;
   var st= result.server_time||moment().unix();
  
  
  if( result.last_nid  ){

  localStorage.setItem( SITE_UNIQUE__ + "_" + username + "_last_notification_check_id",  result.last_nid );
   }
  else  if( result.status=='success' && result.result ){
   notifications_( result.result);
   }
  
 setTimeout(function(){
     fetchNotifications();
  }, check_freq );
    
  }).fail(function(e,txt,xhr){
   // alert( JSON.stringify(e));
   connCounts--;
    loadingNotificationsPosts= false;
   setTimeout(function(){
     fetchNotifications()
   }, 20000);
   
  });
  
}

   
function openNotifications(){
  goCloseComment();
  $('#total-new-notifications').attr('data-total',0).text(0).css('display','none');
  localStorage.removeItem(username + '_total_new_notifications');
  
 var mCont=$('#go-notifications-container');
 
  if( !mCont.is(":visible")) changeHash("notification");
  
  mCont.fadeIn();  
  var cont=$('#go-notifications');
 
 var pnumElem=$("#go-notifications-next-page-number");
   var pnum=pnumElem.text();
   
 if( pnum=="0") return;
 
 loadingNotificationsPosts=true;
 var loader=$("#notifications-loader");
 loader.removeClass("d-none");

   connCounts++;
   
  loadingNotificationAjax = $.ajax({
    url: config_.domain + '/oc-ajax/go-social/notifications-mobi.php',
    type:'POST',
   timeout: 15000,
    dataType: "json",
    data: {
      "username": username,
      "page": pnum,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  // alert(JSON.stringify(result)  )  
  connCounts--;
    loadingNotificationsPosts= false;
    loader.addClass("d-none");
 if( result.no_noti ){
   return cont.html('<div class="text-center">No notification</div>');
   pnumElem.text(0);
 
}else if ( result.error){

	return cont.html('<div class="text-center">' + result.error + '</div>');
	
	}
else if( result.status=="success"){
pnumElem.text(result.next_page);
  var r='<div class="container-fluid">';
 var d="";
var res=result.result;

  $.each( res,function(i,data){
  var nid=data.id;
 
   var meta= JSON.parse( data.meta);
   var author=meta.author||"";
   var action= meta.action;
   var type= meta.action_type;
   var aid= meta.action_id;
   var aid2=meta.action_id_2||"";
   var post_by=meta.post_by||"";
   
   var status=meta.status;
     
   d+='<div class="row go-un-' + nid + ' ' + (status?'go-unread-notification':'') + '">';
     d+='<div class="col" style="max-width: 60px;">';
     d+= go_user_icon( author,'go-notifications-user-icon' );
     d+='</div>';
     d+='<div class="col go-open-notification" onclick="openNotification_(this);" data-post-by="' + post_by + '" data-file="' + nid + '" data-author="' + author + '" data-action="' + action + '" data-action-type="' + type + '" data-action-id="' + aid + '" data-action-id-2="' + aid2 + '">';
     d+= data.message.replace(/\B@([\w- ]+)@/gi,'<span class="go-notification-names">$1</span>');
     d+='<div class="go-notifications-time">' + timeSince( data.message_time) + '</div>';
     d+='</div>';
     d+='<div class="d-none col go-delete-notification text-center" data-file="' + nid + '" style="max-width: 60px;" onclick="delNotification(this);">';
     d+='<img class="icon-normal" src="' + __THEME_PATH__ + '/assets/go-icons/delete2.png">';
     d+='</div>';
     d+='</div>';
     
   });
     
 r+=d;
 
  r+='</div>';
  
  cont.append(r);
  
  }
  else {
  	return cont.html('<div class="text-center">Unknown error occured</div>');
  }
 
 
 }).fail(function(e,txt,xhr){
  // alert( JSON.stringify(e));
  connCounts--;
  loader.addClass("d-none");
  toast("Something went wrong " + xhr);
    loadingNotificationsPosts= false;
  });
   
 }


function openNotification_(t){
  var this_=$(t);
  var action = this_.data('action');  
  var type = this_.data('action-type'); 
  var aid = this_.data('action-id');
  var aid2 = this_.data('action-id-2'); //comment reply
  var post_by = this_.data('post-by'); //comment reply

  var file = this_.data('file');   
  
 if( action=="open" ){   
  
 if( type =="post" ){
  var elem=$('<div/>').addClass('go-open-single-post')
      .attr('data-pid', aid);
    elem.appendTo('body').click();
    
  }else if( type=="follow"){
   //data+='<span class="highlight comment-author go-open-profile friend-' + author_ + '" data-user-fullname="' + author + '" data-user="' + author_ + '">' + strtolower( fullname) + ' ' + icon + '</span>' ;
  var elem=$("<div/>").addClass("go-open-profile")
  .attr("data-user-fullname", aid )
  .attr("data-user", aid);
    
   elem.appendTo('body').click();
  }
   else if( type=="comment-reply" && aid2 && post_by){
    $('#current-post-id').val(aid);
    $('#current-post-by').val(post_by )
   $('#go-view-orig-post').css('display','block');
    
  var elem=$('<div/>').attr('data-parent-id', aid2)
  .on('click',function(){
    replyComment(this);
  });
   elem.appendTo('body').click();
   
  }
   
 }
   
 var elem=$('.go-un-' + file);
   if( elem.hasClass('go-unread-notification')){
  
     elem.removeClass('go-unread-notification'); 
  }
}
 
 function delNotification(delBtn){
  
 }
  


//VIEW FOLLOWERS
var lfAjax,lfTimeout,loadingFollowers,toast_f_once;
  
function viewFollowers( refresh){
  $('#go-followers-container').fadeIn();
  changeHash("followers");
  loadFollowers();
  }

function loadFollowers_( data){
   var d='<div class="container-fluid">';
  
  $.each(data,function(i,v){
     var user=v.follower||"";
     var fullname=v.real_name||user;
  
  var veri=checkVerified(user, fullname);
  var verified=veri.icon;
      fullname= veri.name;
  var fullname_=fullname + verified;
    
    
     var status=v.status;
     var bio=v.bio||"";
    if( bio.length>60 ){
      bio=bio.substr(0,80) + '...';
    }
    var type='block';
    var btext='Block';
    if( status=='0'){
      type='unblock';
      btext='Unblock';
    }
    
    d+='<div class="row">';
     d+='<div class="col" style="max-width: 60px;">';
     d+= go_user_icon( user,'go-followers-user-icon' );
     d+='</div>';
     d+='<div class="col go-open-profile" data-user="' + user+ '" data-user-fullname="' + fullname + '">';
     d+='<div class="go-followers-name">' +  fullname_ + '</div>';
     d+='<div class="go-followers-bio">' +  bio + '</div>';
     d+='</div>';
     d+='<div class="col" style="max-width: 120px; text-align: center;">';
     d+='<button onclick="blockUnblockFollower(this);" class="go-followers-block-btn go-bf-btn-' + user + '" data-type="' + type + '" data-pin="' + user + '">' + btext + '</button>';
     d+='</div>';
     d+='</div>';
  });
    d+='</div>';
  
 $('#go-followers').append( d);
}


function loadFollowers( refresh){
	
  goCloseComment();

  var pnElem=$('#go-followers-next-page-number');
  var pageNum=pnElem.val();
   
/*
if( loadingFollowers ){
    return;
  } else  
*/
    if( refresh ){
    toast_f_once=false;
    pageNum="";
    displayData('<div class="text-center" style="padding-top: 30px;"><img class="w-40 h-40" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>',{ data_class:'.home_refresh', no_cancel: true});
  }
  
  
  if( !refresh && pageNum=="0"){
   if( !toast_f_once ){
     toast_f_once=true;
   //  toast('That is all for now.',{type: 'info'});
   }
    return;
   }
    
  loadingFollowers=true;
 
  var loader=$('#go-followers-loading-indicator');
  loader.css('visibility','visible');
  
  connCounts++;
  
 lfTimeout=setTimeout(  function(){
  lfAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/view-followers.php',
    type:'POST',
  // timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "page": pageNum,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){
   //alert(JSON.stringify(result));
   connCounts--;
      loadingFollowers=false;  
      loader.css('visibility','hidden');
    if( refresh ){
     closeDisplayData('.home_refresh'); 
    }
    $('#nfw__').remove();
 if( result.no_follower){
   $('#go-followers').html('<div id="nfw__" class="text-center">' + result.no_follower +'</div>' );
  // return toast( result.no_follower,{type:'info'});
  } 
    else  
  if( result.status=='success' ){
    var posts= result.result;
    var nextPage=result.next_page;
    pnElem.val( nextPage );
  loadFollowers_( result.result);
 
 }
   else if(result.error){
toast(result.error );
  }
   else toast('No more followers.',{type:'info'});
 
 }).fail(function(e,txt,xhr){
 	connCounts--;
   loadingFollowers=false;
  //  loader.css('display','none');
  //toast('Connection error. ' + xhr, {type:'light',color:'#333'});
  if( refresh ){
     closeDisplayData('.home_refresh');
    return;
    }
    
    lfTimeout=setTimeout(function(){
       loadFollowers( refresh); },4000);
  });
    
  },1000);
}


//FOLLOWING
var lfgAjax,lfgTimeout,loadingFollowing,toast_fg_once;
  
function viewFollowing(refresh){
  $('#go-following-container').fadeIn();
  changeHash("following");
  loadFollowing(refresh);
  }


function loadFollowing_( data){
   var d='<div class="container-fluid">';
  
  $.each(data,function(i,v){
     var user=v.following||"";
    var fullname=v.real_name||user;
     var bio=v.bio||"";
    if( bio.length>60 ){
      bio=bio.substr(0,80) + '...';
    }
  var veri=checkVerified(user, fullname);
  var verified=veri.icon;
      fullname= veri.name;
  var fullname_=fullname + verified;
    
    d+='<div class="row">';
     d+='<div class="col" style="max-width: 60px;">';
     d+= go_user_icon( user,'go-followers-user-icon' );
     d+='</div>';
     d+='<div class="col go-open-profile" data-user="' + user+ '" data-user-fullname="' + fullname + '">';
     d+='<div class="go-followers-name">' +  fullname_ + '</div>';
     d+='<div class="go-followers-bio">' +  bio + '</div>';
     d+='</div>';
     d+='<div class="col" style="max-width: 120px; text-align: center;">';
     d+='<button class="go-unfollow-btn go-follow-btn-' + user + '" data-pin="' + user + '">Following</button>';
     d+='</div>';
     d+='</div>';
  });
    d+='</div>';
  
 $('#go-following').append( d);
}



function loadFollowing( refresh){
  //People you follow
  goCloseComment();

  var pnElem=$('#go-following-next-page-number');
  var pageNum=pnElem.val();
   
/*
if( loadingFollowing ){
    return;
  } else  
  */
  if( refresh ){
    toast_fg_once=false;
    pageNum="";
    displayData('<div class="text-center" style="padding-top: 30px;"><img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>',{ data_class:'.home_refresh', no_cancel: true});
  }
  
  
  if( !refresh && pageNum=="0"){
   if( !toast_fg_once ){
     toast_fg_once=true;
   //  toast('That is all!.',{type: 'info'});
   }
    return;
   }
	
  loadingFollowing=true;
 
  var loader=$('#go-following-loading-indicator');
  loader.css('visibility','visible');
 
   connCounts++;
   
lfgTimeout=setTimeout(  function(){
  lfgAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/view-following.php',
    type:'POST',
 //  timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "page": pageNum,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){
   //alert(JSON.stringify(result));
   connCounts--;
      loadingFollowing=false;  
      loader.css('visibility','hidden');
   $('#nf__').remove();
 if( result.no_following){
   $('#go-following').html( '<div id="nf__" class="text-center">' + result.no_following +'</div>' );
  // return toast( result.no_follower,{type:'info'});
  } 
    else  
  if( result.status=='success' ){
    var posts= result.result;
    var nextPage=result.next_page;
    pnElem.val( nextPage );
  loadFollowing_( result.result);
 
 }
   else if(result.error){
toast(result.error );
  }
   else toast('That is all!',{type:'info'});
 
 }).fail(function(e,txt,xhr){
 	connCounts--;
   loadingFollowing=false;
  //  loader.css('display','none');
 // android.toast.show('Something happened! Please try again. ' + xhr );
  
  lfgTimeout=setTimeout(function(){
       loadFollowing(refresh); },6000);
  });
    
  },1000);
}


//BLOCKED FOLLOWERS
var lbfAjax,lbfTimeout,loadingBFollowers,toast_bf_once;
  
function viewBlockedFollowers(refresh){
  $('#go-blocked-followers-container').fadeIn();
  changeHash("blocked-followers");
  loadBlockedFollowers(refresh);
}


function loadBlockedFollowers_( data){
   var d='<div class="container-fluid">';
  
  $.each(data,function(i,v){
     var user=v.follower||"";
    var fullname=v.real_name||user;
     var bio=v.bio||"";
    if( bio.length>60 ){
      bio=bio.substr(0,80) + '...';
    }
 var veri=checkVerified(user, fullname);
  var verified=veri.icon;
      fullname= veri.name;
  var fullname_=fullname + verified;
    
    d+='<div class="row">';
     d+='<div class="col" style="max-width: 60px;">';
     d+= go_user_icon( user,'go-followers-user-icon' );
     d+='</div>';
     d+='<div class="col go-open-profile" data-user="' + user+ '" data-user-fullname="' + fullname + '">';
     d+='<div class="go-followers-name">' +  fullname_ + '</div>';
     d+='<div class="go-followers-bio">' +  bio + '</div>';
     d+='</div>';
     d+='<div class="col" style="max-width: 120px; text-align: center;">';
     d+='<button onclick="blockUnblockFollower(this);" class="go-followers-block-btn go-bf-btn-' + user + '" data-type="unblock" data-pin="' + user + '">Unblock</button>';    
     d+='</div>';
     d+='</div>';
  });
    d+='</div>';
  
 $('#go-blocked-followers').append( d);
}


function loadBlockedFollowers( refresh){
  goCloseComment();

  var pnElem=$('#go-blocked-followers-next-page-number');
  var pageNum=pnElem.val();
   
/*
if( loadingBFollowers ){
    return;
  } else  
  */
  
    if( refresh ){
    toast_bf_once=false;
    pageNum="";
    displayData('<div class="text-center" style="padding-top: 30px;"><img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>',{ data_class:'.home_refresh', no_cancel: true});
  }
  
  if( !refresh && pageNum=="0"){
   if( !toast_bf_once ){
     toast_bf_once=true;
   //  toast('That is all!.',{type: 'info'});
   }
    return;
   }
   
  loadingBFollowers=true;
 
  var loader=$('#go-blocked-followers-loading-indicator');
  loader.css('visibility','visible');

 connCounts++;
 
lbfTimeout=setTimeout(  function(){
  lfgAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/view-blocked-followers.php',
    type:'POST',
  // timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "page": pageNum,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
}).done(function(result){
   //alert(JSON.stringify(result));
   connCounts--;
      loadingBFollowers=false;  
      loader.css('visibility','hidden');
  $('#nb__').remove();
 if( result.no_blocked){
   $('#go-blocked-followers').html( '<div id="nb__" class="text-center">' + result.no_blocked + '</div>');
    } 
    else  
  if( result.status=='success' ){
    var posts= result.result;
    var nextPage=result.next_page;
    pnElem.val( nextPage );
  loadBlockedFollowers_( result.result);
 
 }
   else if(result.error){
toast(result.error );
  }
   else toast('That is all!',{type:'info'});
 
 }).fail(function(e,txt,xhr){
 	connCounts--;
   loadingBFollowers=false;
  //  loader.css('display','none');
 // android.toast.show('Something happened! Please try again. ' + xhr );
  
  lbfTimeout=setTimeout(function(){
       loadBlockedFollowers(); },6000);
  });
    
  },1000);
}


var bfTimeout, bfAjax,b_u_block;

function blockUnblockFollower(t){
  if( b_u_block){
   return toast('Please be patient');
 }
  
  var this_=$(t);
  var pin=this_.data('pin');
  var type=this_.attr('data-type');
 
  this_.prop('disabled', true);
  buttonSpinner(this_);
   
   b_u_block=true;
  
  connCounts++;
  
 bfTimeout=setTimeout(  function(){
  bfAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/block-follower.php',
    type:'POST',
  // timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "pin": pin,
      "type": type,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){
   //alert(JSON.stringify(result));
   connCounts--;
   this_.prop('disabled', false);
  buttonSpinner(this_,true);
  b_u_block=false;
  if( result.status=='success' ){
    var elem=$('.go-bf-btn-' + pin );
    elem.text( result.result);
    if( type=='block'){
     elem.attr('data-type', 'unblock');
    }else{
     elem.attr('data-type', 'block'); 
    }
 }
   else if(result.error){
toast( result.error );
  }
   else{
    toast('Something went wrong. Try again.');
   }
    
  }).fail(function(e,txt,xhr){
  	connCounts--;
    this_.prop('disabled', false);
    b_u_block=false;
    buttonSpinner(this_,true);
 toast("Something went wrong");     
  report__('Error "blockUnblockFollowers()" in go-social.js', JSON.stringify(e),true );
 
  });
 },1000);
    
}



function goProfileCameraOption(t){
  var this_=$(t);
  var user=$.trim( this_.attr('data-user') );

 if( user!=username && !siteAdmin( username)  ){
  return;
 }
  else if( user!=username 
      && siteAdmin( username ) 
      && !goPage( user) ){
    return;
  }
          
 var data='<div class="center_text_div text-left bg-white text-dark" style="width:100%; font-size: 14px; font-weight: bold; padding: 8px 15px; border: 0; border-radius: 5px;">';
     

data+='<div class="mb-1 mt-3" style="padding-bottom: 10px;" data-pin="' + user + '"><label for="goUploadProfilePhoto">Choose existing photo</label></div>';
    
data+='<form class="d-none"><input type="file" id="goUploadProfilePhoto" name="file" data-user="' + user + '" accept="image/*" onchange="goUploadProfilePicture(this, \'image\');" /></form>';

if(  $("#go-profile-page-" + user).find('.go-profile-cover-photo').hasClass("img-loaded") ){
   
data+='<div class="mb-1 mt-1" style="padding-bottom: 10px;" data-pin="' + user + '" onclick="removeProfilePhoto(\'' + user + '\')"><label for="removeProfilePhoto">Remove photo</label></div>';
   }
  data+='</div>'; 
  displayData( data, { width: '90%', oszindex: 205, pos: '50', data_class: '.go-profile-camera-option-div', osclose:true});  
}

function removeProfilePhoto( user){
var ucont=$("#go-profile-page-" + user);
if( !confirm("Remove photo?") ) return;
closeDisplayData(".go-profile-camera-option-div");

toast("Removing", {type:"info"});

 setTimeout( function(){
 
$.ajax({
    url: config_.domain + '/oc-upload/remove-profile-picture.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "username": username,
      "user": user,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){
   // alert(JSON.stringify(result));
 
 connCounts--;
   if( result.status=="success"){ 
 	
ucont.find(".go-profile-cover-photo").removeClass("img-loaded").removeAttr("src");

ucont.find(".go-profile-photo").removeAttr("src");
   
   	toast("Photo removed", {type: "success"});
 }
   else{
   toast("Failed to remove");	
   }
   
 }).fail( function(e,txt,xhr){
	connCounts--;
 toast("Something went wrong");

   report__('Error "removeProfilePhoto()" ', JSON.stringify(e),true );
  
//   alert(JSON.stringify(e))
   
 });
 
 },1000);
 
}

function goProfilePhotoUploaded(){
  var pin=$.trim( $('#go-current-opened-profile').val() );
 var ucont=$("#go-profile-page-" + pin);
 var rid=randomString(3) 
  localStorage.setItem("go_photo_token",  rid);
  
var pimg_path=config_.users_path + '/' + strtolower( pin[0] + '/' + pin[1] + '/' + pin[2] + '/' + pin )+ '/profile_picture_full.jpg?due=' + rid;
 
   var coverImg=ucont.find('.go-profile-cover-photo');
   var img=ucont.find('.go-profile-photo');
  var coverImgCont=ucont.find('.go-profile-cover-photo-container');
  
 img.on('load',function(){
   var rgb=getAverageRGB( this);
   coverImg.attr("data-bg", rgb);
   coverImgCont.attr("style","background-color: " + rgb);
  // attr("style","background-color:" + bg);
  });
     
  var icon=pimg_path.replace("_full.jpg","_small.jpg"); 
   img.attr("src", icon )
            .attr("data-user", pin);
   coverImg.attr("src", pimg_path).addClass("img-loaded");
  $("#go-pphoto-reload-btn-" + pin).remove();
  
  $(".go-post-author-icon-" + pin).attr("src", icon);
  
 if( pin==username){
   $(".my-photo-icon").attr("src", icon);
 }

}


function sidebarPages( result){
	
if(!result.status ) return;
  if( result.total<1) return;
 
 var data="";
 
 $.each( result.data, function(i, v){
 	var user=v.username;
    var fullname=v.fullname;
    
  data+='<div class=" container-fluid mt-3 go-open-profile" data-user="' + user + '" data-user-fullname="' + fullname + '">';
  data+='<div class="row">';
  data+='<div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">';
    
var path=config_.users_path + '/' + strtolower( user[0]+'/' + user[1] + '/' + user[2] + '/' + user ) + '/profile_picture_medium.jpg';

  data+='<img class="menu-icon opacity-1x" src="' + path + '" alt="" style="border: 0; border-radius: 3px;" onerror="go_imgIconError(this);">';
  
    data+='</div><div class="col p-0">';
   data+='<span style="color:#485960; text-transform: capitalize;">' + fullname + '</span>';
  data+='</div>';
  data+='</div>';
  data+='</div>';
        
 });

$("#OSB-TOP-LEFT-SIDEBAR").html(data);

	}
	

//SPONSORED POSTS
function sponsoredPosts( result){
    alert(JSON.stringify(result));
ADS___=result;
     //    showAds(1);
}


function sponsoredPostsx(){
 
  var pnElem=$('#go-next-sp-page-number');
  var pageNum=pnElem.val();
   
 if( pageNum=="0"){
   return;
 }
    
  lspLoading=true;
   
 var path=config_.domain + "/oc-ajax/go-social/sponsored-posts.php";
  
  connCounts++;
  
 lspAjax=$.ajax({
    url: path,
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "username": username,
      "version": config_.APP_VERSION,
      "page": pageNum,
      "token": __TOKEN__,
    }
  }).done(function(result){
    // alert(JSON.stringify(result));
 connCounts--;
   lspLoading=false;
   
   if( result.no_post ){
     pnElem.val("0");
   }
   else 
   if( result.status=='success'){ 
         ADS___=result;
         showAds(1);
 }
   
 }).fail( function(e,txt,xhr){
 	connCounts--;
   lspLoading=false;
   report__('Error "sponsoredPosts()" in go-social2.js', JSON.stringify(e),true );
   // alert(JSON.stringify(e))
 });
    
}

function showAds( cnt){
	if(!ADS___) return;
	if( ADS___.error || ADS___.no_post) {
	  return;
	}
	var ad=ADS___.result;
	var total=ADS___.total_posts;

 if( !total) return;
 if( cnt >total) return;
  var post=[ad[cnt-1]];
      
function randBtw(min, max) {
 // min and max included 
  return Math.floor(Math.random() * (max - min + 1) + min)
}

 if( adPosMin<1 ){
 
var adPosMax=adPosMin + 2;
var pos=randBtw( adPosMin, adPosMax);
    adPosMin=adPosMax + 1; 

    $("#go-the-posts .go-post-container:eq(" + pos + ")").after( display_post( post, false , false, true)  );
    
    }else{
    	
       $('#go-the-posts').append( display_post( post, false, false, true) ); 
    }
  }



function downloadApp(){
	var data='<div class="center-header"></div>';
	data+='<div class="center-text-div">';
	data+='<div id="download-app-link" class="mb-5 ps-3 pe-3"><img class="w-30 h-30" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>';
	data+='</div>';
	
 displayData( data,
      { osclose: true, oszindex: 250,data_class:'.download-app'});
     
 connCounts++;

$.ajax({
    url: config_.domain + "/oc-ajax/download-app.php",
    type:  "POST",
   timeout: 15000,
    data: {
      "username": username,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){
 //  alert(JSON.stringify(result));
 connCounts--;
   
 $("#download-app-link").html( result);
   
 }).fail( function(e,txt,xhr){
 	connCounts--;
 toast("Something went wrong");
 closeDisplayData(".download-app");
  report__('Error "downloadApp()" in go-social2.js', JSON.stringify(e),true );
  //  alert(JSON.stringify(e))
 });
    
}



//PROMPTS

function unhideMessage(action){
var data='<div class="center_text_div text-left bg-white text-dark" style="width:100%; font-size: 14px; font-weight: bold; padding: 8px 15px;">';
     data+='<input type="password" placeholder="Secret pin">';
     data+='<div class="container"><div class="row">';
     data+='<div class="col"><button onclick="action();">OK</button></div>';
   
    data+='</div</div></div>'; 
  displayData(data,{ width: '90%', oszindex:205, pos:'50', data_class: '.go-profile-camera-option-div', osclose:true});  

}


//VIEW SETTINGS

function viewSettingsPage(){
  $('#go-settings-container').fadeIn();
  changeHash("settings");
  }

function closeSettingsPage(){
  $("#go-settings-container").css("display","none");  
}


function closeComposePage( noconfirm){
  var info='Dispose post?\n\n If you dispose now, you will lose this post or better still copy your text.';
  
 if( !noconfirm && GO_UPLOAD_FILE_PATHS.length ){
   if( !confirm('If you dispose now, you will lose appended files') ) return;
  }
  var tb=$('#compose-post-box');
  var text=$.trim(tb.val());
  
if(!noconfirm && text.length){
  //if( !confirm(info) ) return;
 }
 
  GO_UPLOAD_FILE_PATHS=[];
  GO_UPLOADED_FILE_PATHS=[];
  
  tb.val('');
  sessionStorage.removeItem('go_is_sending_post');
  $('#go-repost-data').val("");
  $('#go-upload-preview-container,#go-repost-highlight').empty();
  $('#compose-post-container').css('display','none');
  $('#compose-post-container .go-repost-hide').css('display','block');
}


function closeNotifications(){
  $('#go-notifications-container').css('display','none');  
//  history.replaceState({}, document.title, window.location.href.split('#')[0]);
}

function closeSavedPosts(){
  if( $('#go-single-post-container').is(':visible')){
   return closeSinglePost(); 
 }
  $('#go-saved-posts-container').css('display','none');  
}

function closeViewFollowers(){
  $('#go-followers-container').css('display','none');  
clearTimeout( lfTimeout);
  if(lfAjax) lfAjax.abort();
}

function closeViewFollowing(){
  $('#go-following-container').css('display','none');  
clearTimeout(lfgTimeout);
  if(lfgAjax) lfgAjax.abort();
}

function closeViewBlockedFollowers(){
  $('#go-blocked-followers-container').css('display','none');  

  clearTimeout(lbfTimeout);
  if(lbfAjax) lbfAjax.abort();
}

function goCloseProfile(){
 clearTimeout( gpTimeout);
 if(gpAjax) gpAjax.abort();
  loadingProfilePosts=false;
  var pcont=$('#go-profile-container');
  var pIndex=+pcont.css('z-index');
  var spcont=$('#go-single-post-container');
  var spIndex=spcont.css('z-index');            
    
 if( spcont.is(':visible') ){
// return  $('#go-single-post-container').css('z-index','45');
  if( spIndex>pIndex){
   return closeSinglePost(); 
  }
 }
  var user=$('#go-current-opened-profile').val();
  var ucont=$('#go-profile-page-' + user);
  var loader=ucont.find('.profile-posts-loading-indicator');
  loader.css('display','none');
  $("#load-profile-id").val("");
  if( !location.href.match(/\/post\//)){
 // window.history.pushState("data",  "null",  DOMAIN_);
  }
  return  pcont.css('display','none');
}

function closeMenus(){
  toggleLeftSidebar();
 //$('#go-menus-container').addClass('hide-menus');
}

function closeRightMenus(){
  toggleRightSidebar();
 //$('#go-rmenus-container').addClass('hide-rmenus');
}


function closeSinglePost(){
  $('#go-single-post-container').css('display','none');
  $('#go-single-post').empty();
}

function closeFollowForm(){
  $('#go-follow-container').css('display','none');
}

function closeProfileUpdateForm(){
  $('#go-profile-update-container').css('display','none');
}

function closeFullPhoto(){
  $('meta[name=viewport]').remove();
  $('head').append('<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0">');
  $('#go-full-photo-div').empty();
  $('#go-full-photo-container').css('display','none');
  
setTimeout(function(){
  $('meta[name=viewport]').remove();
  $('head').append('<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2.0">'); 
 },1000);
  
//   android.webView.enableZoom(false);
}

function closeFullCoverPhoto(){
  $('meta[name=viewport]').remove();
  $('head').append('<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0">');
  $('#go-full-cover-photo-container').css('display','none');
  $('#go-full-cover-photo').empty();


 setTimeout(function(){
  $('meta[name=viewport]').remove();
  $('head').append('<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2.0">'); 
 },1000);
  }


function closeSearch(){
  $('#go-search-container').css('display','none');
 // $('#go-searched-posts').empty();
  clearTimeout(spTimeout);
  if(spAjax) spAjax.abort();
}

function closeGoSocial(){
  localStorage.removeItem('go_social_opened');
  
}

function closeCreatePageForm(){
  $('#go-create-page-form-container').css('display','none')
}



function closeRequestApp(){
  $('#go-request-app-container').css('display','none');  
}


function removeFromUploadList(val_, vid){
  GO_UPLOAD_FILE_PATHS = jQuery.grep( GO_UPLOAD_FILE_PATHS, function(value) {
  return value != val_;
});
}


function go_captureVideoPoster(video, dimensions,divide){
 video.pause();
  
  divide=divide||1
  var canvas = document.createElement("canvas");
// scale the canvas accordingly
  var oriWidth= dimensions[0]; //video.videoWidth;
  var oriHeight=dimensions[1]; //video.videoHeight;
  
 var width=oriWidth/divide;
 var perc=(width*100)/oriWidth;
 var height=(perc/100)*oriHeight;
 
var dur=video.duration;
  
  if( dur<1 ){
    return '';
  }
 
  canvas.width = width; 
  canvas.height =height; 
// draw the video at that frame
  var ctx=canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
// convert it to a usable data URL
 var dataURL = canvas.toDataURL("image/jpeg",0.8);
  var data=dataURL.split(',');
  if( data.length>0 ) data=data[1];
  else data=data[0];
  
 if( data){
   return [data,[width,height],];
 }
}



function goVideoPreviewLoaded(video){
  var cid=video.getAttribute("data-cid");
  var src=video.getAttribute("data-src");
  var cid= video.getAttribute("data-cid");
  
  var dur=video.duration;
 
   if(!dur|| dur<5){
       removeFromUploadList(src );
    $('#uppc-' + cid ).remove();
       toast('Video too short')
       return;
     }
  
 var dimensions = [video.videoWidth, video.videoHeight];   

 setTimeout(function(){
   var res= go_captureVideoPoster(video, dimensions); 
   if( res ){
     var elem=$('#vid-poster-' + cid);
     var poster=res[0]||"";
   elem.val(poster );
   elem.attr('data-dim', res[1].toString() );
   $('#vid-child-cont-' + cid).prepend('<img src="data:image/jpeg;base64,' + poster +'" class="go-video-upload-preview-poster">');
  }
  else{ 
  $('#vid-child-cont-' + cid).prepend('<img src="' + __THEME_PATH__ + '/assets/go-icons/bg/black-bg.png" class="go-video-upload-preview-poster">');
  }
   
 $('#uppc-cover-' + cid).remove();
 },100);
}

function goVideoPreviewError(t){
 
  var this_=$(t);
  var src=this_.data("src");
  var cid=this_.data("cid");
    removeFromUploadList(src )
    $("#uppc-" + cid ).remove();
   toast('Some files rejected');
 }


function arrayMove(arr, old_index, new_index) {
    if (new_index >= arr.length) {
        var k = new_index - arr.length + 1;
        while (k--) {
            arr.push(undefined);
        }
    }
    arr.splice( new_index, 0, arr.splice(old_index, 1)[0]);
    return arr; // for testing
};


function swapIt(t){
  var this_=$(t);
  var swid=+this_.data('swid');
  arrayMove( GO_UPLOAD_FILE_PATHS, swid, 0);
}

function copyToClipboard( text) {
	var data='<div class="center-header ps-4 pt-2 text-secondary">Copy from box</div>';
	data+='<div class="center-text-div p-2">';
	data+='<textarea id="copy-text-box" class="form-control">' + text + '</textarea>';
	data+='</div>';
	
	displayData( data, {pos: 100, osclose: true});
	
	}

function fallbackCopyTextToClipboard(text) {
  var textArea = document.createElement("textarea");
  textArea.value = text;
  
  // Avoid scrolling to bottom
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.display="none";
  textArea.style.position = "fixed";
  
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();

  try {
    var successful = document.execCommand('copy');
   
 if(  successful)    toast("Copied", {type:"primary"});
 else toast("Copy failed");
    
  } catch (err) {
    toast('Oops, unable to copy');
  }

 document.body.removeChild(textArea);
}

function copyToClipboardx(text) {
  if (!navigator.clipboard) {
    fallbackCopyTextToClipboard(text);
    return;
  }
  navigator.clipboard.writeText(text).then(function() {
    toast('Copied', {type:"primary"});
  }, function(err) {
  
  	fallbackCopyTextToClipboard(text);
  });
}


function copyToClipboarddd(text) {
    if (window.clipboardData && window.clipboardData.setData) {
        // Internet Explorer-specific code path to prevent textarea being shown while dialog is visible.
        return window.clipboardData.setData("Text", text);

    }
    else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
        var textarea = document.createElement("textarea");
        textarea.style.display="none";
        textarea.textContent = text;
        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in Microsoft Edge.
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand("copy");  // Security exception may be thrown by some browsers.
            toast("Copied",{type:"success"});
        }
        catch (ex) {
         toast("Copy to clipboard failed.");
            return prompt("Copy to clipboard: Ctrl+C, Enter", text);
        }
        finally {
            document.body.removeChild(textarea);
        }
    }
}


function changeAccount(){
  var data='<div class="center_header text-left" style="padding-left: 15px; padding-top: 13px; font-size: 15px;">Change account?</div>';
     data+='<div class="center_text_div text-right" style="width:100%; font-size: 13px; padding: 8px 15px;">';
     data+='<div class="row">';
     data+='<div class="col text-left"><img class="w-20 h-20" id="change-account-loading" style="display:none;" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>';
     data+='<div class="col"><span onclick="closeDisplayData(\'.change-account-div\');">CANCEL</span></div>';
     data+='<div class="col text-center"><span class="" onclick="changeAccount_();">LOGOUT</span></div>';
     data+='</div></div>';  
  displayData(data,{ width: '90%', oszindex:205, pos:'50', data_class:'.change-account-div', osclose:true});  
}


function changeAccount_(t, signin){
 var this_=$(t);
 
  $('#change-account-loading').css('display','block');
  //Delay logout if app is sending, fetching or saving
  //messages from server to avoid loss of data
 if( localStorage.getItem('is_sending_message')
  || localStorage.getItem('is_fetching_messages')
  || localStorage.getItem('saving_message') ){
 
 setTimeout( function(){
   localStorage.setItem('is_logging_out','Yes');
    changeAccount_(t, signin);
  },500);
   return;
  }  
  
  if( signin){
  	 location.href=DOMAIN_ + "/oc-login.php"; 
  return;
  }
  
 $.ajax({
    url: config_.domain + "/oc-ajax/logout.php",
    type: "POST",
   //timeout: 15000,
     dataType: "json",
    data: {
      "username": username,
      "version": config_.APP_VERSION,
      "token": __TOKEN__,
    }
  }).done(function(result){ 
if( result.status){  
  localStorage.setItem('is_logging_out','Yes');
  localStorage.removeItem("__TOKEN__");
  localStorage.removeItem("username");
  localStorage.removeItem("logged_in");
  __TOKEN__=null;

localStorage.setItem("login_required","YES");
 localStorage.removeItem("is_logging_out");
 location.href=DOMAIN_ + "/oc-login.php";  
 return;
 }else if( result.error){
 toast( result.error );
}else{
	toast("Unable to log you out");
	}
	closeDisplayData( ".change-account-div");
	
}).fail(function(e,txt,xhr){
	closeDisplayData( ".change-account-div");
  return toast("Failed to log you out");
});  
   
  }

function newMessageNotify( total_messages){

  var elem=$('#total-new-messages');
  var curr=+elem.attr('data-total');
  if( total_messages){
    total_messages= +total_messages.split('-')[0];
   var total= total_messages+curr;
   var tt=total;
    if( tt>99){
      tt='99+';  }
    localStorage.setItem(username + '_total_new_messages', total + '/' + tt);
    elem.attr('data-total', total).text( tt ).css('display','inline-block');
  }
}

function reload(){
  location.reload();
}


function contactUs(){
  android.activity.loadUrl("main","javascript: createDynamicStadium('" + go_config_.contact_us + "','Contact us');");
   setTimeout( function(){
    openMessage();
   this_.prop('disabled', false);
 },600);
    
}

function changePassword(t){
	var resultDiv=$('#change-password-result');
 resultDiv.empty();

 var opbox=$('#old-password-box');
 var pbox=$('#new-password-box');
 
 var opw=$.trim(opbox.val());
 var pw=$.trim( pbox.val() );

if( !opw||opw.length<6||opw.length>50){
  toast('Old password should contain at least 6 characters. Max: 50.');
 return;
}
else
if( !pw||pw.length<6||pw.length>50){
 toast('New password should contain at least 6 characters. Max: 50.');
 return;
}
 else if( !validPassword(pw) ){
 toast('Passwords can only contain these characters: a-z 0-9 ~@#%_+*?-');
 return;
}

var this_=$(t);
    buttonSpinner( this_);    
    this_.prop('disabled',true);
    
  connCounts++;
  
$.ajax({
  url: config_.domain + '/oc-ajax/change-password.php',
  type:'POST',
dataType:'json',
  data: {
  'version': config_.APP_VERSION,
  'username': username,
  'old_password': opw,
  'new_password': pw,
  'token': __TOKEN__,
 }
}).done(function( result ){
	connCounts--;
  buttonSpinner( this_,true);
 this_.prop('disabled',false);
  
  if( result.status){
  toast( result.result,{type:'success'});
   pbox.val('');
   opbox.val('');
  }else if(result.error){
  toast(result.error);
}else{
   toast('Password could not be changed.');
  }
}).fail(function(e,txt, xhr){
	connCounts--;
  buttonSpinner( this_,true);
this_.prop('disabled',false);
  toast('Something went wrong. ' + xhr);
 //alert(JSON.stringify(e) );
  });
}

var exitTime__=false;

function go_onBackPressed(){
	
	localStorage.removeItem("message_opened");
  if( localStorage.getItem('message_opened')){
    return;
 } else if( $('.display--data').length ){
   var elem=$('.display--data:last');
  if(!elem.hasClass('no-cancel') ){
   closeDisplayData( elem.data('class'),null,true );
  closeTopPageList(); //this just cancel ajax
 }
  return;
}
else if($('.console-log').is(':visible')){
  $('.console-log,#show-console-log' ).css('display','none');
    return;
  }
  
 else if( $('#go-full-photo-container').is(':visible')){
   closeFullPhoto();
   return;
 }
  else if( $('#go-full-cover-photo-container').is(':visible')){
  closeFullCoverPhoto();
    return;
  }
  else if( $("#go-video-element-container").is(":visible") ){
  return go_exitVideoFullScreen();
 }
  else if( $('#compose-post-container').is(':visible')){
  return closeComposePage();  
 }
  else if( $('#go-profile-update-container').is(':visible')){
  return closeProfileUpdateForm();
  }  
  else if( $('#go-rcomment-container').is(':visible')){
    return  goCloseCommentReply();
 }  
  else if( $('#go-comment-container').is(':visible')){
   return  goCloseComment();
 }
  
  else if( $('#go-profile-container').is(':visible')){
  return goCloseProfile();
  }
  
  else if($('#go-followers-container').is(':visible') ){
  return closeViewFollowers(); 
  }
  else if($('#go-following-container').is(':visible') ){
  return closeViewFollowing(); 
  }
 
  else if($('#go-blocked-followers-container').is(':visible') ){
  return closeViewBlockedFollowers(); 
  }
  else if( $('#go-follow-container').is(':visible') ){
    clearTimeout(fsuggestionsTimeout);
    if( fsuggestionsAjax) fsuggestionsAjax.abort()
  return closeFollowForm(); 
  }
  else if($('#go-settings-container').is(':visible') ){
  return closeSettingsPage(); 
  }
 else if($('#go-saved-posts-container').is(':visible') ){
  return closeSavedPosts(); 
  }
 else if( $(".reactions-box").length){
   $(".reactions-box").remove();
   return;
 }
  else if( $('#go-single-post-container').is(':visible') ){
  return closeSinglePost();
 }
  
 else if($('#go-notifications-container').is(':visible') ){
 
  return closeNotifications(); 
  }
   
 else if($('#go-search-container').is(':visible')){
   return closeSearch(); 
 }  
  else if( $('#go-request-app-container').is(':visible')){
   closeRequestApp();
   return;
 }
  else if( $('#go-create-page-form-container').is(':visible') ){
    closeCreatePageForm(); 
  } 
  else if( $('#go-downloads-container').is(':visible') ){
   return closeDownloadsPage(); 
  } 
  
  else if ( !$('.right-side-bar-container').hasClass("hide-right-sidebar")
        && $("#IS-MOBILE").is(":visible") ){
 return closeRightMenus();
}
  
else if ( !$('.side-bar-container').hasClass("hide-left-sidebar") 
        && $("#IS-MOBILE").is(":visible") ){
 
   closeMenus();
  
   return;
 } 
 else{
   if( exitTime__ ){
    closeGoSocial();
     return;
   }
  //toast('Press again to exit.');
    exitTime__=true;
  setTimeout( function(){
    exitTime__=false; },1500);
 }
 
}




//COMMENTS BEGINS

var GO_COMMENT_UPLOAD_FILE_PATHS=[]; 
var GO_COMMENT_UPLOADED_FILE_PATHS=[];

var sendBtn=$('#send-message-btn');
var voiceBtn= $('#voice-message-btn');
var attachBtn= $('#attachment-btn-container');

var fetchingComment=false;
var commentAjax;
var commentTimeout=0;
var fetchingRComment=false;
var commentRAjax;
var commentRTimeout=0;

function storedCommentsLikes_(){
	var sl=localStorage.getItem("COMMENTS_SAVED_LIKES")||"";
	var len=sl.length;
if( len> 3000){
	localStorage.removeItem("COMMENTS_SAVED_LIKES");
	sl=null;
}
  return sl?JSON.parse(sl):{}
}

var COMMENTS_SAVED_LIKES= storedCommentsLikes_();

function commentLiked(lid){
	return COMMENTS_SAVED_LIKES[lid];
}
	
function storeCommentLike(lid){
 COMMENTS_SAVED_LIKES[lid]=1;
 localStorage.setItem("COMMENTS_SAVED_LIKES", JSON.stringify( COMMENTS_SAVED_LIKES));
}

function removeCommentLike( lid){
		delete COMMENTS_SAVED_LIKES[lid];
		localStorage.setItem("COMMENTS_SAVED_LIKES", JSON.stringify( COMMENTS_SAVED_LIKES));
	}

function bbcode_comment(data){
  var reg=/@\[::(.*?)::(.*?)::\]/gi;
    data=data.replace(reg, function(m,tagged,tagged_name){
   return '<span class="go-comment-tagged-pin go-open-profile" data-user="' + tagged + '" data-user-fullname="' + tagged_name + '">' + tagged_name + '</span>';
    });
  return data;
}


function commentAuthorPicture(fuser, class_, verified){
  class_=class_||'friend-picture';
  var real_path=config_.users_path + '/' + strtolower( fuser[0]+'/' + fuser[1] + '/' + fuser[2] + '/' + fuser ) + '/profile_picture_small.jpg';
  var local_path=__THEME_PATH__ + '/assets/chat-icons/no_profile_picture.jpg';
 return '<img class="lazy ' + class_ + '" alt="" onerror="imgError(this);" src="' + local_path + '" data-src="' + real_path + '" data-verified="' + (verified?'1':'') + '" data-id="' + strtolower(fuser ) + '">';
}

function imgError(image) {
  var src="' + __THEME_PATH__ + '/assets/chat-icons/no_profile_picture.png";
    image.src = src;
}


$(function(){
 
$('body').on('click','.go-open-comments-box',function(){
      
  var this_=$(this);
  var pid= this_.data('pid');
  var post_by= $.trim( this_.data('post-by') );
 if(!post_by){
   return toast('Post author not found.');
 }
  
  if( pid.length<1 ) return toast('Post id not found.');
  
/*
var highlight=this_.attr('data-highlight')||"";
  highlight=highlight.replace(/(\s|<br>|\?r|\?b|\?g|\?lg|\?sm|`|-|\*|\~|_|\|)/g,' ');
  
  $('#post-comment-title').text( highlight);
 */
  
 var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val() );
      cpi.val( pid);
  $('#current-post-by').val(post_by);

 var ccont= $('#go-comment-container')
 var mccont= $('#my-comments-container')
  
 var pc=$('#post-comments');  
  
 if(cpiv!=pid){ 
  $('#prev-comments').css('display','none');
   mccont.empty();
   pc.empty();
 if(commentAjax) commentAjax.abort();
   clearTimeout( commentTimeout);
  fetch_comments(  pid);
 }
  
  var zi=zindex();
 
// $('#go-profile-container').css('z-index', (zi-10) );
   ccont.css({'display':'block','z-index': zi }); 
   changeHash("comments");
});
  

$('body').on('click','#comment-refresh-btn',function(){
 
  if( fetchingComment){
   return toast('Please be patient.');
 }   
  $('#my-comments-container,#post-comments').empty();
   $('#prev-comments,#next-comments').css('display','none');
   fetch_comments("");
  
 });
  
$('body').on('click','#prev-comments',function(){
 if( fetchingComment){
   return toast('Please be patient.',{type:'light',color:'#333'});
 }
  var page=$(this).attr('data-value');
  if(!page) return toast('No more comments.',{type:'light',color:'#333'});
 //$('#my-comments-container,#post-comments').empty(); 
   fetch_comments("", page);   
 });
  
  
$('body').on('click','.delete-comment',function(){
  var this_=$(this);
  var cid=this_.attr('data-cid');
  var post_id=this_.attr('data-pid');
  var author=this_.attr('cauthor');
 
  if(!confirm('Delete selected comment?') ) return false;

 if(!cid ){
    return toast('Comment id not found.');
  }
 
 var tb=$('#go-comment-box');
     tb.prop('disabled', true); 
      
    $('#post-comment-sending-cont').append('<span id="comment-sending-icon"><img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></span>');

  var loader=$('#comment-loader-container');
  loader.css('display','block');
  
  connCounts++;
  
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/delete-comment.php',
    type:'POST',
  // timeout: 10000,
     dataType: "json",
    data: {
      "username": username,
      "cauthor": author,
      "comment_id": cid,
      "post_id": post_id,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  	connCounts--;
    //alert(JSON.stringify(result))
   $('#comment-sending-icon').remove();
   tb.prop('disabled', false); 
  if( result.status){
   $('#post-comments-container #ccc-' + cid).remove();
  }
   else if(result.error){
      toast(result.error );
  }
   else toast('Unknown error');
    loader.css('display','none');
 }).fail( function(e,txt,xhr){
 	connCounts--;
   loader.css('display','none');
  $('#comment-sending-icon').remove();
  toast('Something went wrong');
  tb.prop('disabled', false);
  report__('Error ".delete-comment"', JSON.stringify(e),true );
 
  });
    
  },1000);
});
  
});



function fetch_comments( post_id, page_number){
  var cpi=$('#current-post-id');
  var pby=$('#current-post-by').val();

  var cpiv=$.trim(cpi.val() );
   post_id=cpiv||post_id;
  page_number=page_number?'?page=' + page_number:'';
    
  var tb=$('#go-comment-box');
      tb.prop('disabled', true);
 
  var loader=$('#comment-loader-container');
  loader.css('display','block');
  var npBtn=$('#prev-comments,#next-comments');
   npBtn.prop('disabled', true);
    
  fetchingComment=true;
  //var containerId=randomString(5);

   connCounts++;

commentTimeout=setTimeout(function(){
     
  commentAjax =$.ajax({
    url: config_.domain + '/oc-ajax/go-social/fetch_comments.php' + page_number,
    type:'POST',
  // timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "post_id": post_id,
      "post_by": pby,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function( result){
  	connCounts--;
  if( cpi.val()!=cpiv) return;
    fetchingComment=false;
 npBtn.prop('disabled',false);
 //alert(JSON.stringify(result))
    var nextPage=result.next_page;
    var prevPage=result.prev_page;
    
  if(result.no_comment){
    
  $('#post-comments').html('<div class="text-center no-comment-container" id="no-comment-cont-' + post_id + '">No Comment Yet</div>');
  }
 else if( result.result){
    var rdata=result.result;
    var ipp=+result.item_per_page;
    var total=rdata.length;
 
 try{
   
   var likes_data="";
   
  $.each( rdata, function(i,v){
    
    var following=v["me_following"];
  
  if( following!="0"){
    var cid= v["id"];
    var likes=v["likes"];
    //var fullname=v["fullname"];
    var cauthor=v["comment_author"];
    var comment=v["message"];
    var cfullname=v["fullname"];
    var has_replies=+v["has_replies"];
    var post_files=v["post_files"]||"";
    
    var meta=JSON.parse( v["meta"] );
        meta["post_id"]=post_id;

if(  commentLiked(cid)  ){
  var liked=true;    
  }else {
   var liked=false;   
  }    
    display_comment('prepend', cid, comment, post_files, meta, cauthor, cfullname, has_replies, false, nextPage,likes,liked);
  } 
  });
   
 }catch(e){
    toast(e); 
}

    
    npBtn.css('display','none');
   
 if( prevPage ){
   // $('#next-comments').attr('data-value', prevPage).css('display','block');  
 }
  if( nextPage ){
    $('#prev-comments').attr('data-value', nextPage).css('display','block');
 }
   
  }
   else if(result.error){
    toast(result.error,{type:'light',color:'#333'});  
  }
    loader.css('display','none');
    tb.prop('disabled', false);
   // sendBtn.prop('disabled', false)
  }).fail( function(e,txt,xhr){
    connCounts--;
 if( $('#go-comment-container').is(':visible') ){
    commentTimeout=setTimeout(function(){
     fetch_comments( post_id, page_number);
 },5000);
   
 }else{
   fetchingComment=false;
   npBtn.prop('disabled',false)
   loader.css('display','none');    
 }
  //  toast('Check network. ' + xhr,{type:'light',color:'#333'});
   tb.prop('disabled', false);
    report__('Error "fetch_comments()"', JSON.stringify(e),true );
 
    
  });
   }, 1000);  
}

function display_comment( type, cid, comment, post_files, meta, author_, fullname, has_replies, me, paging,likes,liked){
   type=type||'append';
   
 if(me){   
   var mccont= $('#my-comments-container');
 }
else{
  var mccont=$('#post-comments');
}
 
  var com_files=meta.com_files||"";
  var has_files=meta.has_files||"";
  var post_id= meta.post_id||"";

  var v=checkVerified( author_, fullname);
  var icon=v.icon;
  var author= v.name;
  var ctime=meta.time||moment().unix();
  
  var cdate=timeSince( ctime);
  
  var isMe=false;
  
 if( author_==username){ 
    isMe=true;
  }

 var data='<div class="comment-child-container ' + (isMe?'my-comment-container':'') + '" id="ccc-' + cid + '">';
  data+='<div class="' + ( isMe?'text-right':'') + '">';
  
 if( !isMe) data+='<span class="d-inline-block go-comment-author-icon-container" style="margin-right: 5px; margin-left: 5px;">' + commentAuthorPicture( author_ ,'go-comment-author-icon nosave' ) + '</span>';

 data+='<div class="comment-bubble" id="' + cid + '">';
 data+='<span class="highlight comment-author go-open-profile friend-' + author_ + '" data-user-fullname="' + author + '" data-user="' + author_ + '">' + strtolower( fullname) + ' ' + icon + '</span>' ;

 data+='<div class="comment-message">' + bbcode_comment( comment ) + '</div>';
 
 data+='<div class="go-comment-files-container">';
 data+= go_formatFiles( post_files, null, null, null, true );
 data+='</div></div>';
  
 if( isMe)  data+='<span class="d-inline-block go-comment-author-icon-container" style="margin-left: 5px; margin-right: 5px;">' + commentAuthorPicture( author_ ,'go-comment-author-icon nosave' ) + '</span>';
 
  data+='</div>';
  
  data+='<div class="comment-footer">';
  
 if(isMe || goAdmin(username) ){
   data+='<span class="delete-comment" id="delc-' + cid + '" data-pid="'+ post_id + '" data-cid="' + cid + '" cauthor="' + author_ + '"><img class="w-16 h-16" src="' + __THEME_PATH__ + '/assets/chat-icons/delete.png"></span>';
 }
  likes=likes||0;
  data+=' <span class="comment-date">' + cdate + '</span>';
  data+='<span class="like-comment" id="like-comment-' + cid + '" data-cby="' + author_ + '" data-cid="' + cid + '" data-total-likes="' + likes + '" onclick="like_comment(this);">';
  data+='<span class="' + ( liked ? 'text-info':'text-secondary' ) + ' me-2"><strong>Like</strong></span>';
  data+='</span>';
 
  data+='<span id="reply-btn-' + cid + '" class="reply-comment text-secondary me-2" data-parent-id="' + cid + '" data-cby="' + author_ + '" data-fullname="' + fullname + '" onclick="replyComment(this,\'' + author_ + '\');"><strong>Reply</strong></span>';
  data+=' <img id="like-img-' + cid + '" class="me-2 w-16 h-16" src="' + __THEME_PATH__ + '/assets/chat-icons/' + ( liked?'liked':'like' ) + '.png"> <span class="likes" id="likes-' + cid + '">' + abbrNum( + likes,1 ) + '</span>';
 
 if( has_replies>0){
  data+='<div class="text-dark mt-1 mb-2 text-center" data-parent-id="' + cid + '" data-fullname="' + fullname + '" onclick="replyComment(this);"><strong>View replies</div></div>';
 }
  
  data+='</div>';
  data+='</div>';
  
  if( type=='append'){
  mccont.append(data)
  } else{
  mccont.prepend(data);
  }
}


function format_comment(gpin, post_id,com_files,clen){
 var currentTime=moment().unix();
   var obj_=new Object();
  obj_.post_id="" +  post_id;
  obj_.cf="" +   username;
  obj_.fullname=userData('fullname');
  obj_.com_files="" + com_files; //video, image
  obj_.has_files="" + ( com_files?1:0);
  obj_.size="" + clen; //txt size or file size 
  obj_.time="" + currentTime;
  obj_.ver="" + config_.APP_VERSION;
    return obj_;
}



function add_comment( fuser, comment_, mlen){

   var fpaths=GO_COMMENT_UPLOADED_FILE_PATHS;
   var fpaths_="";
   var com_files="";
   var total_files=fpaths.length;
   var hasFiles=0;
  
  if( total_files){
  com_files= JSON.stringify( fpaths)
  hasFiles=1;
  }  
  
   if( mlen > go_config_.mcl){
    return toast('Comment too long.');  
  }
  var rcid=randomString(5);
  
  var displayComment=sanitizeLocalText(comment_ );
  var comment=sanitizeMessage( comment_);
  
  var tb=$('#go-comment-box');
      tb.prop('disabled', true);
   
  var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val());
  var post_by= $.trim( $('#current-post-by').val() )
  
  if( !$('#post-comment-sending-cont #comment-sending-icon').length){
  	
    $('#post-comment-sending-cont').append('<span id="comment-sending-icon"><img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></span>');
  }
  
 var sb=$('#post-comments-container');
     sb.scrollTop( sb.prop("scrollHeight") );
 
  var fullname=userData('fullname');
  
  var meta=format_comment(fuser, cpiv,com_files,mlen);
 	
  display_comment('append', rcid, displayComment, com_files, meta, username, fullname, 0, true);
  
 var cdiv=$('#my-comments-container #ccc-' + rcid);
 var delBtn= $('#my-comments-container #delc-' + rcid);
 var likeBtnCont=$('#my-comments-container #like-comment-' + rcid);
 var likeBtn=$('#my-comments-container #like-img-' + rcid );
 var replyBtn=$('#my-comments-container #reply-btn-' + rcid );
 
  delBtn.css('display','none');
  likeBtnCont.css('display','none');
  replyBtn.css('display','none')
   
     meta=JSON.stringify( meta);
  
 var btn= $('#go-send-comment-btn');
    btn.prop('disabled',true);
    
var loader=$('#comment-loader-container');
  loader.css('display','block');
 
  connCounts++;
  
  setTimeout(function(){
     $.ajax({
    url: config_.domain + '/oc-ajax/go-social/add_comment.php',
    type:'POST',
  // timeout: 10000,
     dataType: "json",
    data: {
      "username": username,
      "fullname": fullname,
      "message": comment,
      "meta": meta,
      "post_files": com_files,
      "has_files": hasFiles,
      "post_id": cpiv,
      "post_by": post_by,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
   // alert(JSON.stringify(result) );
   connCounts--;
  $('#comment-sending-icon').remove();
  loader.css('display','none');
  
   btn.prop('disabled', false);
   tb.prop('disabled', false);
 if( result.status=='success'){
   sessionStorage.removeItem('temp-com-text-' + fuser);
   GO_COMMENT_UPLOADED_FILE_PATHS=[];
   $('#go-comment-upload-preview-container').empty()
   $('#post-comments #no-comment-cont-' + cpiv).remove();
   var id= result.result;
 
if(id>0){
  
  delBtn.attr('data-cid', id).attr('data-pid', cpiv).css('display','inline-block');
  cdiv.attr('id', 'ccc-' + id);
  $('#likes-' + rcid).attr('id','likes-' + id);
  likeBtnCont.attr('data-cid', id).attr('id','like-comment-' + id).css('display','inline-block');
  likeBtn.attr('id','like-img-' + id);
  replyBtn.attr('data-parent-id',id ).attr('id','reply-btn-' + id).css('display','inline-block');
  
}
   tb.val('');
   tb.autoHeight();
  return;
 }else if(result.error){
    toast( result.error);
   $('#post-comments-container #ccc-' + rcid ).remove();
 }

 }).fail(function(e,txt,xhr){
 	connCounts--;
 	loader.css('display','none');
    $('#comment-sending-icon, #post-comments-container #ccc-' + rcid ).remove();
  toast('Something went wrong');
   tb.prop('disabled', false);
   btn.prop('disabled', false);
   report__('Error "add_comment()"', JSON.stringify(e),true );
 
  });
    
  },1000);
}

function like_comment(t){
  var this_=$(t);
  var cpi=$('#current-post-id');
  var post_id=$.trim( cpi.val() );
  var post_by=$.trim( $('#current-post-by').val());
  var cid=this_.attr('data-cid');
  var comm_by=this_.attr('data-cby');
  var parent_id=$.trim( $('#comment-parent-id').val())||"";
 
  var type=1;

 if( commentLiked(cid)){
  type=2;
}
    
   var tb=$('#go-comment-box');
      tb.prop('disabled', true);
   this_.prop('disabled',true);
 
  var isReply=$('#go-rcomment-upload-preview-container').is(':visible');
 
  if( isReply){
 var loader=$('#rcomment-loader-container')
  }else{
 var loader=$('#comment-loader-container');
  }
  
  loader.css('display','block');
 commentLikeTimeout=setTimeout(function(){
    var fullname=userData('fullname');
   
   connCounts++;
   
  commentAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/like-comment.php',
    type:'POST',
  // timeout: 10000,
     dataType: "json",
    data: {
      "username": username,
      "fullname": fullname,
      "comment_id": cid,
      "post_id": post_id,
      "post_by": post_by,
      "parent_id":parent_id,
      "comment_by": comm_by,
      "type": type,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function( result){
  //  alert( JSON.stringify(result))
  connCounts--;
    loader.css('display','none');
    this_.prop('disabled', false);
    tb.prop('disabled', false);
  if(result.status  ){
  
   var elem= $('#likes-' + cid);
   var curr_likes=  +this_.attr('data-total-likes');
    
   if( type==1){
     curr_likes=curr_likes+1;
     elem.text( abbrNum( curr_likes, 1) );
     this_.attr('data-total-likes', curr_likes)
   $('#like-img-' + cid).attr('src', __THEME_PATH__ + '/assets/chat-icons/liked.png');
   $('#like-comment-' + cid + ' span').addClass('text-info').removeClass('text-secondary');
  // this_.addClass("comment-liked");
   storeCommentLike(cid);   
  }
    else {
   removeCommentLike( cid);
    
      curr_likes=curr_likes-1;
      elem.text( abbrNum(curr_likes,1) );
      this_.attr('data-total-likes', curr_likes);
     
  this_.removeClass("comment-liked");
  
 $('#like-img-' + cid).attr('src', __THEME_PATH__ + '/assets/chat-icons/like.png');

   $('#like-comment-' + cid + ' span').addClass('text-secondary').removeClass('text-info'); 
 
    }
 }else if( result.error){
    toast(result.error );
 }
    
  }).fail(function(e,txt,xhr){
  	connCounts--;
    loader.css('display','none');
    this_.prop('disabled', false);
    tb.prop('disabled', false);
  report__('Error "like_comment()"', JSON.stringify(e), true );
 
 });

 },2000);
}

function goCommentUploadFiles(){
  var fpaths=GO_COMMENT_UPLOAD_FILE_PATHS;
 
 if( fpaths.length<1 ) return;
  
  var v=fpaths[0];
   
  var v_=v.split(".")
  var ext=v_[1];
  var filename=v_[0];

  var pElem=$('#comment-vid-poster-' + filename);
  var base64=$("#comment-base64-data-" + filename).val();
 
 var file_size= base64.length;
 
  var pCont=$('#go-comment-up-progress-container-' + filename);

  var isReply=$('#go-rcomment-upload-preview-container').is(':visible');
  
  setTimeout(function(){
    var poster=pElem.val()||"";
    var pDim=  pElem.data('dim');
    
  $.ajax({
   xhr: function() {
      var xhr = new window.XMLHttpRequest();
    // Upload progress     
    xhr.upload.addEventListener("progress", function(evt){
        if (evt.lengthComputable) {
     var percent= (evt.loaded / evt.total)*100;
  
   $('#go-comment-up-progress-' + filename).css({ width: "" + percent + "%"});
    pCont.css('display','block');
   
  if( percent==100){
    $('#go-comment-up-progress-' + filename).css({width:'100%'});
   // pCont.css('display','none'); //usc-upload status container @"displayMessage()"
  
  }
   }
 }, false); 
       return xhr;
    },
    "url": config_.domain + '/oc-ajax/go-social/upload-comment-file.php',
    "dataType":"json",
    "data":{
     "username" : username,
     "version": config_.APP_VERSION,
     "base64": base64,
     "video_poster": poster,
     "video_dimension": pDim,
     "file_ext": ext,
      "token": __TOKEN__,
 },
 
 type:'POST'
}).done( function(result){
 //alert( JSON.stringify( resp) )
  $('#go-send-comment-btn,#go-send-rcomment-btn').prop('disabled',false);
  
  if( result.status=="success"){
   
var file_obj=new Object();
    file_obj["path"]=result.file_path;
    file_obj["ext"]=result.ext;
    file_obj["width"]=result.width||500;
    file_obj["height"]=result.height||150;
    file_obj["poster"]=result.poster||"";
    file_obj["size"]=result.file_size||file_size;
   
    
    var push_=result.file_path + '|' + result.ext +  (result.poster? '|' + result.poster:'');
  
   GO_COMMENT_UPLOADED_FILE_PATHS.push( file_obj) //push_);
   GO_COMMENT_UPLOAD_FILE_PATHS =$.grep( GO_COMMENT_UPLOAD_FILE_PATHS, function(value) {
   return value != v;
 });
  
 if( isReply ){
   $('#go-send-rcomment-btn').click()
 }else{
   $('#go-send-comment-btn').click();
 }  
  }else if( result.error){
  // var ecode=result.error;
    $("#ucppc-" + filename).remove();
    toast( result.error);
  }
  else{
     toast('Unknown error occured.');
  }
    
  }).fail(function(e,txt,xhr){
     //alert( JSON.stringify(e));
   $('#go-send-comment-btn,#go-send-rcomment-btn').prop('disabled',false);
    toast('Something went wrong');
    report__('Error "goCommentUploadFiles()"', JSON.stringify(e),true );
 
  });
  },2000); 
  
}


function goCloseComment(){
  var ccont=$('#go-comment-container')
  var pcont=$('#go-profile-container');
  var pIndex=+pcont.css('z-index');
  var cIndex=+ccont.css('z-index');
 
if( $('#go-profile-container').is(':visible')){
   if( pIndex > cIndex ) {
     return goCloseProfile();
   }
 }
 
  fetchingComment=false;
  if( commentAjax) commentAjax.abort();
  clearTimeout( commentTimeout);
 $('#comment-loader-container').css('display','none');
 $('#prev-comments,#next-comments').prop('disabled', false);
    
  ccont.css('display','none'); 
}


$(function(){
  
  $('body').on('click','#go-send-comment-btn',function(e){ 
 
 	if( !loggedIn()){
		return toast("Login first");
		}
  
  
     var textBox=$('#go-comment-box'); 
 var msg=$.trim( textBox.val() );
 var fuser=""
 var mlen=( msg.length+1)/1024;
     
  var this_=  $(this);
     
 if( GO_COMMENT_UPLOAD_FILE_PATHS.length>0 ){
    this_.prop('disabled',true);
  return goCommentUploadFiles();
 }
   
 if( GO_COMMENT_UPLOADED_FILE_PATHS.length<1 && !msg){
    
   return toast('Comment empty');
   }

   this_.prop('disabled',true);
    add_comment(fuser, msg, mlen );
 });
   
 
  
  $('body').on('click','.go-comment-remove-upload-preview',function(){
  var this_=$(this);
   var fpath= this_.data('fpath');
   var contId=this_.data('cid');
   var findex= +this_.data('findex');
  
  GO_COMMENT_UPLOAD_FILE_PATHS =$.grep( GO_COMMENT_UPLOAD_FILE_PATHS, function(value) {
   return value != fpath;
 });
   
   
   $('#' + contId).remove();
   
  });
  
  //PHOTO FULL- COMMENT AUTHOR
  
$('body').on('click','.go-comment-author-icon',function(){
   var this_=$(this);
  var img= this_.attr('src');
   if(!img) return;
   var img   = replaceLast( img,'_small','_full');
     $('#go-full-photo-div').html('<img class="lazy go-full-photo" src="' + __THEME_PATH__ + '/assets/go-icons/bg/transparent.png" data-src="' + img + '">')
  var zi=zindex();
  //$('#go-single-post-container') .css({'display':'block', 'z-index': zi}); //z-index previous: 42
    
  $('#go-full-photo-container').css({'display':'block','z-index': zi});
  changeHash("comments-author");
  });
  
  
  
  
});




function goOpenCommentGallery(event,type){
  //Type: image, video
  var allow_vid=false;
   
// try{
 // var settings= JSON.parse( localStorage.getItem("server_settings") );
 
 if( siteAdmin( username) || SERVER_SETTINGS.enable_vid_doc=="YES"  ){
   allow_vid=true;
  } 
    /*
 }catch(e){ 
  return toast("Loading settings...", { type:"info"});
 }
*/
var cont=$('#go-comment-upload-preview-container');


  cont.empty();
  
 GO_COMMENT_UPLOAD_FILE_PATHS=[]; //Empty paths
   GO_COMMENT_UPLOADED_FILE_PATHS=[]; //Empty uploaded paths
  
var this_=$(event);
    
 this_.prop('disabled',true);  
    
    setTimeout(function(){
    this_.prop('disabled', false);
  }, 1500);

 
 var isVerified= userVerified( username);

var cont=$('#go-upload-preview-container');
  

try{
	
	var imageTypes = ["jpg", "jpeg", "gif","png"];
   var videoTypes=["mp4"]; 

for(let i=0;i<event.files.length;++i){
	var ext= event.files[i].name.split('.').pop().toLowerCase();  //file extension from input file
	
	
    var reader = new FileReader();
    
    reader.onload = function(e){
    var data=	this.result; 
      var type=data.match(/(video|image)/);
 
  if( !type ) return toast("One or more file unsupported");
  
   type=type.toString();
   
 if(   type.match(/image/) ){
    comm_image_( i, data); 
 }
   else{
  comm_video_( i, data);   
 }
    };
    reader.readAsDataURL(event.files[i]);
  }
}catch(e){ alert(e); }
    

   
 }

function comm_image_( i, v){
	var cid=randomString(10);
	var filename=cid;
	var fpath=filename + ".jpg";
	GO_COMMENT_UPLOAD_FILE_PATHS.push( fpath );
	
var cont=$('#go-comment-upload-preview-container');

     var data='<div id="uppc-' + cid + '" data-swid="' + i + '" onclick="swapIt(this)" data-fpath="' + fpath + '" class="go-upload-photo-preview-container">';
  data+='<img class="go-upload-photo-preview" src="' + v + '">';
         data+='<span data-findex="' + i + '" data-fpath="' + fpath + '" data-cid="uppc-' + cid + '" class="go-comment-remove-upload-preview" id="close-upbtn-' + cid + '">x</span>';
         data+='<span id="go-comment-up-progress-container-' + filename + '" class="go-up-progress-container">';
         data+='<span id="go-up-progress-' + filename + '" class="go-up-progress"></span>';
         data+='</span>';
         data+='<textarea class="d-none video-data" id="comment-base64-data-' + filename + '">' + v + '</textarea>';
        data+='<input type="hidden" id="comment-vid-poster-' + cid + '" />';
 
  data+='</div>';
     cont.append( data);
}

function comm_video_(i, v) {
	var cid=randomString(10);
	var filename=cid;
	var fpath=filename + ".mp4"; 
	
    GO_COMMENT_UPLOAD_FILE_PATHS.push(fpath);
   
  var cont=$('#go-comment-upload-preview-container');

   var data='<div id="ucppc-' + cid + '" data-swid="' + i + '" data-fpath="' + fpath + '" class="go-upload-video-preview-container">';
data+='<div id="ucppc-cover-' + cid + '" class="go-video-preview-cover"><img class="w-16 h-16" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></div>';

         data+='<div class="go-video-preview-child-cont" id="cvid-child-cont-' + cid + '">';
         data+='<img src="' + __THEME_PATH__ + '/assets/go-icons/video.png" class="w-30" style="position: absolute; bottom: 0; left: 0; z-index: 10;">';
         data+='<video id="cvid-' + cid + '" data-cid="' + cid + '" data-src="' + v + '" class="go-upload-video-preview" preload="auto"';
         data+=' src="' + v + '" onloadeddata="goCommentVideoPreviewLoaded(this);" onerror="goCommentVideoPreviewError(this);" autoplay muted>';
         data+='</video>';
         data+='</div>';
         data+='<span data-findex="' + i + '" data-fpath="' + fpath + '" data-cid="uppc-' + cid + '" class="go-comment-remove-upload-preview" id="close-upbtn-' + cid + '">x</span>';
         data+='<span id="go-comment-up-progress-container-' + filename + '" class="go-up-progress-container">';
         data+='<span id="go-up-progress-' + filename + '" class="go-up-progress"></span>';
         data+='</span>';
         data+='<textarea class="d-none video-data" id="comment-base64-data-'+ filename + '">' + v + '</textarea>';
   data+='<input type="hidden" id="comment-vid-poster-' + cid + '" />';
 
         data+='</div>';
     
//  $base64 = base64_decode(preg_replace('#^data:image/\w+;base64,#i','', $base64)  );
  
         cont.append( data);
       
 }

   
function goCommentVideoPreviewLoaded(video){ 
  var cid=video.getAttribute("data-cid");
  var src=video.getAttribute("data-src");
  
  var dur=video.duration;
   if(!dur|| dur<2){
       GO_COMMENT_UPLOAD_FILE_PATHS =$.grep( GO_COMMENT_UPLOAD_FILE_PATHS, function(value) {
   return value != src;
   });   
    $('#ucppc-' + cid ).remove();
       toast('Video too short')
       return;
     }  
  
  var dimensions = [video.videoWidth, video.videoHeight];
  
setTimeout(function(){
  var res= go_captureVideoPoster(video, dimensions, 1);
 
  if( res ){
   $("#ucppc-cover-" + cid).remove();

   var elem=$('#comment-vid-poster-' + cid);
   elem.val( res[0]);
alert( res[0])
   elem.attr('data-dim', res[1].toString() );
    }else{
    $('#ucppc-' + cid).remove();
   GO_COMMENT_UPLOAD_FILE_PATHS =$.grep( GO_COMMENT_UPLOAD_FILE_PATHS, function(value) {
   return value != src;
   });   
  }
},100);
}

function goCommentVideoPreviewError(video){
    var this_=$(video);
  var src=this_.data("src");
  var cid=this_.data("cid");
    $('#ucppc-' + cid).remove();
   GO_COMMENT_UPLOAD_FILE_PATHS =$.grep( GO_COMMENT_UPLOAD_FILE_PATHS, function(value) {
   return value != src;
   });
   toast("Some files rejected");
}


//COMMENT REPLY BEGINS

function goCloseCommentReply(){
  var ccont=$('#go-rcomment-container')
  var pcont=$('#go-profile-container');
  var pIndex=+pcont.css('z-index');
  var cIndex=+ccont.css('z-index');
 
if( $('#go-profile-container').is(':visible')){
   if( pIndex > cIndex ) {
     return goCloseProfile();
   }
 }
  fetchingRComment=false;
  if(commentRAjax) commentRAjax.abort();
  clearTimeout( commentRTimeout);
 
   $('#go-rcomment-box').prop('disabled',false);
   $('#go-rcomment-container, #go-view-orig-post').css('display','none');
  $('#comment-parent-id').val("");
  goRemoveCommentTagged();
  
}



$(function(){
 

$('body').on('click','#rcomment-refresh-btn',function(){
 if( fetchingRComment){
   return toast('Please be patient.');
 }   
  $('#my-rcomments-container,#post-rcomments').empty();
   $('#prev-rcomments,#next-rcomments').css('display','none');
   fetch_rcomments("");   
 });
  
$('body').on('click','#prev-rcomments',function(){
 if( fetchingRComment){
   return toast('Please be patient.');
 }
  var page=$(this).attr('data-value');
  if(!page) return toast('No more comments.');
 //$('#my-comments-container,#post-comments').empty(); 
   fetch_rcomments("", page);   
 });
});
  
function deleteRComment(t){
  var this_=$(t);
  var cid=this_.attr('data-cid');
  var post_id=this_.attr('data-pid');
  var author=this_.attr('cauthor');
  
  if( !confirm('Delete selected comment?') ) return false;

 if(!cid){
    return toast('Comment id not found.');
  }
 
 var tb=$('#go-rcomment-box');
     tb.prop('disabled', true); 
      
    $('#post-rcomment-sending-cont').append('<span id="rcomment-sending-icon"><img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></span>');
    
  var loader=$('#rcomment-loader-container');
  loader.css('display','block');
 
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/delete-comment.php',
    type:'POST',
  // timeout: 8000,
     dataType: "json",
    data: {
      "username": username,
      "cauthor": author,
      "comment_id": cid,
      "post_id": post_id,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
    //alert(JSON.stringify(result))
   $('#rcomment-sending-icon').remove();
   tb.prop('disabled', false); 
  if( result.status){
   $('#post-rcomments-container #ccc-' + cid).remove();
  }
   else if(result.error){
      toast(result.error );
  }
   else toast('Unknown error');
    loader.css('display','none');
 }).fail( function(e,txt,xhr){
   loader.css('display','none');
  $('#rcomment-sending-icon').remove();
  toast('Something went wrong');
  tb.prop('disabled', false);
  report__('Error "deleteRComment() in go-reply-comment.js"', JSON.stringify(e),true );
 
  });
    
  },1000);
}



function fetch_rcomments( parent_id, page_number){
  var cpi=$('#current-post-id');
  var post_by=$('#current-post-by').val();
  var post_id=$.trim(cpi.val() );
  parent_id=$.trim( $('#comment-parent-id').val() )||parent_id;
 
  page_number=page_number?'?page=' + page_number:'';
    
  var tb=$('#go-rcomment-box');
      tb.prop('disabled', true);
 
  var loader=$('#rcomment-loader-container');
  loader.css('display','block');
  var npBtn=$('#prev-rcomments,#next-rcomments');
  npBtn.prop('disabled',true);
    
  fetchingRComment=true;
  //var containerId=randomString(5);
   rcommentTimeout=setTimeout(function(){
    

  rcommentAjax=$.ajax({
    url: config_.domain + '/oc-ajax/go-social/fetch_comments-replies.php' + page_number,
    type:'POST',
   //timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "parent_id": parent_id,
      "post_by": post_by,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function( result){
 // if( cpi.val()!=cpiv) return;
    fetchingRComment=false;
   npBtn.prop('disabled',false)
 //alert(JSON.stringify(result))
    var nextPage=result.next_page;
    var prevPage=result.prev_page;
    
  if(result.no_comment){
    
  $('#post-rcomments').html('<div class="text-center no-comment-container" id="no-rcomment-cont-' + parent_id + '">' + result.no_comment + '</div>');
  }
 else if( result.result){
    var rdata=result.result;
    var ipp=+result.item_per_page;
    var total=rdata.length;
 
 try{
   
   var likes_data="";  
   
  $.each( rdata, function(i,v){
  
    var cid= v["id"];
    var likes=v["likes"];
    var cauthor=v["comment_author"];
    var comment=v["message"];
    var cfullname=v["fullname"];
    var has_replies=v["has_replies"];
    var post_files=v["post_files"]||"";
    
    var meta=JSON.parse( v["meta"] );
        meta["post_id"]=post_id;
        
        
  if( commentLiked( cid )){
  var liked=true;
    
  }else {
   var liked=false;   
   }    
    display_rcomment('prepend', cid, comment, post_files, meta, cauthor, cfullname, has_replies, false, nextPage,likes,liked);
  
  })
 }catch(e){
  toast(e); 
}
   
   npBtn.css('display','none');
 if( prevPage ){
   // $('#next-comments').attr('data-value', prevPage).css('display','block');  
 }
  if( nextPage ){
    $('#prev-rcomments').attr('data-value', nextPage).css('display','block');
 }
   
  }
   else if(result.error){
    toast(result.error,{type:'light',color:'#333'});  
  }
    loader.css('display','none');
    tb.prop('disabled', false);
   // sendBtn.prop('disabled', false)
  }).fail(function(e,txt,xhr){
  
  if( $('#go-rcomment-container').is(':visible') ){

   setTimeout( function(){
     fetch_rcomments( parent_id, page_number);
   },5000);

}
   else{ 
    fetchingRComment=false;
    npBtn.prop('disabled',false)
    loader.css('display','none');
 //  toast('Something went wrong');
    tb.prop('disabled', false);
   report__('Error "fetch_rcomment()"', JSON.stringify(e),true );
 
   }
 });
   },1000);
}


function display_rcomment( type, cid, comment, post_files, meta, author_, fullname, has_replies, me, paging,likes,liked){
   type=type||'append';
  
 if( me ){   
   var mccont= $('#my-rcomments-container');
 }
else{
  var mccont=$('#post-rcomments');
}
 
  var has_files=meta.has_files||"";
  var post_id= meta.post_id||"";
  
  var v=checkVerified( author_, fullname);
  var icon=v.icon;
  var author= v.name;
  var ctime=meta.time||moment().unix();
  
  var cdate=timeSince( ctime);
  var isMe=false;
  
 if( author_==username){ 
    isMe=true;
  }
  
 var data='<div class="comment-child-container ' + (isMe?'my-comment-container':'') + '" id="ccc-' + cid + '">';
  data+='<div class="' + ( isMe?'text-right':'') + '">';
if(!isMe ){
  data+='<span class="d-inline-block go-comment-author-icon-container" style="margin-right: 5px; margin-left: 5px;">' + commentAuthorPicture( author_ ,'go-comment-author-icon nosave' ) + '</span>';
}
  
 data+='<div class="comment-bubble" id="' + cid + '">';
 data+='<span class="highlight comment-author go-open-profile" data-user-fullname="' + author + '" data-user="' + author_ + '">' + fullname + ' ' + icon + '</span>' ;
  
 data+='<div class="comment-message">' + bbcode_comment( comment) + '</div>';
 data+='<div class="go-comment-files-container">';
  
 data+= go_formatFiles( post_files, null,null,null, true );
 
  data+='</div></div>';
  
 if(isMe ){
  data+='<span class="d-inline-block go-comment-author-icon-container" style="margin-right: 5px; margin-left: 5px;">' + commentAuthorPicture( author_ ,'go-comment-author-icon nosave' ) + '</span>';
}
  
  data+='</div>';
 
  data+='<div class="comment-footer">';
  
 if(isMe || goAdmin(username) ){
   data+='<span class="me-3" id="delc-' + cid + '" data-pid="'+ post_id + '" data-cid="' + cid + '" onclick="deleteRComment(this);" cauthor="' + author_ + '"><img class="w-16 h-16" src="' + __THEME_PATH__ + '/assets/chat-icons/delete.png"></span>';
 }
  likes=likes||0
  data+=' <span class="comment-date">' + cdate + '</span>';
  data+='<span class="like-comment" id="like-comment-' + cid + '" data-cby="' + author_ + '" data-cid="' + cid + '" data-total-likes="' + likes + '" onclick="like_comment(this);">';
  data+=' <span class="' + ( liked?'text-info':'text-secondary' ) + ' me-2"><strong>Like</strong></span>';
  data+='</span>';
  data+=' <span id="reply-btn-' + cid + '" class="reply-comment text-secondary me-2" onclick="replyComment(this);" data-parent-id="' + cid + '" data-tag="' + author_ + '" data-fullname="' + fullname + '"><strong>Reply</strong></span>';
  data+=' <img id="like-img-' + cid + '" class="me-2 w-16 h-16" src="' + __THEME_PATH__ + '/assets/chat-icons/' + ( liked?'liked':'like' ) + '.png"> <span class="likes" id="likes-' + cid + '">' + abbrNum( +likes, 1 ) + '</span>';
  
 if( has_replies ){
    //data+='<div class="text-dark mt-1 mb-2 text-center" onclick="replyComment(this);" data-cid="' + cid + '"><strong>View replies</div></div>';
  }
  data+='</div>';
  data+='</div>';
  
  if( type=='append'){
  mccont.append(data)
  } else{
  mccont.prepend(data);
  }
}


function format_comment(gpin, post_id, has_files, clen){
 var currentTime=moment().unix();
   var obj_=new Object();
  obj_.post_id="" +  post_id;
  obj_.cf="" +   username;
  obj_.fullname=userData('fullname');
  obj_.has_files=has_files||0;
  obj_.size="" + clen; //txt size or file size 
  obj_.time="" + currentTime;
  obj_.ver="" + config_.APP_VERSION;
  return obj_;
  }



function add_rcomment( fuser, comment, mlen){
   var fpaths=GO_COMMENT_UPLOADED_FILE_PATHS;
   var fpaths_="";
   var com_files="";
   var total_files=fpaths.length;
   var hasFiles=0;
  
  if( total_files){
    com_files= JSON.stringify( fpaths);
   hasFiles=1;
  }
  
 
   if( mlen> go_config_.mcl ){
    return toast('Comment too long.');  
  }
  var rcid=randomString(5);
  
  
  var tb=$('#go-rcomment-box');
      tb.prop('disabled', true);
   
  var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val());
  var post_by= $.trim( $('#current-post-by').val() )
  var parent_id=$('#comment-parent-id').val();
 
  if( !$('#post-rcomment-sending-cont #rcomment-sending-icon').length){
  	
    $('#post-rcomment-sending-cont').append('<span id="rcomment-sending-icon"><img class="w-20 h-20" src="' + __THEME_PATH__ + '/assets/loading-indicator/loading2.png"></span>');
  }
   
  
 var sb=$('#post-rcomments-container');
     sb.scrollTop( sb.prop("scrollHeight") );
 
  var fullname=userData('fullname');
  
  var meta=format_comment(fuser, cpiv, hasFiles, mlen);
   
 var btn= $('#go-send-rcomment-btn');
    btn.prop('disabled',true);
  
  var displayComment=sanitizeLocalText( comment);
  var comment=sanitizeMessage( comment );
  
 
 var tagged="";
 var tagged_name="";
  
 var taggedDiv=$("#go-comment-tagged");

  if( taggedDiv.length){
   
  tagged=taggedDiv.attr("data-tagged")||"";
  tagged_name=taggedDiv.text()||"";
    
  comment="@[::" + tagged + "::" + tagged_name + "::] " + comment;
  displayComment="@[::" + tagged + "::" + tagged_name + "::] " + displayComment;
 
  }
  
  display_rcomment('append', rcid, displayComment, com_files, meta, username, fullname, 0, true);
  
 var cdiv=$('#my-rcomments-container #ccc-' + rcid);
 var delBtn= $('#my-rcomments-container #delc-' + rcid);
 var likeBtnCont=$('#my-rcomments-container #like-comment-' + rcid);
 var replyBtn=$('#my-rcomments-container #reply-btn-' + rcid);
 var likeIcon=$('#my-rcomments-container #like-img-' + rcid);
 
  delBtn.css('display','none');
  likeBtnCont.css('display','none');
  replyBtn.css('display','none');
  
  
  meta=JSON.stringify( meta);
  
  var loader=$('#rcomment-loader-container');
  loader.css('display','block');
  
  setTimeout(function(){
    $.ajax({
    url: config_.domain + '/oc-ajax/go-social/add-comment-reply.php',
    type:'POST',
 //  timeout: 30000,
     dataType: "json",
    data: {
      "username": username,
      "fullname": fullname,
      "message": comment,
      "meta": meta,
      "post_files": com_files,
      "has_files": hasFiles,
      "post_id": cpiv,
      "parent_id": parent_id,
      "post_by": post_by,
      "tagged": tagged,
      "tagged_name": tagged_name,
      "version": config_.APP_VERSION,
      "token": __TOKEN__
    }
  }).done(function(result){
  //alert(JSON.stringify(result) );
loader.css('display','none');
  $('#rcomment-sending-icon').remove();
   btn.prop('disabled', false);
   tb.prop('disabled', false);
      
 if( result.status=='success'){
   goRemoveCommentTagged();
    sessionStorage.removeItem('temp-com-text-' + fuser);
   GO_COMMENT_UPLOADED_FILE_PATHS=[];
   $('#go-rcomment-upload-preview-container').empty()
   $('#post-rcomments #no-rcomment-cont-' + parent_id).remove();
   var id= result.result;
 
if(id){
  delBtn.attr('data-cid', id).attr('data-pid', cpiv).css('display','inline-block');
  cdiv.attr('id', 'ccc-' + id);
  $('#likes-' + rcid).attr('id', 'likes-' + id);
  likeBtnCont.attr('data-cid', id).attr('id', 'like-comment-' + id).css('display','inline-block');
  likeIcon.attr('id','like-img-' + id);
  replyBtn.attr('data-parent-id', parent_id).attr('id','reply-btn-' + id).css('display','inline-block');
}
   tb.val("");
   tb.autoHeight();
  return;
 }else if(result.error){
    toast( result.error);
   $('#post-rcomments-container #ccc-' + rcid ).remove();
 }

 }).fail(function(e,txt,xhr){
    $('#rcomment-sending-icon, #post-comments-container #ccc-' + rcid ).remove();
    loader.css('display','none');
   toast('Something went wrong');
   tb.prop('disabled', false);
   btn.prop('disabled', false);
  report__('Error "add_rcomnent()"', JSON.stringify(e),true );
 
  });
    
  },1000);
}


function replyComment(t, parent_cauthor){
  var this_=$(t);
  
  var cfullname=this_.data('fullname')||"";
  
  var tag=this_.data('tag');
  if( tag){
   if( tag!=username){
     $('#go-comment-tagged-cont').html('<span id="go-comment-tagged" data-tagged="' + tag + '">' + cfullname + '</span> <span onclick="goRemoveCommentTagged();" class="text-danger">X</span>');
   }
    return;
  }
  else if ( parent_cauthor){
    if( parent_cauthor!=username){
     $('#go-comment-tagged-cont').html('<span id="go-comment-tagged" data-tagged="' + parent_cauthor + '">' + cfullname + '</span> <span onclick="goRemoveCommentTagged();" class="text-danger">X</span>');
   }
  }
  
  var cid=this_.data('parent-id');
  $('#comment-parent-id').val(cid);
  
 //var ccont=$('#ccc-' + cid);
  
  var ccont= $('#go-rcomment-container');
  
//  ccont.css({'display':'block','z-index': 47});

  var cpi=$('#current-post-id');
  
  var cpiv=$.trim( cpi.val() );
  var post_by= $('#current-post-by').val();
 
 var mccont= $('#my-rcomments-container')
  
 var pc=$('#post-rcomments');  
 
  $('#prev-rcomments').css('display','none');
   mccont.empty();
   pc.empty();
   
 if(commentRAjax) commentRAjax.abort();
   clearTimeout( commentRTimeout);
  fetch_rcomments(cid);
  
  var zi=zindex();

   ccont.css({'display':'block','z-index': zi });
changeHash("comment-replies");
 
}


function goRemoveCommentTagged(){
  $('#go-comment-tagged-cont').empty();
}


$(function(){
  
  $('body').on('click','#go-send-rcomment-btn',function(e){ 
  	if( !loggedIn()){
		return toast("Login first");
		}
  
 var textBox=$('#go-rcomment-box'); 
 var msg=$.trim( textBox.val() );
 var fuser=""
 var mlen=( msg.length+1)/1024;
     
  var this_=  $(this);
     
 if( GO_COMMENT_UPLOAD_FILE_PATHS.length>0 ){
    this_.prop('disabled',true);
  return goCommentUploadFiles();
 }
   
 if( GO_COMMENT_UPLOADED_FILE_PATHS.length<1 && !msg){   
   return toast('Post still empty.');
   }
   this_.prop('disabled',true);
    add_rcomment(fuser, msg, mlen );
 });
   
 
$('body').on('click','#go-rcomment-upload-file-btn', function(){
  $('#go-rcomment-upload-preview-container').empty();
   
   GO_COMMENT_UPLOAD_FILE_PATHS=[]; //Empty paths
   GO_COMMENT_UPLOADED_FILE_PATHS=[]; //Empty uploaded paths
  
 });
 
});


$(window).on("popstate", function(){
	go_onBackPressed();
	});
	
$(window).on('hashchange', function() {
	//alert(7)
	try{
 //go_onBackPressed();
}catch(e){ toast(e);}
    //location.hash = "noBack";
});

window.onbeforeunload = function () {
  window.scrollTo(0, 0);
  $("#go-next-page-number").val("");
}
