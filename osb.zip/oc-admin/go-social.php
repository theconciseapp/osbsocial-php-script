<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn();

require ('includes/admin-functions.php');

$admin_username = getAdminInfo('username');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<link rel="stylesheet" href="assets/css/index.css?y">

<link rel="stylesheet" href="assets/css/mediaelementplayer.css">
<link rel="stylesheet" href="assets/css/go-social.css?i=<?php echo rand(); ?>">
<link rel="stylesheet" href="assets/css/go-comments.css?i=<?php echo rand(); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdn.jsdelivr.net/npm/mediaelement@4.2.0/build/mediaelement-and-player.min.js"></script>
<script src="assets/js/yall.js"></script>

  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
var _SITE_URL_='<?php echo _SITE_URL_; ?>';

var _USERS_PATH_='<?php echo _CHAT_USER_PATH_; ?>';
var _ADMIN_USERNAME_='<?php echo $admin_username; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div id="go-video-element-container"></div>
<input type="hidden" id="current-post-id" value="" /> <!--To be used by posts comment-->
 <input type="hidden" id="current-post-by" value="" /> <!--To be used by post comment-->
 <input type="hidden" id="go-next-page-number" value="" /> <!--To be used by page posts-->
 <input type="hidden" id="go-search-next-page-number" value="" /> <!--To be used by search posts-->
 <input type="hidden" id="go-followers-next-page-number" value="" /> <!---->
 <input type="hidden" id="go-following-next-page-number" value="" /> <!---->
 <input type="hidden" id="go-blocked-followers-next-page-number" value="" /> <!---->
 <input type="hidden" id="go-current-opened-profile" value="" /> <!---->


<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">
<div class="side-bar-container hide-left-sidebar">
	
<a class="side-bar-btn bg-secondary" aria-current="page" href="<?php echo _ADMIN_URL_; ?>"><i class="fa fa-lg fa-home text-light"> </i> Home</a>
	
<button class="side-bar-btn " onclick="goOpenCreatePostForm();"><i class="fa fa-lg fa-pencil-square text-light"></i> Create new post</button>

<button class="side-bar-btn" onclick="goViewPages();"><i class="fa fa-lg fa-file text-light"></i> Pages/Categories</button>

<button class="side-bar-btn"  
onclick="javascript: $('#go-create-page-form-container').fadeIn();"><span class="fa fa-lg fa-plus-circle text-light"></span> Create pages/Categories</button>

<button class="side-bar-btn"  
onclick="openNotifications();"><span class="fa fa-lg fa-bell text-light"></span> Send notifications</button>



<a class="side-bar-btn mt-3" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>"><i class="fa fa-lg fa-sign-out text-light"></i> Logout</a>

</div>

<div class="main-content-container">

<div class="bg-secondary text-center" style="border-radius: 5px 0 0 0;">
<div class="row">
<div class="col-4" style="text-align: left; margin-left: 5px;">

<button class="btn btn-sm btn-success" onclick="goOpenCreatePostForm();" style="padding: 7px 5px;"><small>Create new post</small></button>

</div>

<div class="col" style="text-align: center;">
  <select class="form-control mt-1" id="posts-view-option" style="padding: 2px 5px;" onchange="loadPosts('posts_view_changed');"><option value="1">All posts</option>
<option value="2">Approved posts</option>
<option value="3">Unapproved posts</option>
</select>
</div>

<div class="col-2 pt-2" style="text-align: right;">

	<span class="text-white fa fa-lg fa-refresh" onclick="loadPosts(1);"></span>
	
	</div>

<div class="col-2 pt-2" style="text-align: right;">

<button type="submit" style="background: none; outline: none; border:0; padding-top: 2px;" onclick="goOpenSearchBox();">
     <span class="text-white fa fa-search fa-lg"></span>
     </button>
    </div>
   </div>
    </div>

<div id="go-posts-column">

<div id="go-the-posts"></div>

<div class="text-center" style="position: fixed; left: 0; right: 0;  bottom: 80px; text-align: center;">
<i id="post-loading-indicator" class="text-success fa fa-spinner fa-spin fa-4x text-primary"></i></div>

</div><!--End go-posts-column-->
</div>
</div>
</div>


<!--Search container-->

  <div class="container-fluid" id="go-search-container">
  <div id="go-search-child-container">

<div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">

<div class="row">
<div class="col" onclick="closeSearch();" style="max-width: 60px;">
   <span class="text-danger fa fa-times fa-2x"></span>
</div>

  <div class="col">
   <form action="javascript: void(0);" onsubmit="searchPosts(1);">
     <input type="text" id="go-search-box" maxlength="100" placeholder="Search..." />
   <button type="submit" style="background: none; outline: none; border:0; padding-top: 2px;">
     <span class="fa fa-search fa-lg"></span>
     </button>
    </form>
    </div>
 
</div>
</div>
</div>
<div class="u-content" id="go-search-contents">
  <div id="go-search-suggestions"></div> 
  <div id="go-searched-posts" class=""></div>

 <div class="text-center">
<span id="search-loading-indicator" style="display: none; margin:0 auto;" class="w-20 h-20 fa fa-spinner fa-spin fa-2x text-success"></span>
</div>
</div>
 </div> 
 </div> 


<!--END Search container-->


  <!--SINGLE POST CONTAINER-->
  
  <div class="container-fluid p-0" id="go-single-post-container">

  <div id="go-single-post-child-container">       
    
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
<div class="col"></div>
   <div class="col" onclick="goCloseSinglePost();" style="padding: 10px 0 10px 14px; max-width: 50px;">
  <span class="text-danger fa fa-times fa-2x"></span>
  </div>
  
    </div>
    </div>
    </div>
    <div class="u-content">
    <div id="go-single-post"></div>
<div class="text-center">
  <span id="single-post-loading-indicator" style="display: none; margin:0 auto;" class="w-20 h-20 fa fa-spinner fa-spin fa-3x text-success"></span>
 </div>

    </div>
</div>
   </div>
 <!--END Single container--> 
         


<!--COMMENTS-->
    
   <div id="go-comment-container">
     <div id="go-comment-child-container">
      <div id="comment-loader-container" class="text-center">
       <span class="fa fa-spinner fa-spin fa-3x text-success"></span>
      </div>
   <div id="post-comment-title-cont">

     <div class="container-fluid">
       <div class="row">
     <div class="col pt-2" onclick="refreshComment();" style="max-width: 60px;">
      <span class="text-secondary fa fa-refresh fa-2x"></span>
     </div>
    <div class="col">
    <div id="go-comment-title" class="text-left">Comments</div>
    </div>
       <div class="col" style="max-width: 60px;">
         <div id="post-comment-sending-cont"></div>
       </div>

<div class="col pt-2" style="max-width: 40px;" onclick="goCloseComment();">
<span class="text-danger fa fa-times fa-2x"></span>
</div>

       </div>
     </div>
     </div>
      <div id="post-comments-container">
        <a id="prev-comments" href="javascript:void(0);">Previous comments</a>
        <div id="post-comments"></div>
      <div id="my-comments-container"></div>
        <a id="next-comments" data-value="" href="javascript: void(0);">Next comments</a>    
      </div>
     <div id="go-comment-upload-preview-container"></div>
     
     <div id="go-comment-box-container" class="d-none container">
      <div class="row">
        <div class="col text-center" style="max-width: 50px;">
       <button id="go-comment-upload-file-btn">
          <span class="fa fa-gallery fa-lg"></span>
       </button>
        
        </div>
        <div class="col">
          <textarea id="go-comment-box" placeholder="Share your opinion..."></textarea>
        </div>
        <div class="col" style="max-width: 50px; padding-left: 0;">
        <button id="go-send-comment-btn">
          send
        </button>
        </div>
        
       </div>
     </div>
    </div>  
  </div>

<!--End comment container-->
  

<!--PAGES-->

<div class="container-fluid p-0 go-shade" id="go-pages-container">

  <div class="go-shade-child">       
    
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
<div class="col pt-2">

 </div>
   <div class="col" onclick="$('#go-pages-container').fadeOut();" style="padding: 10px 0 10px 14px; max-width: 50px;">
  <span class="text-danger fa fa-times fa-2x"></span>
  </div>
  
    </div>
    </div>
    </div>
    <div class="u-content">
 <div class="container">

<div class="gpages" id="go-pages-list">
<div class="text-center">
<span class="fa fa-spinner fa-spin fa-4x text-success"></span>
</div>
</div>

<!--EDIT PAGE-->
<div class="gpages" id="go-edit-page-form" style="display: none;">

<div class="text-center">
<button class="btn btn-sm btn-success" onclick="javascript:$('.gpages').css('display','none'); $('#go-pages-list').css('display','block');"><span class="fa fa-lg fa-eye"></span> View pages</button>
</div>

<div class="mb-2">
<strong>Edit page</strong>
<span id="go-edit-page-data-loading" class="fa fa-spinner fa-spin fa-lg text-success" style="display: none;"></span>

</div>
<div class="mb-2">

<div class="d-inline-block" style="height: 60px; width: 60px; border: 1px solid #999; border-radius: 5px; overflow: hidden;">
<img src="" alt="icon" id="go-edit-page-icon" style="width: 100%; min-height: 60px; max-height: 120px;" onerror="go_imgError(this);"></div>
<span class="fa fa-camera fa-2x text-danger" onclick="goUploadPagePhoto();"></span>
</div>

<div class="mb-2">
<label class="form-label">Page pin</label>

 <input type="text" class="form-control" id="go-edit-page-pin" placeholder="Page pin" style="border-left: 0; padding-left: 1px; text-transform: lowercase;" readonly>
</div>

<div class="mb-2">
<label class="form-label">Page display name (Title)</label>

<input type="text" id="go-edit-page-title" class="form-control">
</div>
<div class="mb-2">
<label class="form-label">About page</label>
<textarea id="go-edit-page-bio" class="form-control"></textarea>
</div>

<div class="mb-2">
<label class="form-label">Page phone contact (optional)</label>
 
<input type="number" id="go-edit-page-phone" class="form-control">
</div>

<div class="mb-2">
<label class="form-label">Total followers</label>

<input type="number" class="form-control"  id="go-edit-page-followers">
</div>

<div class="mb-2">

<button class="btn btn-sm btn-primary" id="update-page-btn" onclick="goUpdatePageInfo(this);">Update page</button>

<button class="btn btn-sm btn-warning" id="reset-page-password-btn" data-username="" onclick="resetUserPassword(this);">Reset password</button>

</div>

</div>


</div>
    </div>
  </div>
   </div>
 <!--END Go pages container--> 
         
 <!--CREATE PAGES/CATEGORIES-->
         
     <div class="container-fluid go-shade p-0" id="go-create-page-form-container">

  <div class="go-shade-child" style="max-width: 700px;">  

  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
    <div class="row">
<div class="col pt-2" style="">
<strong>Create new page</strong>
</div>

  <div class="col" style="text-align: right;">
   	
	<span class="fa fa-times fa-2x text-danger" onclick="javascript: $('#go-create-page-form-container').css('display','none');"></span>  
  </div>
  
    </div>
    </div>
    </div>
    <div class="u-content">
    
         <div class="container" id="go-create-page-form">

<div class="mb-2">
<label class="form-label">Select page type</label>

<select class="form-control" onchange="goChangePageType(this);" id="go-create-page-type">
<option value="pv_">Type 1</option>
<option value="sv_">Type 2</option>
<option value="cv_">Type 3</option>
</select>
</div>

<div class="form-text mb-2 page-type-info text-success" id="pv_info">
  This type of page will be suggested to users on front page. Users can follow and read contents of this page. Page pin starts with "pv_"
 </div>

<div style="display: none;" class="form-text mb-2 text-primary page-type-info" id="sv_info">
Static page- This type of page automatically appears at the sidebar (Alphabetically). Users can't follow but can read contents of this page. Page pin starts with "sv_"
</div>


<div style="display: none;" class="form-text mb-2 text-dark page-type-info" id="cv_info">
Static page 2- This type of page is not automatically shown anywhere on the site. It can only be added manually. Users can't follow this page but can read contents. Page pin starts with "cv_"

</div>

<div class="mb-2">

<label class="form-label">Page pin</label>

<div class="input-group">
  <span class="input-group-text bg-light text-center" id="create-page-selected-type" style="height: 40px; padding-right: 0;">
pv_
 </span>

 <input type="text" class="form-control" id="create-page-username" placeholder="Page pin" style="border-left: 0; padding-left: 1px; text-transform: lowercase;">
    </div>
</div>

<div class="mb-2">
<label class="form-label">Page display name (Title)</label>

<input type="text" id="create-page-fullname" class="form-control">
</div>
<div class="mb-2">
<label class="form-label">About page</label>
<textarea id="create-page-bio" class="form-control"></textarea>
</div>

<div class="mb-2">
<label class="form-label">Page phone contact (optional)</label>
 
<input type="number" id="create-page-phone" class="form-control">
</div>

<div class="mb-2">
<label class="form-label">Page password</label>
<div class="form-text">This will allow you to manage this page from app.</div>
<input type="text" id="create-page-password" class="form-control">
 
</div>

<div class="mb-2">
<button class="btn btn-sm btn-primary" id="create-page-btn">Create page</button>
</div>

</div>
  </div>
  </div>
      </div>

<!--EDIT POST FORM-->
  
  <div class="container-fluid go-shade p-0" id="go-edit-post-form-container">

  <div class="go-shade-child" id="go-edit-post-form-child-container" style="max-width: 700px;">       
    
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
<div class="col pt-2" style="max-width: 60px;">
<div id="edit-post-form-loading-indicator" style="display:none;"> <i class=" fa fa-spinner fa-spin fa-2x text-success"></i></div>
</div>
<div class="col">

<button id="edit-post-btn" class="btn btn-sm btn-primary mt-2" onclick="goUpdatePost(this);">Update</button>

</div>
   <div class="col" onclick="goCloseEditPostForm();" style="padding: 10px 0 10px 14px; max-width: 50px;">
  <span class="text-danger fa fa-times fa-2x"></span>
  </div>
  
    </div>
    </div>
    </div>
    <div class="u-content">
    

<form id="edit-post-form" action="<?php echo _ADMIN_URL_ . '/ajax/go-social/edit-post.php'; ?>" method="post">
<div class="container">

<div class="row">

<div class="col-3">
ID
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-id" name="id" readonly="readonly">
</div>


<div class="col-3">
POST BY
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_by" name="post_by">
</div>

<div class="col-12">
POST TITLE
</div>
<div class="col-12">
<textarea id="edit-post-post_title" class="form-control mb-2" style="height: 100px;" name="post_title"></textarea>
</div>




<div class="col-12 d-none">
POST PREVIEW
</div>
<div class="col-12 d-none">
<textarea id="edit-post-post_preview" class="form-control mb-2" style="height: 100px;" name="post_preview"></textarea>
</div>

<div class="col-12">
POST
</div>
<div class="col-12">

<textarea id="edit-post-post" class="form-control mb-3" style="height: 200px;" name="post"></textarea>

</div>

<div class="col-3 d-none">
Post by name
</div>
<div class="col-9 d-none">
<input class="form-control mb-2" id="edit-post-post_by_fullname" name="post_by_fullname">
</div>


<div class="col-12">
POST FILES
</div>
<div class="col-12">
<textarea id="edit-post-post_files" class="form-control mb-2" style="height: 100px;" name="post_files"></textarea>
</div>


<div class="col-3">
Post type
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_type" name="post_type">
</div>

<div class="col-3">
Total comments
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-total_comments" name="total_comments">
</div>

<div class="col-3">
Total shares
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-total_shares" name="total_shares">
</div>


<div class="col-3">
Total reactions
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-reactions" name="reactions">
</div>

<div class="col-3">
Post status
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_status" name="post_status">
</div>

<div class="col-3">
Post date
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_date" name="post_date">
</div>

<div class="col-3">
Date time
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-date_time" name="date_time">
</div>

</div>

<input type="hidden" id="edit-post-post_meta" name="post_meta">
</div>
</form>

<div class="container bg-light pt-2">

<div class="row">
<div class="col-3">
<strong>POST META</strong>
</div>
<div class="col-9">

<form id="edit-meta-form"></form>

</div>
</div>
</div>

</div>
    </div>
   </div>
 <!--END edit post form container--> 


<!--CREATE NEW POST-->

<div class="container-fluid go-shade p-0" id="go-create-post-form-container">

  <div class="go-shade-child" id="go-create-post-form-child-container" style="max-width: 700px;">       
    
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
<div class="col pt-2 d-none" style="max-width: 60px;">
<div id="create-post-loading-indicator" style="display:none;"> <i class=" fa fa-spinner fa-spin fa-2x text-success"></i></div>
</div>
<div class="col">

<button id="create-new-post-btn" class="btn btn-sm btn-primary mt-2" onclick="goCreateNewPost(this);">Submit</button>

</div>
   <div class="col" onclick="goCloseCreatePostForm();" style="padding: 10px 0 10px 14px; max-width: 50px;">
  <span class="text-danger fa fa-times fa-2x"></span>
  </div>
  
    </div>
    </div>
    </div>
    <div class="u-content">
 <div class="container">
<div class="row">

<div class="col-12">
<span class="text-danger">
Select page</span>

<div class="input-group mb-2 mt-2">

<span class="input-group-text bg-light text-center" style="height: 40px;" onclick="goOpenCreatePostForm();">
<i id="go-create-post-by-loading" class="fa fa-refresh fa-spin fa-lg"></i>
 </span>

<select id="go-create-post-by" class="form-control">
<option value="">Select page</option>
</select>
</div>
</div>

 <div class="col-12" id="go-create-post-title">
   <label><strong>Post Title</strong></label>
<input type="text" id="post-title-box" class="form-control">
 </div>

<div class="col-12">
<strong>POST <span class="d-inline-block text-primary" id="post-char-count" style="padding: 1px 10px; border:0; border-radius: 5px;"></span></strong>
<textarea id="go-new-post" class="form-control mb-2" style="height: 200px;" data-bg="" name="post" maxlength="15000"></textarea>

<div id="go-post-bg-container">
     <span class="go-post-bg go-post-bg-1" data-bg="go-pbg-1"></span>
     <span class="go-post-bg go-post-bg-2" data-bg="go-pbg-2"></span>
     <span class="go-post-bg go-post-bg-3" data-bg="go-pbg-3"></span>
     <span class="go-post-bg go-post-bg-4" data-bg="go-pbg-4"></span>
     <span class="go-post-bg go-post-bg-5" data-bg="go-pbg-5"></span>
     <span class="go-post-bg go-post-bg-6" data-bg="go-pbg-6"></span>     
     <span class="go-post-bg go-post-bg-7" data-bg="go-pbg-7"></span>
     <span class="go-post-bg go-post-bg-8" data-bg="go-pbg-8"></span>
     <span class="go-post-bg go-post-bg-9" data-bg="go-pbg-9"></span>
    <span class="go-post-bg go-post-bg-10" data-bg="go-pbg-10"></span>

 </div>


<div class="custom-control custom-checkbox" style="margin: 11px 12px;">
   <input type="checkbox" class="custom-control-input" id="go-new-post-commentable" checked="checked">
   <label class="custom-control-label" for="go-new-post-commentable">
     <span style="display: inline-block; font-weight: bold; font-size: 18px;"> Commentable</span>
   </label>
  </div>

  <div class="custom-control custom-checkbox" style="margin: 6px 12px;">
   <input type="checkbox" class="custom-control-input" id="go-new-post-shareable" checked="checked">
   <label class="custom-control-label" for="go-new-post-shareable">
     <span style="display: inline-block; font-weight: bold; font-size: 18px;"> Shareable</span>
   </label>
  </div>
   
<div class="custom-control custom-checkbox" style="margin: 6px 12px;">
   <input type="checkbox" class="custom-control-input" id="go-file-downloadable" checked="checked">
   <label class="custom-control-label" for="go-file-downloadable">
     <span style="display: inline-block; font-weight: bold; font-size: 18px;"> Downloadable</span>
   </label>
  </div> 
   
</div>

<div class="col-3">
Attach file
</div>
<div class="col-9">
<button class="btn btn-sm btn-secondary d-block mb-1" id="go-upload-photo" onclick="goUploadPostFiles();"><span class="fa fa-image fa-lg"></span> <small>Photos/Videos (6) [ Max: 100MB ]</small></button>

<button class="d-none btn btn-sm btn-secondary d-block mb-2" onclick="goUploadPostVideo();"><span class="fa fa-video-camera fa-lg"></span> <small>Videos (6) [ MP4 only. Max: 100MB ]</small></button>

<div id="go-upload-previews" class="mt-2 mb-2" style="position: relative;"></div>

</div>


<div class="col-3">
Add Link
</div>
<div class="col-9">
Link (Must start with https://)
<input type="text" id="go-new-post-link" class="form-control">
Link Text
<input type="text" id="go-new-post-link-title" class="form-control">
</div>
</div>
</div>

    </div>
   </div>
   </div>
    
   <!--PROFILE-->
  
  <div id="go-profile-container">
  	<span class="fa fa-times fa-2x text-danger" onclick="closeProfile();" style="position: absolute; top: 10px; left: 16px; z-index: 50;"></span>
  <select id="go-page-post-order" class="btn btn-sm btn-light">
        <option value="" selected>SORT</option>
        <option value="DESC">NEWER FIRST</option>
        <option value="ASC">OLDER FIRST</option>
        
      </select>
  </div>
  

   <!--PROFILE PAGE TEMPLATE-->
   	
   <div id="go-profile-template">
<div class="container-fluid">
   	
   	  <input type="hidden" class="go-profile-next-page-number" value="" /> <!--To be used by page posts-->
    
 <div class="row">
  <div class="col-12 p-0">
  	
   <div class="go-profile-cover-photo-container">
    <img id="cp" class="go-profile-cover-photo" onerror="go_imgError(this,'transparent');">
  </div>
  
   <div class="container-fluid" style="position: relative;">
   <div class="row">
 <div class="col" style="overflow: visible; height: 45px; max-width: 120px;">
  <div class="go-profile-photo-container" onclick="goProfileCameraOption(this);">
   <img class="go-profile-photo" onerror="go_imgError(this,'transparent');">
   </div>
     </div>
     <div class="col text-right" style="padding-top: 10px; overflow-x: hidden;">
      <div style="display:none;" class="go-profile-message-follow-btn-container">
      <span class="fa fa-inbox fa-2x go-profile-message-btn"></span>
       </div>    
    </div>
    
   </div>
   </div>
    
  <div class="go-profile-info-container">
  	
   <div class="go-profile-fullname" data-name=""></div>
   <div class="go-profile-user-pin"></div>
    <div class="go-profile-email go-hide"></div>
    
   <div class="go-profile-bio go-hide"></div>
   <div class="go-profile-country go-hide"></div>
   <div class="go-profile-phone go-hide"></div>   
   <div class="go-profile-birth go-hide"></div>
   <div class="go-profile-joined go-hide"></div>

 </div>

 <div class="container-fluid">
   <div class="row">
     <div class="col">
   <div class="go-total-following"></div>
     </div>    
     <div class="col">
   <div class="go-total-followers"></div>
     </div>
   </div>
   </div>   
   
</div>
    
  <div class="col-12 p-0" style="background: rgba(0,0,0,0.15);">
  	
    <div class="bg-white" style="padding-left: 16px; margin-bottom: 5px;">
      <strong><big>Posts</big></strong> 
   </div>
    
    <div class="go-profile-posts"></div>
    
    <div class="profile-posts-loading-indicator text-center" style="display: none;">
	<span class="fa fa-spinner fa-spin fa-3x text-success"></span>
    </div>
    
  </div>
</div>

</div>
  
</div> <!--End profile page template-->

   

<!--NOTIFICATIONS-->
  
  <div id="go-notifications-container">
    <div class="u-shadow" onclick="closeNotifications();"></div>
    <div id="go-notifications-child-container">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
   	<div class="d-none" id="go-notifications-next-page-number">1</div>
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeNotifications();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo _SITE_URL_ . '/oc-contents/assets/go-icons/back.png';?>">
  </div>
 <div class="col" style="padding-top: 8px;">
   <button class="btn btn-sm btn-warning" onclick="toggleNotificationPage('go-notifications');">Notifications</button>
   </div>
<div class="col text-end" style="padding-top: 8px;">
<button class="btn btn-sm btn-primary" onclick="toggleNotificationPage('create-notification-form');">Create</button>
</div>
    <div class="col text-end" style="padding-top: 8px;">
    	<img id="notifications-loader" class="d-none" src="<?php echo _SITE_URL_ . '/oc-contents/assets/loading-indicator/loading2.png';?>" style="width: 16px; height: 16px;">
    	</div>
   
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
<duv class="d-none noti-page" id="create-notification-form">
 <div class="container">
 <div class="mb-3">
<label>Compose</label>
<div class="form-text">This notification is public</div>
<textarea id="notification-message-box" class="form-control" style="height: 150px;"></textarea>
</div>

<button class="btn btn-sm btn-success" onclick="sendNotification(this);">Send</button>
</div>
</div>

  <div class="noti-page" id="go-notifications"></div>
    </div>
   </div>
  </div>
  </div>
      
    </div>
  </div>    
 
  




<!--ENLARGED PICTURE-->
 
  <div id="go-full-photo-container">

<span id="go-close-full-photo-btn" onclick="goCloseFullPhoto();" class="fa fa-times fa-3x text-danger mt-4"></span>
<div id="go-full-photo-child-container"></div>
</div>

  <div id="go-full-cover-photo-container">
</div>


<div class="fixed-botto footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="assets/js/global.js?i"></script>
<script src="assets/js/index.js"></script>
<script src="assets/js/go-social.js?o=<?php echo rand(); ?>"></script>
<script src="assets/js/go-comments.js?i=<?php echo rand(); ?>"></script>
<script src="assets/js/go-social2.js"></script>

<script>
$(function(){
loadPosts();

$('body').on('change','#go-page-post-order', function(){
  var uElem= $('#go-current-opened-profile');
   var user=uElem.val();
   var fullname=uElem.attr('data-fullname');
   
  var ucont= $('#go-profile-page-' + user);
   var pnElem=ucont.find('.go-profile-next-page-number');
  var pageNum=pnElem.val("");
      ucont.find('.go-profile-posts').empty();
   
  go_profile( user, fullname, 'load');
  });


});

document.addEventListener("DOMContentLoaded", function() {
  yall({
    observeChanges: true,
   // delay: 5000,
  });
});

$('#go-posts-column').on('touchstart mouseover', function(e) {

   var scr=$(this).scrollTop() + $(this).innerHeight();
   if(!loadingPosts && scr >=  $(this)[0].scrollHeight-300) {
 loadingPosts=true;
       loadPosts();
    }
  });
  
  //SCROLL SEARCH PAGE

  $('#go-search-contents').on('touchstart mouseover', function() {
   var scr=$(this).scrollTop() +
 $(this).innerHeight();
   if( !searchingPosts && scr >=  $(this)[0].scrollHeight-300) {
   searchingPosts=true;
    searchPosts();
  }
});
  
</script>

</body>
</html>
