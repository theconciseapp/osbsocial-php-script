<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn();
require ('../includes/admin-functions.php');

require ('../../oc-includes/server.php');



$sJson                = getSettings();


$site_title          = isset(  $sJson["site_title"] ) ? $sJson["site_title"] : "OSB Social";

$tagline          = isset(  $sJson["site_tagline"] ) ? $sJson["site_tagline"] : "My OSBs Website";



$force_login          = isset($sJson["force_user_login"]) ? $sJson["force_user_login"] : "YES";


$enable_chat          = isset($sJson["enable_chat"]) ? $sJson["enable_chat"] : "YES";

$enable_send          = isset($sJson["enable_send_chat"]) ? $sJson["enable_send_chat"] : "YES";


$enable_receive          = isset($sJson["enable_receive_chat"]) ? $sJson["enable_receive_chat"] : "YES";

$req_speed            = isset($sJson["chat_request_speed"]) ? $sJson["chat_request_speed"] : "10";

$enable_addcontact    = isset($sJson["enable_add_contact"]) ? $sJson["enable_add_contact"] : "YES";

$enable_cgroup        = isset($sJson["enable_create_group"]) ? $sJson["enable_create_group"] : "YES";

$enable_jgroup        = isset($sJson["enable_join_group"]) ? $sJson["enable_join_group"] : "YES";

$mgc                  = isset($sJson["max_groups_check"]) ? $sJson["max_groups_check"] : "3";

$users_pgroup         = isset($sJson["users_per_group"]) ? $sJson["users_per_group"] : "100";

$enable_vid_doc       = isset($sJson["enable_vid_doc"]) ? $sJson["enable_vid_doc"] : "YES";

$enable_registration  = isset($sJson["enable_registration"]) ? $sJson["enable_registration"] : "YES";

$enable_login         = isset($sJson["enable_login"]) ? $sJson["enable_login"] : "YES";


$enable_email_ver     = isset($sJson["enable_email_verification"]) ? $sJson["enable_email_verification"] : "NO";

$enable_mactivation   = isset($sJson["enable_manual_activation"]) ? $sJson["enable_manual_activation"] : "NO";

$users_pp             = isset($sJson["users_per_page"]) ? $sJson["users_per_page"] : "20";

$app_name             = isset($sJson["app_name"]) ? $sJson["app_name"] : "OSBSocial";

$epost_title               = isset($sJson["enable_post_title"]) ? $sJson["enable_post_title"] : "NO";

$go_author_name               = isset($sJson["go_hide_author_name"]) ? $sJson["go_hide_author_name"] : "NO";

$go_post_time               = isset($sJson["go_hide_post_time"]) ? $sJson["go_hide_post_time"] : "NO";

$go_allow_video               = isset($sJson["go_allow_video"]) ? $sJson["go_allow_video"] : "YES";

$go_allow_reactions               = isset($sJson["go_allow_reactions"]) ? $sJson["go_allow_reactions"] : "YES";

$go_allow_comment               = isset($sJson["go_allow_comment"]) ? $sJson["go_allow_comment"] : "YES";

$go_allow_share               = isset($sJson["go_allow_share"]) ? $sJson["go_allow_share"] : "YES";

$go_ppl               = isset($sJson["go_ppl"]) ? $sJson["go_ppl"] : 5; //Go-posts per load

$go_po               = isset($sJson["go_posts_order"]) ? $sJson["go_posts_order"] : "DESC";

$go_suggest_pymk             = isset($sJson["go_suggest_pymk"]) ? $sJson["go_suggest_pymk"] : "1"; //1: Suggest people you may know, else 0

$go_cpost             = isset($sJson["go_can_post"]) ? $sJson["go_can_post"] : "1"; //Who can post... 1: Only admins, 2: Admins & verified users, 3: All

$go_approve_post             = isset($sJson["go_auto_approve_post"]) ? $sJson["go_auto_approve_post"] : "1";

$go_homepage             = isset($sJson["go_homepage_posts"]) ? $sJson["go_homepage_posts"] : "1"; //1- User posts, 0- Static page

$go_static_page             = isset( $sJson["go_static_page"]) ? $sJson["go_static_page"] : "";

$go_enable_follow            = isset( $sJson["go_enable_follow_btn"]) ? $sJson["go_enable_follow_btn"] : "YES";


$enable_file_upload           = isset( $sJson["enable_file_upload"]) ? $sJson["enable_file_upload"] : "YES";


$max_file_size           = isset( $sJson["max_upload_size"]) ? $sJson["max_upload_size"] : "5";

$cache_reset        = isset( $sJson["cache_reset"] ) ? $sJson["cache_reset"] : "1|1";

$go_enable_download          = isset( $sJson["go_enable_download"]) ? $sJson["go_enable_download"] : "YES";
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="../assets/css/index.css?i=<?php echo randomString(3); ?>">

<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; } 
.string { color: green; }
.number { color: darkorange; }
.boolean { color: blue; } 
.null { color: magenta; } 
.key { color: red; }
</style>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 50px;">

<div class="alert alert-success"><span class="fa fa-info fa-lg"></span> Please note that some settings requires you view your <a href="<?php echo _SITE_URL_;?>" target="blank_">site</a> as a regular user to see the effect
</div>
<h5>App/Site settings</h5>

<div id="app-settings-container" class="container p-3" style="background: #f5f5f5; border: 0; border-radius: 3px;">


<form id="settings-form">

<div class="row">
<div class="col-12 col-md-6 pt-2">

<h2>Messenger settings</h2>

<div class="mb-2">
<label class="form-label">
Enable messenger feature
</label>

<div class="form-text">If disabled, users will not be able to receive or send any messages</div>

<select class="form-control" id="enable_chat" name="enable_chat" onchange="toggleMessengerFeatures(this);">
<option<?php echo ($enable_chat == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_chat == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div id="messenger-features" style="<?php if( $enable_chat=="NO" ) { echo"display: none;"; }?>">

<div class="mb-2">
<label class="form-label">
Allow users to send messages to eachother
</label>
<div class="form-text">If disabled, users can still send message to admins</div>

<select class="form-control" id="enable_send_chat" name="enable_send_chat">
<option<?php echo ($enable_send == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_send == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">New messages check speed ( in seconds. Minimum: 2)</label>
<div class="form-text text-danger">
Alert: Please make sure your server is up to the task if you set value below 10
</div>

<input type="number" maxlength="3" class="form-control" id="chat_request_speed" name="chat_request_speed" value="<?php echo $req_speed; ?>">
</div>

<div class="mb-2">
<label class="form-label">
Users can add contact
</label>

<select class="form-control" id="enable-add-contact" name="enable_add_contact">
<option<?php echo ($enable_addcontact == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_addcontact == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow users create groups
</label>

<select class="form-control" id="enable_create_group" name="enable_create_group">
<option<?php echo ($enable_cgroup == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_cgroup == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow users to join groups
</label>

<select class="form-control" id="enable_join_group" name="enable_join_group">
<option<?php echo ($enable_jgroup == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_jgroup == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Max number of groups or pages to query from database at a time from the app.
</label>
<div class="form-text">
Recommended: 3. If you have fewer user base, you can increase this value.
</div>

<select class="form-control" id="max-groups-check" name="max_groups_check">
<option<?php echo ($mgc == '1' ? ' selected' : ''); ?>>1</option>
<option<?php echo ($mgc == '2' ? ' selected' : ''); ?>>2</option>
<option<?php echo ($mgc == '3' ? ' selected' : ''); ?>>3</option>
<option<?php echo ($mgc == '5' ? ' selected' : ''); ?>>5</option>
<option<?php echo ($mgc == '7' ? ' selected' : ''); ?>>7</option>

</select>
</div>


<div class="mb-2">
<label class="form-label">
Maximum number of participants per group
</label>
<div class="form-text">
Maximum: <?php echo _MAX_GROUP_MEMBERS_; ?>
</div>
<input type="number" maxlength="3" class="form-control" id="users_per_group" name="users_per_group" value="<?php echo $users_pgroup; ?>">
</div>

</div>

<div id="social-settings-container" class="<?php if( !enb_social() ){ echo "d-none"; }?> pt-2">

<h2>Social settings</h2>

<div class="mb-2">
<label class="form-label">
Enable follow button
</label>
<div class="form-text">
If enabled, users will be able to follow eachother and see posts based on people they followed
</div>

<select class="form-control" id="go_enable_follow_btn" name="go_enable_follow_btn">
<option<?php echo ( $go_enable_follow == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($go_enable_follow == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Your homepage displays
</label>

<select class="form-control" id="go_homepage_posts" name="go_homepage_posts" onchange="toggleHomepageSetting(this);">
<option value="1"<?php echo ($go_homepage == '1' ? ' selected' : ''); ?>>Latest posts</option>
<option value="0"<?php echo ($go_homepage== '0' ? ' selected' : ''); ?>>Static page</option>
</select>

<div class="p-4 pt-2 pb-2">
Homepage
<select class="form-control" name="go_static_page" id="go_static_page"<?php

 if( $go_homepage=="1"){ 
  echo" disabled";
 }else{ 
   echo"";
  }?>>
<option value="">--Select--</option>
  <?php 

 $pages= get_pages( $conn );

 if( count($pages)>0) {
foreach( $pages as $page) {

 $page_username=$page['username'];

 echo '<option value="' . $page_username . '"' .
 ( $page_username==$go_static_page?' selected':'') . '>' . $page['fullname'] . '</option>';
   }

}
?>
</select>
 
</div>



</div>


<div class="mb-2">
<label class="form-label">
Suggest pages or people to users
</label>

<select class="form-control" id="go_suggest_pymk" name="go_suggest_pymk">
<option value="1"<?php echo ($go_suggest_pymk == '1' ? ' selected' : ''); ?>>YES</option>
<option value="0"<?php echo ($go_suggest_pymk== '0' ? ' selected' : ''); ?>>NO</option>

</select>

</div>

<div class="mb-2">
<label class="form-label">
Who can make post
</label>

<select class="form-control" id="go_can_post" name="go_can_post">
<option value="1"<?php echo ($go_cpost == '1' ? ' selected' : ''); ?>>Admins only</option>
<!--<option value="2"<?php echo ($go_cpost == '2' ? ' selected' : ''); ?>>Admins & Verified users</option>-->
<option value="3"<?php echo ($go_cpost == '3' ? ' selected' : ''); ?>>Everyone</option>

</select>
</div>

<div class="mb-2">
<label class="form-label">
Automatically approve user posts
</label>

<div class="form-text">Admins posts are always automatically approved</div>

<select class="form-control" id="go_auto_approve_post" name="go_auto_approve_post">
<option value="1"<?php echo ($go_approve_post == '1' ? ' selected' : ''); ?>>YES</option>
<option value="0"<?php echo ($go_approve_post == '0' ? ' selected' : ''); ?>>NO - Admin verification required</option>

</select>

</div>


<div class="mb-2">
<label class="form-label">
Enable post title
</label>
<div class="form-text">If enabled, post title box will appear when creating post. Post title will be shown (if available) instead of post author name</div>

<select class="form-control" id="enable_post_title" name="enable_post_title">
<option<?php echo ($epost_title == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($epost_title == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>





<div class="mb-2">
<label class="form-label">
Hide post author name
</label>

<select class="form-control" id="go_hide_author_name" name="go_hide_author_name">
<option<?php echo ($go_author_name == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($go_author_name == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Hide post time
</label>

<select class="form-control" id="go_hide_post_time" name="go_hide_post_time">
<option<?php echo ( $go_post_time == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($go_post_time == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow post reactions (like, love, angry e.t.c)
</label>

<select class="form-control" id="go_allow_reactions" name="go_allow_reactions">
<option<?php echo ( $go_allow_reactions == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($go_allow_reactions == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow new comments
</label>

<select class="form-control" id="go_allow_comment" name="go_allow_comment">
<option<?php echo ($go_allow_comment == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($go_allow_comment == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Allow post share
</label>

<select class="form-control" id="go_allow_share" name="go_allow_share">
<option<?php echo ($go_allow_share == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($go_allow_share == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Enable file download
</label>

<div class="form-text">When enabled, users still have the choice to enable/disable file download on their posts</div>

<select class="form-control" id="go_enable_dowload" name="go_enable_download">
<option<?php echo ($go_enable_download == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ( $go_enable_download == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>



<div class="mb-2">
<label class="form-label">
Posts per load
</label>
<div class="form-text">
Total number of posts to load per request
</div>
<input class="form-control" id="go_ppl" name="go_ppl" value="<?php echo $go_ppl; ?>">
</div>

<div class="mb-2">
<label class="form-label">
Order of posts
</label>

<select class="form-control" id="go_posts_order" name="go_posts_order">
<option value="DESC"<?php echo ($go_po == 'DESC' ? ' selected' : ''); ?>>Newer first (DESC. ORDER)</option>
<option value="ASC"<?php echo ($go_po == 'ASC' ? ' selected' : ''); ?>>Older first (ASC. ORDER)</option>
</select>

</div>
</div>
</div>


<div class="col-12 col-md-6 pt-2">
<h2>General settings</h2>
<br>
<div class="mb-2">
<label class="form-label">
Site title
</label>
<div class="form-text">

</div>

<input class="form-control" id="site_title" name="site_title" value="<?php echo $site_title; ?>">
</div>

<div class="mb-2">
<label class="form-label">
Site short name/Alias
</label>
<div class="form-text">
Alphabets, underscore & numbers supported only (no space ), and must start with an alphabet. Max: 20
</div>

<input class="form-control" id="app_name" name="app_name" value="<?php echo $app_name; ?>">
</div>


<div class="mb-2">
<label class="form-label">
Tagline
</label>
<div class="form-text">

</div>

<input class="form-control" id="site_tagline" name="site_tagline" value="<?php echo $tagline; ?>">
</div>

<div class="mb-2">
<label class="form-label">
Force user login
</label>

<div class="form-text">
If enabled, only registered and logged in users can read site contents. However, only logged in users or admins can create post, share posts, make comment and also use app.
</div>

<select class="form-control" id="force_user_login" name="force_user_login">
<option<?php echo ($force_login == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($force_login == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Enable users to upload or send files
</label>
<div class="form-text">
Images, Videos, Audios and Documents
</div>
<select class="form-control" id="enable_file_upload" name="enable_file_upload">
<option value="YES"<?php echo ($enable_file_upload == 'YES' ? ' selected' : ''); ?>>YES</option>
<option value="NO"<?php echo ($enable_file_upload == 'NO' ? ' selected' : ''); ?>>NO (Texts only)</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Allow videos and documents
</label>
<div class="form-text">
Videos and documents from users can take up much of your server's space & bandwidth
</div>
<select class="form-control" id="enable-vid_doc" name="enable_vid_doc">
<option<?php echo ($enable_vid_doc == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_vid_doc == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Users file upload max size
</label>
<div class="form-text">
Maximum file size a user can upload on your server in Megabytes
</div>

<select class="form-control" id="max_upload_size" name="max_upload_size">
<option<?php echo ($max_file_size == '1' ? ' selected' : ''); ?>>1</option>
<option<?php echo ($max_file_size == '2' ? ' selected' : ''); ?>>2</option>
<option<?php echo ($max_file_size == '5' ? ' selected' : ''); ?>>5</option>
<option<?php echo ($max_file_size == '8' ? ' selected' : ''); ?>>8</option>
<option<?php echo ($max_file_size == '10' ? ' selected' : ''); ?>>10</option>
<option<?php echo ($max_file_size == '12' ? ' selected' : ''); ?>>12</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Enable user registration
</label>
<div class="form-text">
Disable if you don't want to accept new user registration on your app
</div>
<select class="form-control" id="enable_registration" name="enable_registration">
<option<?php echo ($enable_registration == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_registration == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Enable user login
</label>

<div class="form-text">
Disable if you don't want to accept new login on your app
</div>

<select class="form-control" id="enable_login" name="enable_login">
<option<?php echo ($enable_login == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_login == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Verify email address of newly registered users. If disabled, users will be automatically activated
</label>

<select class="form-control" id="enable_registration_captcha" name="enable_email_verification">
<option<?php echo ($enable_email_ver == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_email_ver == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>

<div class="mb-2">
<label class="form-label">
Activate newly registered users manually
</label>
<div class="form-text">
If you choose to activate manually, user's email address will not be verified.
</div>

<select class="form-control" id="enable-manual-activation" name="enable_manual_activation">
<option<?php echo ($enable_mactivation == 'YES' ? ' selected' : ''); ?>>YES</option>
<option<?php echo ($enable_mactivation == 'NO' ? ' selected' : ''); ?>>NO</option>
</select>
</div>


<div class="mb-2">
<label class="form-label">
Total number of users to show per page in admin panel
</label>

<select class="form-control" id="users_per_page" name="users_per_page">
<option<?php echo ($users_pp == '5' ? ' selected' : ''); ?>>5</option>
<option<?php echo ($users_pp == '10' ? ' selected' : ''); ?>>10</option>
<option<?php echo ($users_pp == '15' ? ' selected' : ''); ?>>15</option>
<option<?php echo ($users_pp == '20' ? ' selected' : ''); ?>>20</option>
<option<?php echo ($users_pp == '40' ? ' selected' : ''); ?>>40</option>
<option<?php echo ($users_pp == '100' ? ' selected' : ''); ?>>100</option>

</select>
</div>


<div class="mb-2">
<label class="form-label">
Cache settings e.g 1|1
</label>
<div class="form-text">
The first number before | is meant to reset profile images cached by user browser. The next number is to reset script, css files cached by user browsers. These numbers should increment for changes to take effect.
</div>

<input class="form-control" id="cache_reset" name="cache_reset" value="<?php echo $cache_reset; ?>">
</div>



</div>
</div>

</form>

<button id="save-settings-btn" class="btn btn-sm btn-primary mt-1" style="position: fixed; bottom: 10vh; right: 5vw; z-index: 10; height: 60px; width: 60px; border:2px solid #999; border-radius: 100%;">Save</button>


</div>
</div>
</div>
</div>







<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="../assets/js/global.js?i=s"></script>
<script src="../assets/js/index.js?i=1"></script>
<script src="../assets/js/settings.js?y=<?php echo rand(); ?>"></script>

<script>
function toggleHomepageSetting(t){
  var v=t.value;
 var elem=$("#go_static_page");
  if( v==1){
  elem.attr("disabled", true);
 }
  else{

  elem.attr("disabled", false);

  }
}

function toggleMessengerFeatures(t){
var v=t.value;
 var elem=$("#messenger-features");
  if( v=="YES"){
  elem.slideDown();
 }
  else{

  elem.slideUp();

  }

}
</script>

</body>
</html>
