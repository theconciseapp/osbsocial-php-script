<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn();
require ('../includes/admin-functions.php');
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="../assets/css/index.css?i=<?php echo randomString(3); ?>">

<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; } 
.string { color: green; }
.number { color: darkorange; }
.boolean { color: blue; } 
.null { color: magenta; } 
.key { color: red; }
</style>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 50px;">


<div class="">
<h5>SMTP Mail setup</h5>
</div>
   
<div id="smtp-setup-container" class="stmp-setup-container p-3">

<?php $emailer_file     = _ADMIN_DIR_ . '/settings-files/emailer-config.txt';

$emailer_info     = "";

if (file_exists($emailer_file)) 

  {

    $emailer_info     = "" . (file_get_contents($emailer_file));

  }

$ei               = json_decode($emailer_info);

$email_channel    = isset($ei->email_channel) ? $ei->email_channel : "";

$email_host       = isset($ei->email_host) ? $ei->email_host : "";

$email_auth       = isset($ei->email_authentication) ? $ei->email_authentication : "";

$email_username   = isset($ei->email_username) ? $ei->email_username : "";

$email_password   = isset($ei->email_password) ? $ei->email_password : "";

$email_port       = isset($ei->email_port) ? $ei->email_port : "";

$email_encryption = isset($ei->email_encryption) ? $ei->email_encryption : "";

$email_from       = isset($ei->email_from) ? $ei->email_from : "";

$email_alias      = isset($ei->email_alias) ? $ei->email_alias : "";

?>

<form id="stmp-setup-form">

<div class="mb-2">

<label class="form-label">Channel</label>
<div class="form-text">
If you set to "default", you may leave other fields as it is.
</div>
<select class="form-control" id="email-channel" name="email_channel">
<option value="phpmailer"<?php echo ($email_channel == 'phpmailer' ? ' selected' : ''); ?>>PHPMAILER</option>
<option value="default"<?php echo ($email_channel == 'default' ? ' selected' : ''); ?>>DEFAULT</option>
</select>
</div>

<div class="mb-2">

<label class="form-label">SMTP Host</label>

<input class="form-control" id="email-host" name="email_host" value="<?php echo $email_host; ?>">
</div>


<div class="mb-2">

<label class="form-label">SMTP Authentication</label>

<select class="form-control" id="email-authentication" name="email_authentication">
<option value="true"<?php echo ($email_auth == 'true' ? ' selected' : ''); ?>>TRUE</option>
<option value=""<?php echo ($email_auth == '' ? ' selected' : ''); ?>>FALSE</option>
</select>
</div>

<div class="mb-2">

<label class="form-label">SMTP Username</label>
<div class="form-text">
The username to connect to your SMTP server.</div>

<input class="form-control" id="email-username" name="email_username" value="<?php echo $email_username; ?>">
</div>

<div class="mb-2">
<label class="form-label">SMTP Password</label>
<div class="form-text">
The password to connect to your SMTP server.
</div>

<input class="form-control" type="password" id="email-password" name="email_password" value="">

</div>

<div class="mb-2">

<label class="form-label">Type of encryption</label>

<div class="form-text">
The encryption to be used when sending an email (TLS/SSL. TLS is recommended).
</div>

<select class="form-control" id="email-encryption" name="email_encryption">
<option value="tls"<?php echo ($email_encryption == 'tls' ? ' selected' : ''); ?>>TLS</option>
<option value="ssl"<?php echo ($email_encryption == 'ssl' ? ' selected' : ''); ?>>SSL</option>
</select>
</div>

<div class="mb-2">

<label class="form-label">SMTP Port</label>
<div class="form-text">
The port to be used when sending an email (587/465). If you choose TLS the port should be set to 587. For SSL use port 465 instead.
</div>

<input class="form-control" id="email-port" name="email_port" value="<?php echo $email_port; ?>">

</div>


<div class="mb-2">

<label class="form-label">From email</label>
<div class="form-text">
Some email providers requires you set sender email. You may enter your business email address.
</div>
<input class="form-control" id="email-from" name="email_from" value="<?php echo $email_from; ?>">
</div>

<div class="mb-2">
<label class="form-label">From alias</label>

<input class="form-control" id="email-alias" name="email_alias" value="<?php echo $email_alias; ?>">

</div>
</form>

<button id="save-emailer-config-btn" class="btn btn-sm btn-primary mt-1">Save</button>
</div>

</div>
</div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="../assets/js/global.js?i=1"></script>
<script src="../assets/js/index.js?i=1"></script>
<script src="../assets/js/settings.js?y=<?php echo rand(); ?>"></script>

</body>
</html>
