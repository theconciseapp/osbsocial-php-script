<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn();

require ('../includes/admin-functions.php');

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="../assets/css/index.css?i=<?php echo randomString(3); ?>">

<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; } 
.string { color: green; }
.number { color: darkorange; }
.boolean { color: blue; } 
.null { color: magenta; } 
.key { color: red; }
</style>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 50px;">


<div class="mb-2">
<label class="form-label"><b>Welcome message</b></label>

<div class="form-text">Set a welcome message for newly registered users (Max: 100 words). To include user's name in your message, enter "[user::]" without quotes. E.g Welcome [user::], will result to Welcome Caroline.</div>

<div class="form-text text-danger fa fa-warning"> Always backup your welcome note.</div>

<textarea class="form-control" style="height: 150px;" id="welcome-message-box" row="3"><?php

$wmessage = _CHAT_FILES_DIR_ . '/welcome/welcome.txt';

if (is_readable($wmessage)) 

  {

    echo @file_get_contents($wmessage);

  }

?></textarea>

</div>

<button id="welcome-message-btn" class="btn btn-sm btn-primary mt-1">Save</button>

<div id="save-welcome-message-result" class="pt-2"></div>

<hr />

<form action="upload_welcome_video.php" method="post" enctype="multipart/form-data">
<div class="mb-3">

<label class="form-label"><b>Upload welcome video</b></label>
<div class="form-text">Short video message for newly registered user ( Max: 10MB )</div>
<input type="file" name="video" class="form-control" accept="video/*">
</div>

<input type="submit" class="btn btn-sm btn-primary" value="Upload">

<?php

$wvideo = _CHAT_FILES_DIR_ . '/welcome/0123456789.mp4';

$dnone  = "d-none";

if (is_file($wvideo)) 

  {

    $dnone  = "";

  }

echo '<button id="delete-welcome-video" class="btn btn-sm btn-warning ' . $dnone . '"><i class="fa fa-lg fa-trash"></i> Delete</button>';

?>
</form>
<hr />


</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="../assets/js/global.js?i=1"></script>
<script src="../assets/js/index.js?i=1"></script>
<script src="../assets/js/settings.js?y=<?php echo rand(); ?>"></script>

</body>
</html>
