<?php require ('../oc-includes/bootstrap.php');

$ffmpeg = trim(shell_exec('type -P ffmpeg'));

die($ffmpeg);

$ffmpeg_path = 'ffmpeg'; //or: /usr/bin/ffmpeg , or /usr/local/bin/ffmpeg - depends on your installation (type which ffmpeg into a console to find the install path)

$vid         = _CHAT_FILES_DIR_ . "/a.mp4"; //Replace here!

if (file_exists($vid)) 

  {

    $finfo       = finfo_open(FILEINFO_MIME_TYPE);

    $mime_type   = finfo_file($finfo, $vid); // check mime type

    finfo_close($finfo);

    if (preg_match('/video\/*/', $mime_type)) 

      {

        $video_attributes = _get_video_attributes($vid, $ffmpeg_path);

        print_r('Codec: ' . $video_attributes['codec'] . '<br/>');

        print_r('Dimension: ' . $video_attributes['width'] . ' x ' . $video_attributes['height'] . ' <br/>');

        print_r('Duration: ' . $video_attributes['hours'] . ':' . $video_attributes['mins'] . ':' . $video_attributes['secs'] . '.' . $video_attributes['ms'] . '<br/>');

        print_r('Size:  ' . _human_filesize(filesize($vid)));

      }

    else

      {

        print_r('File is not a video.');

      }

  }

else

  {

    print_r('File does not exist.');

  }

function _get_video_attributes($video, $ffmpeg) 

  {

    $command     = $ffmpeg . ' -i ' . $video . ' -vstats 2>&1';

    $output      = shell_exec($command);

    // $regex_sizes = "/Video: ([^,]*), ([^,]*), ([0-9]{1,4})x([0-9]{1,4})/"; // or : $regex_sizes = "/Video: ([^\r\n]*), ([^,]*), ([0-9]{1,4})x([0-9]{1,4})/"; (code from @1owk3y)

    $regex_sizes = "/Video: ([^\r\n]*), ([^,]*), ([0-9]{1,4})x([0-9]{1,4})/";

    die($output);

    if (preg_match($regex_sizes, $output, $regs)) 

      {

        $codec          = $regs[1] ? $regs[1] : null;

        $width          = $regs[3] ? $regs[3] : null;

        $height         = $regs[4] ? $regs[4] : null;

      }

    $regex_duration = "/Duration: ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}).([0-9]{1,2})/";

    if (preg_match($regex_duration, $output, $regs)) 

      {

        $hours          = $regs[1] ? $regs[1] : null;

        $mins           = $regs[2] ? $regs[2] : null;

        $secs           = $regs[3] ? $regs[3] : null;

        $ms             = $regs[4] ? $regs[4] : null;

      }

    return array(

        'codec'          => $codec,

        'width'          => $width,

        'height'          => $height,

        'hours'          => $hours,

        'mins'          => $mins,

        'secs'          => $secs,

        'ms'          => $ms

    );

  }

function _human_filesize($bytes, $decimals = 2) 

  {

    $sz       = 'BKMGTP';

    $factor   = floor((strlen($bytes) - 1) / 3);

    return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$sz[$factor];

  }

