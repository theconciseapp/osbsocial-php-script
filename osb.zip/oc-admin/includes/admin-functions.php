<?php function leftSidebar(){ ?>

<a class="side-bar-btn bg-secondary" aria-current="page" href="<?php echo _ADMIN_URL_;?>"><i class="fa fa-lg fa-home text-light"> </i> Home</a>

<?php if( enb_social()){?>

 <a href="<?php echo _ADMIN_URL_;?>/go-social.php" class="d-block  side-bar-btn"><strong><i class="fa fa-asl-interpreting"></i> SOCIAL</<strong></a>

<?php }?>

<a href="<?php echo _ADMIN_URL_;?>/messenger.php" class="d-block side-bar-btn"><strong><i class="fa fa-comment"></i> MESSENGER</strong></a>

<a href="<?php echo _ADMIN_URL_;?>/admins.php" class="d-block side-bar-btn"><i class="fa fa-user-md"></i> Admins</a>

<a href="<?php echo _ADMIN_URL_;?>/add_user.php" class="d-block  side-bar-btn"><i class="fa fa-user-plus"></i> Add a user</a>

<a href="<?php echo _ADMIN_URL_;?>/reported-contents.php" class="d-block side-bar-btn"><i class="fa fa-volume-up"></i> Reported contents</a>


<button class="side-bar-btn" onclick="$('#settings-sub-menu').slideToggle()"><i class="fa fa-cog"></i> Settings</button>

<div id="settings-sub-menu" style="display: none; width: 85%; margin: 0 auto;">


<a href="<?php echo _ADMIN_URL_;?>/settings-pages/site.php" class="d-block side-bar-btn">Messenger/Social</a>

 <a href="<?php echo _ADMIN_URL_;?>/settings-pages/welcome-message.php" class="d-block side-bar-btn">Set user welcome message</a>


<a href="<?php echo _ADMIN_URL_;?>/settings-pages/mail-setup.php" class="d-block side-bar-btn">SMTP mail Setup</a>

<a href="<?php echo _ADMIN_URL_;?>/settings-pages/account.php" class="d-block side-bar-btn">Account</a>

<a href="<?php echo _ADMIN_URL_;?>/settings-pages/insert-html.php" class="d-block side-bar-btn">Add HTML</a>

<a href="<?php echo _ADMIN_URL_;?>/settings-pages/app-upgrade-notification.php" class="d-block side-bar-btn">Notify App Upgrade</a>

<a href="<?php echo _ADMIN_URL_;?>/settings-pages/others.php" class="d-block side-bar-btn">Others</a>


</div>


<a href="<?php echo _ADMIN_URL_;?>/perform-query.php" target="_blank" class="d-block side-bar-btn"><i class="fa fa-database"></i> Perform Query</a>

<a href="<?php echo _ADMIN_URL_;?>/manage_space.php" target="_blank" class="d-block side-bar-btn"><i class="fa fa-pie-chart"></i> Manage space</a>


<a href="<?php echo _ADMIN_URL_;?>/backup/index.php" id="backu" class="d-block side-bar-btn"><i class="fa fa-hdd-o"></i> Backup</a>


<a href="<?php echo _ADMIN_URL_;?>/site-log.php" class="d-block side-bar-btn"><i class="fa fa-warning"></i> Site log</a>

<a class="side-bar-btn mt-3" href="<?php echo _ADMIN_URL_;?>/logout.php"><i class="fa fa-lg fa-sign-out text-light"></i> Logout</a>

 <?php }

function site_header(){ ?>

<nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo _ADMIN_URL_;?>"> <img src="<?php echo _SITE_URL_;?>/oc-logo.png" class="logo"><?php echo _BRAND_NAME_; ?></a>

    <button class="toggle-sidebar-btn" type="button" onclick="toggleSidebar();">

     <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
         
      </div>
    </div>
  </div>
</nav>

<?php }


function get_pages( $conn, $ignore_static_page=true){

$table       = _TABLE_USERS_;

$result     = array();

$static_page = "";

if ( $ignore_static_page) 

  {
    $static_page = "";
 
  }
else{

 $static_page = "role=2 OR";
  }

$stmt        = $conn->prepare("SELECT username, fullname FROM {$table} WHERE $static_page role=5  ORDER BY role DESC LIMIT 50");

if ($stmt && $stmt->execute()) 

  {

    $res         = $stmt->get_result();

    $stmt->close();

    if ($res->num_rows > 0) {

    while ($row    = $res->fetch_assoc()) 
    {
        $result[]        = $row;
      }
   }
 }
   return $result;

}


function uploadFile($name, $destination, $ftype     = "", $filename, $dir, $folder, $ext) 

  {

    $result    = ["status"           => ""];

    if ($ftype == 'image') 

      {

        $source    = $_FILES[$name]['tmp_name'];

        $file_data = file_get_contents($source);

        if ($result    = masterImageUpload($file_data, $filename, ["resi"           => 500, "thumb_width"           => 20, "folder"           => $folder, "dir"           => $dir])) 

          {

            $file_size = filesize($result["saved_to"]);

            $result["status"]           = "success";

            return $result;

          }

      }

    else

      {

        if (move_uploaded_file($_FILES[$name]['tmp_name'], $destination)) 

          {

$file_size = filesize($destination);
            $result["status"] = "success";

            $result["file_path"] = _CHAT_FILES_PATH_ . "/{$folder}/{$filename}.{$ext}";

            $result["filename"] = "{$filename}.{$ext}";

            $result["folder"] = $folder;

            $result["width"] = 300;

            $result["height"] = 300;
            $result["file_size"]= $file_size;
            return $result;

          }

      }

    $result["status"] = "error";

    return $result;

  }

function uploadVideo($name, $destination, $filename) 

  {

    if (move_uploaded_file($_FILES[$name]['tmp_name'], $destination)) 

      {

        try

          {

            $black_poster   = _CHAT_FILES_DIR_ . '/video-poster-error.png';

            $folder         = "videos/social/" . _CHAT_FILES_STRUCTURE_;

            $dir            = _CHAT_FILES_DIR_ . "/{$folder}";

            $poster_dir     = "{$dir}/__POSTERS__/";

            if (make_dir($poster_dir)) 

              {

                $save_poster_to = "{$poster_dir}/{$filename}.jpg";

                copy($black_poster, $save_poster_to);

              }

          }

        catch(Exception $e) 

          {

            //Ignore

            

          }

        return '__SUCCESS__';

      }

    return '__ERROR__';

  }
