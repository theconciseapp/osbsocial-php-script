<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['username'])) 

  {

    die('{"error":"Empty parameter."}');

  }

$user     = test_input($_POST['username']);

$lsfile   = getGroupDir($user) . "/friends_typing.txt";

$lastseen = "";

if (file_exists($lsfile)) 

  {

    $lsdata   = filemtime($lsfile);

    if (!empty($lsdata)) 

      {

        $lastseen = date('M-d-Y h:i:a', $lsdata);

      }

  }

require '../../oc-includes/server.php';

$table = _TABLE_GROUPS_;

$user  = mysqli_real_escape_string($conn, $user);

$sql   = "SELECT auto_join, username, fullname, group_info, group_admins, total_members FROM $table WHERE username='$user' LIMIT 1";

if ($query = mysqli_query($conn, $sql)) 

  {

    if (mysqli_num_rows($query) < 1) 

      {

        die('{"error":"No record found."}');

      }

    $row   = mysqli_fetch_assoc($query);

    $row["lastseen"]       = $lastseen;

    echo json_encode($row);

  }


