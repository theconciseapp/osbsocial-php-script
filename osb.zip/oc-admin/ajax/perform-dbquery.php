<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

if (empty($_POST['type'])) 

  {

    die('{"error":"Missing parameters."}');

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanAddAdmin()) 

  {

    die('{"error":"Sorry, you are not permitted to perform this task."}');

  }

$admin_username = getAdminInfo('username');

$type           = $_POST['type'];

require '../../oc-includes/server.php';

$database      = $CONFIG___->database;

if ($type == 'show_tables') 

  {

    $tables_prefix = _TABLE_PREFIX_;

    $stmt          = $conn->prepare("SHOW TABLES LIKE '%$tables_prefix%' ");

    if (!$stmt || !$stmt->execute()) 

      {

        die('{"error":"Unable to execute."}');

      }

    $res = $stmt->get_result();

    $stmt->close();

    $conn->close();

    $results = $result  = array();

    while ($row     = $res->fetch_array()) 

      {

        $result[]         = $row;

      }

    $results["status"]         = "success";

    $results["database"]         = $database;

    $results["result"]         = $result;

    die(json_encode($results));

  }

else if ($type == 'show_fields') 

  {

    if (empty($_POST['table'])) 

      {

        $conn->close();

        die('{"error":"Missing parameter"}');

      }

    $table = $_POST['table'];

    $stmt  = $conn->prepare("SHOW COLUMNS FROM $table");

    if (!$stmt || !$stmt->execute()) 

      {

        die('{"error":"Unable to execute."}');

      }

    $res = $stmt->get_result();

    $stmt->close();

    $conn->close();

    $results = $result  = array();

    while ($row     = $res->fetch_assoc()) 

      {

        $result[]         = $row;

      }

    $results["status"]         = "success";

    $results["table"]         = $table;

    $results["result"]         = $result;

    die(json_encode($results));

  }

else if ($type == 'execute') 

  {

    if (empty($_POST['query'])) 

      {

        $conn->close();

        die('{"error":"Missing parameter"}');

      }

    $sql     = $_POST['query'];

    $results = $result  = array();

    try

      {

        if (isUpdateSql($sql)) 

          {

            if ($q       = $conn->query($sql)) 

              {

                $results["status"]         = "success";

                $results["type"]         = "update";

                $results["affected"]         = $conn->affected_rows;

              }

          }

        else if (isSelectSql($sql)) 

          {

            if ($q       = $conn->query($sql)) 

              {

                $total   = $q->num_rows;

                $results["status"]         = "success";

                $results["type"]         = "select";

                $results["affected"]         = $conn->affected_rows;

                $results["total"]         = $total;

                if ($total > 0) 

                  {

                    while ($row     = $q->fetch_assoc()) 

                      {

                        $result[]         = $row;

                      }

                    $q->free_result();

                    $results["result"]   = $result;

                  }

              }

          }

        else if (isInsertSql($sql)) 

          {

            if ($q = $conn->query($sql)) 

              {

                $results["status"]   = "success";

                $results["type"]   = "update";

                $results["affected"]   = $conn->affected_rows;

              }

          }

        else if (isCreateSql($sql)) 

          {

            if ($q = $conn->query($sql)) 

              {

                $results["status"]   = "success";

                $results["type"]   = "update";

                $results["affected"]   = $conn->affected_rows;

              }

          }

        else

          {

            $results["error"]   = "Cannot perform such";

          }

        $conn->close();

        die(json_encode($results));

      }

    catch(Exception $e) 

      {

        $conn->close();

        $results["error"] = $e->getMessage();

        die(json_encode($results));

      }

  }

else

  {

    $conn->close();

    die('{"error":"Cannot perform this query"}');

  }

