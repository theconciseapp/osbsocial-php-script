<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

if (empty($_POST['group_pin']) || empty($_POST['post_id'])) 

  {

    die('{"error":"Empty parameter."}');

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser()) 

  {

    die('{"error":"Permission denied."}');

  }

$gpin = strtolower($_POST['group_pin']);

$pid  = strtolower($_POST['post_id']);

require "../../oc-includes/server.php";

require '../../oc-ajax/group/group-functions.php';

$table   = _TABLE_GROUPS_MESSAGES_;

$message = "delete-message|" . $gpin . "|" . $pid;

if (customGroupMessage($conn, $gpin, "", $message, "act")) 

  {

    die('{"status":"success","result":"Deleted successfully."}');

  }

die('{"error":"Failed to delete. Err02"}');

