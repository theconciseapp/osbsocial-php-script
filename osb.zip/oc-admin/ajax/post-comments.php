<?php header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

if (empty($_POST['post_id']) || empty($_POST['group_pin'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$post_id = test_input($_POST['post_id']);

$gpin    = test_input(strtolower($_POST['group_pin']));

require ('../../oc-includes/server.php');

require ('../../oc-ajax/comment/comment-functions.php');

$result = fetch_comments($conn, $gpin, $post_id);

$conn->close();

die(json_encode($result));

