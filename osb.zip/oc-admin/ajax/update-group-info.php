<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanAddUser()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST["group_pin"]) 
|| empty($_POST["group_admins"]) 
|| empty($_POST["group_title"]) 
|| empty($_POST["group_info"] ) 
|| !isset($_POST["total_members"] )
|| !isset($_POST["auto_join"] )
 ) 

  {

    die('{"error":"Parameters missing."}');

  }

$gpin    = test_input( $_POST['group_pin']);

$gadmins = test_input(str_replace(' ', '', $_POST['group_admins']));

$gadmins = trim(preg_replace("/,+/", ",", $gadmins) , ",");

if (!preg_match("/^[a-z0-9,_]{4,250}$/i", $gadmins)) 

  {

    die('{"error":"Admins has some unwanted characters or length."}');

  }

$gadmins = $gadmins . ',';

$gtitle  = test_input($_POST['group_title']);

$ginfo   = test_input(  $_POST['group_info']);

if (strlen($ginfo) > 600) 

  {

    die('{"error":"Description too long. Max: 600 characters."}');

  }

$utm = (int)$_POST["total_members"];

require "../../oc-includes/server.php";

require "../../oc-ajax/group/group-functions.php";

$table  = _TABLE_GROUPS_;

$gtitle = preg_replace("/(\s+|\|)/", " ", $gtitle);

$auto_join=(int)$_POST["auto_join"];

$aj=true;

$sanitized_ginfo= str_replace("|","&#124;", $ginfo);

$ajgfile = _ADMIN_DIR_ . "/settings-files/auto-join-groups.txt";


if( file_exists( $ajgfile) ){

  $ajgroups= file_get_contents( $ajgfile );
 
  $regex="/^$gpin\|.*?\n/im";

if( $ajgroups!==false && preg_match( $regex, $ajgroups ) ){
 
 if( $auto_join===0 ) {
  
    $replaceWith="";
}
 else if( $auto_join===1) {
   
 $replaceWith="{$gpin}|{$gtitle}|{$sanitized_ginfo}|none\n";

}

$ajgroups_=preg_replace( $regex, $replaceWith, $ajgroups );

if( file_put_contents( $ajgfile, $ajgroups_) ===false)  $aj=false;

 }else if( $auto_join===1) {

if ( file_put_contents( $ajgfile, "{$gpin}|{$gtitle}|{$sanitized_ginfo}|none\n", FILE_APPEND  ) === false ) $aj= false;
 
  }

}else if( $auto_join===1) {

if ( file_put_contents( $ajgfile, "{$gpin}|{$gtitle}|{$sanitized_ginfo}|none\n", FILE_APPEND  ) === false)  $aj=false;
  
}


if(!$aj){

  die('{"error":"No changes maderr"}');
}


$stmt   = $conn->prepare("UPDATE {$table} SET auto_join=?, fullname=?, group_info=?, group_admins=?, total_members=? WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('isssis', $auto_join, $gtitle, $ginfo, $gadmins, $utm, $gpin) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    $data = array();

    $data["status"]      = "success";

    $data["result"]      = "Successfully updated";

    die(json_encode($data));

  }

$conn->close();
die('{"error":"No changes made."}');
