<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['username']) || empty($_POST["fullname"])) 

  {

    die('{"error":"Missing parameters."}');

  }

else if (empty($_POST["has_files"]) && !isset($_POST["post"])) 

  {

    die('{"error":"Post is empty."}');

  }

function format_post($post = "") 

  {

    $post = htmlspecialchars(trim($post));

    return preg_replace("/(\r?\n){2,}/", "\n\n", $post);

  }

$username     = test_input(strtolower($_POST['username']));

$fullname     = test_input($_POST['fullname']);

$meta         = $post     =$post_title    = "";

if (isset($_POST["post"]) && $plen         = strlen($_POST["post"])) 

  {

    if ($plen > 20480) 

      {

        die('{"error":"Post too long."}');

      }

    $post         = format_post($_POST["post"]);

  }

$meta      = $post_files   = "";

if (!empty($_POST["post_meta"])) 

  {

    $meta         = htmlspecialchars(trim($_POST['post_meta']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');

  }


if (!empty( $_POST["post_files"])) 

  {

    $post_files         = htmlspecialchars(trim($_POST['post_files']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');

  }


if (!empty( $_POST["post_title"])) 

  {
  $post_title=test_input( $_POST["post_title"] );
}


$post_preview = mb_substr($post, 0, 250, 'utf-8');

$ptime        = time();

//(microtime(true) * 10000);

require ('../../../oc-includes/server.php');

$table  = _TABLE_SOCIAL_POSTS_;

$result = array();

$stmt   = $conn->prepare("INSERT INTO $table ( post_date, post_by, post_title, post, post_preview, post_files, post_meta, date_time)  VALUES(?,?,?, ?,?,?,?, NOW() )");

if ($stmt && $stmt->bind_param('issssss', $ptime, $username, $post_title, $post, $post_preview, $post_files, $meta) && $stmt->execute()) 

  {

    $stmt->close();

    $result["status"] = "success";

    $result["result"] = "Posted Successfully";

    $result["id"] = mysqli_insert_id($conn);

    die(json_encode($result));

  }

die('{"error":"Sending failed."}');




