<?php if (!defined('_UPLOAD_POST_FILES_')) 

  {

    die('{"error":"Not permitted"}');

  }

$folder         = $ftype          = $ext            = $file_highlight = $preview_text   = "";

if (in_array($file_type, allowedVideos()) && $file_ext == "mp4") 

  {

    $ftype          = 'video';

    $folder         = "videos";

    $ext            = 'mp4';

    $file_highlight = $upload_file_name;

    $preview_text   = 'Video File';

  }

else

  {

    die('{"error":"File not supported."}');

  }

if ($file_ext == 'htaccess') 

  {

    die('{"error":"File not supported."}');

  }

require '../../../oc-admin/includes/admin-functions.php';

$folder   = $folder . "/social/" . _CHAT_FILES_STRUCTURE_;

$vid      = (microtime(true)*10000) . randomNumbers(3);


$vby      = $admin_username;

$filename = "OSB_VID_A_{$vid}";

$dir      = _CHAT_FILES_DIR_ . "/{$folder}";

if (!make_dir($dir)) 

  {

    die('{"error":"Failed to upload. Could not create directory."}');

  }

$dest        = "{$dir}/{$filename}.{$ext}";

$result      = uploadVideo('file', $dest, $filename);

if (preg_match("/__SUCCESS__/", $result)) 

  {

    $sfpath      = _CHAT_FILES_PATH_ . "/{$folder}/{$filename}.{$ext}";

    $poster_file = _CHAT_FILES_PATH_ . "/{$folder}/__POSTERS__/{$filename}.jpg";

$file_size = filesize($dest);

    $result      = array();

    $result["status"]             = "success";

    $result["file_path"]             = $sfpath;

    $result["ext"]             = $ext;

    $result["folder"]             = $folder;

    $result["cover_path"]             = $poster_file;

  $result["file_size"]= $file_size;
    $result["filename"]             = $filename;

    die(json_encode($result));

  }

else

  {

    die('{"error":"Failed to upload."}');

  }




