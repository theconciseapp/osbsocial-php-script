<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['pin'])) 

  {

    die('{"error":"Missing parameter"}');

  }

require ('../../../oc-includes/server.php');

$table   = _TABLE_USERS_;

$pin     = $_POST['pin'];

$iresult = array();

$stmt    = $conn->prepare("SELECT username, fullname, bio, phone, total_followers, total_following FROM {$table} WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('s', $pin) && $stmt->execute()) 

  {

    $res     = $stmt->get_result();

    $stmt->close();

    $conn->close();

    if ($res->num_rows < 1) 

      {

        die('{"status":"success","not_found":"Page not found"}');

      }

    $row = $res->fetch_assoc();

    $iresult["status"]     = "success";

    $iresult["result"]     = $row;

    die(json_encode($iresult));

  }

die(json_encode('{"error":"Not known"}'));

