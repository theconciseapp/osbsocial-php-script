<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['post_id'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$post_id = test_input($_POST['post_id']);

require ('../../../oc-includes/server.php');

$table = _TABLE_SOCIAL_POSTS_;

$stmt  = $conn->prepare("SELECT*FROM $table WHERE id=? LIMIT 1");

if (!$stmt || !$stmt->bind_param('i', $post_id) || !$stmt->execute()) 

  {

    $conn->close();

    die('{"error":"Try again"}');

  }

$res = $stmt->get_result();

$stmt->close();

$conn->close();

$total = $res->num_rows;

if ($total < 1) 

  {

    die('{"error":"Post not found"}');

  }

$row    = $res->fetch_assoc();

$result = array();

$result["status"]        = "success";

$result["post"]        = $row;

die(json_encode($result));

