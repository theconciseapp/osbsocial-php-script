<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, '', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

require ('../../../oc-includes/server.php');

$table   = _TABLE_USERS_;

$iresult = array();

$stmt    = $conn->prepare("SELECT username, fullname FROM {$table} WHERE role IN(2,5,6) ORDER by fullname ASC LIMIT 50");

if ($stmt && $stmt->execute()) 

  {

    $res     = $stmt->get_result();

    $conn->close();

    $stmt->close();

    if ($res->num_rows < 1) 

      {

        die('{"status":"success","no_pages":"No pages created yet."}');

      }

    $result = array();

    while ($row    = $res->fetch_assoc()) 

      {

        $result[]        = $row;

      }

    $iresult["status"]        = "success";

    $iresult["result"]        = $result;

    die(json_encode($iresult));

  }

die(json_encode('{"error":"Not known"}'));



