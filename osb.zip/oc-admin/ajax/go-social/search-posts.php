<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST["s"])) 

  {

    die('{"error":"Search term not found."}');

  };

$search_word = $_POST["s"];

$search_word = preg_replace("/[^A-Za-z0-9_ -]/", '', $search_word);

if (empty($search_word) || strlen($search_word) < 3) 

  {

    die('{"error":"No post found."}');

  };

require '../../../oc-includes/server.php';

$table                 = _TABLE_SOCIAL_POSTS_;

$result                = array();

$final_result          = array();

if (!empty($_POST["page"])) 

  {

    $page_number           = (int)$_POST["page"];

  }

else

  {

    $page_number           = 1;

  }

$item_per_page         = 6;

$item_per_page_ex      = $item_per_page + 1;

$previous_page         = 0;

$next_page             = 0;

$page_position         = (($page_number - 1) * $item_per_page);

$words                 = array_slice(explode(" ", $search_word, 3) , 0, 2);

$post_preview_         = $post_author_fullname_ = $post_author_          = "";

foreach ($words as $word) 

  {

    if (strlen($word) > 1) 

      {

        $post_preview_.= "P.post_preview LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

        $post_author_.= "P.post_by LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

        $post_author_fullname_.= "U.fullname LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

      }

  }

if (empty($post_preview_) && empty($post_author_) && empty($post_author_fullname_)) 

  {

    die('{"error":"No result found."}');

  }

$post_preview_         = substr($post_preview_, 0, -4);

$post_author_          = substr($post_author_, 0, -4);

$post_author_fullname_ = substr($post_author_fullname_, 0, -4);

$table_users           = _TABLE_USERS_;

$ftable                = _TABLE_SOCIAL_FOLLOWERS_;

$sql                   = "SELECT U.fullname AS real_name, U.country, U.bio, U.birth, U.phone, U.added_on AS joined_on, P.id, P.post_date,P.post_by,P.post_preview, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status FROM {$table} AS P 
INNER JOIN $table_users AS U ON P.post_by=U.username WHERE ( ($post_preview_) OR ( $post_author_) OR ($post_author_fullname_ ) ) ORDER BY id DESC LIMIT $page_position, $item_per_page_ex";

$query                 = mysqli_query($conn, $sql);

mysqli_close($conn);

$total_posts   = $total_to_send = mysqli_num_rows($query);

if ($total_posts < 1) 

  {

    die('{"status":"success","no_post":"No post found."}');

  }

if ($total_posts > $item_per_page) 

  {

    $next_page     = $page_number + 1;

    $total_to_send = $item_per_page;

  }

$i             = 0;

while ($row           = mysqli_fetch_assoc($query)) 

  {

    $i++;

    if ($i <= $total_to_send) 

      {

        $result[]               = $row;

      }

  }

$final_result["status"]               = "success";

$final_result["total_posts"]               = $total_posts;

$final_result["next_page"]               = $next_page;

$final_result["result"]               = $result;

die(json_encode($final_result));

