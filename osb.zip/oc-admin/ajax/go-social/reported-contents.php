<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

require '../../../oc-includes/server.php';

$sJson            = getSettings();

$item_per_page    = 20;

//isset( $sJson["users_per_page"] ) ? $sJson["users_per_page"] : "20";

$table            = _TABLE_REPORTS_;

if (!empty($_POST["page"])) 

  {

    $page_number      = (int)$_POST["page"];

  }

else

  {

    $page_number      = 1;

  }

$item_per_page_ex = $item_per_page + 1;

$previous_page    = 0;

$next_page        = 0;

$page_position    = (($page_number - 1) * $item_per_page);

$stmt             = $conn->prepare("SELECT id, report_by, report, report_section, report_id, report_time, meta FROM $table ORDER BY id DESC LIMIT $page_position, $item_per_page_ex");

if (!$stmt || !$stmt->execute()) 

  {

    $conn->close();

    die('{"error":"Please try again."}');

  }

$res = $stmt->get_result();

$stmt->close();

$conn->close();

$final_result  = $result        = array();

$total_posts   = $total_to_send = $res->num_rows;

if ($total_posts < 1) 

  {

    die('{"no_report":"No report yet."}');

  }

if ($total_posts > $item_per_page) 

  {

    $next_page     = $page_number + 1;

    $total_to_send = $item_per_page;

  }

$i             = 0;

while ($row           = $res->fetch_assoc()) 

  {

    $i++;

    if ($i <= $total_to_send) 

      {

        $result[]               = $row;

      }

  }

$final_result["status"]               = "success";

$final_result["total_posts"]               = $total_posts;

$final_result["next_page"]               = $next_page;

$final_result["reports"]               = $result;

die(json_encode($final_result));

