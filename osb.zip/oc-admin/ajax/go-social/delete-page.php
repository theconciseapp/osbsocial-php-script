<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['username'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$pin = test_input(strtolower($_POST['username']));


$exception=array("cv_drafts","cv_sponsoredposts");


if ( in_array($pin, $exception) ) 

  {

    die('{"error":"Not allowed"}');

  }

else if (!validUsername($pin, true)) 

  {

    die('{"error":"Invalid pin"}');

  }

if (!adminCanDeleteUser()) 

  {

    die('{"error":"Permission denied. You do not have enough permission."}');

  }

require ('../../../oc-includes/server.php');

$table = _TABLE_USERS_;

$stmt  = $conn->prepare("DELETE FROM $table WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('s', $pin) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    $userDir = getUserDir($pin);

    if (is_dir($userDir)) 

      {

        deleteTree($userDir);

      }

    die('{"status":"success"}');

  }

$conn->close();

die('{"error":"Please try again."}');


