<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }


if( !isset($_POST["post_status"] )
  || empty($_POST["post_id"]) ) 

  {

    die('{"error":"Missing parameters."}');

  }


$post_status  = (int)$_POST['post_status'];

$post_id      = test_input( $_POST['post_id']);

  $new_status=1;

if( $post_status=="1"){

  $new_status=0;

}

require ('../../../oc-includes/server.php');

$table  = _TABLE_SOCIAL_POSTS_;

$result = array();

$stmt   = $conn->prepare("UPDATE $table SET post_status=? WHERE id=? LIMIT 1");

if ($stmt && $stmt->bind_param('ii', $new_status, $post_id) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    $result["status"] = "success";

    $result["result"] = $new_status;

    die(json_encode($result));

  }

$conn->close();

die('{"error":"Update failed."}');



