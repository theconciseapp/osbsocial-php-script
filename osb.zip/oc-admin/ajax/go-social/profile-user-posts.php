<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['user'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$user = test_input(strtolower($_POST['user']));

require ('../../../oc-includes/server.php');

$result           = $final_result     = array();

if (!empty($_POST["page"])) 

  {

    $page_number      = (int)$_POST["page"];

  }

else

  {

    $page_number      = 1;

  }

$item_per_page    = 10;

$item_per_page_ex = $item_per_page + 1;

$previous_page    = 0;

$next_page        = 0;

$page_position    = (($page_number - 1) * $item_per_page);

$table_users      = _TABLE_USERS_;

$table            = _TABLE_SOCIAL_POSTS_;

$settings__       = getSettings();

$post_order       = isset($settings__["go_ppo"]) ? $settings__["go_ppo"] : "DESC";

if (!empty($_POST['post_order'])) 

  {

    $porder           = preg_replace("/[^A-Z]+$/", "", $_POST['post_order']);

    if ($porder == 'DESC' || $porder == 'ASC') 

      {

        $post_order       = $porder;

      }

  }

$stmt             = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, U.total_following, U.total_followers, P.*
FROM $table_users AS U 
LEFT JOIN $table AS P ON ( U.username=P.post_by )
WHERE U.username=?
ORDER BY P.id $post_order LIMIT $page_position, $item_per_page_ex");

if (!$stmt || !$stmt->bind_param('s', $user) || !$stmt->execute()) 

  {

    die('{"error":"Something went wrong."}');

  }

$res = $stmt->get_result();

$stmt->close();

$conn->close();

$total_posts   = $total_to_send = $res->num_rows;

if ($total_posts < 1) 

  {

    die('{"status":"success","not_found":"Pin not found"}');

  }

if ($total_posts > $item_per_page) 

  {

    $next_page     = $page_number + 1;

    $total_to_send = $item_per_page;

  }

$i             = 0;

while ($row           = $res->fetch_assoc()) 

  {

    $i++;

    if ($i <= $total_to_send) 

      {

        $result[]               = $row;

      }

  }

$final_result["status"]               = "success";

$final_result["total_posts"]               = $total_posts;

$final_result["next_page"]               = $next_page;

$first         = $result[0]; //Use the first post result to get user details

$final_result["real_name"]               = $first["real_name"];

$final_result["country"]               = $first["country"];

$final_result["bio"]               = $first["bio"];

$final_result["phone"]               = $first["phone"];

$final_result["birth"]               = $first["birth"];

$final_result["email"]               = $first["email"];

$final_result["joined_on"]               = $first["joined_on"];

$final_result["total_following"]               = $first["total_following"];

$final_result["total_followers"]               = $first["total_followers"];

$final_result["has_post"]               = $first["id"];

$final_result["result"]               = $result;

die(json_encode($final_result));


