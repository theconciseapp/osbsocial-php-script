<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, '', 'json');


if (  !empty($_POST["page"])) 

      {

        $page_number      = (int)$_POST["page"];

      }

    else

      {

        $page_number      = 1;

      }

   $item_per_page=10;

    $item_per_page_ex = $item_per_page + 1;

    $previous_page    = 0;

    $next_page        = 0;

    $page_position    = ( ( $page_number - 1) * $item_per_page);

$result=$final_result=array();


require ('../../../oc-includes/server.php');
$table   = _TABLE_SOCIAL_NOTIFICATIONS_;


$stmt    = $conn->prepare("SELECT id, message_time,  message, meta FROM {$table} WHERE message_to='general'
ORDER BY id DESC LIMIT $page_position, $item_per_page_ex");
if (!$stmt|| !$stmt->execute() ) 
  {
    $conn->close();
    $final_result["error"] = "Server fault";

    die(json_encode($results) );

  }

$res = $stmt->get_result();

    $stmt->close();
    $conn->close();

    $total_posts   = $total_to_send = $res->num_rows;

    if ($total_posts < 1) 

      {

        $final_result["status"]               = "success";

        $final_result["no_noti"]               = "No more posts";

    die( json_encode($final_result));

      }

    if ($total_posts > $item_per_page) 

      {

        $next_page     = $page_number + 1;

        $total_to_send = $item_per_page;

      }

    $i             = 0;

    while ($row           = $res->fetch_assoc()) 

      {

        $i++;

        if ($i <= $total_to_send) 

          {

            $result[]               = $row;

          }

      }

    $final_result["status"]               = "success";

    $final_result["total_posts"]               = $total_posts;

    $final_result["next_page"]               = $next_page;

    $final_result["result"]               = $result;

  
die(json_encode($final_result));
