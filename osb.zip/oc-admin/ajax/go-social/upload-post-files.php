<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require '../../../oc-includes/bootstrap.php';

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

@ini_set('memory_limit', '512M');

@ini_set('post_max_size', '256M');

@ini_set('upload_max_filesize', '256M');

@ini_set('max_execution_time', 600);

@ini_set('max_input_time', 600);

$name = 'file'; //File <input type="file" name="file">

if (empty($_FILES[$name]['tmp_name']) || empty($_FILES[$name]['type']) || empty($_FILES[$name]['name'])) 

  {

    die('{"error":"Some parameters are missing."}');

  }

else if (0 < $_FILES[$name]['error']) 

  {

    die('{"error":"Error:' . $_FILES[$name]['error'] . '"}');

  }

$file_size = $_FILES[$name]['size'];

if (($file_size / 1024) > 100000) 

  { //100mb

    die('{"error":"File too large."}');

  }

$tmpFile          = $_FILES[$name]['tmp_name'];

$upload_file_name = test_input($_FILES[$name]["name"]);

$expl             = explode(".", strtolower($upload_file_name));

$file_ext         = end($expl);

if (empty($file_ext)) 

  {

    die('{"error":"File extension missing"}');

  }

$file_type      = finfo_file(finfo_open(FILEINFO_MIME_TYPE) , $tmpFile);

$admin_username = getAdminInfo('username');

require '../../../oc-includes/chat_functions.php';

define('_UPLOAD_POST_FILES_', '1');

$file_ext = strtolower($file_ext);

$img_arr  = array(

    'jpg',

    'png',

    'jpeg',

    'gif'

);

if (in_array($file_ext, $img_arr)) 

  {

    include ('upload-image.php');

  }

else if ($file_ext == 'mp4') 

  {

    include ('upload-video.php');

  }

