<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['username']) || empty($_POST['fullname']) || empty($_POST['bio']) || !isset($_POST['phone']) || !isset($_POST['total_followers'])) 

  {

    die('{"error":"One or more fields are empty."}');

  }

$username        = strtolower($_POST['username']);

$fullname        = test_input(strtolower($_POST['fullname']));

$bio             = test_input($_POST['bio']);

$phone           = test_input($_POST["phone"]);

$total_followers = test_input($_POST['total_followers']);

if (!validUsername($username, true)) 

  {

    die('{"error":"Page pin can contain alphanumerics, underscore and must start with a letter. Min: 4, Max: 30"}');

  }

else if (!validName($fullname)) 

  {

    die('{"error":"Enter a good display name or title"}');

  }

else if (!empty($phone) && !preg_match("/^[0-9+() -]{4,50}$/i", $phone)) 

  {

    die('{"error":"Enter a valid phone number"}');

  }

else if (!is_numeric($total_followers)) 

  {

    die('{"error":"Invalid total followers"}');

  }

require "../../../oc-includes/server.php";

$table = _TABLE_USERS_;

//Check if username or email exists

$stmt  = $conn->prepare("UPDATE $table SET fullname=?, bio=?, phone=?, total_followers=? WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('sssis', $fullname, $bio, $phone, $total_followers, $username) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    die('{"status":"success","result":"Updated successfully."}');

  }

$conn->close();

die('{"error":"Unable to update page. Please try again."}');

