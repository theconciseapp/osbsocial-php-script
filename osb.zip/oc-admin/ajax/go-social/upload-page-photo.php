<?php

/**

 * Class and Function List:

 * Function list:

 * - uploadImage()

 * Classes list:

 */

@ini_set('max_execution_time', 200);

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require '../../../oc-includes/bootstrap.php';

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

$name = 'file'; //File <input type="file" name="file">

if (empty($_FILES[$name]['type'])) 

  {

    die('{"error":"Some parameters are missing."}');

  }

else if (0 < $_FILES[$name]['error']) 

  {

    die('{"error":"Error:' . $_FILES[$name]['error'] . '"}');

  }

$file_size = $_FILES[$name]['size'];

if (($file_size / 1024) > 5000) 

  { //5mb

    die('{"error":"File too large."}');

  }

$tmpFile          = $_FILES[$name]['tmp_name'];

$upload_file_name = test_input($_FILES[$name]["name"]);

$expl             = explode(".", strtolower($upload_file_name));

$name_ext         = end($expl);

$file_type        = finfo_file(finfo_open(FILEINFO_MIME_TYPE) , $tmpFile);

require '../../../oc-includes/chat_functions.php';

if (!in_array($file_type, allowedImages())) 

  {

    die('{"error":"Invalid image type"}');

  }

$folder         = $ftype          = $ext            = $file_highlight = $preview_text   = "";

$admin_username = getAdminInfo('username');

$username       = test_input(strtolower($_POST['username']));

$dir            = getUserDir($username);

if (!is_dir($dir)) 

  {

    die('{"error":"Upload not successful."}');

  }

$dest        = $dir . '/profile_picture_full.jpg';

$thumb_dest  = $dir . '/profile_picture_small.jpg';

$mthumb_dest = $dir . '/profile_picture_medium.jpg';

$file_data   = file_get_contents($tmpFile);

if ($result      = masterImageUpload($file_data, "profile_picture_full", ["dir"             => $dir, "folder"             => "null", "direct_filename"             => true])) 

  {

    $file_size   = filesize($result["saved_to"]);

    $saved_to    = $result["saved_to"];

    $file_path   = $result["file_path"];

    $width       = $result["width"];

    $height      = $result["height"];

    resizeImage($saved_to, $thumb_dest, 100);

    resizeImage($saved_to, $mthumb_dest, 140);

    /*

    if (move_uploaded_file($_FILES[$name]['tmp_name'], $dest) ){

    

    createThumbnail( $dest, $thumb,50);

    */

    die('{"status":"success","result":"Upload successful"}');

  }

die('{"error":"Upload not successful"}');

