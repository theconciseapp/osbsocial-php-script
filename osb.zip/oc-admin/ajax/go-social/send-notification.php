<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser()) 

  {

    die('{"error":"Permission denied"}');

  }
else if( empty( $_POST["message"] ) ){

  die('{"error":"Message is empty"}');

}


$username = test_input(getAdminInfo('username'));

$message= test_input( $_POST["message"] );

require '../../../oc-includes/server.php';

    //NOTIFICATION

    require ("../../../oc-ajax/go-social/go-functions.php");

    $meta    = array();

    $meta["author"]         = $username;

    $meta["action"]         = "expand";

    $meta["action_type"]         = "";

    $meta["action_id"]         = $username;

    try

      {

        $send_to = "general";

   if( sendNotification( $conn, $send_to, $message , $meta, "force-send") ){

die('{"status":"success","result":"Notification sent"}');

}else{

die('{"error":"Not sent"}');

}

      }

    catch(Exception $e) 

      {

        // logIt( $e->getMessage());

        //Just Ignore
die('{"error":"Not sent"}');
        

      }

    $conn->close();

   
