<?php

if (!defined('_UPLOAD_POST_FILES_')) 

  {

    die('{"error":"Not permitted"}');

  }

$folder         = $ftype          = $ext            = $file_highlight = $preview_text   = "";

if (in_array($file_type, allowedImages())) 

  {

    $ftype          = 'image';

    $folder         = "images";

    $ext            = 'jpg';

    $file_highlight = $upload_file_name;

    $preview_text   = 'Image File';

  }

else

  {

    die('{"error":"File not supported."}');

  }

if ($file_ext == 'htaccess') 

  {

    die('{"error":"File not supported."}');

  }

$folder   = $folder . "/social/" . _CHAT_FILES_STRUCTURE_;

$fid      = (microtime(true)*10000) . randomNumbers(3);

$fby      = $admin_username;

$filename = "OSB_IMG_A_{$fid}";

$dir      = _CHAT_FILES_DIR_ . "/{$folder}";

if (!make_dir($dir)) 

  {

    die('{"error":"Failed to upload. Could not create directory."}');

  }

$dest      = "{$dir}/{$filename}.{$ext}";

$file_data = file_get_contents($_FILES[$name]['tmp_name']);

if ($result    = masterImageUpload($file_data, $filename, ["dir"           => $dir, "folder"           => $folder])) 

  {

    $file_size = filesize($result["saved_to"]);

    $file_path = $result["file_path"];

    $folder    = $result["folder"];

    $width     = $result["width"];

    $height    = $result["height"];

    $sfpath    = _CHAT_FILES_PATH_ . "/{$folder}/{$filename}.{$ext}";

    $result    = array();

    $result["status"]           = "success";

    $result["file_path"]           = $file_path;

    $result["dimension"]           = "{$width}_{$height}";
   $result["width"]= $width;
   $result["height"]=$height;
   $result["file_size"]=$file_size;
    $result["ext"]           = $ext;

    $result["filename"]           = $filename;

    die(json_encode($result));

  }

else

  {

    die('{"error":"Failed to upload."}');

  }



