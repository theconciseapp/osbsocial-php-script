<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['post_id'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$post_id = test_input($_POST['post_id']);

require ('../../../oc-includes/server.php');

$table = _TABLE_SOCIAL_POSTS_;

$stmt  = $conn->prepare("DELETE FROM $table WHERE id=? LIMIT 1");

if ($stmt && $stmt->bind_param('i', $post_id) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    die('{"status":"success"}');

  }

$conn->close();

die('{"error":"Please try again."}');

