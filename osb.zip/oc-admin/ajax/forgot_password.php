<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\SMTP;

use PHPMailer\PHPMailer\Exception;

if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 

  {

    die('{"error":"Invalid email address."}');

  }

sleep(2);

$email = test_input($_POST["email"]);

require "../../oc-includes/server.php";

$table   = _TABLE_ADMINS_;

$sql     = "SELECT email FROM $table  WHERE email='$email' LIMIT 1";

$results = mysqli_query($conn, $sql);

$row     = mysqli_num_rows($results);

if ($row < 1) 

  {

    die('{"error":"This email address is not registered."}');

  }

if (!$token = createToken($conn, $email, 15)) 

  {

    die('{"error":"Please try again."}');

  }

mysqli_close($conn);

$output = '<p>Hello,</p>';

$output.= '<p>Please click on the following link to reset your password.</p>';

$output.= '<p>-------------------------------------------------------------</p>';

$output.= '<p><a href="' . _ADMIN_URL_ . '/reset_password.php?token=' . $token . '&email=' . $email . '&action=reset" target="_blank">' . _ADMIN_URL_ . '/reset_password.php?token=' . $token . '&email=' . $email . '&action=reset</a></p>';

$output.= '<p>-------------------------------------------------------------</p>';

$output.= '<p>You may also copy the entire link into your browser.
The link will expire after 15 minutes for security reason.</p>';

$output.= '<p>If you did not request this email, no action 
is needed, your password will not be reset. However, you may want to log into 
your account and change your password as someone may have guessed it.</p>';

$output.= '<p>Thanks,</p>';

$output.= '<p>© ' . date('Y') . ' ' . _APP_NAME_ . '</p>';

$body       = $output;

$subject    = "Password Reset Link- " . _APP_NAME_;

$fromserver = "noreply@noreply.com";

if (Emailer($email, $subject, $body)) 

  {

    die('{"status":"success","result":"You will receive a password reset link in your inbox or spam."}');

  }

else

  {

    die('{"error":"Sorry, an error occured. Try again."}');

  }

