<?php header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

if (empty($_POST['comment_id']) || empty($_POST['group_pin'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$cid  = test_input($_POST['comment_id']);

$gpin = test_input(strtolower($_POST['group_pin']));

require ('../../oc-includes/server.php');

require ('../../oc-ajax/comment/comment-functions.php');

if (delete_comment($conn, $gpin, $cid, "", "sa")) 

  {

    $conn->close();

    die('{"status":"success","result":"Succesful."}');

  }

$conn->close();

die('{"error":"Please try again."}');

