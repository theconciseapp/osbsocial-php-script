<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['new_password']) || empty($_POST['old_password'])) 

  {

    die('{"error":"Passwords cannot be empty."}');

  }

else if (!preg_match("/^[a-z0-9~@#%_+*?-]{6,50}/i", $_POST['new_password'])) 

  {

    die('{"error":"Password can only contain these characters: a-z 0-9 ~@#%_+*?-"}');

  }

require ("../../oc-includes/server.php");

$table    = _TABLE_ADMINS_;

$username = test_input(getAdminInfo('username'));

if (strtolower($username) == 'admin123') 

  {

    die('{"error":"Permission denied."}');

  }

$op    = $_POST['old_password'];

$np    = $_POST['new_password'];

$query = mysqli_query($conn, "SELECT password FROM $table WHERE username='$username' LIMIT 1");

$row   = mysqli_fetch_assoc($query);

$old_p = $row["password"];

if (!password_verify($op, $old_p)) 

  {

    $conn->close();

    die('{"error":"Invalid old password."}');

  }

$password = password_hash($np, PASSWORD_DEFAULT);

if (mysqli_query($conn, "UPDATE $table SET password='$password' WHERE username='$username' LIMIT 1")) 

  {

    if (mysqli_affected_rows($conn) > 0) 

      {

        mysqli_close($conn);

        die('{"status":"success"}');

      }

  }

mysqli_close($conn);

die('{"error":"Failed to change"}');

