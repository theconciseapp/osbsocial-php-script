<?php

/**

 * Class and Function List:

 * Function list:

 * - uploadImage()

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require '../../oc-includes/bootstrap.php';

adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser()) 

  {

    die('{"error":"Permission denied"}');

  }

@ini_set('memory_limit', '512M');

@ini_set('upload_max_filesize', '256M');

@ini_set('post_max_size', '257M');

@ini_set('max_execution_time', 600);

@ini_set('max_input_time', 600);

require '../../oc-admin/includes/admin-functions.php';

$name = 'file'; //File <input type="file" name="file">

if (empty($_FILES[$name]['type'])) 

  {

    die('{"error":"Some parameters are missing."}');

  }

else if (0 < $_FILES[$name]['error']) 

  {

    die('{"error":"Error:' . $_FILES[$name]['error'] . '"}');

  }

$file_size = $_FILES[$name]['size'];

if (($file_size / 1024) > 100000) 

  { //100mb

    die('{"error":"File too large."}');

  }

$tmpFile          = $_FILES[$name]['tmp_name'];

$upload_file_name = test_input($_FILES[$name]["name"]);

$expl             = explode(".", strtolower($upload_file_name));

$name_ext         = end($expl);

$file_type        = finfo_file(finfo_open(FILEINFO_MIME_TYPE) , $tmpFile);

$admin_username   = getAdminInfo('username');

require '../../oc-includes/chat_functions.php';

$folder         = $ftype          = $ext            = $file_highlight = $preview_text   = "";

if (in_array($file_type, allowedImages())) 

  {

    $ftype          = 'image';

    $folder         = "images";

    $ext            = 'jpg';

    $file_highlight = $upload_file_name;

    $preview_text   = 'Image File';

  }

else if (in_array($file_type, allowedVideos()) && $name_ext == 'mp4') 

  {

    $ftype          = 'video';

    $folder         = "videos";

    $ext            = 'mp4';

    $file_highlight = $upload_file_name;

    $preview_text   = 'Video File';

  }

else if (in_array($file_type, allowedAudios()) && ($name_ext == 'mp3' || $name_ext == 'mp4')) 

  {

    $ftype          = 'audio';

    $folder         = "audios";

    $ext            = 'mp3';

    $file_highlight = $upload_file_name;

    $preview_text   = 'Audio File';

  }

else if (!in_array($file_type, bannedDocuments())) 

  {

    $ftype          = 'document';

    $folder         = "documents";

    $expl           = explode(".", $upload_file_name);

    $ext            = end($expl);

    $file_highlight = $upload_file_name;

    $preview_text   = 'Document File';

  }

else

  {

    die('{"error":"File not supported."}');

  }

if ($name_ext == 'htaccess') 

  {

    die('{"error":"File not supported."}');

  }

$folder   = $folder . "/messenger/" . _CHAT_FILES_STRUCTURE_;

$chat_id  = randomNumbers(15);

$chat_to  = $admin_username;

$filename = $chat_to . '-' . $chat_id;

$dir      = _CHAT_FILES_DIR_ . "/{$folder}";

if (!make_dir($dir)) 

  {

    die('{"error":"Failed to upload. Could not create directory."}');

  }

$destination = "{$dir}/{$filename}.{$ext}";

$result      = uploadFile('file', $destination, $ftype, $filename, $dir, $folder, $ext);

if ($result["status"] == "success") 

  {

    $file_path   = $result["file_path"];

    $filename    = $result["filename"];

    $width       = $result["width"];

    $height      = $result["height"];

    $folder      = $result["folder"];

    $dimension   = "{$width}_{$height}";

    $meta        = array();

    $meta["file"]             = $ftype;

    $meta["pt"]             = $preview_text;

    $meta["fx"]             = $ext;

    $meta["size"]             = $file_size;

    $meta["fol"]             = $folder;

    $meta["dimension"]             = $dimension;

    $meta["lfpath"]             = "";

    $meta["sfpath"]             = $file_path;

    $message     = "[file=::{$filename}::]";

    $result      = array();

    $result["status"]             = "success";

    $result["file_preview"]             = $file_highlight;

    $result["file_message"]             = $message;

    $result["meta"]             = base64_encode(json_encode($meta));

    $result["file_name"]             = $filename;

    die(json_encode($result));

  }

else

  {

    die('{"error":"Failed to upload."}');

  }

