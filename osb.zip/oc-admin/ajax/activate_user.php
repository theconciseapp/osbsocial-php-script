<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die');

if (!adminCanActivateUser()) 

  {

    die('Permission denied');

  }

if (empty($_POST['username'])) 

  {

    die('Username empty.');

  }

require "../../oc-includes/server.php";

$table    = _TABLE_USERS_;

$username = test_input($_POST['username']);

if (!validUsername($username, true)) 

  {

    die('__FAILED__');

  }

$stmt = $conn->prepare("UPDATE $table SET user_status='1' WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('s', $username) && $stmt->execute()) 

  {

    $stmt->close();

    $table = _TABLE_GROUPS_;

    try

      {

        $stmt  = $conn->prepare("UPDATE $table SET total_members=total_members+1 WHERE group_pin='gp_pofficials' LIMIT 1");

        if ($stmt && $stmt->execute()) 

          {

            $stmt->close();

          }

      }

    catch(Exception $e) 

      {

        //ignore error

        

      }

    $conn->close();

    die('__SUCCESS__');

  }

$conn->close();

die('__FAILED__');

