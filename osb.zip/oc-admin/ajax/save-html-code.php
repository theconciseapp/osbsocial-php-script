<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanAddAdmin()) 

  {

    die('{"error":"Permission denied"}');

  }

 else if( empty( $_POST["type"] )){

die('{"error":"Type not found"}');
}

$udir = _CHAT_FILES_DIR_ . "/welcome";

$udir = _PROJECT_DIR_ . "/oc-includes";

if (!make_dir($udir)  ) 

  {

    die('{"error":"Failed to create dir."}');

  }

$type= test_input( $_POST["type"] );

$file= $udir . "/" . $type."-code.html.php";

if (empty($_POST["message"])) 

  {

    if (is_file($file)) 

      {

        unlink($file);

      }

    die('{"status":"success","result":"Saved successfully"}');

  }

$data = $_POST['message'];

if (file_put_contents($file, $data)) 

  {

    die('{"status":"success","result":"Saved successfully."}');

  }

die('{"error":"Failed"}');




