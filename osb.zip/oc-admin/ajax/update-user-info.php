<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, "die", "json");

if (!adminCanAddUser()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['username'])
 || empty($_POST['fullname'])
 || empty($_POST['email'])
 || empty($_POST['phone'] )
 || !isset($_POST['groups'])
 || !isset($_POST['bio'] )
 || !isset($_POST['following'] )
 || !isset($_POST['followers'] ) )

  {

    die('{"error":"Parameters missing"}');

  }

$username = test_input($_POST['username']);

$fullname = test_input($_POST['fullname']);

$email    = test_input($_POST["email"]);

$phone    = test_input($_POST["phone"]);

$bio      = test_input($_POST["bio"]);

$groups   = test_input($_POST["groups"]);

$following = (int)$_POST["following"];
$followers = (int)$_POST["followers"];

if (!validUsername($username, true)) 

  {

    die('{"error":"Invalid username."}');

  }

else if (!validName($fullname)) 

  {

    die('{"error":"Bad display name."}');

  }

else if (!validEmail($email)) 

  {

    die('{"error":"Invalid email address."}');

  }

else if (!validPhone($phone)) 

  {

    die('{"error":"Invalid phone number."}');

  }

require "../../oc-includes/server.php";

$table  = _TABLE_USERS_;

if (!empty($groups)) 

  {

    $groups = "{$groups} ";

  }

$stmt   = $conn->prepare("UPDATE {$table} SET fullname=?, email=?, phone=?, bio=?, groups=? , total_followers=?, total_following=? WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('sssssiis', $fullname, $email, $phone, $bio, $groups, $followers, $following, $username) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    $data = array();

    $data["status"]      = "success";

    $data["result"]      = "Successfully updated.";

    die(json_encode($data));

  }

$conn->close();

die('{"error":"No changes made."}');
