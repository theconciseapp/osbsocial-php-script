<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die');

if (empty($_GET["search"])) 

  {

    die('<div class="alert alert-warning text-center">
<span class="far fa-arrow-up"></span> Search string is empty.
   </div>');

  };

$search_word = $_GET["search"];

$search_word = preg_replace("/[^A-Za-z0-9_ -]/", '', $search_word);

if (empty($search_word) || strlen($search_word) < 3) 

  {

    die('<div class="alert alert-warning text-center">
<span class="far fa-arrow-up"></span>No result found.
   </div>');

  };

if (!isset($page_url)) $page_url       = "";

$settings_file  = _ADMIN_DIR_ . '/settings-files/settings.txt';

$settings       = "";

if (is_file($settings_file)) 

  {

    $settings       = "" . (file_get_contents($settings_file));

  }

$sJson          = json_decode($settings);

$users_per_page = isset($sJson->users_per_page) ? $sJson->users_per_page : "10";

$item_per_page  = $users_per_page;

$param          = !empty($_POST['param']) ? test_input($_POST['param']) : '';

$sort_by        = 'id';

$desc           = 'DESC';

if (!empty($_SESSION['sort_by'])) 

  {

    $sby            = $_SESSION['sort_by'];

    if ($sby == 'fullname_desc') 

      {

        $sort_by        = 'fullname';

        $desc           = 'DESC';

      }

    else if ($sby == 'fullname_asc') 

      {

        $sort_by        = 'fullname';

        $desc           = 'ASC';

      }

    else if ($sby == 'id_desc') 

      {

        $sort_by        = 'id';

        $desc           = 'DESC';

      }

    else if ($sby == 'id_asc') 

      {

        $sort_by        = 'id';

        $desc           = 'ASC';

      }

  }

if (isset($_GET["page"])) 

  {

    //Get page number from $_GET["page"]

    $page_number    = (int)$_GET["page"];

  }

else

  {

    $page_number    = 1;

    //if there's no page number, set it to 1

    

  }

require '../../oc-includes/server.php';

$table          = _TABLE_GROUPS_ . "_messages";

$results        = mysqli_query($conn, "SELECT COUNT(id) FROM $table");

//get total number of records from database

$get_total_rows = $results->fetch_row();

//hold total records in variable

if ($get_total_rows[0] < 1) 

  {

    $conn->close();

    die('<div class="alert alert-primary text-center">
<span class="far fa-arrow-up"></span> No active user yet.
   </div>');

  }

$total_pages   = ceil($get_total_rows[0] / $item_per_page);

$page_position = (($page_number - 1) * $item_per_page);

//get starting position to fetch the records

$words         = array_slice(explode(" ", $search_word, 3) , 0, 2);

$group_pin_    = "";

$message_      = "";

foreach ($words as $word) 

  {

    $group_pin_.= "group_pin LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

    $message_.= "message LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

  }

$group_pin_ = substr($group_pin_, 0, -4);

$message_   = substr($message_, 0, -4);

$sql        = "SELECT group_pin, message_by, message, message_id, date_time FROM $table WHERE ( ($group_pin_) OR ($message_) ) ORDER BY {$sort_by} {$desc} LIMIT {$page_position}, {$item_per_page} ";

$query      = mysqli_query($conn, $sql);

mysqli_close($conn);

if (mysqli_num_rows($query) < 1) 

  {

    die('<div class="alert alert-primary text-center">
<span class="fa fa-arrow-down"></span>No result found.
   </div>');

  }

echo '<div class="container">';

echo "<div>Searched: {$search_word}</div>";

while ($row     = mysqli_fetch_assoc($query)) 

  {

    $mto     = $row["group_pin"];

    $mby     = ucfirst($row["message_by"]);

    $msg     = ucfirst($row["message"]);

    $mdt     = $row["date_time"];

    $mdata   = json_decode($msg, true);

    if (isset($mdata["msg"])) 

      {

        $message = substr($mdata["msg"], 0, 100);

        $mid     = $mdata["cid"];

      }

?>
 <div class="user-panel border-bottom" id="group-post-<?php echo $mid; ?>">

  <div class="row">
<div class="col-3">

<div class="user-photo-icon-container"> <img src="<?php echo user_photo_icon(strtolower($mby) , "g"); ?>" onerror="imgError( this, 50);" class="user-photo-icon">
</div>

</div>

<div class="col" style="overflow-x: hidden;">

<div class="users-list-container">
 <?php echo "<strong><span class='user-fullname-text'>{$mby}</span>, To: <strong><small>[ " . strtoupper(str_replace('gp_', '', $mto)) . "</strong></small> ]</strong>"; ?>

<?php echo '<div><b>ID:' . $mid . '</b></div>';

    echo $message;

?>

<div class="mt-2" style="white-space: nowrap; overflow-x: auto;">

<button class="btn btn-sm btn-success view-post-comments fa fa-book" data-pid="<?php echo $mid; ?>" data-gpin="<?php echo $mto; ?>">Comments</button>

<button class="btn btn-sm btn-warning hide-post fa fa-ban" data-pid="<?php echo $mid; ?>" data-gpin="<?php echo $mto; ?>">Hide in app</button>

<button class="btn btn-sm btn-danger delete-post fa fa-trash" data-pid="<?php echo $mid; ?>" data-gpin="<?php echo $mto; ?>"> Delete</button> 

</div>

<div id="user-info-result-?php echo $username; ?>"></div>

</div>
 </div>
</div>
</div>

<?php

  } ?>


<div class="pagination">
 
<?php echo paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url, 'admin'); ?>

</div>

<?php echo '</div>'; ?>
