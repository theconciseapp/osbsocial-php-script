<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanChangeSettings()) 

  {

    die('{"error":"Permission denied."}');

  }

$result       = array();

foreach ($_POST as $key          => $val) 

  {

    //do sanitization

    $val          = htmlspecialchars($val);

    $key_         = $key;

    $result[$key_]              = $val;

  }

$data         = json_encode($result);

$emailer_file = _ADMIN_DIR_ . '/settings-files/emailer-config.txt';

if (@file_put_contents($emailer_file, $data)) 

  {

    die('{"status":"success","result":"Saved successfully"}');

  }

else

  {

    die('{"error":"Could not save."}');

  }

