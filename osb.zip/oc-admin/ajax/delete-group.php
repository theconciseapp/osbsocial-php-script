<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

if (empty($_POST['username'])) 

  {

    die('{"error":"Empty parameter."}');

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanDeleteUser()) 

  {

    die('{"error":"Permission denied."}');

  }

$username = strtolower($_POST['username']);

if ($username == 'gv_pofficials') 

  {

    die('{"error":"This group is an official group."}');

  }

require "../../oc-includes/server.php";

require "../../oc-ajax/group/group-functions.php";


$ajgfile=_ADMIN_DIR_ . "/settings-files/auto-join-groups.txt";

$ajgroups = @file_get_contents( $ajgfile);

if( !empty( $ajgroups) ){

 $regex="/^$username\|.*?\n/mi";

if( preg_match( $regex, $ajgroups)){

 $ajgroups_=preg_replace( $regex, "", $ajgroups);

  if( file_put_contents( $ajgfile, $ajgroups_)===false){
   die('{"error":"Failed to delete. AutoJ"}');
  }
 }
}


$userDir = getGroupDir($username);
if (@deleteTree($userDir) ){

$table = _TABLE_GROUPS_;

$stmt  = $conn->prepare("DELETE FROM $table WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('s', $username) && $stmt->execute()) 

  {

    $stmt->close();
    remove_group($conn, $username);
    $conn->close();
 die('{"status":"success","result":"Deleted successfully."}');

  }
}

$conn->close();

die('{"error":"Failed to delete. Err02"}');
