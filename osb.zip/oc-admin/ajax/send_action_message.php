<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanMessageUser()) 

  {

    die('{"error":"Permission denied."}');

  }

if (empty($_POST['message_to']) || empty($_POST['message'])) 

  {

    die('{"error":"One or more fields are empty."}');

  }

$admin_username = getAdminInfo('username');

$chat_to        = test_input($_POST['message_to']);

$send_as        = "act_act";

$msg            = $_POST['message'];

if (strlen($msg) < 1) 

  {

    die('{"error":"Cannot send empty message."}');

  }

$msg     = htmlspecialchars(trim($_POST['message']) , ENT_QUOTES);

$msg     = preg_replace('#&lt;(/?(?:br))&gt;#', '<\1>', $msg);

$msg     = str_replace(' ', '&nbsp;', $msg);

$preview = mb_substr($msg, 0, 100);

require '../../oc-includes/server.php';

if (is_group_page($chat_to)) 

  {

    //Group message

    require '../../oc-ajax/group/group-functions.php';

    if (customGroupMessage($conn, $chat_to, $preview, $msg, $send_as) === 1) 

      {

        $conn->close();

        die('{"status":"success","result":"Sent successfully."}');

      }

    $conn->close();

    die('{"error":"Not sent."}');

  }

else

  {

    if (inboxUser($conn, $chat_to, $preview, $msg, str_replace("~", "", $send_as))) 

      {

        $conn->close();

        die('{"status":"success","result":"Sent successfully."}');

      }

    else

      {

        $conn->close();

        die('{"error":"Not sent."}');

      }

  }

