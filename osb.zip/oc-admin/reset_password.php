<?php require '../oc-includes/bootstrap.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no,user-scalable=0" />
<meta id="csrf-token" name="csrf-token" content="">
<title>Reset password</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>

</head>
<body>
<div class="container">

<?php if (empty($_GET["token"]) || empty($_GET["email"])) 

  {

    die('<div class="mt-5 alert alert-danger">Invalid parameters.</div>');

  }

$token = test_input($_GET["token"]);

$email = test_input($_GET["email"]);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 

  {

    die('<div class="mt-5 alert alert-danger">Invalid email address or link.</div>');

  }

require '../oc-includes/server.php';

$table_tokens = _TABLE_TOKENS_;

$email        = mysqli_real_escape_string($conn, $email);

$token        = mysqli_real_escape_string($conn, $token);

$time         = time();

$query        = mysqli_query($conn, "SELECT expiry_time FROM $table_tokens WHERE email='$email' AND expiry_time>'$time' AND token='$token' LIMIT 1");

if (mysqli_num_rows($query) < 1) 

  {

    $conn->close();

    die('<div class="mt-5 alert alert-danger">Invalid Link. The link is invalid/expired.</div>');

  }

?>

<div class="form-container mt-5 border" style="margin-top: 80px auto; max-width: 500px; padding: 30px;">

<img src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>" class="d-block" style="margin: 20px auto; height: 60px; width: 60px;">

 <div class="mb-3">
<label class="form-label">Enter New Password</label>
  <input type="text" id="password" maxlength="50" class="form-control" required />
  </div>
 
 <input type="hidden" id="token" value="<?php echo $token; ?>"/>
<input type="hidden" id="email" value="<?php echo $email; ?>"/>
 <button id="reset-password-btn" class="btn btn-sm btn-primary">Reset Password</button>

</div>
</div>

<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>
<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>
</body>
</html>
