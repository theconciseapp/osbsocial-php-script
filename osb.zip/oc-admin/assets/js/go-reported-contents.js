function displayReports( data){
  var d="";

$.each( data,function(i,v){
  var rby=v.report_by;
  var report=v.report;
  var section=v.report_section;
  var id=v.id;
  var rid=v.report_id;
  var rtime=v.report_time;

  d+='<div class="container-fluid go-report-container-' + id + '"><div class="row">';
     d+='<div class="col" style="max-width: 60px;">';
     d+= go_user_icon( rby, 'go-notifications-user-icon' );
     d+='</div>';
     d+='<div class="col"><i>Report By</i> ' + rby;
     d+='<div><strong>' + report + '</strong></div>';
     d+='<div class="go-report-time">' + timeSince( rtime) + ' ago</div>';
     d+='</div>';
     d+='<div class="col go-delete-report text-center" data-id="' + id + '" onclick="goDeleteReport(this);" style="max-width: 60px;">';
     d+='<span class="fa fa-trash fa-lg text-danger"></span>';
     d+='</div>';
     d+='</div>';
     d+='<div>'

  if( section=="post"){
    d+='<button class="btn btn-sm btn-primary" onclick="goOpenSinglePost(this);" data-post-by="" data-pid="' + rid + '">View post</button>';

}
     d+='</div>';
     d+='</div>';
});

return d;

}

var toast_once=false,loadingReports=false; connCounts=0, lpFails=0;

function loadReports(refresh ){
  var pnElem=$('#go-next-report-page-number');
  var pageNum=pnElem.val();
   
  /*
if( loadingReports ){
    return;
  } else
*/
 if( refresh ){
    toast_once=false;
    pageNum="";
    displayData('<div class="text-center" style="padding-top: 30px;"><img class="w-40 h-40" src="file:///android_asset/loading-indicator/loading2.png"></div>', { data_class:'.home_refresh', no_cancel: true});

  }
  
  if( !refresh && pageNum=="0"){
   if( !toast_once ){
     toast_once=true;
     toast('That is all for now.',{type: 'info'});
   }
    return;
   }
  
  loadingReports=true;
 
  var loader=$('#report-loading-indicator');
  loader.css('display','block');
  
  connCounts++;
  
 setTimeout(  function(){
  $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/reported-contents.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "page": pageNum,
    }
  }).done(function(result){
 //alert(JSON.stringify(result));
    connCounts--;
lpFails=0;
      loadingReports=false;  
      loader.css('display','none');
    if( refresh ){
    closeDisplayData('.home_refresh'); 
    }

 if( result.no_post){
   $('#go-reports-column').html( 'No reports yet');
  
  } 
    else  
  if( result.status=='success' ){

    var posts= result.reports;
    var nextPage=result.next_page;
    pnElem.val( nextPage );

 $('#go-reports-column').append(displayReports( posts) );

}
else if( result.no_report){
$('#go-reports-column').html('<div class="text-center"><h2>' + result.no_report + '</h2></div>');
}
   else if(result.error){
      toast(result.error );
  }
   else toast('No more post to load.',{type:'info'});
 
    setTimeout( function(){
      $('#go-initializing-container').css('display','none');
    },1000);
    
 }).fail(function(e,txt,xhr){
  //alert(JSON.stringify(e));

   loadingReports=false;
    connCounts--;
  //  loader.css('display','none');
  if(!lpFails) toast('Check your connection. ' + xhr, {type:'light',color:'#333'});
 
lpFails=1;
    if( refresh ){
     closeDisplayData('.home_refresh');
    return;
    }
    
    setTimeout(function(){
       loadReports(); },6000);
  });
    
  },1000);
}
  

//SEARCH REPORTS

var toast_s_once=false,searchingReports=false,spTimeout,spAjax;

function searchReports( fresh){
 var pnElem=$('#go-next-search-report-page-number');
  
var searchDiv=$('#go-searched-report-posts');
  
  if( fresh){
    toast_s_once=false;
    pnElem.val("");
    searchDiv.empty();
  }
  
  var pageNum=pnElem.val();
 
 // if( searchingReports ) return;
  
  if(!fresh && pageNum=="0"){
   if( !toast_s_once){
     toast_s_once=true;
     toast('That is all for now.',{type: 'info'});
   } 
    return;
  }
    
  var s=$('#go-search-box');
  var text=$.trim( s.val());
  
  if(!text ||text.length<3){
  return toast('Search term too small.',{ type:'info'});
  }
    
  searchingReports=true
var loader=$('#search-loading-indicator');
  loader.css('display','block');
  
  connCounts++;

  $('#go-search-report-container').css('display','block');


spTimeout=setTimeout( function(){  
    spAjax=$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/search-reports.php',
    type:'POST',
   timeout: 10000,
    dataType: "json",
    data: {
      "s": text,
      "page": pageNum,
    }
  }).done(function(result){
   //alert(JSON.stringify(result)) 
      connCounts--;
      searchingReports=false;
      loader.css('display','none');
  
  if( result.no_post ){
   return toast( result.no_report,{type:'info'});
  }
 else if( result.status=='success' ){
   var nextPage=result.next_page;
   pnElem.val( nextPage);
   
  var posts= result.reports;
    searchDiv.append( displayReports( posts) );            
  }
   else if(result.error){
      toast(result.error );
  }
   else toast('No more reports.',{type:'info'});
      
 
 }).fail(function(e,txt,xhr){
 //alert(JSON.stringify(e))

      connCounts--;
      searchingReports=false;
      loader.css('display','none');
  //toast('Connection error. ' + xhr, {type:'light',color:'#333'});
     spTimeout=setTimeout(function(){
     searchReports(); },6000);
  });
  },1000); 

}
 



/*DELETE POST*/

function goDeleteReport(t){
if( !confirm('Delete?') ) return;
 var this_=$(t);
var id=this_.data('id');

 if(!id){
   return  toast('Id not found.');
  }
 setTimeout( function(){
   
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/delete-report.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "id": id,
    }
  }).done(function(result){
   //alert(JSON.stringify(result))
      
  if( result.status=='success'){
   $('.go-report-container-' + id).remove();
 }
  else if(result.error){
      toast( result.error );
  }
   else toast('Unknown error'); 
 }).fail(function(e,txt,xhr){
 // alert(JSON.stringify(e))
  toast('Failed. ' + xhr);
   });
  },1000); 
  
  
}


//OPEN SEARCH BOX

         
function goOpenSearchReportBox(){
    $('#go-search-report-container').css('display','block');
    $('#go-posts-column').css('display','none');

  }

function goCloseSearchReport(){

  $('#go-posts-column').css('display','block');
  $('#go-search-report-container').css('display','none');
  $('#go-searched-report-posts').empty();
  clearTimeout(spTimeout);
  if(spAjax) spAjax.abort();
}



$(function(){

$('#go-reports-column').on('scroll', function() {
   var scr=$(this).scrollTop() + $(this).innerHeight();
   if(!loadingReports && scr >=  $(this)[0].scrollHeight-400) {
loadingReports=true;
     loadReports();
    }
  });

$('#go-search-report-contents').on('scroll', function() {
   var scr=$(this).scrollTop() +
 $(this).innerHeight();
   if(!searchingReports && scr >=  $(this)[0].scrollHeight - 400) {
searchingReports=true;
    searchReports(); }
  });


});








