var GO_COMMENT_UPLOAD_FILE_PATHS=[]; 
var GO_COMMENT_UPLOADED_FILE_PATHS=[];


var sendBtn=$('#send-message-btn');
var voiceBtn= $('#voice-message-btn');
var attachBtn= $('#attachment-btn-container');

var fetchingComment=false;
var commentAjax;
var commentTimeout=0;

function commentAuthorPicture(fuser,class_,verified){
  class_=class_||'friend-picture';
  var real_path=_USERS_PATH_ + '/' + strtolower( fuser[0]+'/' + fuser[1] + '/' + fuser[2] + '/' + fuser ) + '/profile_picture_small.jpg';
  var local_path='file:///android_asset/chat-icons/no_profile_picture.jpg';
 return '<img class="lazy ' + class_ + '" alt="" onerror="imgError(this);" src="' + local_path + '" data-src="' + real_path + '" data-verified="' + (verified?'1':'') + '" data-id="' + strtolower(fuser ) + '">';
}

function imgError(image) {
  var src="file:///android_asset/chat-icons/no_profile_picture.png";
    image.src = src;
}


 
function goOpenCommentsBox(t){
 
  var this_=$(t);
  var pid= this_.data('pid');
  var post_by= $.trim( this_.data('post-by') );
 if(!post_by){
   return toast('Post author not found.');
 }
  
  if( pid.length<1 ) return toast('Post id not found.');
  
  var highlight=this_.attr('data-highlight')||"";
  highlight=highlight.replace(/(\s|\?r|\?b|\?g|\?lg|\?sm|`|-|\*|\~|_|\|)/g,' ');
  
  $('#post-comment-title').text(highlight);
  var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val() );
      cpi.val( pid);
  $('#current-post-by').val(post_by);

 var ccont= $('#go-comment-container')
 var mccont= $('#my-comments-container')
  
 var pc=$('#post-comments');  
  
 if(cpiv!=pid){ 
  $('#prev-comments').css('display','none');
   mccont.empty();
   pc.empty();
 if(commentAjax) commentAjax.abort();
   clearTimeout( commentTimeout);
  fetch_comments(  pid);
 }
   ccont.css('display','block'); 
}
  


function refreshComment(){

  if( fetchingComment){
   return toast('Please be patient.',{type:'info'});
 }   
  $('#my-comments-container,#post-comments').empty();
   $('#prev-comments,#next-comments').css('display','none');
   fetch_comments("");   
 }
  

$(function(){



$('body').on('click','#prev-comments',function(){
 if( fetchingComment){
   return toast('Please be patient.',{type:'light',color:'#333'});
 }
  var page=$(this).attr('data-value');
  if(!page) return toast('No more comments.',{type:'light',color:'#333'});
 //$('#my-comments-container,#post-comments').empty(); 
   fetch_comments("", page);   
 });
  
  
$('body').on('click','.delete-comment',function(){
  var this_=$(this);
  var cid=this_.attr('data-cid');
  var post_id=this_.attr('data-pid');
  if(!confirm('Delete selected comment?') ) return false;

 if(!cid){
    return toast('Comment id not found.');
  }
 
 var tb=$('#go-comment-box');
     tb.prop('disabled', true); 
      
//    $('#post-comment-sending-cont').append('<span id="comment-sending-icon"><img class="w-20 h-20" src="file:///android_asset/loading-indicator/loading2.png"></span>');

  var loader=$('#comment-loader-container');
  loader.css('display','block');
 
  setTimeout(function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/delete-comment.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "comment_id": cid,
      "post_id": post_id
    }
  }).done(function(result){
   // alert(JSON.stringify(result))
   $('#comment-sending-icon').remove();
   tb.prop('disabled', false); 
  if( result.status){
   $('#post-comments-container #ccc-' + cid).remove();
  }
   else if(result.error){
      toast(result.error );
  }
   else toast('Unknown error');
    loader.css('display','none');
 }).fail( function(e,txt,xhr){
   loader.css('display','none');
  $('#comment-sending-icon').remove();
  toast('Could not delete. ' + xhr);
  tb.prop('disabled', false);  
  });
    
  },1000);
});
  
});



function fetch_comments( post_id,page_number){
  var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val() );
   post_id=cpiv||post_id;
  page_number=page_number?'?page=' + page_number:'';
    
  var tb=$('#go-comment-box');
      tb.prop('disabled', true);
 
  var loader=$('#comment-loader-container');
  loader.css('display','block');
  $('#prev-comments, #next-comments').prop('disabled',true);
    
  fetchingComment=true;
  //var containerId=randomString(5);
   commentTimeout=setTimeout(function(){
     
  commentAjax=$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/fetch_comments.php' + page_number,
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "post_id": post_id,
    }
  }).done(function( result){
  if( cpi.val()!=cpiv) return;
    fetchingComment=false;
    $('#prev-comments, #next-comments').prop('disabled',false)
 //alert(JSON.stringify(result))
    var nextPage=result.next_page;
    var prevPage=result.prev_page;
    
  if(result.no_comment){
    
  $('#post-comments').html('<div class="text-center no-comment-container" id="no-comment-cont-' + post_id + '">No Comment Yet</div>');
  }
 else if( result.result){
    var rdata=result.result;
    var ipp=+result.item_per_page;
    var total=rdata.length;
 
  $.each( rdata, function(i,v){
    try{
    var following=v["me_following"];
  
  if( following!="0"){
    var cid= v["id"];
    var likes=v["likes"];
    //var fullname=v["fullname"];
    var cauthor=v["comment_author"];
    var comment=v["message"];
   var post_files=v["post_files"]||"";

    var meta=JSON.parse( v["meta"]||"[]" );
       meta["post_id"]=post_id;
  var liked=false;
    display_comment('prepend', cid, comment,post_files, meta, cauthor,false, nextPage,likes,liked );
  }    
 }catch(e){
    toast(e); 
}
  });
    
    
    $('#next-comments,#prev-comments').css('display','none');
 if( prevPage ){
   // $('#next-comments').attr('data-value', prevPage).css('display','block');  
 }
  if( nextPage ){
    $('#prev-comments').attr('data-value', nextPage).css('display','block');
 }
   
  }
   else if(result.error){
    toast(result.error,{type:'light',color:'#333'});  
  }
    loader.css('display','none');
    tb.prop('disabled', false);
   // sendBtn.prop('disabled', false)
  }).fail(function(e,txt,xhr){
    fetchingComment=false;
    $('#prev-comments,#next-comments').prop('disabled',false)
    loader.css('display','none');
    toast('Check network. ' + xhr);

    tb.prop('disabled', false);
  });
   },1500);  
}



function display_comment( type, cid, comment, post_files, meta, author_, me, paging,likes,liked){
   type=type||'append';
   
 if(me){   
   var mccont= $('#my-comments-container');
 }
else{
  var mccont=$('#post-comments');
}
 
  var has_files=meta.has_files||"";
  var post_id= meta.post_id||"";
  var fullname=meta.fullname||"";
  var v=checkVerified( author_, fullname);
  var icon=v.icon;
  var author= v.name;
  var ctime=meta.time||moment().unix();
  
  var cdate=timeSince( ctime ,'comment_date');
  comment=comment.replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/(:nl::){3,}/g,':nl:::nl::')
    .replace(/:nl::/g,'<br>')

  var isMe=false;
 
 var data='<div class="comment-child-container ' + (isMe?'my-comment-container':'') + '" id="ccc-' + cid + '">';
  data+='<div class="' + ( isMe?'text-right':'') + '">';
 data+='<span class="d-inline-block go-comment-author-icon-container" style="margin-right: 5px;">' + commentAuthorPicture( author_ ,'go-comment-author-icon go-enlarge-user-icon nosave' ) + '</span>';
 data+='<div class="comment-bubble" id="' + cid + '">';
 data+='<span class="highlight comment-author go-open-user-profile friend-' + author_ + '" data-fname="' + author + '" data-type="friend" data-friend="' + author_ + '">' + strtolower( fullname).replace('vf_','') + '</span> ' + icon ;
 data+='<span class="d-none friend-name-' + author_ + '">' + author + '</span>';
  
  
data+='<div class="comment-message">' + comment + '</div>';
  
 data+='<div class="go-comment-files-container">';
   
 data+= go_formatFiles( post_files, has_files, false, true);
  
  data+='</div>';
  data+='</div></div>';
 
  data+='<div class="comment-footer">';
 
   data+='<span class="delete-comment" id="delc-' + cid + '" data-pid="'+ post_id + '" data-cid="' + cid + '"><span class="fa fa-trash fa-lg"></span></span>';

  likes=likes||0
  data+='<span class="comment-date">' + cdate + '</span>';
  data+='<span class="like-comment" id="like-comment-' + cid + '" data-cid="' + cid + '" data-total-likes="' + likes + '" onclick="like_comment(this);">';
 if(author_) data+=' <span class="fa fa-thumbs-up fa-lg text-secondary"></span><span class="likes" id="likes-' + cid + '">' + abbrNum( +likes,1 ) + '</span></span>';
  
  data+='</div>';
  data+='</div>';
  if( type=='append'){
  mccont.append(data)
  } else{
  mccont.prepend(data);
  }
}

function format_comment(gpin, post_id,com_files,clen){
 var currentTime=moment().unix();
   var obj_=new Object();
  obj_.pid="" +  post_id;
  obj_.cf="" +   username;
  obj_.fullname=userData('fullname');
  obj_.com_files="" + com_files; //video, image
  obj_.has_files="" + (com_files?1:0);
  obj_.size="" + clen; //txt size or file size 
  obj_.time="" + currentTime;
  obj_.ver="" + config_.APP_VERSION;

  return obj_;
  }



function add_comment( fuser, comment, mlen){
   var fpaths=GO_COMMENT_UPLOADED_FILE_PATHS;
   var fpaths_="";
   var com_files="";
   var total_files=fpaths.length;
   var hasFiles=0;
  
  if( total_files){
    fpaths_=fpaths.toString();
   $.each( fpaths,function(i,v){
    com_files+='[file=::' + v + '::]';
   });
   hasFiles=1;
  }
 
   if( mlen>2){
    return toast('Comment too long.');  
  }
  var rcid=randomString(5);
  
  var comment=sanitizeMessage( comment );
  
  var tb=$('#go-comment-box');
      tb.prop('disabled', true);
   
  var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val());
  var post_by= $.trim( $('#current-post-by').val() )
  
  if( !$('#post-comment-sending-cont #comment-sending-icon').length){
    $('#post-comment-sending-cont').append('<span id="comment-sending-icon"><img class="w-20 h-20" src="file:///android_asset/loading-indicator/loading2.png"></span>');
  }
  
 var sb=$('#post-comments-container');
     sb.scrollTop( sb.prop("scrollHeight") );
 
  var meta=format_comment(fuser, cpiv,com_files,mlen);
 
  display_comment('append', rcid, comment, meta, "ADMIN", true);
  
 var cdiv=$('#my-comments-container #ccc-' + rcid);
 var delBtn= $('#my-comments-container #delc-' + rcid);
 var likeBtnCont=$('#my-comments-container #like-comment-' + rcid);
 var likeBtn=$('#my-comments-container #like-img-' + rcid);
 
  delBtn.css('display','none');
  likeBtnCont.css('display','none');
  
  
     meta=JSON.stringify( meta);
 var btn= $('#go-send-comment-btn');
    btn.prop('disabled',true);

 
  setTimeout(function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/add_comment.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "message": comment,
      "meta": meta,
      "has_files": hasFiles,
      "post_id": cpiv,
      "post_by": post_by,
     
    }
  }).done(function(result){
   // alert(JSON.stringify(result) );
  $('#comment-sending-icon').remove();
   btn.prop('disabled', false);
   tb.prop('disabled', false);
 if( result.status=='success'){
   sessionStorage.removeItem('temp-com-text-' + fuser);
   GO_COMMENT_UPLOADED_FILE_PATHS=[];
   $('#go-comment-upload-preview-container').empty()
   $('#post-comments #no-comment-cont-' + cpiv).remove();
   var id= result.result;
 
if(id){
  
  delBtn.attr('data-cid', id).attr('data-pid', cpiv).css('display','inline-block');
  cdiv.attr('id', 'ccc-' + id);
  $('#likes-' + rcid).attr('id','likes-' + id);
  likeBtnCont.attr('data-cid',id).css('display','inline-block');
  likeBtn.attr('id','like-img-' + id);
  
}
   tb.val('');
   tb.autoHeight();
  return;
 }else if(result.error){
    toast( result.error);
   $('#post-comments-container #ccc-' + rcid ).remove();
 }

 }).fail(function(e,txt,xhr){
    $('#comment-sending-icon, #post-comments-container #ccc-' + rcid ).remove();
   toast('Not sent. ' + xhr);
    tb.prop('disabled', false);
   btn.prop('disabled', false);
  });
    
  },1000);
}



function goCloseComment(){
   $('#go-comment-container').css('display','none'); 
}




$(function(){
  
  $('body').on('click','#go-send-comment-btn',function(e){ 
     var textBox=$('#go-comment-box'); 
 var msg=$.trim( textBox.val() );
 var fuser=""
 var mlen=( msg.length+1)/1024;
     
  var this_=  $(this);
     
 if( GO_COMMENT_UPLOAD_FILE_PATHS.length>0 ){
    this_.prop('disabled',true);
  return goCommentUploadFiles();
 }
   
 if( GO_COMMENT_UPLOADED_FILE_PATHS.length<1 && !msg){
    
   return toast('Post still empty.');
   }
   this_.prop('disabled',true);
    add_comment(fuser, msg, mlen );
 });
   
 
  
  //PHOTO FULL- COMMENT AUTHOR
 
 
$('body').on('click','.go-enlarge-user-icon', function(){
   var this_=$(this);
  var img= this_.attr('src');
   if(!img) return;
   var img   = img.replace('_small.jpg','_full.jpg');
$('#go-full-photo-child-container').html('<img class="lazy go-full-photo" data-src="' + img + '">');
 $('#go-full-photo-container').css('display','block');


  });
  
});

    
    
