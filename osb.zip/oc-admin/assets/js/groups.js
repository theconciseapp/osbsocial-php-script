$(function(){

$('body').on('click','.group-info', function(){

var this_=$(this);
var user=this_.data('username');
 if(!user){
  alert('User not found.');
 return;
}

 var ui=$('.group-info');
  buttonSpinner(this_);
  ui.prop('disabled',true);
$.ajax({
url: _ADMIN_URL_ + '/ajax/group-info.php',
type:'POST',
dataType:'json',
data: {
  username: user,
},

}).done(function(result){
 
 buttonSpinner( this_,true);
  ui.prop('disabled', false);
 //alert( JSON.stringify(result))

 if(result.username){
 var fuser=result.username;
 var fullname=result.fullname;
 var info=result.group_info;
 var gadmins=result.group_admins;
 var auto_join=+result.auto_join;
 var total_members=result.total_members;
 var lastseen=result.lastseen;

var data='<div class="mb-2"><label class="form-label">Group title</label><input type="text" class="form-control" id="ugtitle" value="' + fullname + '"></div>';

data+='<div class="mb-2"><label class="form-label">Group desc.</label><textarea class="form-control" id="uginfo">' + info + '</textarea></div>';

data+='<div class="mb-2"><label class="form-label">Group admins</label><div class="form-text">Group or page admin must be an existing user. Separate multiple admins with comma.</div><input type="text" id="ugadmins" class="form-control" value="' + gadmins + '"></div>';


data+='<div class="mb-2"><label class="form-label">Total members</label><input type="text" class="form-control" value="' + total_members + '" id="utotal-members"></div>';

data+='<div class="mb-2"><label class="form-label">Last seen</label><input type="text" class="form-control" value="' + lastseen + '" readonly></div>';

if( isPage(fuser) ){

data+='<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="uauto-join" name="uauto_join"' + ( auto_join==1?' checked="checked"':'') + '> <label class="custom-control-label" for="auto-join">Auto join/follow</label><div class="form-text">If you select auto join/follow, all users will automatically join or follow the group/page</div></div>';

}

data+='<div class="mb-2"><button class="btn btn-sm btn-primary" id="update-group-btn">Save</button><input type="hidden" id="ugpin" value="' + fuser + '"></div>';


 displayData( data,{ id:'showing-user-info', htitle: '<i class="fa fa-user text-secondary"></i> Group Pin: <b>' + ucfirst( fuser.replace('gp_','').toUpperCase() ) + '</b>'});

}else if(result.error){
  toast(result.error);
}
else{
  toast('Unknown error occured.');
  }

}).fail(function(e, txt, xhr ){
  buttonSpinner( this_, true);
  ui.prop('disabled', false)

toast('Check your network connection. ' + xhr);
  });


});



$('body').on('click','.delete-group',function(){
var this_=$(this);
var fullname=this_.parent().parent().find('.user-fullname-text').text();

if(!confirm('Delete group: ' + fullname + '\'s?\n\nThis action is irreversible.')) return;
 
var el=$('.delete-group');
 el.prop('disabled',true);
 buttonSpinner(this_);

 setTimeout(function(){
 var user=this_.data('username');
$.ajax({
url: 'ajax/delete-group.php',
type:'POST',
dataType:'json',
data: {username: user}
}).done(function(result){

el.prop('disabled', false);
buttonSpinner( this_,true);

 if(result.status ){
  this_.closest('.user-panel').remove();
 }else if(result.error){
   toast(result.error);
 }
else{
  toast('Failed to delete');
  }
}).fail(function(e,txt,xhr){
 el.prop('disabled', false)
 buttonSpinner(this_,true);
 toast('Check your internet connection. ' + xhr);
});
},1000);

});



$('body').on('change','#group-setting',function(e){
 var this_=$(this);
var data=$.trim(this_.val());
$('#selected-group-setting').text(data);
 
 var info='Limited members &bull;';
$("#auto-follow-option").addClass("d-none");

if ( data=='GV_P'){
   info='Unlimited followers &bull;';
 $("#auto-follow-option").removeClass("d-none");
}

$('#group-setting-info').html( info); 
});


$('body').on('click','#create-group-btn', function(){
var this_=$(this);
var gadmins= $.trim($('#group-admins').val());
var gsetting=$.trim( $('#group-setting').val() );
var gpin=$.trim( $('#group-pin').val() );
var gtitle= $.trim($('#group-title').val());
var ginfo= $.trim($('#group-info').val() );
var auto_join=$("#auto-join").prop("checked")?1:0;

buttonSpinner(this_);
  this_.prop('disabled',true);

$.ajax({
url: _ADMIN_URL_ + '/ajax/create-group.php',
type:'POST',
dataType:'json',
data: {
 'group_admins': gadmins,
 'group_setting': gsetting,
 'group_pin': gpin,
 'group_title': gtitle,
 'group_info': ginfo,
 'auto_join': auto_join,
}
}).done(function(result){
  buttonSpinner( this_,true);
  this_.prop('disabled', false);
  //alert( JSON.stringify(result))

 if(result.status){

$('#group-admins, #group-pin,#group-title,#group-info').val("");

  toast( result.result, {type:'success'});

}else if(result.error){
  toast(result.error);
}
else{
  toast('Unknown error occured.');
  }

}).fail(function(e, txt, xhr ){
  buttonSpinner( this_, true);
  this_.prop('disabled', false)

toast('Check your network connection. ' + xhr);
  });

});

$('body').on('click','#update-group-btn', function(){

var this_=$(this);
var ugadmins= $.trim($('#ugadmins').val() );
var ugtitle= $.trim($('#ugtitle').val());
var uginfo= $.trim($('#uginfo').val() ); 
var ugpin= $.trim($('#ugpin').val() );
var utotalm= $.trim($('#utotal-members').val() );

 var auto_join=( isPage( ugpin) && $("#uauto-join").prop("checked") )?1:0;

buttonSpinner(this_);
  this_.prop('disabled',true);

$.ajax({
url: _ADMIN_URL_ + '/ajax/update-group-info.php',
type:'POST',
dataType:'json',
data: {
'group_pin': ugpin,
 'group_admins': ugadmins,
 'group_title': ugtitle,
 'group_info': uginfo,
 'total_members': utotalm,
 'auto_join': auto_join,
}
}).done(function(result){
  buttonSpinner( this_,true);
  this_.prop('disabled', false);
  //alert( JSON.stringify(result))

 if(result.status){
  toast( result.result, {type:'success'});

}else if(result.error){
  toast(result.error);
}
else{
  toast('Unknown error occured.');
  }

}).fail(function(e, txt, xhr ){
  buttonSpinner( this_, true);
  this_.prop('disabled', false)

toast('Check your network connection. ' + xhr);
  });

});


});
