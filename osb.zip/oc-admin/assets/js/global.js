var lastTop;

function toggleSidebar(){
	var sbar=$('.side-bar-container');
    var mcont=$('.main-content-container');

  var oWidth_=+sbar.attr("data-width");
  var oWidth=oWidth_||sbar.width();
  
  if( !oWidth_) {
   sbar.attr("data-width", oWidth);
 }
  
  if( !sbar.hasClass("hide-left-sidebar") ){
	 sbar.animate({
            width: 0
        }, 100,function(){
   sbar.css({"width": oWidth,"display":"none"});
   sbar.addClass("hide-left-sidebar");
   sbar.css("display","");
});
 $(".main-content-shadow").fadeOut(100);
  }else{
    sbar.removeClass("hide-left-sidebar").css({"width":0, "display":"inline-block"});
        
     sbar.animate({
        width: oWidth
     }, 100 );

     $(".main-content-shadow").fadeIn(200);
}
	}



function toggleSidebarx(){
	var sbar=$('.side-bar-container');

	if( !sbar.hasClass("hide-sidebar") ){
	 sbar.animate({
            width: 0
        }, 100,function(){
  sbar.addClass("hide-sidebar");
});
	
		}else{
  var oWidth_=+sbar.attr("data-width");
		var oWidth=oWidth_||sbar.width()||230;
  
  if( !oWidth_) {
   sbar.attr("data-width", oWidth);
 }
	
sbar.removeClass("hide-sidebar");
	sbar.css({"width":0, "display":"inline-block"})


		sbar.animate({
            width: oWidth
        }, 300 );
}
	}


function randomNumber(len,charSet) {
    charSet = charSet || '023456789';
    var randomString='';
    for (var i=0; i<len;i++) {
        var randomPoz=Math.floor(Math.random()*charSet.length);
        randomString+=charSet.substring(randomPoz,randomPoz+1);
    }
    return randomString;
}

function randomString(len,charSet) {
    charSet = charSet || 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    var randomString='a';
    for (var i=0; i<(len-1);i++) {
        var randomPoz=Math.floor(Math.random()*charSet.length);
        randomString+=charSet.substring(randomPoz,randomPoz+1);
    }
    return randomString;
}


function parseJson( string_){
  try{
    return JSON.parse( string_);
  } catch(e){
   return {};
  }
}

function ucfirst(str) {
    return str.replace(/([a-z])/, function (match, value) {
        return value.toUpperCase();
    })
}

function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}


function startsWith(str, word) {
    return ("" +str).lastIndexOf(word, 0) === 0;
}

function checkVerified(fuser, name){
  name=name||fuser;
 var obj=new Object();
     obj.name=name;
     obj.icon='';
 if( userVerified( fuser) ){
   obj.icon='<span style="color: gold;" class="fa fa-check-circle"></span>';
   }
    
 return obj;
}


function userVerified( pin ){
  return pin.indexOf('v_')!== -1;
}

function isPage(gpin ){
 var str=strtolower( gpin ).substr(0, 4);
 return $.inArray( str, ['gu_p','gv_p'] )>-1;
}

function isGroup( gpin){
 var str=strtolower( gpin).substr(0,4);
 return $.inArray( str, ['gu_g', 'gv_g'] )>-1;
}

function isGroupPage( gpin){
  var str=strtolower( gpin).substr(0,4);
 return $.inArray( str, ['gu_g','gu_p','gv_p','gv_g'] )>-1;
}

function goPage( pin){
  var str=strtolower( pin).substr(0,3);
 return $.inArray( str, ['pv_','cv_','sv_'] )>-1;
}

function goStaticPage( fuser){
  var str=strtolower( fuser).substring(0,3);
 return $.inArray( str, ["sv_","cv_"] )>-1;

}

function goAdmin( pin){
  var str=strtolower( pin).substr(0,3);
 return str=='av_'?true: false;
}


function imageScale(imgW,imgH,maxW,maxH){
    return(Math.min((maxW/imgW),(maxH/imgH,1)));
}


function friendProfilePicture(fuser,class_,verified){
  class_=class_||'friend-picture';
 
  var real_path= _USERS_PATH_ + '/' + strtolower( fuser[0]+'/' + fuser[1] + '/' + fuser[2] + '/' + fuser ) + '/profile_picture_small.jpg';

 return '<img class="lazy ' + class_ + ' enlarge-user-icon" onerror="imgError(this,\'' + fuser + '\');" src="' + real_path + '" data-sr="' + real_path + '" data-verified="' + (verified?'1':'') + '" data-id="' + strtolower(fuser ) + '">';

}




function strtolower(data){
 return data.toString().toLowerCase();
 
}

function strtoupper(data){
  return data.toString().toUpperCase();
}


function validPassword(password){
  if(!password) return false;
  else if(password.match(/^[a-zA-Z0-9~@#%_+*?-]+$/) ) return true;
  else return false;
}

function validName(fullname){
 if(!fullname) return false;
else if(fullname.match(/^[a-zàáèöïÿŕëäśĺžźżçćčñńôêėřûîéìíòóùú]([.'-]?[0-9a-z àáèöïÿŕëäśĺžźżçćčñńôêėřûîéìíòóùú]+)*$/i) )return true;
else return false;
}

function validUsername(username){
 if(!username) return false;
else if (username.match(/^([a-z]+)_?[a-z0-9]{3,29}$/i) ) return true;
else return false;
}





const htmlFormat =[
    { symbol: '*',   tag: 'strong',     regex: '(?:\\*)(?:(?! ))((?:(?!<br>|\\*).)+)(?:\\*)' },
    { symbol: '_',   tag: 'em',    regex: '(?:_)(?:(?! ))((?:(?!<br>|_).)+)(?:_)' },
    { symbol: '~',   tag: 's',     regex: '(?:~)(?:(?! ))((?:(?!<br>|~).)+)(?:~)' },
    { symbol: '```', tag: 'tt',    regex: '(?:```)(?:(?! ))((?:(?!<br>|```).)+)(?:```)' },
    { symbol: '--',  tag: 'u',     regex: '(?:--)(?:(?! ))((?:(?!<br>|--).)+)(?:--)' },
    { symbol: '^',   tag: 'code',  regex: '(?:\\^)(?:(?! ))([^\^]+)(?:\\^)' },
    { symbol: '?r',  tag: 're',    regex: '(?:\\?r)(?:(?! ))((?:(?!<br>|\\?r).)+)(?:\\?r)' },
    { symbol: '?b',  tag: 'bl',    regex: '(?:\\?b)(?:(?! ))((?:(?!<br>|\\?b).)+)(?:\\?b)' },
    { symbol: '?g',  tag: 'gr',    regex: '(?:\\?g)(?:(?! ))((?:(?!<br>|\\?g).)+)(?:\\?g)' },
    { symbol: '?sm', tag: 'small', regex: '(?:\\?sm)(?:(?! ))((?:(?!<br>|\\?sm).)+)(?:\\?sm)' },
    { symbol: '?lg', tag: 'big',   regex: '(?:\\?lg)(?:(?! ))((?:(?!<br>|\\?lg).)+)(?:\\?lg)' }
  ]


function parsemd__(string, show_symbol){
 
var obj={}
 string=string.replace(/(\b(https?|ftps?|mailto):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.]*[-A-Z0-9+&@#\/%=~_|;])/gi, function(m){
    var lid=randomString(15);
      obj[lid]=m.toString();
   return lid;
 })
  
 $.each( htmlFormat,function(i,v){
  var symbol=v.symbol;
  var tag= v.tag;
  var reg= v.regex;
  if( show_symbol && tag=='code'){
    tag="plaincode";
  }
 // const regex = new RegExp(`\\${symbol}([^${symbol}]*)\\${symbol}`, 'g');
   const regex=new RegExp( reg, "g");
   const match = string.match(regex);
   
   if(!match ) return;
  if( tag!='code' && tag!='plaincode' && match.toString().match(/(<br>|\n)/) ) return;
  
  match.forEach(m => {
        let formatted = m;
        for(let i=0; i<2; i++){
            formatted = formatted.replace(symbol, `<${i > 0 ? '/' : ''}${tag}>`);
        }
        string = string.replace(m, (show_symbol?'<span class="text-format-symbol">' + symbol + '</span>':'') + formatted + ( show_symbol?'<span class="text-format-symbol">' + symbol + '</span>':'') );
    });
 });

 $.each(obj, function( lid, link){
   string=string.replace( lid,'<a href="' + link + '">' + link + '</a>');  
 })
   
return string;  
}



function bbCode(text, show_symbol){
  var string = parsemd__( text, show_symbol );

 string= string.replace(/\B@([\w-]+)/gi, '<span class="post-chat-user" data-fuser="$1">$1</span>')
     .replace(/\[\[([\w-]+)\]\]/g,'<span class="join-group-btn-2" data-gpin="$1">+ $1</span>')
 
  return string;
}


function bbCod(text){
   return text
   .replace(/(?:\*)(?:(?!\s))((?:(?!<br>|\*).)+)(?:\*)/g,'<b>$1</b>')
    .replace(/(?:_)(?:(?!\s))((?:(?!<br>|_).)+)(?:_)/g,'<i>$1</i>')
    .replace(/(?:~)(?:(?!\s))((?:(?!<br>|~).)+)(?:~)/g,'<s>$1</s>')
    .replace(/(?:--)(?:(?!\s))((?:(?!<br>|--).)+)(?:--)/g,'<u>$1</u>')
    .replace(/(?:```)(?:(?!\s))((?:(?!<br>|```).)+)(?:```)/g,'<tt>$1</tt>')
    
    .replace(/(\b(https?|ftps?|mailto|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi,'<a href="$1">$1</a>')
     
     .replace(/(?:\?r)(?:(?!\s))((?:(?!<br>|\?r).)+)(?:\?r)/g,'<re>$1</re>')
     .replace(/(?:\?g)(?:(?!\s))((?:(?!<br>|\?g).)+)(?:\?g)/g,'<gr>$1</gr>')
     .replace(/(?:\?b)(?:(?!\s))((?:(?!<br>|\?b).)+)(?:\?b)/g,'<bl>$1</bl>')
     .replace(/(?:\?lg)(?:(?!\s))((?:(?!<br>|\?lg).)+)(?:\?lg)/g,'<h3>$1</h3>')
     .replace(/(?:\?sm)(?:(?!\s))((?:(?!<br>|\?sm).)+)(?:\?sm)/g,'<small>$1</small>')
     .replace(/\[\[([\w-]+)\]\]/gi,'<span class="join-group-btn-2" data-gpin="$1">+ $1</span>')
     .replace(/\B@([\w-]+)/gi,'<span class="post-chat-user" data-fuser="$1">$1</span>')
.replace(/\[code\]([\s\S]*?)\[\/code\]/g,'<code class="go-post-code">$1</code>')
     

 }

function buttonSpinner(node,done,custom_id){

  node.find('.button-spinner').remove();
if(done ) return;

node.append('<span class="fa fa-lg fa-spinner fa-spin button-spinner" id="' + (custom_id||"") + '"></span>');
}



function timeSince( date) {
  date=new Date( +date * 1000);
  var seconds = Math.floor( ( new Date() - date) / 1000);

  var interval = seconds / 31536000;

  if (interval > 1) {
    return Math.floor(interval) + "y";
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + "mo";
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + "d";
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + "h";
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + "m";
  }
 
 return "Just now";
 // return Math.floor(seconds) + " seconds";
}


function readableFileSize(bytes, si=false, dp=1) {
  const thresh = si ? 1000 : 1024;

  if (Math.abs(bytes) < thresh) {
    return bytes.toFixed(dp) + ' B';
  }

  const units = si 
    ? ['kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'] 
    : ['KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'];
  let u = -1;
  const r = 10**dp;

  do {
    bytes /= thresh;
    ++u;
  } while (Math.round(Math.abs(bytes) * r) / r >= thresh && u < units.length - 1);


  return bytes.toFixed(dp) + ' ' + units[u];
}

function abbrNum(number, decPlaces) {
    // 2 decimal places => 100, 3 => 1000, etc
    decPlaces = Math.pow(10,decPlaces);

    // Enumerate number abbreviations
    var abbrev = [ "K", "M", "B", "T" ];

    // Go through the array backwards, so we do the largest first
    for (var i=abbrev.length-1; i>=0; i--) {

        // Convert array index to "1000", "1000000", etc
        var size = Math.pow(10,(i+1)*3);

        // If the number is bigger or equal do the abbreviation
        if(size <= number) {
             // Here, we multiply by decPlaces, round, and then divide by decPlaces.
             // This gives us nice rounding to a particular decimal place.
             number = Math.round(number*decPlaces/size)/decPlaces;

             // Handle special case where we round up to the next abbreviation
             if((number == 1000) && (i < abbrev.length - 1)) {
                 number = 1;
                 i++;
             }

             // Add the letter for the abbreviation
             number += abbrev[i];

             // We are done... stop
             break;
        }
    }

    return number;
}


function getAverageRGB(imgEl) {

    var blockSize = 5, // only visit every 5 pixels
        defaultRGB = "rgba(0,0,0);", // for non-supporting envs
        canvas = document.createElement('canvas'),
        context = canvas.getContext && canvas.getContext('2d'),
        data, width, height,
        i = -4,
        length,
        rgb = {r:0,g:0,b:0},
        count = 0;

    if (!context) {
        return defaultRGB;
    }

    height = canvas.height = imgEl.naturalHeight || imgEl.offsetHeight || imgEl.height;
    width = canvas.width = imgEl.naturalWidth || imgEl.offsetWidth || imgEl.width;

    context.drawImage(imgEl, 0, 0);

    try {
        data = context.getImageData(0, 0, width, height);
    } catch(e) {
        /* security error, img on diff domain */
        return defaultRGB;
    }

    length = data.data.length;

    while ( (i += blockSize * 4) < length ) {
        ++count;
        rgb.r += data.data[i];
        rgb.g += data.data[i+1];
        rgb.b += data.data[i+2];
    }

// ~~ used to floor values
    rgb.r = ~~(rgb.r/count);
    rgb.g = ~~(rgb.g/count);
    rgb.b = ~~(rgb.b/count);

    return "rgba(" + (rgb.r + ',' + rgb.g + ',' + rgb.b) + ");";
}



function displayData(data, options){

var sclass='sclass_' + randomNumber(10);
  var a=$.extend({
    'ddclass':'body',
    'scroll': false,
    'shadow':true,
    'header': true,
    'footer': true,
    'hheight': 40,
    'fheight': 40,
    'htitle': '', //header title
    'ftitle': '', //footer title
    'bmax_height': 50, //Content body max height
    'sc': sclass, //shadow class
    'zindex': 1,
    'id':'nothing',
    'sclose': true, //can close on shadow click
    'dummy': false,
    'on_close': '',
    'no_cancel': false,
    'sopacity':'0.5', //shadow opacity
  }, options);

 var container=$('<div class="clear-display-data" id="' + a.id + '" style="position: fixed; top:0; width: 100%; bottom:0; z-index: ' + (999999 + (+ a.zindex) ) + '; background: none;"></div>');

var shadow=$('<div class="display-data-shadow" style="position: absolute; width: 100%; height: 100%; background: #000; z-index: 1; opacity: ' + a.sopacity + '"></div>');
 
if( a.shadow){
 if(a.sclose){
 shadow.on('click',function(){
  closeDisplayData(a.id, a.on_close);
});
 }

container.append( shadow);
}

var contentBodyCont=$('<div style="position: absolute; z-index: 10; left: 50%; top: 50%; transform: translate(-50%, -50%); -webkit-transform: translate(-50%, -50%); width: 80%; max-width: 500px; background: #fff; border:0; border-radius: 3px; padding: 20px;"></div>');

if( a.no_cancel){
var closeBtn="";

 }else{

var closeBtn=$('<i class="text-danger fa fa-lg fa-close" style="position: absolute; top: 5px; right: 2%;"></i>').click(function(){
  closeDisplayData(a.id,a.on_close);
});
}


var contentBody=$('<div style="overflow-y: auto; max-height: ' + a.bmax_height + 'vh;">' + data + '</div>');

var contentHeader=$('<div style="min-height: ' + a.hheight + 'px;">' + a.htitle + '</div>');

var contentFooter=$('<div style="min-height: ' + a.fheight + 'px;">' + a.ftitle + '</div>');

contentBodyCont.append( closeBtn)
    .append(contentBody);

 if( a.htitle){
 contentBodyCont.prepend(contentHeader);
}

 if( a.ftitle){
   contentBodyCont.append(contentFooter);
}
if(!a.dummy){  
container.append(contentBodyCont);

}
 $('body').prepend(container);

  if(!a.scroll) {
   disableScroll();
 }
}
  
function closeDisplayData(elem,callback){
 if(!elem){
    $('.clear-display-data').remove();
   }else{
   $('#' + elem).remove();
   if( callback){
  if(typeof callback==='string' ||callback instanceof String){ window[callback](); } 
      else { callback(); }
   }
}
 enableScroll();
 }



function disableScroll(){

var scrollPosition = [
  self.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
  self.pageYOffset || document.documentElement.scrollTop  || document.body.scrollTop
];

var html = $('html'); // it would make more sense to apply this to body, but IE7 won't have that


if( html.css('overflow')=='hidden'){
   return;
}

html.data('scroll-position', scrollPosition);
html.data('previous-overflow', html.css('overflow') );
html.css('overflow', 'hidden');
window.scrollTo( scrollPosition[0], scrollPosition[1]);

}

function enableScroll(){
// un-lock scroll position
  if($('.clear-display-data').length) return;
var html = $('html');
var scrollPosition = html.data('scroll-position'); 
  if( !scrollPosition ) return;
html.css('overflow', html.data('previous-overflow'));
window.scrollTo( scrollPosition[0], scrollPosition[1]);
}


function stopScroll(elem,elem2){
  var v=0;
   if (elem2){
  if( elem2.search('.')!=-1 ) v=$(elem2).visibleHeight()-10;
    else v=+elem2;
 }

  elem=elem||'.main-container';
   lastTop =$(window).scrollTop();
  sessionStorage.setItem('lastTop',lastTop);
   $(elem).addClass('noscroll').css({top:-(lastTop-v)}); //lastTop-118
  }

function continueScroll(elem) {  
  elem=elem||'.main-container';                  
    $(elem).removeClass( 'noscroll' );

  var lastTo=+sessionStorage.getItem('lastTop')||lastTop;
      
      $(window).scrollTop( lastTo );       
 }          


var toastTimer;
function toast(data,c,callback){
  if(toastTimer) clearTimeout(toastTimer);
  var config=$.extend({
  pos:80,
  custom_class:'',
  hide: 3000,
  type: 'danger',
  align: 'center',
  font_size: '90%',
  width: '80%',
  text_color:'#ffffff',
  background:'',
  manual_close: false,
  z_index: 99999999
},c);
   
   var bg={
           danger: '#d9534f',
           success: 'seagreen',
           info: '#0065A3',
           warning:'orange'
          };
   if(config.background)  bg={
           danger: config.background,
           success: config.background,
           info: config.background,
           warning: config.background
          };
   /* info: background:#4b6cb7*/

 if(toastTimer) clearTimeout(toastTimer);
   $('.android_toast').hide();
    var mc="";
  if(config.manual_close){
   mc='<img onclick="' + (callback?'callback();':'') + 'clearTimeout(toastTimer);$(\'.android_toast\').fadeOut();" src="' + _SITE_URL_ + '/images/bg/close.png" style="width: 17px; position: absolute; top:-5px; left:-5px;">'; 
  }
    
  var div='<div class="dont_print DONT_PRINT android_toast ' + config.custom_class + '" style="background: ' + bg[config.type] +
       '; position: fixed; z-index: ' + config.z_index + ';left: 50%; opacity:.95; color:#fff; width: 50%;border:0;font-size:90%; border-radius: 7px;padding: 8px 20px; max-width: 550px; top: ' + config.pos + 
       '%; width: ' + config.width + '; -webkit-transform: translate(-50%,-' + config.pos + '%); transform:translate(-50%,-' + config.pos + '%); text-align: ' + config.align + 
        '; font-size: ' + config.font_size + '; color: ' + config.text_color + '">' + mc + data + '</div>';
  
  $('body').append(div);
 toastTimer=setTimeout(function(){
    $('.android_toast').fadeOut();
   clearTimeout(toastTimer);
   if(callback) callback();
  },config.hide);
}


function displayDatar(data, options){
  var osclass='dd_' + randomString(10);
  var a=$.extend({
    'ddclass':'body',
    'gs':true,
    'os':true,
    'osc': osclass,
    'oszindex': 150,
    'data_class':'.nothing',
    'osclose': false,
    'on_close': '',
    'type':0,
    'osopacity':'0.5',
    'title':''
  }, options);
  if($(a.data_class).length) return;
  
  //osclose if set to true, then user can also close div on overshadow click
  var osclose='';
   if(a.osclose) osclose=' onclick="closeDisplayData(\'' + a.data_class + '\',\'' + a.on_close + '\');"';
     
var mt_=$('.main_table');
var im_=$('.isMobile');
var is_mobile_=true;
 if( mt_.length && im_.is(':visible') ){
is_mobile_=false;
}

  var div='';
var myDiv = document.createElement("div");
 
//Set its unique ID.
var uid = 'div_id_' + randomString(6);
myDiv.id=uid;
  if(a.type)
  {
     div='<div class="center_div ' + a.data_class.replace('.','') + '" style="background:#fff;">';
     div+='<div class="center_header">' + (a.title?a.title:'') + '</div>';
     div+='<div class="center_text_div" style="width:100%; padding: 10px 15px;">';
     div+=data;
    div+='</div></div>';
 $(a.ddclass).prepend(div);
 }
  else {
$(a.ddclass).prepend(data);
}
  

  $(a.data_class).css('z-index',(a.oszindex+30) ).attr('data-overshadow','.' + a.osc).after('<div class="DONT_PRINT dont_print ' + a.osc + '" style="background: #000; position: fixed; z-index: ' + a.oszindex + '; top:0; left:0; right:0;  bottom:0; opacity: ' + a.osopacity + '; display:none;"' + osclose + '></div>');


  if(is_mobile_ && a.gs){
$('body').addClass('stop-scrolling');
$('.' + a.osc).bind('touchmove', function(e){
e.preventDefault();
 })

}

   if(a.os) $('.' + a.osc).show();

}

 function closeDisplayDatar(elem,callback){
var mt=$('.main_table');
var im=$('.isMobile');
var is_mobile_=true;

 if( mt.length && im.is(':visible') ){
is_mobile_=false;
   mt.css({'overflow-y':'auto'});
}
  var os=$(elem).data('overshadow');
   $(elem).remove();
  $(os).remove();

if(is_mobile_) {
  $('body').removeClass('stop-scrolling');
 }

   if(callback){
  if(typeof callback==='string' ||callback instanceof String){ window[callback](); } 
      else { callback(); }
   }
 }


function fallbackCopyTextToClipboard(text) {
  var textArea = document.createElement("textarea");
  textArea.value = text;
  
  // Avoid scrolling to bottom
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.position = "fixed";

  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();

  try {
    var successful = document.execCommand('copy');
    var msg = successful ? 'successful' : 'unsuccessful';
    console.log('Fallback: Copying text command was ' + msg);
  } catch (err) {
    console.error('Fallback: Oops, unable to copy', err);
  }

  document.body.removeChild(textArea);
}

function copyToClipboard(text) {
  if (!navigator.clipboard) {
    fallbackCopyTextToClipboard(text);
    return;
  }
  navigator.clipboard.writeText(text).then(function() {
    console.log('Async: Copying to clipboard was successful!');
  }, function(err) {
    console.error('Async: Could not copy text: ', err);
  });
}





var escape = function (str) {
  return str
    .replace(/[\\]/g, '\\\\')
    .replace(/[\"]/g, '\\\"')
    .replace(/[\/]/g, '\\/')
    .replace(/[\b]/g, '\\b')
    .replace(/[\f]/g, '\\f')
    .replace(/[\n]/g, '\\n')
    .replace(/[\r]/g, '\\r')
    .replace(/[\t]/g, '\\t');
};
