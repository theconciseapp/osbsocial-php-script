<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn();
require ('includes/admin-functions.php');

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
  
 
<a class="side-bar-btn bg-secondary" aria-current="page" href="<?php echo _ADMIN_URL_; ?>"><i class="fa fa-lg fa-home text-light"> </i> Home</a>

<a class="side-bar-btn mt-3" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>"><i class="fa fa-lg fa-sign-out text-light"></i> Logout</a>


</div>
<div class="main-content-container">


<div style="white-space: normal; height: calc(100vh - 65px); overflow-y: auto; padding: 15px 15px 100px 15px;">

    <form class="d-flex">
      <input id="search-box" class="form-control me-2" type="search" placeholder="Search group" aria-label="Search">
      <button id="search-button" class="btn btn-outline-success" type="submit" data-header-button-item="search-groups-container" data-page="search-groups">Search</button>

<input type="hidden" id="search-box-item" value="">
    </form>

<div class="main-header-container">
 <div class="row text-center">
 <div class="col">
<div data-header-button-item="active-groups-container" class="main-header-button main-header-button-selected is_group bg-secondary" data-page="active-groups" style="border-radius: 5px 0 0 0;">
   GROUPS
    </div>
</div>

<div class="col">

<div data-header-button-item="create-group-container" data-page="empty" class=" main-header-button">
    CREATE GROUP
    </div>
</div>

 </div>
</div>

<div id="active-groups-container" class="header-page" style="background: rgba(0,255,1,0.03); border:0; border-radius: 5px;"></div>

<div id="create-group-container" class="d-none header-page">

<div class="mb-3">
<label for="group-setting" class="form-label">Select type</label>

<div class="input-group">
<span class="input-group-text bg-light text-center" style="height: 40px;">
<i class="fa fa-cog fa-lg"></i>
</span>
<select id="group-setting" class="form-control">
<option value="GV_G">Group</option>
<option value="GV_P">Page</option>
</select>
</div>

<div class="alert alert-success form-text mt-1" id="group-setting-info">
Limited members •</div>

</div>

<div class="mb-3">
<label class="form-label">Custom pin</label>
<div class="form-text">
 Enter alphanumerics only, one underscore ( Exactly 11 characters e.g GV_GXSFAYFJ)
</div>

<div class="input-group">
  <span class="input-group-text bg-light text-center" style="height: 40px;">
 <i class="fa fa-at fa-lg"></i>
  </span>
<span class="input-group-text bg-white text-right" id="selected-group-setting" style="padding-right:0;">
GV_G
</span>

 <input type="text" class="form-control" id="group-pin" placeholder="Pin" style="border-left: 0; padding-left: 1px; text-transform: uppercase;">
    </div>
</div>

  <div class="mb-3">
<label class="form-label">Title</label>
<div class="input-group">
  <span class="input-group-text bg-light text-center" style="height: 40px;">
   <i class="fa fa-edit fa-lg"></i>
  </span> 
     <input class="form-control" type="text" id="group-title" placeholder="Title">
   </div>
</div>

<div class="mb-3">
<label class="form-label">Description</label>

<div class="input-group">
  <span class="input-group-text bg-light text-center">
   <i class="fa fa-file-text fa-lg"></i>
  </span>  
<textarea class="form-control" type="text" id="group-info" placeholder="Description"></textarea>
</div>
   </div>

<div class="mb-3 d-none" id="auto-follow-option">

<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="auto-join" name="auto_join">
<label class="custom-control-label" for="auto-join">Auto join/follow</label>
<div class="form-text">
If you select auto join/follow, all users will automatically join or follow the group/page
</div>
</div> 

</div>

<div class="mb-3">
<label class="form-label">Assign admins (Optional)</label>
<div class="form-text">
You are automatically an admin, You can add another admin. An admin should be an existing user. Separate multiple admins by comma.
</div>
<div class="input-group">
  <span class="input-group-text bg-light text-center" style="height: 40px;">
   <i class="fa fa-group fa-lg"></i>
  </span> 
     <input class="form-control" type="text" id="group-admins" placeholder="Admins">
   </div>
</div>


  <div class="create-group-btn-container mb-3">
      <button id="create-group-btn" class="btn btn-sm btn-primary">Confirm</button>
  </div>
</div>

<div id="search-groups-container" class="d-none header-page"></div>

</div>
</div>


<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="assets/js/global.js?y=7"></script>
<script src="assets/js/index.js?i=<?php echo randomString(2); ?>"></script>
<script src="assets/js/groups.js?i=<?php echo randomString(2); ?>"></script>

<script>
loadMain( _ADMIN_URL_ + '/ajax/active-groups.php','#active-groups-container');
</script>
</body>
</html>
