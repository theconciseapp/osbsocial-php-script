<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> <img src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>" class="logo"> <?php echo _BRAND_NAME_; ?> </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collaps" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation" onclick="toggleSidebar();">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="<?php echo _ADMIN_URL_; ?>">Home</a>

<a class="nav-link" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>">Logout</a>
     
      </div>
    </div>
  </div>
</nav>

<div class="container">
<div class="row">
<div class="col-12">


<div class="add-user-form-container" style="max-width: 500px; margin: 0 auto 300px auto;">

<div class="form-text">Register a user. Users registered here are automatically active and does not require email validation from the user. To create a verified user account precede pin with uv_ e.g uv_abosede</div>

<div class="add-user-form mb-3">
<div class="mb-2">
<label class="form-label">Pin</label>
 
<input type="text" id="username1" class="form-control">

</div>
<div class="mb-2">
<label class="form-label">Email address</label>
<input type="email" id="email1" class="form-control">

</div>

<div class="mb-2">
<label class="form-label">Phone</label>
 
<input type="number" id="phone1" class="form-control">

</div>

<div class="mb-2">
<label class="form-label">Display name</label>

<input type="text" id="fullname1" class="form-control">

 </div>
<div class="mb-2">
<label class="form-label">Password</label>

<input type="text" id="password1" class="form-control">
 
</div>

<div class="input-error mb-1" id="register-user-result"></div> 
       
<button id="add-user-btn" class="btn btn-sm btn-primary mb-2">ADD USER</button>
</div>
</div>


</div>
</div>
</div>



<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<script src="assets/js/global.js"></script>

<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>
</body>
</html>
