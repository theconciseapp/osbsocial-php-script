<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn(); 
require ('includes/admin-functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header()?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
 
<a class="side-bar-btn bg-secondary" aria-current="page" href="<?php echo _ADMIN_URL_; ?>"><i class="fa fa-lg fa-home text-light"> </i> Home</a>
	

 <a href="add_admin.php" class="side-bar-btn" target="_blank"><i class="fa fa-user-o"></i> Add an admin</a>
<a class="side-bar-btn mt-3" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>"><i class="fa fa-lg fa-sign-out text-light"></i> Logout</a>


</div>

<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 100px;">

<div class="container" style="padding: 15px;">
    <form class="d-flex">
      <input id="search-box" class="form-control me-2" type="search" placeholder="Search admin" aria-label="Search">
      <button id="search-button" class="btn btn-outline-success" data-header-button-item="search-admins-container" data-page="search-admins" type="submit">Search</button>
<input type="hidden" id="search-box-item"  value="">
    </form>
  </div>

<div class="main-header-container container">
 <div class="row text-center">
 <div class="col">
<div data-header-button-item="admins-container" data-page="admins" class="main-header-button main-header-button-selected" style="border-radius: 5px 0 0 0;">
    ADMINS
    </div>
</div>
 
 </div>
</div>

<div id="pages-container">

<div id="admins-container" class="header-page" style="background: rgba(0,0,255,0.03); border:0; border-radius: 5px;"></div>

<div id="search-admins-container" class="d-none header-page"></div>

</div>
</div>
</div>
</div>


<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>

<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>

<script>
loadMain( _ADMIN_URL_ + '/ajax/admins.php','#admins-container');
</script>
</body>
</html>
