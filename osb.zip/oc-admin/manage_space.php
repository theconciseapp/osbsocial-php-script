<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn(); ?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 
<style>
span.delete-fd{
margin-left: 10px;
}
</style> 
</head>
<body>

<nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> <img src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>" class="logo"> <?php echo _BRAND_NAME_; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="<?php echo _ADMIN_URL_; ?>">Home</a>

<a class="nav-link" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>">Logout</a>
     
     </div>
    </div>
  </div>
</nav>

<div class="container-fluid mb-5">
<div class="row">
 <div class="col-12 col-sm-7">

<button class="load-dir btn btn-sm btn-primary d-block mb-2" data-level="images" data-load-to="images" data-margin-left="10">Images</button>
 <div class="load-to-images"></div>

<button class="load-dir btn btn-sm btn-primary d-block mb-2" data-level="videos" data-load-to="videos">Videos</button>
 <div class="load-to-videos"></div>

<button class="load-dir btn btn-sm btn-primary d-block mb-2" data-level="audios" data-load-to="audios">Audios</button>
 <div class="load-to-audios"></div>

<button class="load-dir btn btn-sm btn-primary d-block mb-2" data-level="documents" data-load-to="documents">Documents</button>
 <div class="load-to-documents"></div>

<hr>
<div class="form-text">Stats: Users daily app usage</div>
<button class="load-dir btn btn-sm btn-primary d-block mb-2" data-level="stats" data-load-to="stats">View stats</button>
 <div class="load-to-stats mb-5"></div>

</div>

<div class="col-12 col-sm-5">
<h2>
DATABASE 
</h2>

<div class="alert alert-info">
Delete old datas from database periodically to free database space and hence increase chat speed. It's recommended to do this @mid night or when the load on server is low. 
</div>


<h2>PRIVATE CHATS</h2>
<strong>Delete old private chats from database</strong>


<div class="mb-2">
<label>Select old messages</label>
<select id="private-messages-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old chats to delete at most</label>
<select id="private-messages-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-private-messages-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="delete-private-messages-result"></div>
</div>



<h2>GROUP/PAGES MESSAGES</h2>

<strong>Delete old group chat messages, pages posts from database</strong>

<div class="mb-2">
<label>Select old messages</label>
<select id="age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old messages to delete at most</label>
<select id="limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-db-messages" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="db-result"></div>
</div>


<h2>GROUP/PAGE COMMENTS</h2>
<strong>Delete old group/page COMMENTS from database</strong>

<div class="mb-2">
<label>Select old messages</label>
<select id="del-comment-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old comments to delete at most</label>
<select id="del-comment-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="del-comment-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="del-comment-result"></div>
</div>



<h2>GO-SOCIAL POSTS</h2>

<strong>Delete old go-social posts from database</strong>


<div class="mb-2">
<label>Select old posts</label>
<select id="go-posts-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old posts to delete at most</label>
<select id="go-posts-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-go-posts-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="delete-go-posts-result"></div>
</div>


<h2>GO-SOCIAL COMMENTS</h2>

<strong>Delete old go-social comments from database</strong>


<div class="mb-2">
<label>Select old comments</label>
<select id="go-comments-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old comments to delete at most</label>
<select id="go-comments-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-go-comments-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="delete-go-comments-result"></div>
</div>



<h2>GO-SOCIAL NOTIFICATIONS</h2>

<strong>Delete old go-social notifications from database</strong>


<div class="mb-2">
<label>Select old notifiactions</label>
<select id="go-notifications-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old notifications to delete at most</label>
<select id="go-notifications-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-go-notifications-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="delete-go-notifications-result"></div>
</div>




<h2>PRIVATE MESSAGES RECEIPTS</h2>

<strong>Delete old private messages receipts from database</strong>


<div class="mb-2">
<label>Select old receipts</label>
<select id="private-messages-receipts-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old receipts to delete at most</label>
<select id="private-messages-receipts-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-private-messages-receipts-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="delete-private-messages-receipts-result"></div>
</div>





<h2>REPORTED CONTENTS</h2>

<strong>Delete old reported contents from database</strong>


<div class="mb-2">
<label>Select old reports</label>
<select id="reported-contents-age" class="form-control">
<option value="1">1-DAY OLD</option>
<option value="3">3-DAY OLD</option>
<option value="7">7-DAY OLD</option>
<option value="14">14-DAY OLD</option>
<option value="21">21-DAY OLD</option>
<option value="28">28-DAY OLD</option>
<option value="30" selected>30-DAY OLD</option>
<option value="40">40-DAY OLD</option>
<option value="50">50-DAY OLD</option>
<option value="100">100-DAY OLD</option>
<option value="365">365-DAY OLD</option>
</select>
</label>
</div>

<div class="mb-2">
<label>Amount of old reports to delete at most</label>
<select id="reported-contents-limit" class="form-control">
<option>100</option>
<option>1000</option>
<option>5000</option>
<option>10000</option>
</select>
</label>
</div>


<div class="mb-5">
<button id="delete-reported-contents-btn" class="d-block btn btn-secondary"><i class="fa fa-trash fa-lg"></i> Delete now</button>
<div id="delete-reported-contents-result"></div>
</div>








</div>

</div>
</div>



<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>
<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>
<script src="assets/js/manage_space.js?i=<?php echo randomString(3); ?>"></script>
</body>
</html>
