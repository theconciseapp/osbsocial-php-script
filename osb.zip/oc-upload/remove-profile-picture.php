<?php header('Content-type:application/json;charset=utf-8');
require '../oc-includes/bootstrap.php';
if (!verifyToken()) 
  {
    die('{"error":"Token not valid"}');
  }
require '../oc-includes/chat_functions.php';
if (empty($_POST['username'])) 
  {
    die('{"error":"Missing parameters"}');
  }
$username     = test_input(strtolower($_POST['username']));
if (isset($_POST["user"]) && go_page($_POST["user"]) && site_admin($username)) 
  {
    $username     = test_input($_POST["user"]);
  }
$dir          = getUserDir($username);
$file         = $dir . '/profile_picture_full.jpg';
$medium_thumb = $dir . '/profile_picture_medium.jpg';
$thumb        = $dir . '/profile_picture_small.jpg';
if (file_exists($file)) 
  {
    @unlink($file);
  }
if (file_exists($medium_thumb)) 
  {
    @unlink($medium_thumb);
  }
if (file_exists($thumb)) 
  {
    @unlink($thumb);
  }
die('{"status":"success","result":"Photo removed."}');
