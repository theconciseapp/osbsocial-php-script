<?php if (!defined('__ALLOW__')) 
  {
    die('{"error":"51"}'); //Method not allowed
    
  }
if (empty($_POST['chat_to']) || empty($_POST['chat_id']) || !is_numeric($_POST['chat_id']) && strlen($_POST['chat_id']) > 30) 
  {
    die('{"error":"52"}'); //Parameters missing.
    
  }
$chat_to = test_input(strtolower($_POST['chat_to']));
$dir     = getUserDir($chat_to); //recipient directory
if (!startsWith($chat_to, 'gp_') && !is_dir($dir)) 
  {
    die('{"status":"success","file_size":"1","file_folder":"audios","file_path":""}');
    //fake sent file since recipient's directory does not exist
    
  }
function uploadBase64Audio($save_to, $file_data, $folder, $filename) 
  {
    $f                    = finfo_open();
    $mime_type            = finfo_buffer($f, $file_data, FILEINFO_MIME_TYPE);
    $file_type            = explode('/', $mime_type) [0];
    $extension            = explode('/', $mime_type) [1];
    $acceptable_mimetypes = allowedAudios();
    if (in_array($mime_type, $acceptable_mimetypes)) 
      {
        if (file_put_contents($save_to, $file_data)) 
          {
            $file_size            = filesize($save_to);
            $file_path            = _CHAT_FILES_PATH_ . "/{$folder}/{$filename}.mp3";
            die('{"status":"success","file_size":"' . $file_size . '","file_folder":"' . $folder . '","file_path":"' . $file_path . '"}'); //Successful
            
          }
        else die('{"error":"00"}'); //Failed
        
      }
    else
      {
        die('{"error":"2"}'); //Unsupported
        
      }
    die('{"error":"00"}'); //Failed
    
  }
$chat_to   = test_input(strtolower($_POST['chat_to']));
$chat_id   = test_input($_POST['chat_id']);
$base64    = test_input($_POST['base64']);
$bfilesize = strlen($base64) / 1024;
$bfilesize = $bfilesize / 1024;
if ($bfilesize > _MAX_CHAT_FILES_SIZE_) 
  {
    die('{"error":"3"}'); //File too large
    
  }
$base64   = base64_decode($base64);
$filename = $chat_to . '-' . $chat_id;
$folder   = "audios/messenger/" . _CHAT_FILES_STRUCTURE_;
$dir      = _CHAT_FILES_DIR_ . "/{$folder}";
if (!make_dir($dir)) 
  {
    die('{"error":"53"}'); //Unable to create directory
    
  }
$file = $dir . '/' . $filename . '.mp3';
uploadBase64Audio($file, $base64, $folder, $filename);
