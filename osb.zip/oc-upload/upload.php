<?php @ini_set('memory_limit', '72M');
@ini_set('upload_max_filesize', '36M');
@ini_set('post_max_size', '37M');
@ini_set('max_execution_time', 60);
@ini_set('max_input_time', 60);
header('Content-type:application/json;charset=utf-8');
require '../oc-includes/bootstrap.php';
if (empty($_POST['username'])) 
  {
    die('{"error":"52"}');
  }
$chat_from = $_POST['username'];
if (!validUsername($chat_from, true)) 
  {
    die('{"error":"52"}');
  }
$settings__     = getSettings();
$chat_status    = isset($settings__["enable_chat"]) ? $settings__["enable_chat"] : "YES";
$enable_vid_doc = isset($settings__["enable_vid_doc"]) ? $settings__["enable_vid_doc"] : "YES";
if ($chat_status == 'NO') 
  {
    die('{"error":"0"}'); //Chat disabled
    
  }
else if (!verifyToken()) 
  {
    die('{"error":"1"}'); //invalid token
    
  }
require '../oc-includes/chat_functions.php';
define('__ALLOW__', '1');
if (empty($_REQUEST['file_type'])) 
  {
    die('{"error":"2"}'); //Unsupported file
    
  }
$file_type = $_REQUEST['file_type'];
if ($file_type == 'image') 
  {
    include ('upload-image.php');
  }
else if ($file_type == 'video') 
  {
    if (!site_admin($chat_from) && $enable_vid_doc != 'YES') 
      {
        die('{"error":"54"}');
      }
    include ('upload-video.php');
  }
else if ($file_type == 'audio') 
  {
    include ('upload-audio.php');
  }
else
  {
    if (!site_admin($chat_from) && $enable_vid_doc != 'YES') 
      {
        die('{"error":"54"}');
      }
    include ('upload-documents.php');
  }
