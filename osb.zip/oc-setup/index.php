<?php if (file_exists('../oc-includes/config.php')) 

  {

    die('<h2>NOTHING TO DO HERE...</h2>');

  }

require '../oc-includes/bootstrap.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <style>
body{
background: #fff;
}

.setup-container{
width: 95%;
max-width: 1000px;
 margin: 10px auto 100px auto;
border: 1px solid #999;
border-radius: 4px;
}

.form-label{
 font-size: 13px;
font-weight: 500;
}

#error-report{
 height: 20px;
font-size: 13px;

}

</style>

</head>
<body>

<img class="mt-3 mb-3" style="display: block; margin:0 auto;width: 60px; height: 60px;" src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>">
 
<div class="setup-container border p-3">
<div class="form-text">Enter your database connection details below. If you are not sure about these, contact your web host.</div>

<div class="container-fluid p-2">
 <div class="row">
 <div class="col-12 col-sm-3">
<div class="mt-2 mb-2">
 <label class="form-label">DATABASE HOST*</label>
</div>
</div>
<div class="col-12 col-sm-4">
 <div class="mb-2">
<input type="text" id="database-host" class="form-control" value="Localhost">
 </div>
</div>

<div class="d-none d-sm-block col-sm-5">
<div class="mb-2">
  Get this info from your web host, if Localhost doesn't work.</div>
</div>

<div class="col-12 col-sm-3">
 <div class="mb-2">
<label class="form-label">DATABASE NAME*</label>
 </div>
</div>

<div class="col-12 col-sm-4">
<div class="mb-2">
<input type="text" class="form-control" id="database-name" value="">
</div>
</div>

<div class="d-none d-sm-block col-sm-5">
<div class="mb-2">
 The name of database you want to use Oluchat with.</div>
</div>
<div class="col-12 col-sm-3">
<div class="mb-2">
<label class="form-label">DATABASE USERNAME*</label>
</div>
</div>

<div class="col-12 col-sm-4">
<div class="mb-2">
<input type="text" id="database-username" class="form-control" value="">
</div>
</div>
<div class="d-none d-sm-block col-sm-5">
<div class="mb-2">
  Your database username.
  </div>
</div>
<div class="col-12 col-sm-3">
<div class="mb-2">
<label class="form-label">DATABASE PASSWORD</label>
</div>
</div>

<div class="col-12 col-sm-4">
<div class="mb-2">
<input type="text" id="database-password" class="form-control" value="">
 </div>
</div>

<div class="d-none d-sm-block col-sm-5">
<div class="mb-2">
Your database password.
</div>
</div>

<div class="col-12 col-sm-3">
<div class="mb-2>
<label class="form-label">TABLE PREFIX*</label>
</div>
</div>
<div class="col-12 col-sm-4">
<div class="mb-2">
<input type="text" id="table-prefix" class="form-control" value="oc_">
</div>

</div>
<div class="d-none d-sm-block col-sm-5">
 <div class="mb-2">
Change this only if you want to run multiple apps of OluChat</div>
</div>

</div><!--end row-->

<div id="error-report" class="mb-2"></div>
<button class="setup-now-btn btn btn-sm btn-primary">Let's Go</button>
</div>
</div>
</div>

<script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
<script src="<?php echo _ADMIN_URL_ . '/assets/js/global.js?i=' . randomString(3); ?>"></script>
<script src="setup.js?t=<?php echo time(); ?>"></script>

</body>
</html>
