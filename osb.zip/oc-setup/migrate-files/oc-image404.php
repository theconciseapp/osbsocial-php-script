<?php

$file = 'oc-image404.png';

$type = 'image/png';

header("HTTP/1.0 404 Not Found");

header('Content-Type:' . $type);

// header('Content-Length: ' . filesize($file));

// readfile($file);

