<?php if (!defined('setup')) 

  {

    die('Setup not found.');

  }

$time                  = time();

$date_                 = date('Y-m-d H:i:s');

$table_users           = "{$table_prefix}users";

$table_admins          = "{$table_prefix}admins";

$table_pmessages       = "{$table_prefix}private_messages";

$table_preceipts       = "{$table_pmessages}_receipts";

$table_groups          = "{$table_prefix}groups";

$table_gmessages       = "{$table_groups}_messages";

$table_gcomments       = "{$table_prefix}groups_comments";

$table_gosocial        = "{$table_prefix}go_social_posts";

$table_gocomments      = "{$table_prefix}go_social_comments";

$table_gonotifications = "{$table_prefix}go_social_notifications";

$table_gofollowers     = "{$table_prefix}go_social_followers";

$table_reports         = "{$table_prefix}reports";

$table_pr              = "{$table_prefix}tokens";

/*CREATE TABLE ADMINS*/

$sql_admins            = "CREATE TABLE IF NOT EXISTS {$table_admins}(
  `id` int(11) NOT NULL AUTO_INCREMENT, `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `fullname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL, `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `role` smallint(6) NOT NULL DEFAULT '3', `added_on` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`,`username`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

/*INSERT INTO TABLE ADMINS*/

$sql_admins2           = "INSERT INTO $table_admins (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `added_on`) VALUES
(1,	'av_official',	'official@site.com',	'Official',	'123456789',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	1,	'$date_')";

/*TABLE TOKENS*/

$sql_pr                = "CREATE TABLE IF NOT EXISTS {$table_pr} (
  `id` int(11) NOT NULL AUTO_INCREMENT, `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `expiry_time` int(11) NOT NULL, PRIMARY KEY (`id`), KEY `token_email_expiry_time` (`token`,`email`,`expiry_time`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

/*CREATE TABLE USERS*/

$sql_users             = "CREATE TABLE IF NOT EXISTS {$table_users} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL, `fullname` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL, `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL, `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL, `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `bio` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL, `birth` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL, `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `groups` varchar(700) COLLATE utf8mb4_unicode_ci NOT NULL, `total_following` int(11) unsigned NOT NULL DEFAULT '0', `total_followers` int(11) unsigned NOT NULL DEFAULT '0', `role` smallint(6) NOT NULL DEFAULT '3', `user_status` smallint(6) NOT NULL DEFAULT '0', `last_online` int(11) NOT NULL, `added_on` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `email_username` (`email`,`username`), KEY `role` (`role`), FULLTEXT KEY `fullname` (`fullname`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

/*INSERT INTO TABLE USERS*/

$sql_users2            = "INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(1,	'av_official',	'Official@noreply.com',	'Official',	'+234123456789',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	1,	1,	'$time',	NOW() )";

$sql_users3            = "INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(2,	'pv_myfirstpage',	'axdgvdscvv@noreply.com',	'My First Page',	'',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	5,	1,	'$time',	NOW() )";

$sql_users4            = "INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(3,	'cv_drafts',	'axdgdradcvv@noreply.com',	'Drafts',	'',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	2,	1,	'$time',	NOW() )";


$sql_users5            = "INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(4,	'cv_contact',	'ourcompany@noreply.com',	'Contact Us',	'',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	2,	1,	'$time',	 NOW() )";

//SPONSORED POSTS PAGE 

$sql_users6            = "INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(5,	'cv_sponsoredposts',	'sponsoredposts@noreply.com',	'Sponsored posts',	'',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	2,	1,	'$time', 	NOW() )";

$sql_users7            = "INSERT INTO {$table_users} (`id`, `username`, `email`, `fullname`, `phone`, `password`, `role`, `user_status`, `last_online`, `added_on`) VALUES
(6,	'cv_aboutus',	'aboutus@noreply.com',	'About us',	'',	'$2y$10$3QMFOm46obSII42yIUBd1en5.uDZzEAOaN/XZlB3b60z0EfJeIAUK',	2,	1,	'$time', 	NOW() )";


//CREATE PRIVATE MESSAGES

$sql_pmessages         = "CREATE TABLE IF NOT EXISTS {$table_pmessages} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `message_id` bigint(20) NOT NULL, `message_time` int(11) NOT NULL, `message_from` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message_to` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message_preview` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL, `message` text COLLATE utf8mb4_unicode_ci NOT NULL, `meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `message_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,  `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `post_date_post_by_post_type_post_status` (`message_from`,`message_type`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

//CREATE PRIVATE MESSAGES RECEIPTS

$sql_preceipts         = "CREATE TABLE IF NOT EXISTS {$table_preceipts} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `receipt_from` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `receipt_to` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `receipt` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `receipt_time` int(11) NOT NULL, `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `receipt_to` (`receipt_to`), KEY `receipt_time` (`receipt_time`) ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

/* CREATE GROUPS TABLE */

$sql_groups            = "CREATE TABLE IF NOT EXISTS {$table_groups} (
 `id` int(11) NOT NULL AUTO_INCREMENT, `group_type` tinyint(4) NOT NULL DEFAULT '1', `auto_join` tinyint(2) NOT NULL DEFAULT '0', `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `fullname` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL, `group_info` varchar(600) COLLATE utf8mb4_unicode_ci NOT NULL, `group_admins` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `group_members` text COLLATE utf8mb4_unicode_ci NOT NULL, `total_members` smallint(5) unsigned NOT NULL DEFAULT '1', `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `is_admin` tinyint(4) NOT NULL DEFAULT '0', `created_on` int(11) NOT NULL, PRIMARY KEY (`id`), UNIQUE KEY `username` (`username`), KEY `fullname_group_type` (`fullname`,`group_type`), KEY `auto_join_is_admin` (`auto_join`,`is_admin`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

/*INSERT INTO GROUP*/

$sql_groups2           = "INSERT INTO {$table_groups} (`id`, `group_type`,`auto_join`, `username`, `fullname`, `group_info`,`group_admins`, `group_members`, `total_members`, `created_by`, `is_admin`, `created_on`) VALUES
(1,	2, 1, 'gv_pofficials',	'Official',	'Official','av_official,',	'av_official,',	1,	'av_official',	 1, '$time')";

/*TABLE GROUP MESSAGES*/

$sql_gmessages         = "CREATE TABLE IF NOT EXISTS {$table_gmessages} (
`id` bigint(20) NOT NULL AUTO_INCREMENT, `message_id` bigint(20) NOT NULL, `message_time` int(11) NOT NULL, `message_from` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message_to` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message_preview` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL, `message` text COLLATE utf8mb4_unicode_ci NOT NULL, `meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `post_date_post_by_post_type_post_status` (`message_from`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

$sql_gcomments         = "CREATE TABLE IF NOT EXISTS {$table_gcomments} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `parent_id` bigint(20) NOT NULL DEFAULT '0', `group_pin` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL, `post_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL, `comment_author` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message` text COLLATE utf8mb4_unicode_ci NOT NULL, `meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `likes` smallint(6) NOT NULL DEFAULT '0', `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0', `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `group_pin_post_id_status` (`group_pin`,`post_id`,`status`), KEY `parent_id` (`parent_id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

//GO-SOCIAL

/* CREATE GO SOCIAL POSTS*/

$sql_gosocial          = "CREATE TABLE IF NOT EXISTS {$table_gosocial} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `post_date` int(11) NOT NULL, `post_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `post_title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `post_preview` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL, `post` text COLLATE utf8mb4_unicode_ci NOT NULL, `post_files` text COLLATE utf8mb4_unicode_ci NULL, `post_meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,`post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `reactions` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL default '{\"like\":0,\"love\":0,\"laugh\":0,\"wow\":0,\"sad\":0,\"angry\":0}', `total_comments` int(11) unsigned NOT NULL DEFAULT '0', `total_shares` int(11) unsigned NOT NULL DEFAULT '0', `post_status` smallint(5) unsigned NOT NULL DEFAULT '1', `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`),
  KEY `post_title` (`post_title`),
  KEY `post_by_post_date_post_status` (`post_by`,`post_date`,`post_status`),
  KEY `post_name` (`post_name`),
  FULLTEXT KEY `post_preview` (`post_preview`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";


//INSERT INTO GO SOCIAL POST

$file_data='[{"path":"'. _CHAT_FILES_PATH_ . '/welcome/social.jpg?ocwh=893_1245","ext":"jpg","width":"893","height":"1245","poster":"","size":"100000"}]';

//Contact page

$sql_gosocial2         = "INSERT INTO $table_gosocial (`id`, `post_date`, `post_by`, `post_title`, `post_preview`, `post`, `post_files`, `post_meta`, `post_type`, `reactions`, `total_comments`, `total_shares`, `post_status`, `date_time`) VALUES( 1,	'$time',	'cv_contact',	'', '69, Contact address here...\n\nContact us via email @ Ourcompany@ourcompany.com\nWebsite: Ourcompany.com\n@Cv_contact',	'69, Contact address here...\n\nContact us via email @ Ourcompany@ourcompany.com\nWebsite: Ourcompany.com\n@Cv_contact','',	'{\"pbf\":\"Contact Us\",\"true_author\":\"cv_contact\",\"plen\":800,\"shareable\":\"0\",\"commentable\":\"0\",\"total_files\":1,\"has_files\":1,\"post_bg\":\"\",\"link\":\"\",\"link_text\":\"\",\"fdload\":\"1\"}',	'',	'{\"like\":1000,\"love\":0,\"laugh\":0,\"wow\":0,\"angry\":0,\"sad\":0}',0,0,	1,	NOW() )";

//First Post

$sql_gosocial3         = "INSERT INTO $table_gosocial (`id`, `post_date`, `post_by`, `post_title`, `post_preview`, `post`, `post_files`, `post_meta`, `post_type`, `reactions`, `total_comments`, `total_shares`, `post_status`, `date_time`) VALUES( 2,	'$time',	'pv_myfirstpage',	'', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac turpis eu felis vehicula elementum eget a ipsum. Fusce tincidunt libero eu erat porta, at tempus dui egestas. Nunc a nisl orci. Sed in semper risus. Phasellus tristique massa sit amet ',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac turpis eu felis vehicula elementum eget a ipsum. Fusce tincidunt libero eu erat porta, at tempus dui egestas. Nunc a nisl orci. Sed in semper risus. Phasellus tristique massa sit amet enim mattis, a rutrum erat varius. Pellentesque elementum leo nisl, eget fringilla ante mollis ut. Cras pretium dolor ut varius vehicula. Donec eu auctor mauris. Curabitur pulvinar felis nec mauris varius placerat vel ac erat.\n\nQuisque aliquet ut leo eu tincidunt. Enim in iaculis.', '{$file_data}',	'{\"pbf\":\"My First Page\",\"true_author\":\"av_official\",\"plen\":800,\"shareable\":\"1\",\"commentable\":\"1\",\"total_files\":1,\"has_files\":1,\"post_bg\":\"\",\"link\":\"\",\"link_text\":\"\",\"fdload\":\"1\"}',	'',	'{\"like\":1000,\"love\":10000,\"laugh\":100,\"wow\":800,\"angry\":0,\"sad\":0}',0,0,	1,	NOW() )";



//CREATE GO SOCIAL COMMENTS

$sql_gocomments        = "CREATE TABLE IF NOT EXISTS {$table_gocomments} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `parent_id` bigint(20) NOT NULL DEFAULT '0', `post_id` bigint(20) NOT NULL DEFAULT '0', `post_by` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL, 
 `comment_author` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL, `message` text COLLATE utf8mb4_unicode_ci NOT NULL, `post_files` text COLLATE utf8mb4_unicode_ci NULL, `meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `likes` smallint(6) unsigned NOT NULL DEFAULT '0', `has_replies` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0', `status` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0', `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `parent_id_has_replies` (`parent_id`,`has_replies`), KEY `post_id_status_post_by` (`post_id`,`status`,`post_by`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

//GO SOCIAL NOTIFICATIONS

$sql_gonotifications   = "CREATE TABLE IF NOT EXISTS {$table_gonotifications} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `message_time` int(11) NOT NULL, `message_to` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `message` text COLLATE utf8mb4_unicode_ci NOT NULL, `meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `message_time_message_to` (`message_time`,`message_to`), KEY `date_time` (`date_time`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

//CREATE GO SOCIAL FOLLOWERS

$sql_gofollowers       = "CREATE TABLE IF NOT EXISTS {$table_gofollowers} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, `following` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `follower` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1', `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `following_follower_status` (`following`,`follower`,`status`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

//CREATE TABLE REPORTS

$sql_reports           = "CREATE TABLE IF NOT EXISTS {$table_reports} (
  `id` int(11) NOT NULL AUTO_INCREMENT, `report_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `report` text COLLATE utf8mb4_unicode_ci NOT NULL, `report_section` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL, `report_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `meta` text COLLATE utf8mb4_unicode_ci NOT NULL, `report_time` int(11) NOT NULL, `date_time` datetime DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `report_by_report_id` (`report_by`,`report_id`), KEY `date_time` (`date_time`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

//ADMINS

try

  {

    if ($query                 = mysqli_query($conn, $sql_admins)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_admins . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//PRIVATE MESSAGES

try

  {

    if ($query = mysqli_query($conn, $sql_pmessages)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_pmessages . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//PRIVATE MESSAGES RECEIPTS

try

  {

    if ($query = mysqli_query($conn, $sql_preceipts)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_preceipts . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GROUPS

try

  {

    if ($query = mysqli_query($conn, $sql_groups)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_groups . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GROUPS/PAGE MESSAGES

try

  {

    if ($query = mysqli_query($conn, $sql_gmessages)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_gmessages . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GROUPS COMMENTS

try

  {

    if ($query = mysqli_query($conn, $sql_gcomments)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_gcomments . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//USERS

try

  {

    if (mysqli_query($conn, $sql_users)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_users . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GO SOCIAL POSTS

try

  {

    if ($query = mysqli_query($conn, $sql_gosocial) ) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_gosocial . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GO SOCIAL COMMENTS

try

  {

    if ($query = mysqli_query($conn, $sql_gocomments)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_gocomments . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GO FOLLOWERS

try

  {

    if ($query = mysqli_query($conn, $sql_gofollowers)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_gofollowers . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//GO NOTIFICATIONS

try

  {

    if ($query = mysqli_query($conn, $sql_gonotifications)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_gonotifications . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//REPORTS

try

  {

    if ($query = mysqli_query($conn, $sql_reports)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_reports . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

//TOKENS

try

  {

    if (mysqli_query($conn, $sql_pr)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Table ' . $table_pr . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

try

  {

    if ($query = mysqli_query($conn, $sql_admins2)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Data inserts in ' . $table_admins . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

try

  {

    if (mysqli_query($conn, $sql_groups2)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Data inserts in ' . $table_groups . ' was created successfully.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

try

  {

    if (mysqli_query($conn, $sql_users2)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Data inserts in ' . $table_users . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

try

  {

    if (mysqli_query($conn, $sql_users3)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i>Page data insert in ' . $table_users . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

try

  {

    if (mysqli_query($conn, $sql_users4)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i>Drafts page insert in ' . $table_users . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }


try

  {

    if (mysqli_query($conn, $sql_users5)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i>Contact account insert in ' . $table_users . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }


try

  {

    if (mysqli_query($conn, $sql_users6)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i>Sponsored posts account insert in' . $table_users . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }


try

  {

    if (mysqli_query($conn, $sql_users7)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i>About us account insert in ' . $table_users . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }



try

  {

    if (mysqli_query($conn, $sql_gosocial2)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Data insert in ' . $table_gosocial . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }


try

  {

    if (mysqli_query($conn, $sql_gosocial3)) 

      {

        $success.= '<div><i class=\"fa fa-lg fa-check\"></i> Data insert in ' . $table_gosocial . ' was successful.</div>';

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }
