<?php require ('oc-includes/bootstrap.php'); ?>
<!DOCTYPE HTML>
<html>
<head> 
  
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
       <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no,user-scalable=0"> 

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="<?php echo theme_path(); ?>/assets/chat/css/login.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

  <?php require theme_dir() . "/includes/header.html.php"; ?>

    <script src="<?php echo theme_path(); ?>/assets/chat/js/chat_globals.js"></script>
 <script src="<?php echo theme_path(); ?>/assets/chat/js/login.js?y=<?php echo rand(); ?>"></script>

  </head>
  <body>
    <div id="privacy-terms-container">
   <img style="position: sticky; top: 1%; left: 2%;" class="w-20 h-20" src="<?php echo theme_path(); ?>/assets/go-icons/back.png" onclick="$('#privacy-terms-container').hide();">
   
    <div id="privacy-content">
    <img id="privacy-loader" src="<?php echo theme_path(); ?>/assets/loading-indicator/loading3.png">
    </div>
    </div>
    
 <div id="login-form-container" class="form-page form-container">
 
 <div class="form-title-container">
<div class="container">
    	<div class="row">
    	<div class="col-5">
    	 <div class="form-title">Login</div>
      </div>
      <div class="col text-right">

  </div>
  </div>
 </div>
  </div> 
 
   <div class="login-form-container">
   
   <div class="login-form">
   	
   <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/username.png"></span> 
   <input type="text" class="form-control login-username" id="login-pin" placeholder="Pin">  
  
    </div>
   <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/pass.png"></span>
     <input class="form-control login-password" type="password" id="login-password" placeholder="password">
   </div>
    
   <div id="show-forgot-pwd-form" data-page="fpwrd-form-container" class="mb-2 form-page-switch mt-3">
     Forgot password?
    </div>
   
  <div id="login-captcha-container" style="display: none;">   
 <div class="form-text">Verification code</div>
   <div id="login-captcha-text"></div>      
      
  <div class="input-group mb-2"> 
       <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/lock.png"></span>
  <input class="form-control" type="text" id="login-captcha" placeholder="Enter code">  
 </div>
</div>  
     
    <div class="mb-2 d-none">
     <label>
     <input type="checkbox" id="customerRemember"  name="remember" checked="checked"> Remember me
     </label>
</div> 
     
    <div class="login-btn-container mb-3">
      <button id="login-btn" class="login-btn btn btn-sm btn-primary" style="background: #0079c6;">Sign In <div id="login-loader" class="loader loader1"><div class="spin"></div></div></button>
    </div>
    
    <div class="text-center form-page-switch" data-page="register-form-container" id="show-signup-form">
     Don't have an account? Sign up 
    </div>
    
    </div>
   </div>
   </div>
  
    <!--REGISTER FORM-->
    
   <div id="register-form-container" class="form-page form-container">

    <div class="form-title-container">
      	<div class="container">
    	<div class="row">
    	<div class="col-5  form-page-switch" data-page="login-form-container">
      <img class="w-30 h-30" src="<?php echo theme_path(); ?>/assets/chat-icons/back.png">
      </div>
      <div class="col-7 text-end">
 	<div class="form-title">Sign Up</div>
  </div>
  </div>
 </div>
 </div>
 
   <div class="register-form-container">
   <div class="register-form">
     <label class="d-block">New Pin (Username)</label>
   <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/username.png"></span>
   <input type="text" class="form-control reg-username" id="reg-pin" placeholder="Choose a pin">
  </div>
  
     <label class="d-block">Email address</label>
   <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/email.png"></span>
   <input type="text" class="form-control reg-email" id="reg-email" placeholder="Email address">
    </div>
  
     <label class="d-block">Display Name</label>
     <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/name.png"></span>
   <input type="text" class="form-control reg-name" id="reg-name" placeholder="Display name">
    </div> 
     <label class="d-block">Phone Number</label> 
     <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/phone.png"></span>
   <input type="text" class="form-control reg-phone" id="reg-phone" placeholder="Phone number">
   </div>
     
  <label class="d-block">Location (Country, state)</label>
   <div class="input-group mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/location.png"></span>
   <input type="text" class="form-control reg-location" id="reg-location" placeholder="Location">
  </div>  
     
  <label class="d-block">Date of Birth</label>
      <div class="input-group mb-2">
     <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/calendar.png"></span>
   <input type="date" class="form-control reg-birth" id="reg-birth" placeholder="Date of birth">
   </div>
     <label class="d-block">Choose a Password</label> 
     <div class="input-group mb-2">
       <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/pass.png"></span>
     <input class="form-control reg-password" type="text" id="reg-password" placeholder="Choose a password">
   </div>   
     
  <div id="reg-captcha-container" class="mt-2" style="display: none;">   
 <div class="form-text">Verification code</div>
   <div id="reg-captcha-text"></div>      
         
     <div class="input-group mt-1 mb-3">
    <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/lock.png"></span>
  <input class="form-control" type="text" id="reg-captcha" placeholder="Enter code">  
 </div>
  </div>
     
    <div class="register-btn-container mb-3">
      <div class="form-text mb-2">
        By clicking on sign up button implies that you accepted our <a href="javascript:void(0);" onclick="loadPrivacyTerms();">Privacy policy</a>
      </div>
      <button id="register-btn" class="register-btn btn btn-sm btn-info">Sign Up <div id="reg-loader" class="loader loader1"><div class="spin"></div></div> </button>
      </div>
    
    <div id="show-signin-form" data-page="login-form-container" class="form-page-switch text-center">
    Already have an account? Sign In 
    </div>
    
    </div>
   </div>
   </div>    
    
    <!--FORGOT PASSWORD-->
    
  <div id="fpwrd-form-container" class="form-page form-container">

       <div class="form-title-container">
      	<div class="container">
    	<div class="row">
    	<div class="col-5  form-page-switch" data-page="login-form-container">
      <img class="w-30 h-30" src="<?php echo theme_path(); ?>/assets/chat-icons/back.png">
      </div>
      <div class="col-7 text-right">
 	<div class="form-title"></div>
  </div>
  </div>
 </div>
 </div>
 
   <div class="fpwrd-form-container">
   <div class="fpwrd-form">
  
   <div class="input-group mb-1">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/email.png"></span>
   <input type="email" class="form-control fpwrd-email" id="fpwrd-email" placeholder="Your email address">
  </div>    
 <button id="send-fpwrd-code-btn" class="btn btn-sm btn-secondary" style="margin-top: 7px;">Request reset code</button>

  <div class="input-group mt-2 mb-2">
  <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/code.png"></span>
   <input type="text" id="fpwrd-code" class="form-control" placeholder="Enter code">
     </div>
  
  <div class="input-group mb-2">
       <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/pass.png"></span>
   <input type="text" id="fpwrd-password" class="form-control" placeholder="New password">
 </div> 
  <button id="reset-password-btn" class="btn btn-sm btn-primary" style="margin-top: 7px;">Confirm</button>
       
     </div>
      </div>
    </div>
    
  <!--Register verify email-->
 <div id="vemail-form-container" class="form-page form-container">
   

    <div class="form-title-container">
      	<div class="container">
    	<div class="row">
    	<div class="col-5  form-page-switch" data-page="login-form-container">
      <img class="w-30 h-30" src="<?php echo theme_path(); ?>/assets/chat-icons/back.png">
      </div>
      <div class="col-7 text-right">
 	<div class="form-title"></div>
  </div>
  </div>
 </div>
 </div>
 
     
   <div class="vemail-form-container">
   <div class="vemail-form">
  
     <div id="resend-code-btn" style="color: #3535e5;">
         <img class="w-16 h-16" src="<?php echo theme_path(); ?>/assets/chat-icons/resend.png"> Resend code
      </div>
     
   <div class="input-group mb-1">
       <span class="input-group-text" id="basic-addon1"> <img class="h-20 w-20" src="<?php echo theme_path(); ?>/assets/chat-icons/code.png"></span>
   <input class="form-control" type="text" id="verification-code" placeholder="Verification code" maxlength="20">
     </div>  
    <input type="hidden" id="verification-email" value="">
     <div class="row">
      <div class="col text-right">
       <button id="verify-code-btn" class="btn btn-sm btn-primary">VERIFY</button>
    </div>
    </div>
    
    </div>
   </div>
  </div>
     
  </body>
  
</html>
