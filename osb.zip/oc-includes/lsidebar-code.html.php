<!--Left side bar-->
<!--Add html, Javascript , Php e.t.c here-->

<div class="container-fluid mt-3 go-open-profile" data-user="cv_askaquestion" data-user-fullname="Ask a question">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px; color: #333;">
   <i class="fa fa-question menu-icon"></i>
    </div>
  <div class="col p-0">
    <span style="color: #485960;">Ask a question</span>
  </div>
  </div>
  </div>

<div class="container-fluid mt-3 go-open-profile" data-user="cv_aboutus" data-user-fullname="About us">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px; color: #333;">
   <i class="fa fa-info menu-icon"></i>
    </div>
  <div class="col p-0">
    <span style="color: #485960;">About Us</span>
  </div>
  </div>
  </div>

<div class="container-fluid mt-3 go-open-profile" data-user="cv_contact" data-user-fullname="Contact us">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
   <img class="menu-icon" src="<?php echo theme_path(); ?>/assets/go-icons/contact.png">
    </div>
  <div class="col p-0">
    <span style="color: #485960;">Contact Us</span>
  </div>
  </div>
  </div>

<div class="container-fluid mt-3 go-open-profile" data-user="cv_reportbug" data-user-fullname="Report a bug">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px; color: #333;">
   <i class="fa fa-bug menu-icon"></i>
    </div>
  <div class="col p-0">
    <span style="color: #485960;">Report a bug</span>
  </div>
  </div>
  </div>