<script type="text/javascript">
/*
  var uid = '451860';
   var wid = '678126';
   var pop_tag = document.createElement('script');pop_tag.src='//cdn.popcash.net/show.js';document.body.appendChild(pop_tag);
   pop_tag.onerror = function() {pop_tag = document.createElement('script');pop_tag.src='//cdn2.popcash.net/show.js';document.body.appendChild(pop_tag)};
*/
</script>

<!--
<script type="text/javascript" src="https://udbaa.com/bnr.php?section=General&pub=783813&format=468x60&ga=g"></script>
<noscript><a href="https://yllix.com/publishers/783813" target="_blank"><img src="//ylx-aff.advertica-cdn.com/pub/468x60.png" style="border:none;margin:0;padding:0;vertical-align:baseline;" alt="ylliX - Online Advertising Network" /></a></noscript>
-->

<!-- Default Statcounter code for OSB Social
https://osbsocial.com.ng -->
<script type="text/javascript">
var sc_project=12833443; 
var sc_invisible=1; 
var sc_security="64fa0a43"; 
</script>
<script type="text/javascript"
src="https://www.statcounter.com/counter/counter.js"
async></script>
<noscript><div class="statcounter"><a title="Web Analytics"
href="https://statcounter.com/" target="_blank"><img
class="statcounter"
src="https://c.statcounter.com/12833443/0/64fa0a43/1/"
alt="Web Analytics"
referrerPolicy="no-referrer-when-downgrade"></a></div></noscript>
<!-- End of Statcounter Code -->