<meta name="google-site-verification" content="6yfaL53PNk3puKlWE-LWbjVyesgrd_fr-BXYDeNdaNc" />
<meta name="google-site-verification" content="vAiifL9wP4cQnh39MjPTu-piUzF51aBribbAy0aJFgk" />
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8869250168024061"
     crossorigin="anonymous"></script>