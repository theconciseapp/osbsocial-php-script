<?php function sendPrivateMessages($message_id, $message_to, $pstmt) 
  {
    $result = array(
        "result"        => "",
    );
    $REZ    = "{$message_id}|{$message_to} ";
    if ($pstmt && $pstmt->execute()) 
      {
        $result["result"]        = $REZ;
      }
    return $result;
  }
function sendGroupMessages($message_id, $message_from, $message_to, $gstmt) 
  {
    $result    = array(
        "status"           => "",
        "group"           => $message_to,
        "result"           => "",
        "invalid_groups"           => "",
        "lock_status"           => ""
    );
    $gdir      = getGroupDir($message_to);
    $REZ       = "{$message_id}|{$message_to} ";
    $is_locked = false;
    if ($message_to != "gv_pofficials" && !is_dir($gdir)) 
      {
        //If group doesn't exist, remove from app
        //to prevent user from sending again.
        //Fake message sent
        // $result["invalid_groups"]=$message_to;
        $result["result"]           = $REZ;
        return $result;
      }
    else if (file_exists($gdir . '/lock.md')) 
      {
        $admins    = file_get_contents($gdir . '/lock.md');
        //Only group admins can send message
        if (!preg_match("/\b{$message_from}\b,/", $admins)) 
          {
            $result["result"]           = $REZ;
            $result["lock_status"]           = $message_to;
            $is_locked = true;
          }
      }
    if ($is_locked) 
      {
        $result["result"]           = $REZ;
        return $result;
      }
    if ($gstmt && $gstmt->execute()) 
      {
        $result["result"] = $REZ;
      }
    return $result;
  }
function sendMessage($conn, $msg_datas, $chat_from, $version     = "") 
  {
    // massMessageTest( $conn, "", "uv_oluwaseyi", 100);
    $chat_time   = time();
    $success     = $message     = $message_to  = $inv_groups  = $lock_status = "";
    $gtable      = _TABLE_GROUPS_ . '_messages';
    //PREPARE GROUP/PAGE MESSAGES
    $gstmt       = $conn->prepare("INSERT INTO $gtable ( message_id, message_time,message_from, message_to, message_preview, message, meta, date_time)  VALUES(?,?,?,?,?,?,?, NOW() )");
    $gstmt->bind_param('iisssss', $message_id, $message_time, $message_from, $message_to, $message_preview, $message, $meta);
    //PREPARE PRIVATE MESSAGE STMT
    $ptable = _TABLE_PRIVATE_MESSAGES_;
    $pstmt  = $conn->prepare("INSERT INTO $ptable ( message_id, message_time,message_from, message_to, message_preview, message, meta, date_time)  VALUES(?,?,?,?,?,?,?, NOW() )");
    $pstmt->bind_param('iisssss', $message_id, $message_time, $message_from, $message_to, $message_preview, $message, $meta);
    foreach ($msg_datas AS $messageData) 
      {
        $ddata           = $messageData;
        //stripslashes( $messageData);
        $data            = json_decode($ddata);
        if ($data && $data != $ddata) 
          {
            $message_id      = $data->message_id;
            $message         = $data->message;
            $message_preview = $data->message_preview;
            $message_from    = $data->message_from;
            $message_to      = $data->message_to;
            $message_time    = $data->message_time;
            $meta            = json_encode($data->meta);
            //   $mtime           = (microtime(true) * 10000) + $add_to_mtime;
            if (is_group_page($message_to)) 
              {
                //SEND GROUP/PAGE MESSAGES
                $gresult         = sendGroupMessages($message_id, $message_from, $message_to, $gstmt);
                $success.= $gresult["result"];
                $inv_groups.= $gresult["invalid_groups"];
                $lock_status.= $gresult["lock_status"];
              }
            else if (!empty($message_to) && validChatId($message_id)) 
              {
                //SEND PRIVATE MESSAGE
                $presult = sendPrivateMessages($message_id, $message_to, $pstmt);
                $success.= $presult["result"];
              }
            else
              {
                //Fake sent message
                $success.= "{$message_id}|{$message_to} ";
              }
          }
      }
    if ($gstmt) $gstmt->close();
    if ($pstmt) $pstmt->close();
    if (!empty($success)) 
      {
        die(json_encode(["status" => "success", "result" => trim($success) , "invalid_groups" => $inv_groups, "lock_status" => $lock_status]));
      }
    else
      {
        die('{"error":"Sending failed.","invalid_groups":"' . $inv_groups . '"}');
      }
  }
function fetchPrivateMessages($conn, $message_to) 
  {
    $result = array();
    if (!isset($_POST["last_message_id"])) 
      {
        return $result();
      }
    $table   = _TABLE_PRIVATE_MESSAGES_;
    if ($_POST["last_message_id"] == "fresh") 
      {
        $mresult = mysqli_query($conn, "SELECT id FROM $table ORDER BY id DESC LIMIT 1");
        if (!$mresult) 
          {
            return $result;
          }
        $mrow    = mysqli_fetch_row($mresult);
        $lastmid = array(
            "private_fresh_id"         => 1,
            "last_private_message_id"         => (!empty($mrow[0]) ? $mrow[0] : 0)
        );
        $result[]         = $lastmid;
        return $result;
      }
    else
      {
        $lm_id = $_POST["last_message_id"];
        if (!is_numeric($lm_id)) 
          {
            return $result;
          }
      }
    $stmt = $conn->prepare("SELECT id, message_id, message_time, message_from, message_to, message_preview, message, meta, date_time FROM {$table} WHERE  id>? AND message_to=? ORDER BY id ASC LIMIT 60");
    if (!$stmt || !$stmt->bind_param('is', $lm_id, $message_to) || !$stmt->execute()) 
      {
        return $result;
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total_messages = $res->num_rows;
    if ($total_messages < 1) 
      {
        return $result;
      }
    while ($row = $res->fetch_assoc()) 
      {
        $result[]     = $row;
      }
    return $result;
  }
function sendMessagesReports($conn) 
  {
    $reports  = $dreports = $rreports = "";
    if (!empty($_POST["mark_as_delivered"])) 
      {
        $dreports = test_input($_POST["mark_as_delivered"]);
      }
    if (!empty($_POST["mark_as_read"])) 
      {
        $rreports = test_input($_POST["mark_as_read"]);
      }
    $reports  = trim($dreports . " " . $rreports);
    if (empty($reports)) 
      {
        return "";
      }
    $table       = _TABLE_PRIVATE_MESSAGES_RECEIPTS_;
    $exp_reports = explode(" ", $reports);
    $results     = "";
    $time        = time();
    // $mtime       = (microtime(true) * 10000);
    $stmt        = $conn->prepare("INSERT INTO $table ( receipt_from, receipt_to, receipt, receipt_time, date_time)  VALUES(?, ?, ?, ?, NOW() )");
    $stmt->bind_param('sssi', $receipt_from, $receipt_to, $receipt, $time);
    if ($stmt) 
      {
        // $conn->query("START TRANSACTION");
        foreach ($exp_reports AS $report) 
          {
            $rep          = explode("-", $report);
            $receipt_to   = $rep[0];
            $receipt_from = $rep[1];
            $receipt      = $rep[2];
            $time         = $time;
            if ($stmt->execute()) 
              {
                $results.= $report . " ";
              }
          }
        $stmt->close();
      }
    //$conn->query("COMMIT");
    return trim($results);
  }
function fetchReceipts($conn, $receipt_to) 
  {
    $result = array();
    if (!isset($_POST["last_receipt_id"])) 
      {
        return $result;
      }
    $table   = _TABLE_PRIVATE_MESSAGES_RECEIPTS_;
    if ($_POST["last_receipt_id"] == "fresh") 
      {
        $mresult = mysqli_query($conn, "SELECT id FROM $table ORDER BY id DESC LIMIT 1");
        if (!$mresult) 
          {
            return $result;
          }
        $mrow    = mysqli_fetch_row($mresult);
        $lastrid = array(
            "receipt_fresh_id"         => 1,
            "last_receipt_id"         => (!empty($mrow[0]) ? $mrow[0] : 0)
        );
        $result[]         = $lastrid;
        return $result;
      }
    $rid = $_POST["last_receipt_id"];
    if (!is_numeric($rid)) return $result;
    $stmt = $conn->prepare("SELECT id, receipt_from, receipt_to, receipt, receipt_time FROM {$table} WHERE id>? AND receipt_to=? ORDER BY id ASC LIMIT 10");
    if (!$stmt || !$stmt->bind_param('is', $rid, $receipt_to) || !$stmt->execute()) 
      {
        return $result;
      }
    $res = $stmt->get_result();
    $stmt->close();
    if ($res->num_rows < 1) 
      {
        return $result;
      }
    while ($row = $res->fetch_assoc()) 
      {
        $result[]     = $row;
      }
    return $result;
  }
function getMessage($conn, $settings, $ajgroups, $app_upgrade_data = null) 
  {
    //massMessageTest( $conn,  $message="Great","av_official", 100, "unique");
    $friends_typing   = $getMessage       = "";
    $message_to       = test_input(strtolower($_POST['username']));
    $udir             = getUserDir($message_to);
    //SEND MESSAGES RECEIPTS
    $sent_reports     = sendMessagesReports($conn);
    //FETCH PRIVATE MESSAGES
    $private_messages = fetchPrivateMessages($conn, $message_to);
    //FETCH GROUP MESSAGES & OTHER INFOS
    $group_datas      = groupMessages($conn, $message_to);
    $group_messages   = $group_datas["group_messages"];
    //FETCH DELIVERED, READ MESSAGES
    $receipts         = fetchReceipts($conn, $message_to);
    $conn->close();
    $rgroup         = $group_datas["invalid_groups"];
    $glock_status   = $group_datas["glock_status"]; //Group lock status
    $mt             = $group_datas["members_typing"];
    //FETCH LAST SEEN OF FRIEND
    $lastSeen       = @lastSeen();
    //Check who is typing message
    $friends_typing = trim($mt . "\n" . friendTyping($udir));
    $mem            = "";
    // $mem= formatBytes( memory_get_peak_usage() );
    $mtime          = (microtime(true) * 10000);
    return (object)["private_messages"                => $private_messages, "group_messages"                => $group_messages, "invalid_groups"                => $rgroup, "glock_status"                => $glock_status, "sent_reports"                => $sent_reports, "delivery_read_report"                => $receipts, "friend_last_seen"                => $lastSeen, "typing"                => $friends_typing, "auto_join_groups"                => $ajgroups, "status"                => "success", "settings"                => $settings, "current_time"                => time() , "current_mtime"                => $mtime, "app_upgrade_data"                => $app_upgrade_data, "memory_consumption"                => $mem];
  }
//Friends typing...
function friendTyping($udir) 
  {
    $typ_file       = $udir . "/friends_typing.txt";
    $friends_typing = "";
    if (file_exists($typ_file)) 
      {
        $friends_typing = trim(@file_get_contents($typ_file));
        //unlink( $typ_file );
        
      }
    return $friends_typing;
  }
//RETURN LAST SEEN OF FRIEND
function lastSeen() 
  {
    $data      = $last_seen = "";
    if (!empty($_POST['check_lastseen'])) 
      {
        $friend    = test_input($_POST['check_lastseen']);
        $lsfile    = getUserDir($friend) . "/lastseen.txt";
        if (file_exists($lsfile)) 
          {
            $ls        = file_get_contents($lsfile);
            $last_seen = $friend . '|' . trim($ls) . '|' . time();
          }
      }
    return $last_seen;
  }
//UPDATE USER LASTSEEN (i.e. update user online status) & IS TYPING TO
function updateLastSeen() 
  {
    //Return empty if app is minimised
    if (!empty($_POST['app_minimized'])) 
      {
        return "";
      }
    $chat_to = strtolower(test_input($_POST['username']));
    $dir     = getUserDir($chat_to);
    $lsfile  = "{$dir}/lastseen.txt";
    if (!empty($_POST['update_lastseen']) && is_dir($dir)) 
      {
        file_put_contents($lsfile, time());
      }
    if (empty($_POST['typing_to'])) 
      {
        return;
      }
    $typing_to = strtolower(test_input($_POST['typing_to']));
    if ($typing_to == 'uv_private') 
      {
        return;
      }
    $mtyping = "";
    $tdir    = getUserDir($typing_to);
    if (is_group_page($typing_to)) 
      {
        return;
        $mtyping = "|" . $chat_to;
        $chat_to = $typing_to;
        $tdir    = getGroupDir($typing_to);
      }
    if (!is_dir($tdir)) return;
    $file = $tdir . "/friends_typing.txt";
    $data = $chat_to . '|' . time() . $mtyping . "\n";
    //Save only the latest typer
    @file_put_contents($file, $data, LOCK_EX);
  }
function saveBase64Image($base64, $destination, $new_width     = 300) 
  {
    $im            = imagecreatefromstring($base64);
    $source_width  = imagesx($im);
    $source_height = imagesy($im);
    $ratio         = $source_height / $source_width;
    if ($source_width > 500 && $source_width <= 1000) 
      {
        $new_width     = $source_width;
      }
    else if ($source_width > 1000) 
      {
        $new_width     = 1000;
      }
    $new_height    = $ratio * $new_width;
    $thumb         = imagecreatetruecolor($new_width, $new_height);
    $transparency  = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
    imagefilledrectangle($thumb, 0, 0, $new_width, $new_height, $transparency);
    imagecopyresampled($thumb, $im, 0, 0, 0, 0, $new_width, $new_height, $source_width, $source_height);
    $result = imagejpeg($thumb, $destination, 100);
    imagedestroy($im);
    if ($result) return [$new_width, $new_height];
    else return false;
  }
function resizeImagexxx($source, $dest, $new_width, $force_height = false) 
  {
    list($width, $height)               = getimagesize($source);
    $ratio        = $height / $width;
    if ($width < $new_width) $new_width    = $width;
    $new_height   = $ratio * $new_width;
    if ($force_height) $new_height   = $force_height;
    $image_p      = imagecreatetruecolor($new_width, $new_height);
    $image        = imagecreatefromjpeg($source);
    imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    $result = imagejpeg($image_p, $dest, 100);
    imagedestroy($image_p);
    return $result;
  }
function resizeImage($source, $dest, $new_width, $force_height = false, $keep_ratio   = false, $base64       = false) 
  {
    if ($keep_ratio) 
      {
        //imagecopyresampled( $image_p, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height );
        return square_thumbnail($source, $dest, $new_width, 90, $base64);
      }
    list($width, $height)               = getimagesize($source);
    $ratio        = $height / $width;
    if ($width < $new_width) 
      {
        $new_width    = $width;
      }
    $new_height   = $ratio * $new_width;
    if ($force_height) 
      {
        $new_height   = $force_height;
      }
    $smallestSide = min($height, $width);
    $src          = imagecreatefromstring(file_get_contents($source));
    // $src=imagecreatefromjpeg($source);
    $image_p      = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($image_p, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    $result = imagejpeg($image_p, $dest, 90);
    imagedestroy($image_p);
    $file_path = str_replace(_CHAT_FILES_DIR_, _CHAT_FILES_PATH_, $dest);
    if ($result) 
      {
        return ["file_path" => $file_path, "width" => $new_width, "height" => $new_height, "saved_to" => $dest];
      }
    else return false;
  }
function createThumbnail($source, $destination, $width                          = 100, $height                         = 0) 
  {
    resizeImage($source, $destination, $width, $height);
  }
function square_thumbnail($source, $destination_file, $square_dimensions, $jpeg_quality                   = 90, $base64                         = false) 
  {
    // Step one: Rezise with proportion the src_file *** I found this in many places.
    if ($base64) 
      {
        $src_img                        = imagecreatefromstring($source);
      }
    else
      {
        $src_img                        = imagecreatefromstring(file_get_contents($source));
      }
    //imagecreatefromjpeg($src_file);
    $old_x                          = imageSX($src_img);
    $old_y                          = imageSY($src_img);
    $ratio1                         = $old_x / $square_dimensions;
    $ratio2                         = $old_y / $square_dimensions;
    if ($ratio1 > $ratio2) 
      {
        $thumb_w                        = $square_dimensions;
        $thumb_h                        = $old_y / $ratio1;
      }
    else
      {
        $thumb_h                        = $square_dimensions;
        $thumb_w                        = $old_x / $ratio2;
      }
    // we create a new image with the new dimmensions
    $smaller_image_with_proportions = ImageCreateTrueColor($thumb_w, $thumb_h);
    // resize the big image to the new created one
    imagecopyresampled($smaller_image_with_proportions, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);
    // *** End of Step one ***
    // Step Two (this is new): "Copy and Paste" the $smaller_image_with_proportions in the center of a white image of the desired square dimensions
    // Create image of $square_dimensions x $square_dimensions in white color (white background)
    $final_image = imagecreatetruecolor($square_dimensions, $square_dimensions);
    imagealphablending($final_image, false);
    $bg = imagecolorallocatealpha($final_image, 255, 255, 255, 127);
    imagefilledrectangle($final_image, 0, 0, $square_dimensions, $square_dimensions, $bg);
    imagealphablending($final_image, true);
    // need to center the small image in the squared new white image
    if ($thumb_w > $thumb_h) 
      {
        // more width than height we have to center height
        $dst_x = 0;
        $dst_y = ($square_dimensions - $thumb_h) / 2;
      }
    elseif ($thumb_h > $thumb_w) 
      {
        // more height than width we have to center width
        $dst_x = ($square_dimensions - $thumb_w) / 2;
        $dst_y = 0;
      }
    else
      {
        $dst_x = 0;
        $dst_y = 0;
      }
    $src_x = 0; // we copy the src image complete
    $src_y = 0; // we copy the src image complete
    $src_w = $thumb_w; // we copy the src image complete
    $src_h = $thumb_h; // we copy the src image complete
    $pct   = 100; // 100% over the white color ... here you can use transparency. 100 is no transparency.
    imagecopymerge($final_image, $smaller_image_with_proportions, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct);
    $result = imagejpeg($final_image, $destination_file, $jpeg_quality);
    // destroy aux images (free memory)
    imagedestroy($src_img);
    imagedestroy($smaller_image_with_proportions);
    imagedestroy($final_image);
    $file_path = str_replace(_CHAT_FILES_DIR_, _CHAT_FILES_PATH_, $destination_file);
    if ($result) 
      {
        return ["file_path" => $file_path, "width" => $src_w, "height" => $src_h, "saved_to" => $destination_file];
      }
    else return false;
  }
function masterImageUpload($source, $filename        = "", $options         = array()) 
  {
    $thumb_width     = false;
    $resize_image    = false;
    $base64          = true;
    $direct_filename = false;
    $folder          = "images/" . _CHAT_FILES_STRUCTURE_;
    $dest_dir        = _CHAT_FILES_DIR_ . "/{$folder}";
    if (empty($filename)) 
      {
        $filename        = randomString(10);
      }
    if (isset($options["thumb_width"])) 
      {
        $thumb_width     = (int)$options["thumb_width"];
      }
    if (isset($options["resize"])) 
      {
        $resize_image    = (int)$options["resize"]; //Same as width
        
      }
    if (isset($options["base64"])) 
      {
        $base64          = $options["base64"];
      }
    if (isset($options["dir"])) 
      {
        $dest_dir        = $options["dir"];
      }
    if (isset($options["folder"])) 
      {
        $folder          = $options["folder"];
      }
    if (isset($options["direct_filename"])) 
      {
        $direct_filename = $options["direct_filename"];
      }
    function upload_base64_image($source, $dest_dir, $filename        = "", $direct_filename = false) 
      {
        list($width, $height)                  = getimagesizefromstring($source);
        if ($direct_filename) 
          {
            $filename        = "{$filename}.jpg";
          }
        else
          {
            $filename        = "{$filename}.jpg";
          }
        $destination     = $dest_dir . "/" . $filename;
        if (file_put_contents($destination, $source)) 
          {
            $file_path       = str_replace(_CHAT_FILES_DIR_, _CHAT_FILES_PATH_, $destination);
            return ["saved_to"                 => $destination, "filename"                 => $filename, "file_path"                 => $file_path, "width"                 => $width, "height"                 => $height];
          }
      }
    function resize_base64_image($source, $dest_dir, $filename        = "", $new_width       = 300, $direct_filename = false) 
      {
        $im              = imagecreatefromstring($source);
        $source_width    = imagesx($im);
        $source_height   = imagesy($im);
        $ratio           = $source_height / $source_width;
        if ($source_width > 500 && $source_width <= 600) 
          {
            $new_width       = $source_width;
          }
        else if ($source_width > 600) 
          {
            $new_width       = 600;
          }
        $new_height      = ceil($ratio * $new_width);
        $thumb           = imagecreatetruecolor($new_width, $new_height);
        $transparency    = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
        imagefilledrectangle($thumb, 0, 0, $new_width, $new_height, $transparency);
        imagecopyresampled($thumb, $im, 0, 0, 0, 0, $new_width, $new_height, $source_width, $source_height);
        if ($direct_filename) 
          {
            $filename    = "{$filename}.jpg";
          }
        else
          {
            $filename    = "{$filename}.jpg";
            //~{$new_width}~{$new_height}~x.jpg";
            
          }
        $destination = "{$dest_dir}/{$filename}";
        $result      = imagejpeg($thumb, $destination, 100);
        imagedestroy($im);
        if ($result) 
          {
            $file_path = str_replace(_CHAT_FILES_DIR_, _CHAT_FILES_PATH_, $destination);
            return ["saved_to"             => $destination, "filename"             => $filename, "file_path"             => $file_path, "width"             => $new_width, "height"             => $new_height];
          }
      }
    if ($base64) 
      {
        if ($resize_image) 
          {
            $result      = resize_base64_image($source, $dest_dir, $filename, $resize_image, $direct_filename);
          }
        else
          {
            $result      = upload_base64_image($source, $dest_dir, $filename, $direct_filename);
          }
      }
    $destination = $file_path   = $thumb_path  = $width       = $height      = "";
    if ($result) 
      {
        $destination = $result["saved_to"];
        $filename    = $result["filename"];
        $file_path   = $result["file_path"];
        $width       = $result["width"];
        $height      = $result["height"];
        if ($thumb_width) 
          {
            $thumb_dir   = "{$dest_dir}/thumbnails";
            make_dir($thumb_dir);
            $thumb_dest = "{$thumb_dir}/{$filename}";
            $thumb_path = _CHAT_FILES_PATH_ . "/{$folder}/thumbnail/{$filename}";
            resizeImage($destination, $thumb_dest, $thumb_width, false, false);
          }
      }
    if ($result) 
      {
        return ["file_path" => $file_path, "thumb_path" => $thumb_path, "folder" => $folder, "width" => $width, "height" => $height, "filename" => $filename, "saved_to" => $destination];
      }
    else return false;
  }
function imageToBase64($filename) 
  {
    if (is_readable($filename)) 
      {
        $filetype  = pathinfo($filename, PATHINFO_EXTENSION);
        $imgbinary = file_get_contents($filename);
        return base64_encode($imgbinary);
      }
    else return "";
  }
