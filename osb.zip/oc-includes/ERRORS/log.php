<?php die('Life is sweet!'); ?>
