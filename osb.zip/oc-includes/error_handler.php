<?php error_reporting(E_ALL);
function myExceptionHandler($e) 
  {
    $file = _ERROR_DIR_ . '/oc-errors.php';
    error_log($e, 3, $file);
    http_response_code(500);
    if (filter_var(ini_get('display_errors') , FILTER_VALIDATE_BOOLEAN)) 
      {
        die('{"error":"' . $e . '"}');
      }
    else
      {
        die('{"error":"<h1>500 Internal Server Error</h1>"}');
      }
  }
set_exception_handler('myExceptionHandler');
set_error_handler(function ($level, $message, $file = '', $line = 0) 
  {
    $msg  = "[ " . date('F j, Y, g:i a e O') . " ]-" . $message;
    throw new ErrorException($msg, 0, $level, $file, $line);
  });
register_shutdown_function(function () 
  {
    $error = error_get_last();
    if ($error !== null) 
      {
        $e     = new ErrorException($error['message'], 0, $error['type'], $error['file'], $error['line']);
        myExceptionHandler($e);
      }
  });
