<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (empty($_POST['code']) || empty($_POST['email']) || !preg_match("/^[0-9a-z]{5,20}/i", $_POST['code'])) 
  {
    die('{"error":"Invalid verification code."}');
  }
else if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
  {
    die('{"error":"Invalid email address."}');
  }
$code  = test_input($_POST['code']);
$email = test_input($_POST['email']);
$time  = time();
require "../oc-includes/server.php";
$table        = _TABLE_USERS_;
$table_tokens = _TABLE_TOKENS_;
$stmt         = $conn->prepare("SELECT token FROM $table_tokens WHERE email =? AND token=? AND expiry_time>? LIMIT 1");
if (!$stmt || !$stmt->bind_param('ssi', $email, $code, $time) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
if ($res->num_rows < 1) 
  {
    $stmt->close();
    $conn->close();
    die('{"error":"Invalid code or expired."}');
  }
$stmt->close();
$stmt = $conn->prepare("UPDATE $table SET user_status='1' WHERE email=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $email) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Verification failed at the moment. Please try again."}');
  }
$stmt->close();
$stmt = $conn->prepare("DELETE FROM $table_tokens WHERE token=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $code) || !$stmt->execute()) 
  {
    logIt('Email verification successful but, could not delete used code from token table');
  }
if ($stmt) $stmt->close();
$table = _TABLE_GROUPS_;
try
  {
    $stmt  = $conn->prepare("UPDATE $table SET total_members=total_members+1 WHERE group_pin='gp_pofficials' LIMIT 1");
    if ($stmt && $stmt->execute()) 
      {
        $stmt->close();
      }
  }
catch(Exception $e) 
  {
    //ignore error
    
  }
$conn->close();
die('{"status":"success","result":"You may login now."}');
