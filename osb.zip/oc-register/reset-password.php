<?php header('Content-type:application/json;charset=utf-8');
if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
  {
    die('{"error":"Invalid email address."}');
  }
else if (empty($_POST['code'])) 
  {
    die('{"error":"You entered an invalid code."}');
  }
else if (empty($_POST['password'])) 
  {
    die('{"error":"Password field is empty."}');
  }
require ('../oc-includes/bootstrap.php');
$code     = test_input($_POST['code']);
$email    = $_POST['email'];
$password = test_input($_POST['password']);
if (!validPassword($password)) 
  {
    die('{"error":"Password can only contain: a-z 0-9 ~@#%_+*?-, Min 6 chars, Max 40 chars."}');
  }
require "../oc-includes/server.php";
$table        = _TABLE_USERS_;
$table_tokens = _TABLE_TOKENS_;
$time         = time();
$stmt         = $conn->prepare("SELECT token FROM $table_tokens WHERE email=? AND token=? AND expiry_time>? LIMIT 1");
if (!$stmt || !$stmt->bind_param('ssi', $email, $code, $time) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Reset unsuccessful. Try again! Err01"}');
  }
$res = $stmt->get_result();
if ($res->num_rows < 1) 
  {
    $stmt->close();
    $conn->close();
    die('{"error":"Code not found or might have expired."}');
  }
$stmt->close();
$password = password_hash($password, PASSWORD_DEFAULT);
$stmt     = $conn->prepare("UPDATE $table SET password=? WHERE email=? LIMIT 1");
if ($stmt && $stmt->bind_param('ss', $password, $email) && $stmt->execute()) 
  {
    $stmt->close();
    $stmt = $conn->prepare("DELETE FROM $table_tokens WHERE token=? LIMIT 1");
    if (!$stmt || !$stmt->bind_param('s', $code) || !$stmt->execute()) 
      {
        logIt('reset_password.php: Reset successful but coul not delete reset token from database');
      }
    $stmt->close();
    $conn->close();
    die('{"status":"success","result":"Password changed succesfully."}');
  }
$conn->close();
die('{"error":"Password could not be changed. Please try again."}');
