<?php header('Content-type:application/json;charset=utf-8');
if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
  {
    die('{"error":"Invalid email address."}');
  }
require ('../oc-includes/bootstrap.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require "../oc-includes/server.php";
$table = _TABLE_USERS_;
$email = test_input($_POST['email']);
$stmt  = $conn->prepare("SELECT id FROM $table WHERE email=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $email) || !$stmt->execute()) 
  {
    die('{"error":"Please try again."}');
  }
$res = $stmt->get_result();
if ($res->num_rows < 1) 
  {
    $stmt->close();
    $conn->close();
    die('{"error":"Email address is not registered."}');
  }
if ($token = createToken($conn, $email, 15)) 
  {
    $stmt->close();
    $conn->close();
    sendPasswordResetCode($email, $token);
    die('{"status":"success","result":"A code has been sent to your email address. Check your inbox or spam."}');
  }
$stmt->close();
$conn->close();
die('{"error":"Reset code not sent."}');
