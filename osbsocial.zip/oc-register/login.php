<?php if (!isset($_SESSION)) 
  {
    session_start();
  }
header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['version'])) 
  {
    die('{"error":"One or more fields are empty."}');
  }
$settings__        = getSettings();
$login_status      = isset($settings__["enable_login"]) ? $settings__["enable_login"] : 'YES';
$manual_activation = isset($settings__["enable_manual_activation"]) ? $settings__["enable_manual_activation"] : 'NO';
$username          = test_input(strtolower($_POST['username']));
$admin             = site_admin($username);
if (!$admin && $login_status != 'YES') 
  {
    die('{"error":"Login temporarily unavailable"}');
  }
$password = test_input($_POST['password']);
$version  = test_input($_POST['version']);
if (!validUsername($username, true) && !filter_var($username, FILTER_VALIDATE_EMAIL)) 
  {
    die('{"error":"Invalid username or password"}');
  }
else if (strlen($password) < 6) 
  {
    die('{"error":"Invalid username or password."}');
  }
else if (!validPassword($password)) 
  {
    die('{"error":"Invalid username or password"}');
  }
require "../oc-includes/server.php";
$status = '1';
$table  = _TABLE_USERS_;
$stmt   = $conn->prepare("SELECT username, email,fullname, phone, country, bio, birth, added_on AS joined, groups, password, user_status FROM $table WHERE username=? OR email =? LIMIT 1");
if (!$stmt || !$stmt->bind_param('ss', $username, $username) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"Login failed. Try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    $conn->close();
    die('{"error":"Invalid Username or Password"}');
  }
//fetch DB results
$row         = $res->fetch_assoc();
$fullname    = $row["fullname"];
$username_   = $row["username"];
$email       = $row["email"];
$pwrd        = $row["password"];
$user_status = $row["user_status"];
if (!password_verify($password, $pwrd)) 
  {
    $conn->close();
    die('{"error":"Invalid Username or Password."}');
  }
else if ($user_status == '0') 
  {
    if ($manual_activation == 'YES') 
      {
        $conn->close();
        die('{"require_mverification":"Your account is awaiting activation. Kindly be patient.","email":"' . $email . '"}');
      }
    else
      {
        $conn->close();
        die('{"require_verification":"Check your email address inbox or spam for your activation code.","email":"' . $email . '"}');
      }
  }
else if ($user_status == '-1') 
  {
    $conn->close();
    die('{"error":"This account is not accessible at the moment."}');
  }
session_destroy();
//Create a hash and save on server in a file and client browser. Which is to be verified on each call to the server from client
$udir       = getUserDir($username_);
if (makeUserDir($username)) 
  {
    $uniq_id    = uniqid();
    $token      = password_hash($uniq_id, PASSWORD_DEFAULT, ['cost'            => '7']);
    $secureFile = $udir . "/secure__.php";
    if (!$token) 
      {
        $conn->close();
        die('{"error":"Unable to generate token."}');
      }
    $exit_              = "<?php die('Life is sweet!');?>";
    $generate_new_token = true;
    /*
    if( @is_readable( $secureFile ) ){
    $token=@file_get_contents( $secureFile);
    
    if( !empty( $token ) ){
    
    $token=str_replace( $exit_, "", $token );
    $generate_new_token= false;
    }
    }
    */
    if ($generate_new_token && file_put_contents($secureFile, $exit_ . $token) === FALSE) 
      {
        $conn->close();
        die('{"error":"Unable to generate token."}');
      }
    $currenttime     = (microtime(true) * 10000);
    //In microseconds
    //Get official group last message id
    $lastmtime       = "" . ($currenttime - 1); //Useful for first time logger
    $sync_contacts   = $lastprivatemid  = $lastofficialmid = "";
    if (empty($_POST['last_private_mid'])) 
      {
        //Fetch Last private message id in database
        $table_messages  = _TABLE_PRIVATE_MESSAGES_;
        $mresult         = mysqli_query($conn, "SELECT id FROM $table_messages ORDER BY id DESC LIMIT 1");
        if (!$mresult) 
          {
            die('{"error":"Please try again"}');
          }
        $mrow           = mysqli_fetch_row($mresult);
        $lastprivatemid = (!empty($mrow[0]) ? $mrow[0] : 0);
        sendWelcomeMessage($conn, $username, $fullname);
      }
    if (empty($_POST['last_official_mid'])) 
      {
        //Fetch Last official message id in database
        $table_gmessages = _TABLE_GROUPS_MESSAGES_;
        $mresult         = mysqli_query($conn, "SELECT id FROM $table_gmessages ORDER BY id DESC LIMIT 1");
        if (!$mresult) 
          {
            die('{"error":"Please try again."}');
          }
        $mrow            = mysqli_fetch_row($mresult);
        $lastofficialmid = (!empty($mrow[0]) ? $mrow[0] : 0);
      }
    $contacts_file   = getUserDir($username) . "/contacts.txt";
    if (file_exists($contacts_file)) 
      {
        $sync_contacts   = file_get_contents($contacts_file);
      }
    $row["status"]                 = "success";
    $row["server_settings"]                 = getSettings();
    $row["sync_contacts"]                 = $sync_contacts;
    $row["token"]                 = $token;
    $row["official_lmtime"]                 = $lastmtime;
    $row["last_official_mid"]                 = $lastofficialmid;
    $row["last_private_message_id"]                 = $lastprivatemid;
    $row["login_time_micro"]                 = $currenttime;
    $row["password"]                 = "";
    setcookie("OSB__TOKEN__", $token, time() + (86400 * 30) , "/");
    setcookie("OSB__USERNAME__", $username, time() + (86400 * 30) , "/");
    $conn->close();
    die(json_encode($row));
  }
else
  {
    $conn->close();
    die('{"error":"Could not log you in at the moment."}');
  }
$conn->close();
die('{"error":"An error occured."}');
