<?php $status  = $_SERVER['REDIRECT_STATUS'];

$codes   = array(

    403         => array(

        '403 Forbidden',

        'The server has refused to fulfill your request.'

    ) ,

    404         => array(

        '404 Not Found',

        'The document/file requested was not found on this server.'

    ) ,

    405         => array(

        '405 Method Not Allowed',

        'The method specified in the Request-Line is not allowed for the specified resource.'

    ) ,

    408         => array(

        '408 Request Timeout',

        'Your browser failed to send a request in the time allowed by the server.'

    ) ,

    418         => array(

        '408 Request Timeout',

        'Your browser failed to send a request in the time allowed by the server.'

    ) ,

    500         => array(

        '500 Internal Server Error',

        'The request was unsuccessful due to an unexpected condition encountered by the server.'

    ) ,

    502         => array(

        '502 Bad Gateway',

        'The server received an invalid response from the upstream server while trying to fulfill the request.'

    ) ,

    504         => array(

        '504 Gateway Timeout',

        'The upstream server failed to send a request in the time allowed by the server.'

    ) ,

);

$title   = $codes[$status][0];

$message = $codes[$status][1];

if ($title == false || strlen($status) != 3) 

  {

    $message = 'Please supply a valid status code.';

  } ?>

<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no,user-scalable=0">
<title>Error!</title> 

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<style>

body {
  background-color: #95c2de;
}

.mainbox {
  background-color: #95c2de;
  margin: auto;
  height: 600px;
  width: 600px;
  position: relative;
}

  .err {
    color: #ffffff;
    font-family: 'Nunito Sans', sans-serif;
    font-size: 11rem;
    position:absolute;
    left: 20%;
    top: 8%;
  }

.far {
  position: absolute;
font-size: 8.5rem;
  left: 42%;
  top: 15%;
  color: #ffffff;
}

 .err2 {
    color: #ffffff;
    font-family: 'Nunito Sans', sans-serif;
    font-size: 11rem;
    position:absolute;
    left: 68%;
    top: 8%;
  }

.msg {
    text-align: center;
    font-family: 'Nunito Sans', sans-serif;
    font-size: 1.6rem;
    position:absolute;
    left: 16%;
    top: 45%;
    width: 75%;
}

a {
  text-decoration: none;
  color: white;
}

a:hover {
  text-decoration: underline;
}

.calendar-text { margin-top: .3em; }

</style>
</head>
<body>
<div class="container text-center">
<?php

// Insert headers here

echo "<h1>{$title}</h1>
<p>{$message}</p>";

?>
</div>
</body>
</html>
