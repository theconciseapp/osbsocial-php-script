<?php header('Content-type:application/json;charset=utf-8');

define('setup', 'true');

$error   = $success = "";

if ($_SERVER['REQUEST_METHOD'] != 'POST') 

  {

    die('{"error":"Invalid request."}');

  }

if ( file_exists("../../oc-includes/config.php") ) 

  {

    die('{"error":"Already installed. Delete \"config.php\" to re-install"}');

  }

require "../../oc-includes/bootstrap.php";

if (empty($_POST["database_name"]) || empty($_POST['database_username']) || empty($_POST['database_host']) || empty($_POST['table_prefix'])) 

  {

 die('{"error":"One or more fields are empty"}');

  }

else if (!preg_match("/^[a-z][a-z0-9_-]{0,19}$/i", $_POST['table_prefix'])) 

  {

    die('{"error":"Invalid table prefix. Can only contain alphanumerics, dash and underscore."}');

  }

$dbhost       = test_input($_POST["database_host"]);

$dbname       = test_input($_POST["database_name"]);

$dbuname      = test_input($_POST["database_username"]);

$dbpass       = test_input($_POST["database_password"]);

$table_prefix = test_input(  $_POST["table_prefix"]);

mysqli_report( MYSQLI_REPORT_STRICT | MYSQLI_REPORT_ALL);

try

  {

    if ($conn   = new mysqli($dbhost, $dbuname, $dbpass, $dbname ) ) 

      {

        //Create config file

        if (createConfigFile($dbhost, $dbname, $dbuname, $dbpass, $table_prefix ) ) 

          {

            $sdir   = _PROJECT_DIR_ . "/oc-setup";

            //copy "oc-image404.png" to root folder

            $nopic  = "{$sdir}/migrate-photos/oc-image404.png";

            $copyTo = _ROOT_DIR_ . '/oc-image404.png';

            if (is_file($nopic)) 

              {

                @copy($nopic, $copyTo);

              }

            //copy "oc-image404.php" to root folder

            $nopic  = "{$sdir}/migrate-files/oc-image404.php";

            $copyTo = _ROOT_DIR_ . '/oc-image404.php';

            if (is_file($nopic)) 

              {

                @copy($nopic, $copyTo);

              }

  makeUserDir("av_official");               
  makeUserDir("pv_myfirstpage");
  makeUserDir("cv_drafts");
  makeUserDir("cv_contact");
  makeGroupDir("gv_pofficials");
  makeGroupDir("cv_sponsoredposts");

            $gdir = getGroupDir("gv_pofficials");

            file_put_contents($gdir . "/lock.md", "av_official,");

            $udir   = getUserDir("pv_myfirstpage");

            //Copy pv_myfirstpage profile picture

            $pic    = "{$sdir}/migrate-photos/profile_picture_small.jpg";

            $copyTo = $udir . '/profile_picture_small.jpg';

            if (file_exists($pic)) 

              {

                @copy($pic, $copyTo);

              }

            $pic    = "{$sdir}/migrate-photos/profile_picture_medium.jpg";

            $copyTo = $udir . '/profile_picture_medium.jpg';

            if (file_exists($pic)) 

              {

                @copy($pic, $copyTo);

              }

            $pic    = "{$sdir}/migrate-photos/profile_picture_full.jpg";

            $copyTo = $udir . '/profile_picture_full.jpg';

            if (file_exists($pic)) 

              {

                @copy($pic, $copyTo);

              }

            //pv_myfirstpage first post picture

            $pic    = "{$sdir}/migrate-photos/social.jpg";

            $copyTo = _CHAT_FILES_DIR_ . '/welcome/social.jpg';

            if (file_exists($pic)) 

              {

                @copy($pic, $copyTo);

              }

            $epage  = "{$sdir}/migrate-files/oc-error-page.php";

            $copyTo = _ROOT_DIR_ . "/oc-error-page.php";

            if (file_exists($epage)) 

              {

                @copy($epage, $copyTo);

              }

            if (!file_exists(_PROJECT_DIR_ . "/index.php")  ) 

              {

                file_put_contents(_PROJECT_DIR_ . "/index.php", "#Life is sweet!");

              }

     require "tables.php";

 define("_TABLE_GROUPS_MESSAGES_", $table_prefix.  "groups_messages");

     require "../../oc-ajax/group/group-functions.php";

   $msg     = "Successful installation!";
   $preview = $msg;

        customGroupMessage( $conn , "gp_pofficials" , $preview, $msg);

 }

        else

          {

            $error.= '<div><i class=\"fa fa-warning\"></i> Unable to create "config.php" file.</div>';

          }

      }

  }

catch(mysqli_sql_exception $e) 

  {

    $error.= '<div><i class=\"fa fa-warning\"></i> ' . $e->getMessage() . '</div>';

  }

die('{"result":"' . (!empty($success) ? '<div class=\"text-success\"><b>Success:</b> ' . $success . '</div><div class=\"text-right\"><a href=\"' . _ADMIN_URL_ . '/login.php?fresh=1\" class=\"ml-2 btn btn-sm btn-success\">Next</a></div><br>' : '') . '<div class=\"text-danger\"><b>Errors:</b> ' . $error . '</div>"}');
