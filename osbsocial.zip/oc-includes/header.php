<?php require ('bootstrap.php');
$osb_token    = $osb_username = "";
if (isset($_COOKIE["OSB__TOKEN__"])) 
  {
    $osb_token    = $_COOKIE["OSB__TOKEN__"];
  }
if (isset($_COOKIE["OSB__USERNAME__"])) 
  {
    $osb_username = test_input(strtolower($_COOKIE["OSB__USERNAME__"]));
  }
$rURI_        = explode("?", $_SERVER['REQUEST_URI']);
$rURI         = explode("/", $rURI_[0]);
$scriptName   = explode("/", $_SERVER['SCRIPT_NAME']);
for ($i            = 0;$i < sizeof($scriptName);$i++) 
  {
    if ($rURI[$i] == $scriptName[$i]) 
      {
        unset($rURI[$i]);
      }
  }
$loc              = array_values($rURI);
$total_loc        = count($loc);
$single_post_id   = $load_profile_id  = "";
if (isset($_GET["p"]) && is_numeric($_GET["p"])) 
  {
    $single_post_id   = trim($_GET["p"]);
  }
else if (empty($loc[0])) 
  {
    //Do nothing
    
  }
else if ($loc[0] == "post" && !empty($loc[1])) 
  {
    //It is a single post
    $single_post_id   = $loc[1];
  }
else if (isset($_GET["u"]) && validUsername($_GET["u"])) 
  {
    $load_profile_id  = test_input($_GET["u"]);
  }
else if (validUsername($loc[0])) 
  {
    $load_profile_id  = test_input($loc[0]);
  }
else
  {
    //die("Web page you are looking for does not exist");
    
  }
$settings__       = getSettings();
$force_login      = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
$site_title       = isset($settings__["site_title"]) ? $settings__["site_title"] : "OSB Social";
$site_otagline    = isset($settings__["site_tagline"]) ? $settings__["site_tagline"] : "My OSBs Website";
$site_tagline     = $site_otagline;
$cache_reset      = isset($settings__["cache_reset"]) ? $settings__["cache_reset"] : "0|0";
$cache_reset      = explode("|", $cache_reset);
$cache_reset      = $cache_reset[1];
$content_icon     = _SITE_URL_ . "/oc-logo.png";
$the_post         = $single_post_data = "";
if (!empty($single_post_id)) 
  {
    require ("../oc-ajax/go-social/go-functions.php");
    $_POST["username"]                  = $osb_username;
    $_POST["post_id"]                  = $single_post_id;
    $_POST["load_count"]                  = 0;
    $_POST["token"]                  = $osb_token;
    $single_post_data = home_posts();
    if (isset($single_post_data["result"])) 
      {
        $the_post         = $single_post_data["result"][0];
        $post_preview     = $the_post["post_preview"];
        $post_title       = $the_post["post_title"];
        if (!empty($post_title)) 
          {
            $site_tagline     = $post_title;
          }
        else if (!empty($post_preview)) 
          {
            $site_tagline     = mb_substr($post_preview, 0, 100, "utf-8");
          }
        $post_files       = json_decode($the_post["post_files"], true);
        if (count((array)$post_files) > 0) 
          {
            $first_post_file  = $post_files[0];
            $ext              = $first_post_file["ext"];
            if ($ext == "jpg") 
              {
                $content_icon     = $first_post_file["path"];
              }
            else
              {
                $content_icon     = $first_post_file["poster"];
              }
          }
      }
  }
/*Load Theme*/
require theme_dir() . "/index.php";
