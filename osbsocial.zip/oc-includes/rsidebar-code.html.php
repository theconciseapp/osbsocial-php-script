<!--Right side bar-->
<?php
$counter_file = "oc-contents/stats/visitors-count.txt";
$count        = 1;
if (is_file($counter_file)) 
  {
    $count        = @file_get_contents($counter_file);
    $count        = (int)$count + 1;
  }
file_put_contents($counter_file, $count, LOCK_EX);
?>
