<?php if (!defined('_DEFINED_')) 
  {
    die('{"error":"Error occured. CONFF::NF"}');
  }
define('_TABLE_PREFIX_', 'oc_');
define('_TABLE_ADMINS_', 'oc_admins');
define('_TABLE_USERS_', 'oc_users');
define('_TABLE_PRIVATE_MESSAGES_', 'oc_private_messages');
define('_TABLE_PRIVATE_MESSAGES_RECEIPTS_', 'oc_private_messages_receipts');
define('_TABLE_GROUPS_', 'oc_groups');
define('_TABLE_GROUPS_MESSAGES_', 'oc_groups_messages');
define('_TABLE_GROUPS_COMMENTS_', 'oc_groups_comments');
define('_TABLE_SOCIAL_COMMENTS_', 'oc_go_social_comments');
define('_TABLE_SOCIAL_POSTS_', 'oc_go_social_posts');
define('_TABLE_SOCIAL_NOTIFICATIONS_', 'oc_go_social_notifications');
define('_TABLE_SOCIAL_FOLLOWERS_', 'oc_go_social_followers');
define('_TABLE_REPORTS_', 'oc_reports');
define('_TABLE_TOKENS_', 'oc_tokens');
$CONFIG___ = (object)array(
    'host' => 'Localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'tca_online_datab'
);
