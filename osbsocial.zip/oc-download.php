<?php require ('oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    http_response_code(401);
    die();
  }
require ('oc-includes/chat_functions.php');
if (empty($_GET['filename']) || empty($_GET['folder'])) 
  {
    http_response_code(406);
    die();
  }
$filename    = basename(test_input($_GET['filename']));
$file_folder = test_input($_GET['folder']);
$file        = _CHAT_FILES_DIR_ . "/{$file_folder}/{$filename}";
function download($file, $filename) 
  {
    if (!is_file($file)) 
      {
        http_response_code(404);
        die();
      }
    // Gzip enabled may set the wrong file size.
    if (function_exists('apache_setenv')) 
      {
        @apache_setenv('no-gzip', 1);
      }
    if (ini_get('zlib.output_compression')) 
      {
        @ini_set('zlib.output_compression', 'Off');
      }
    @set_time_limit(0);
    session_write_close();
    $size = intval(sprintf("%u", filesize($file)));
    header("Content-Length: " . $size);
    header("Content-Type: " . mime_content_type($file));
    header("Content-Disposition: attachment; filename=\"" . $filename . "\"");
    if (ob_get_level()) 
      {
        ob_end_clean();
      }
    readSlow($file, 1, $size);
  }
function readSlow($file, $chunkSize   = 1, $size, $sleepAmount = 0) 
  {
    readfile($file);
    exit;
  }
download($file, $filename);
