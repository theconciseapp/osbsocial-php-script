<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:fb="http://ogp.me/ns/fb#"><?php if( !enb_social() ) die("#Life is sweet");?><head><base id="base-url" href="<?php echo _SITE_URL_;?>/">
<meta charset="UTF-8">
<meta name="description" content="<?php echo $site_tagline;?>">
 <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no,user-scalable=0">
<title data-title="<?php echo $site_title . " - " . $site_otagline;?>"><?php echo $site_title . " - ". $site_tagline;?></title>
<meta property="og:title" content="<?php echo $site_tagline;?>" />
<meta property="og:type" content="website" />
 <meta property="og:image" content="<?php echo $content_icon;?>" />
 <meta property="og:site_name" content="<?php echo $site_title;?>" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo theme_path();?>/assets/css/fonts/stylesheet.css?<?php echo $cache_reset;?>" type="text/css">
  <link rel="stylesheet" href="<?php echo theme_path();?>/assets/css/centerlize.css?<?php echo $cache_reset;?>">
    <link rel="stylesheet" href="<?php echo theme_path();?>/assets/css/mediaelementplayer.css" />
    <link rel="stylesheet" href="<?php echo theme_path();?>/assets/chat/css/go-social.css?02<?php echo $cache_reset;?>">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdn.jsdelivr.net/npm/mediaelement@4.2.0/build/mediaelement-and-player.min.js"></script>
    <script src="<?php echo theme_path();?>/assets/chat/js/yall.js"></script>
  
 <?php
 include( theme_dir() . "/includes/header.html.php");
?>
<script src="<?php echo theme_path();?>/assets/chat/js/php_date_time.js"></script>
  <script src="<?php echo theme_path();?>/assets/chat/js/finger.js"></script>  
    <script src="<?php echo theme_path();?>/assets/chat/js/chat_globals.js?1<?php echo $cache_reset;?>"></script>
     <script src="<?php echo theme_path();?>/assets/chat/js/go-social.js?7<?php echo $cache_reset;?>"></script>
<?php $header_file=_PROJECT_DIR_ . "/oc-includes/header-code.html.php";
  if( is_readable( $header_file)  ){
   include( $header_file );
}
?>
</head>
<body>
<div id="MASTER-CONTAINER"> 	
 	  <div id="go-initializing-container">
   <div id="go-initializing-loader">
      <img class="w-40 h-40" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
    </div>
  </div>

  <div id="go-main-header">
<div id="OSB-SITE-TAGLINE"><?php echo $site_tagline;?></div>
<div class="row">
   <div class="col">
     <div id="OSB-SITE-TITLE" class="app-label" onclick="showSiteTagline();">
     	<?php
  $site_logo= _PROJECT_DIR_ . "/oc-logo.png";
 if( is_file( $site_logo ) ){?>
   <img src="<?php echo _SITE_URL_  . "/oc-logo.png";?>" id="OSB-SITE-LOGO"> 
<?php } echo $site_title;?>
    </div>
   </div>
   <div class="col" style="text-align: right; padding: 0; max-width: 130px;">
     <button id="go-open-search-box" onclick="goOpenSearchBox();">
       <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/search.png">
     </button>
     <button id="go-open-menu" onclick="toggleRightSidebar();">
       <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/menu.png">
     </button>
   </div>
  </div>
  <div id="header-navlists">
   
   <div onclick="home();">
    <span id="home-info-count" data-total="0">0</span>
    <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/home.png">
   </div>
     
 <div onclick="openNotifications();">
    <span id="total-new-notifications" data-total="0">0</span>
    <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/bell.png">
   </div>
   
  <div class="messenger-feature" onclick="openMessage();">
    <span id="total-new-messages" data-total="0">0</span>
    <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/inbox4.png">
   </div>
   
   <div onclick="openPages();">
    <span id="total-pages" data-total="0">0</span>
    <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/flag.png">
   </div>
   
   <div id="open-right-menu-btn" onclick="toggleLeftSidebar();" onclic="openRightMenu();">
      <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/menu2.png">
   </div>
     </div>

 </div>
 <div class="the-main-container">
<div style="height: 100%; font-size:0; white-space: nowrap;">
  <div class="side-bar-container hide-left-sidebar">
    <!--left body-->
    <div id="go-left-menu-container">
    
 <div class="container-fluid" id="left-menu-header">
 <div class="row">
  <div class="col" onclick="toggleRightSidebar();" onclic="closeRightMenus();" style="padding: 10px; max-width: 150px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col"></div>  
  </div>
  </div>
 <div class="container-fluid p-0" id="left-menu-content">
  
  <div id="OSB-TOP-LEFT-SIDEBAR"></div>
  
  <div style="display: none;" id="go-open-drafts-btn" class="container-fluid mt-3 go-open-profile" data-user="cv_drafts" data-user-fullname="Drafts">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon" src="<?php echo theme_path();?>/assets/go-icons/draft.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Drafts (Admin only)</span>
  </div>
  </div>
  </div>  

    <?php $lsidebar_file=_PROJECT_DIR_ . "/oc-includes/lsidebar-code.html.php";

if( is_readable( $lsidebar_file ) ){
   include($lsidebar_file);

}
?>
 
  <div id="left-menu-signout-btn" class="go-change-account container-fluid mt-5 go-rlogout-container" onclick="changeAccount();">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon" src="<?php echo theme_path();?>/assets/go-icons/logout.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Log out</span>
  </div>
  </div>
  </div>
     
  <div id="OSB-BOTTOM-LEFT-SIDEBAR"></div>  
     
     
   </div><!--End left menu content--> 
   </div><!--End left menu container-->
   </div><!--End left side bar-->
 
  <div class="main-content-container">
    
    <!--center body-->
    <div class="main-content-shadow" onclick="toggleLeftSidebar();"></div>   
  
     <div id="go-posts-column">
   	<!--SINGLE POST DATA-->
   	<textarea id="osb-single-post-data" style="display: none;">
   <?php echo htmlspecialchars( json_encode( $single_post_data,  JSON_HEX_APOS), ENT_QUOTES, 'UTF-8');?>
  </textarea>
   <div id="go-express-your-mind" class="container-fluid bg-white" style="display: none; padding-bottom: 3px;">
 <div class="row">
   <div class="col go-user-open-profile p-0 " data-user="" data-user-fullname="" style="max-width: 70px;">
     <div class="go-user-icon-container"></div>
      </div>
 <div class="col" style="padding-top:0; padding-bottom:0;">
   <div id="open-compose-page-btn">Express your mind...</div>  
 </div>
    <div class="col p-0 file-upload-feature" id="go-up-photo-btn-cont" style="text-align: center; max-width: 60px; font-size: 12px;">
 <label for="goUploadPhoto">
    <div class="text-secondary" id="go-upload-post-photo-btn">
      <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/gallery.png">
      <div>Photo</div>
      </label>
  <form class="d-none"><input type="file" id="goUploadPhoto" name="file[]" accept="image/*" onchange="goOpenGallery(this, 'image');" multiple /></form>
  
     </div>
    </div>
    </div>   
  </div>
 
<div id="OSB-BEFORE-PYMK"></div>
 <div id="go-pymk-container"></div>

 <div id="OSB-AFTER-PYMK"></div>

  <div id="go-the-posts"></div>
  <div id="OSB-AFTER-POSTS"></div>    
 
  <img id="post-loading-indicator" class="w-30 h-30" src="<?php echo theme_path();?>/assets/loading-indicator/loading7.png">
  
<div class="bubbles">
  	<div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
    <div class="bubble"></div>
  <div class="bubble"></div>
    <div class="bubble"></div>
  <div class="bubble"></div>
    <div class="bubble"></div>
  <div class="bubble"></div>
  </div>
  
     </div> <!--End #go-posts-column-->    
 </div>
  
    <div class="right-side-bar-container hide-right-sidebar">
 <!--right body-->
      <div id="go-right-menu-container">
     <div class="container-fluid" id="right-menu-header">
 <div class="row">
  <div class="col" onclick="closeMenus();" style="padding: 10px; max-width: 150px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/forward.png">
  
  </div>
 <div class="col"></div>  
  </div>
  </div>   
 
 <div id="OSB-TOP-RIGHT-SIDEBAR"></div>
 
 <div class="container-fluid p-0" id="right-menu-content">    
  <div class="container-fluid mt-3 go-open-my-profile">
     <div class="row go-user-open-profile" data-user-fullname="">
    <div class="col" style="max-width: 70px; padding-left: 15px;">
      <div class="go-user-icon-container"></div>
    </div>
  <div class="col p-0">
    <div class="go-user-fullname"></div>
    <span style="color:#485960;">View your profile</span>
  </div>
     </div>
   </div>
   
  <div class="d-none messenger-feature container-fluid mt-3" onclick="openMessage();">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon opacity-1x" src="<?php echo theme_path();?>/assets/go-icons/inbox3.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Messages</span>
  </div>
  </div>
  </div>
   
     <div class="follow-feature container-fluid mt-3">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon opacity-1x" src="<?php echo theme_path();?>/assets/go-icons/following.png">
    </div>
  <div class="col p-0">
   <div style="position: relative; height: 40px;"> 
     <div style="color:#485960; height: 40px;" onclick="viewFollowing();">Following</div>
    <div class="middle go-show-follow-form-btn" style="position: absolute; z-index: 5; top: 0; right: 10px; background: #f2f2f2; width: 40px; height: 40px; border: 1px solid #999; border-radius: 100%;">
      <img style="display: block; margin:0 auto;" class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/follow.png">
    </div>
    </div>
  </div>
  </div>
  </div>
     
     <div class="follow-feature container-fluid mt-3h" onclick="viewFollowers();">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon  opacity-1x" src="<?php echo theme_path();?>/assets/go-icons/followers.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Followers</span>
  </div>
  </div>
  </div>

 
  <div class="follow-feature container-fluid mt-3" onclick="viewBlockedFollowers();">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon  opacity-1x" src="<?php echo theme_path();?>/assets/go-icons/blocked-followers.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Blocked followers</span>
  </div>
  </div>
  </div>
          
       <div id="settings-btn" class="container-fluid mt-3" onclick="viewSettingsPage();">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon  opacity-1x" src="<?php echo theme_path();?>/assets/go-icons/settings.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Settings</span>
  </div>
  </div>
  </div>
                      
    <div id="admin-panel-btn" style="display: none;" class="container-fluid mt-3">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon  opacity-1x" src="<?php echo theme_path();?>/assets/go-icons/control.png">
    </div>
  <div class="col p-0">
<a href="oc-admin/index.php" target="blank_" rel="nofollow"> <span style="color: #485960;">Admin panel</span></a>
  </div>
  </div>
  </div>  
     
    <?php 

$rsidebar_file=_PROJECT_DIR_ . "/oc-includes/rsidebar-code.html.php";

 if( is_readable( $rsidebar_file)){
  include($rsidebar_file);

 }
?>

   <div class="go-change-account container-fluid mt-5 go-mlogout-container" onclick="changeAccount();">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon" src="<?php echo theme_path();?>/assets/go-icons/logout.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Log out</span>
  </div>
  </div>
  </div> 
  
     <div id="OSB-SIGNIN-BTN" class="go-signin-btn d-none container-fluid mt-3" onclick="changeAccount_(0,1);">
  <div class="row">
  <div class="col" style="max-width: 55px; text-align: center; padding-left: 15px;">
      <img class="menu-icon" src="<?php echo theme_path();?>/assets/go-icons/signin.png">
    </div>
  <div class="col p-0">
    <span style="color:#485960;">Sign In</span>
  </div>
  </div>
  </div>  
  
  <div id="OSB-BOTTOM-RIGHT-SIDEBAR"></div>
 
 </div>
   
   </div>
  </div><!--End right-sidebar-container-->
  
    </div>
  </div>
 
  <!--Search container-->
  
  <div class="container-fluid p-0" id="go-search-container">
  <div class="u-shadow" onclick="closeSearch();"></div>
  
    <div id="go-search-child-container">
    <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
  <div class="row">
   <div class="col pt-2" onclick="closeSearch();" style="max-width: 60px;">
   <img class="icon-medium" style="display: block; margin: 6px auto;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
  <div class="col" style="padding: 8px 0;">
   <form action="javascript: void(0);" onsubmit="searchPosts(1);">
     <input type="text" id="go-search-box" maxlength="100" placeholder="Search..." />
   <button type="submit" style="background: none; outline: none; border:0; padding-top: 2px;">
     <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/search.png">
     </button>
    </form>
    </div>
   </div>
      </div>
      </div>
  <div class="u-content" id="go-search-content">
    <div id="go-search-suggestions"></div> 
<div id="OSB-BEFORE-SEARCHED-POSTS"></div>
    <div id="go-searched-posts"></div>
<div id="OSB-AFTER-SEARCHED-POSTS"></div>

  <img id="search-loading-indicator" style="display: none; margin:0 auto;" class="w-20 h-20" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
      </div>
    </div>
   </div> <!--END Search container-->

  
  <!--COMMENTS-->
     
   <div id="go-comment-container">
     <div class="u-shadow" onclick="goCloseComment();"></div>
      <div id="go-comment-child-container">
      <div id="comment-loader-container">
        <div class="loader1">
          <div class="spin"></div>
        </div> 
      </div>
   <div id="post-comment-title-cont">
     <div class="container-fluid">
       <div class="row">
     <div class="col pt-2" style="max-width: 60px;"  onclick="goCloseComment();">
      <img class="w-20 h-20" src="<?php echo theme_path();?>/assets/go-icons/back.png">
     </div>
    <div class="col">
    <div id="go-comment-title" class="text-left">Comments</div>
    </div>
             <div class="col pt-2" style="max-width: 60px;">
      <img id="comment-refresh-btn" class="w-30 h-30" src="<?php echo theme_path();?>/assets/chat-icons/refresh.png">
     </div>
           <div class="col d-none" style="max-width: 60px;">
         <div id="post-comment-sending-cont"></div>
       </div>
       </div>
     </div>
     </div>
      <div id="post-comments-container">
        <a id="prev-comments" href="javascript:void(0);">Previous comments</a>
        <div id="post-comments"></div>
        
    <div id="OSB-COMMENTS-TOP"></div>
    
  <div id="my-comments-container"></div>
      
    <div id="OSB-COMMENTS-BOTTOM"></div>
          
        <a id="next-comments" data-value="" href="javascript: void(0);">Next comments</a>    
      </div>
     
     <div id="go-comment-upload-preview-container"></div>
     
     <div id="go-comment-box-container" class="container">
      <div class="row">
        <div class="col text-center" style="max-width: 50px;">
      

<button id="go-comment-upload-file-btn">
<label for="goUploadCommentFile">
          <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/gallery.png"></label>  </button>
       
         <form class="d-none"><input type="file" id="goUploadCommentFile" name="file" accept="image/*,video/mp4" onchange="goOpenCommentGallery(this, 'image');" /></form> 
       
        </div>
        <div class="col">
          <textarea id="go-comment-box" placeholder="Share your opinion..."></textarea>
        </div>
        <div class="col" style="max-width: 50px; padding-left: 0;">
        <button id="go-send-comment-btn">
          <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/send.png">
        </button>
        </div>
        
       </div>
     </div>
    </div>
  </div><!--End comment container-->
  
    <!--COMMENTS REPLIES-->
     
   <div id="go-rcomment-container" class="go-cont">
     <div class="u-shadow" onclick="goCloseCommentReply();"></div>
      <div id="go-rcomment-child-container" class="go-child-cont">
      <div id="rcomment-loader-container">
        <div class="loader1">
          <div class="spin"></div>
        </div> 
      </div>
   <div id="post-rcomment-title-cont">
     <div class="container-fluid">
       <div class="row">
       	    <div class="col pt-2" style="max-width: 60px;"  onclick="goCloseCommentReply();">
      <img class="w-20 h-20" src="<?php echo theme_path();?>/assets/go-icons/back.png">
     </div>
        <div class="col">
      <div id="go-rcomment-title" class="text-left">
        Replies 
        </div>
 </div>
 <div class="col pt-2">
<div class="d-inline-block ml-3"><span class="text-primary" id="go-view-orig-post" onclick="viewOriginalPost();" style="display:none;">View post</span></div></div>
   <div class="col pt-2" style="max-width: 60px;">
      <img id="rcomment-refresh-btn" class="w-30 h-30" src="<?php echo theme_path();?>/assets/chat-icons/refresh.png">
     </div>
     <div class="col d-none" style="max-width: 60px;">
         <div id="post-rcomment-sending-cont"></div>
       </div>
       </div>
     </div>
     </div>
      <div id="post-rcomments-container">
        <a id="prev-rcomments" href="javascript:void(0);">Previous comments</a>
        <div id="post-rcomments"></div>
        
            <div id="OSB-COMMENT-REPLIES-TOP"></div>
      <div id="my-rcomments-container"></div>
          <div id="OSB-COMMENT-REPLIES-BOTTOM"></div>
      
        <a id="next-rcomments" data-value="" href="javascript: void(0);">Next comments</a>    
      </div>
     
     <div id="go-rcomment-upload-preview-container"></div>
     
     <div id="go-rcomment-box-container" class="container">
       <div id="go-comment-tagged-cont"></div>
      <div class="row">
        <div class="d-none col text-center" style="max-width: 50px;">
       <button id="go-rcomment-upload-file-btn">
          <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/gallery.png">
       </button>
          
        </div>
        <div class="col">
          <textarea id="go-rcomment-box" placeholder="Reply..."></textarea>
          <input type="hidden" id="rcomment-id" />
          <input type="hidden" id="comment-parent-id" value="" />
          
        </div>
        <div class="col" style="max-width: 50px; padding-left: 0;">
        <button id="go-send-rcomment-btn">
          <img class="icon-medium" src="<?php echo theme_path();?>/assets/go-icons/send.png">
        </button>
        </div>
        
       </div>
     </div>
    </div>
  </div><!--End reply comment container-->
  
   
  <!--SINGLE POST CONTAINER-->
  
  <div class="container-fluid p-0" id="go-single-post-container">    
  <div class="u-shadow" onclick="closeSinglePost();"></div>
    <div id="go-single-post-child-container">       
    <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
   <div class="col" onclick="closeSinglePost();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
  <div class="col p-0">
   </div>
    </div>
    </div>
    </div>
    <div class="u-content">
    	    <div id="OSB-SINGLE-POST-TOP"></div>
    <div id="go-single-post"></div>
  <div id="OSB-SINGLE-POST-BOTTOM"></div>
    
  <img id="single-post-loading-indicator" style="display: none; margin:0 auto;" class="w-20 h-20" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
    </div>
    </div>
   </div> <!--END Single container--> 
  
  
  <!--PROFILE-->
  
  <div id="go-profile-container">
  	
  <div style="position: fixed; top: 0px; left: 16px; z-index: 60;" onclick="goCloseProfile();" style="max-width: 60px;">
   <img class="icon-medium" style="display: block; margin: 6px auto;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>	
    
    <select id="go-page-post-order">
        <option value="" selected>SORT</option>
        <option value="DESC">NEWER FIRST</option>
        <option value="ASC">OLDER FIRST</option>     
      </select>
 
</div>

<div id="go-profile-html-data" class="d-none">  
	       <div class="container-fluid">
     
 <div class="row">
 <div class="col-12 p-0">
  <div class="go-profile-cover-photo-container">
  	
    <img id="cp" class="go-profile-cover-photo" src="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=" onerror="go_postImgError(this, 'skyblue',2);" alt="">
  </div>
 
   <div style="position: relative;">
   <div class="container-fluid">
   <div class="row">
 <div class="col" style="overflow: visible; height: 45px; max-width: 120px;">
  <div class="go-profile-photo-container" onclick="goProfileCameraOption(this);">
   <img class="go-profile-photo">
  <img class="go-profile-camera-icon" src="<?php echo theme_path();?>/assets/go-icons/camera.png">
   </div>
     </div>
     <div class="col text-end" style="padding-top: 10px; overflow-x: hidden;">
      <div style="display:none;" class="go-profile-message-follow-btn-container">
       <img class="messenger-feature w-20 h-20 go-profile-message-btn" src="<?php echo theme_path();?>/assets/go-icons/inbox5.png">
        
   <div class="follow-feature d-inline-block" style="margin-left: 16px;">
     <button class="go-follow-btn go-profile-follow-btn" data-pin="" disabled="disabled">Follow</button>
   </div>
       </div>
     <button class="go-profile-update-form-btn" onclick="viewProfileUpdateForm();" disabled="disabled">Edit profile</button>   
       
     </div>
    </div>
   </div>
   </div>
    
  <div class="go-profile-info-container">
   <div class="go-profile-fullname" data-name=""></div>
   <div class="go-profile-user-pin"></div>
    <div class="go-profile-email go-hide"></div>
    
   <div class="go-profile-bio go-hide"></div>
   <div class="go-profile-country go-hide"></div>
   <div class="go-profile-phone go-hide"></div>   
   <div class="go-profile-birth go-hide"></div>
   <div class="go-profile-joined go-hide"></div>
  
   </div>

 <div class="followership-info follow-feature container-fluid mt-2">
   <div class="row">
     <div class="col">
   <div class="go-total-followers text-center"></div>
     </div>    
     <div class="col">
   <div class="go-total-following text-center"></div>
     </div>
   </div>
   </div>   
   
</div>
    
  <div class="col-12 p-0" style="background: rgba(0,0,0,0.15);">
    <div class="d-none bg-white mt-2" style="padding-left: 16px; margin-bottom: 5px;">
      <strong><big>Posts</big></strong> 
    </div>
    
    	    <div id="OSB-PROFILE-POSTS-TOP"></div>
    <div class="go-profile-posts mt-2"></div>
 	    <div id="OSB-PROFILE-POSTS-BOTTOM"></div>

   <img class="profile-posts-loading-indicator w-20 h-20" style="display: none; margin:0 auto;" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">  
    
  </div>
</div>
  <input type="hidden" class="go-profile-next-page-number" value="" /> <!--To be used by page posts-->
  
</div>
     
  </div>
  
 
  
  <!--User name is stored here-->
  <input type="hidden" id="go-profile-current" value="">

<button id="load-profile-id" class="go-open-profile" data-user="<?php echo $load_profile_id;?>" value="<?php echo $load_profile_id;?>" style="display: none;"></button>

  
  <!--COMPOSE POST-->
  
  
  <div id="compose-post-container">
    <div class="container-fluid" id="compose-post-header">
      <div class="row">
   <div class="col pt-2" style="max-width: 60px;" onclick="closeComposePage();">
    
     <img class="icon-medium" style="display: block; margin: 6px auto;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
     </div>
   <div class="col text-end">
    <button class="btn btn-sm btn-primary" id="go-send-post-btn">POST</button>
   </div>
    </div>    
    </div>
   
   <div class="container-fluid mb-3">
     <div class="row">
    <div class="col" style="max-width: 70px; padding-left: 15px;">
      <div class="go-user-icon-container"></div>
    </div>
  <div class="col p-0">
    <div class="go-user-fullname" style="color:#485960;"></div>
    
  </div>
     </div>
     </div>
        
  <div class="container-fluid">
    <div class="row">
      <div class="col-12 col-md-8">
      
 <div class="go-pages"></div>
        
     <div class="container-fluid" id="grh-container" style="display: none;">
       <div class="d-block" id="go-repost-highlight"></div>
     <input id="go-repost-data" type="hidden" data-pid="" data-spid="" data-notify="" value="" />
     </div>
   
 <div class="mt-2 mb-2 d-none" id="go-create-post-title">
   <label><strong>Post Title</strong></label>
<input type="text" id="post-title-box" class="form-control">
 </div>
    <textarea class="form-control" id="compose-post-box" data-bg="" placeholder="Express your mind..."></textarea>

   <div class="form-control" style="max-width: 600px; margin: 0 auto;">
<div id="go-post-bg-container">
     <span class="go-post-bg go-post-bg-1" data-bg="go-pbg-1"></span>
     <span class="go-post-bg go-post-bg-2" data-bg="go-pbg-2"></span>
     <span class="go-post-bg go-post-bg-3" data-bg="go-pbg-3"></span>
     <span class="go-post-bg go-post-bg-4" data-bg="go-pbg-4"></span>
     <span class="go-post-bg go-post-bg-5" data-bg="go-pbg-5"></span>
     <span class="go-post-bg go-post-bg-6" data-bg="go-pbg-6"></span>
     <span class="go-post-bg go-post-bg-7" data-bg="go-pbg-7"></span>
     <span class="go-post-bg go-post-bg-8" data-bg="go-pbg-8"></span>
     <span class="go-post-bg go-post-bg-9" data-bg="go-pbg-9"></span>
     <span class="go-post-bg go-post-bg-10" data-bg="go-pbg-10"></span>
   </div>
   </div>
        
 <div class="custom-control custom-checkbox" style="margin: 6px 12px;">
   <input type="checkbox" class="custom-control-input" id="go-post-commentable" checked="checked">
   <label class="custom-control-label" for="go-post-commentable">
     <span style="display: inline-block; font-weight: bold; font-size: 18px;"> Commentable</span>
   </label>
  </div>

  <div class="custom-control custom-checkbox" style="margin: 6px 12px;">
   <input type="checkbox" class="custom-control-input" id="go-post-shareable" checked="checked">
   <label class="custom-control-label" for="go-post-shareable">
     <span style="display: inline-block; font-weight: bold; font-size: 18px;"> Shareable</span>
   </label>
  </div>
      
   <div class="custom-control custom-checkbox" style="margin: 6px 12px;"><input type="checkbox" class="custom-control-input" id="go-file-downloadable" checked="checked">
<label class="custom-control-label" for="go-file-downloadable">
<span style="display: inline-block; font-weight: bold; font-size: 18px;"> Downloadable</span></label>
</div> 
     
        
   </div>
      
  <div class="col-12 col-md-4">
    <div id="go-upload-preview-container" class="go-repost-hide"></div>
   
   <div style="padding-left: 13px; color: #222;" id="go-upload-post-image-btn" class="go-upload-post-media-btn mb-2 go-repost-hide file-upload-feature">
<label for="goUploadPhotoVideo"><img class="icon-medium" style="margin-right: 14px;" src="<?php echo theme_path();?>/assets/go-icons/gallery.png"> 
      <span id="go-up-ptext">Photos</span><span id="go-up-vtext">/Videos</span>
      </label>
       <form class="d-none"><input type="file" id="goUploadPhotoVideo" name="file[]" accept="image/*,video/mp4" onchange="goOpenGallery(this, 'image');" multiple /></form> 
 
      
   </div>
    
  <div style="padding-left: 13px; color: #222;" class="go-upload-post-media-btn go-repost-hide">
   <div onclick="togglePostLinkForm()">
   <img class="icon-medium" style="margin-right: 14px;" src="<?php echo theme_path();?>/assets/go-icons/link.png"> 
   Add link
    </div>
   <div class="go-repost-hide">
     <div id="go-post-link-form" class="go-hide">
      <div><small>Secure https:// link allowed only</small></div>
      <div class="row">
      <div class="col text-secondary" style="max-width: 100px; font-size: 14px;">Link</div>
      <div class="col">
      <input type="text" class="form-control mt-1 mb-1" id="go-link-input">
      </div>
     </div>
      
 <div class="row">
      <div class="col text-secondary" style="max-width: 100px; font-size: 14px;">Link title (optional)</div>
      <div class="col">
      <input type="text" class="form-control mt-1 mb-1" id="go-link-title-input">
      </div>
     </div>   
     </div>
    </div>
  </div>

      </div>
    </div>
    </div>
    
  <div id="post-progress-bar-container">
   <div id="post-progress"></div>
    </div>
    
    
  </div>
 
<!---FOLLOW -->
  
  <div id="go-follow-container">
    <div class="u-shadow" onclick="closeFollowForm();"></div>
    <div id="go-follow-form-container">
   <div class="u-header">
      <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeFollowForm();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 10px;">
   Search pin
   </div>  
  <div class="col text-end" style="padding-top: 10px;"> 
 <img id="follow-suggestion-loader" class="w-50 d-none" src="<?php echo theme_path();?>/assets/loading-indicator/loading4.png">
  </div>
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12">
     <input type="text" id="go-follow-box" placeholder="Enter pin..."/>
      </div>

       </div>
   </div>
     
     <div id="go-follow-suggestions"></div> 
      </div>
    </div>    
  </div>
 
  <!--NOTIFICATIONS-->
  
  <div id="go-notifications-container">
    <div class="u-shadow" onclick="closeNotifications();"></div>
    <div id="go-notifications-child-container">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
   	<div class="d-none" id="go-notifications-next-page-number">1</div>
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeNotifications();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <h4>Notifications</h4>
   </div>
    <div class="col text-end" style="padding-top: 8px;">
    	<img id="notifications-loader" class="d-none w-16 h-16" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
    	</div>
   
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content" style="padding-bottom: 200px;">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
      	
     	    <div id="OSB-NOTIFICATIONS-TOP"></div> 
        <div id="go-notifications"></div>
        	    <div id="OSB-NOTIFICATIONS-BOTTOM"></div>
        
    </div>
   </div>
  </div>
  </div>
      
    </div>
  </div>    
 
  
  
  <!--FOLLOWERS-->
  
  <div id="go-followers-container">
    <div class="u-shadow" onclick="closeViewFollowers();"></div>
    <div id="go-followers-child-container">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeViewFollowers();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <h4>Followers</h4>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
      		    <div id="OSB-FOLLOWERS-TOP"></div> 
      
        <div id="go-followers"></div>
        <div id="OSB-FOLLOWERS-BOTTOM"></div> 
        
    <img id="go-followers-loading-indicator" class="w-20 h-20" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
  
    </div>
 
       </div>
      </div>
     </div>
    </div>
  </div>    
 
  
 <!--FOLLOWING-->
  
  <div id="go-following-container">
    <div class="u-shadow" onclick="closeViewFollowing();"></div>
    <div id="go-followers-child-container">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeViewFollowing();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <b>You are following</b>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
      	<div id="OSB-FOLLOWING-TOP"></div> 
      
        <div id="go-following"></div>
    <div id="OSB-FOLLOWING-BOTTOM"></div> 
        
    <img id="go-following-loading-indicator" class="w-20 h-20" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
  
    </div>
 
       </div>
      </div>
     </div>
    </div>
  </div>    

  <!--BLOCKED FOLLOWERS-->
  
  <div id="go-blocked-followers-container">
    <div class="u-shadow" onclick="closeViewBlockedFollowers();"></div>
    <div id="go-blocked-followers-child-container">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeViewBlockedFollowers();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <b>People you blocked</b>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
      	<div id="OSB-BLOCKED-FOLLOWERS-TOP"></div> 
      
        <div id="go-blocked-followers"></div>
        <div id="OSB-BLOCKED-FOLLOWERS-BOTTOM"></div> 
        
    <img id="go-blocked-followers-loading-indicator" class="w-20 h-20" src="<?php echo theme_path();?>/assets/loading-indicator/loading2.png">
  
    </div>
 
       </div>
      </div>
     </div>
    </div>
  </div>    
  
  <!--UPDATE PROFILE FORM-->
  
 
  <div id="go-profile-update-container" class="go-cont">
    <div class="u-shadow" onclick="closeProfileUpdateForm();"></div>
    <div id="go-profile-update-child-container" class="go-child-cont">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeProfileUpdateForm();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <b>Edit profile</b>
   </div>
   <div class="col text-end" style="padding-top: 8px;">
     <button id="go-profile-update-btn" onclick="goProfileUpdate(this);">Save</button>
   </div>
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
     	<div id="OSB-UPDATE-PROFILE-TOP"></div> 
     
       <label for="go-update-name-box">Display name</label>
       <input type="text" id="go-update-name-box">
       <label for="go-update-bio-box">Bio</label>
       <textarea id="go-update-bio-box"></textarea>
       <label for="go-update-phone-box">Phone</label>
       <input type="text" id="go-update-phone-box">
     
       <label for="go-update-location-box">Location</label>
       <input type="text" id="go-update-location-box">
     <label for="go-update-birth-box">Birth date</label>
       <input type="date" id="go-update-birth-box">
     
      	<div id="OSB-UPDATE-PROFILE-BOTTOM"></div> 
     
      </div>
     </div>
    </div>
  </div>    
  
  
  <!--SAVED POSTS-->
  
  <div id="go-saved-posts-container" class="go-cont">
    <div class="u-shadow" onclick="closeSavedPosts();"></div>
    <div id="go-saved-posts-child-container" class="go-child-cont">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeSavedPosts();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <h4>Saved posts</h4>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
      	
   <div id="OSB-SAVED-POSTS-TOP"></div> 
        <div id="go-saved-posts"></div>
           <div id="OSB-SAVED-POSTS-BOTTOM"></div> 
        
    </div>
   </div>
  </div>
  </div>
      
    </div>
  </div>    
  
  <!--CREATE GO PAGE-->
  
  <div id="go-create-page-form-container" class="go-cont">
    <div class="go-child-cont">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeCreatePageForm();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <h5>Create page/categories</h5>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container">
       <div class="row">
      <div class="col-12">
        
   <div id="go-create-page-form">
        
    <div class="mb-2">
<label class="form-label">Select page type</label>

<select class="form-control" onchange="goChangePageType(this);" id="go-create-page-type">
<option value="pv_">Type 1</option>
<option value="sv_">Type 2</option>
<option value="cv_">Type 3</option>
</select>
</div>

<div class="form-text mb-2 page-type-info text-success" id="pv_info">
  This type of page will be suggested to users on front page. Users can follow and read contents of this page. Page pin starts with "pv_"
 </div>

<div style="display: none;" class="form-text mb-2 text-primary page-type-info" id="sv_info">
Static page- This type of page automatically appears at the sidebar (Alphabetically). Users can't follow but can read contents of this page. E.g Page pin starts with "sv_"
</div>


<div style="display: none;" class="form-text mb-2 text-dark page-type-info" id="cv_info">
Static page 2- This type of page is not automatically shown anywhere on the site. It can only be added manually. Users can't follow this page but can read contents. Page pin starts with "cv_"

</div>
 
<div class="mb-2">

<label class="form-label">Page pin</label>

<div class="input-group">
  <span class="input-group-text bg-light text-center" id="create-page-selected-type" style="height: 40px; padding-right: 0;">
pv_
 </span>

 <input type="text" class="form-control" id="cp-pin" placeholder="Page pin" style="border-left: 0; padding-left: 1px; text-transform: lowercase;">
    </div>
</div>

<div class="mb-2">
<label class="form-label">Page display name (Title)</label>

<input type="text" id="cp-fullname" class="form-control">
</div>
<div class="mb-2">
<label class="form-label">About page</label>
<textarea id="cp-bio" class="form-control"></textarea>
</div>

<div class="mb-2">
<label class="form-label">Page phone contact (optional)</label>
 
<input type="number" id="cp-phone" class="form-control">
</div>

<div class="mb-2">
<label class="form-label">Page password</label>
<div class="form-text">This will allow another person to login and manage this page for you</div>
<input type="text" id="cp-password" class="form-control">
 
</div>

<div class="mb-2">
<button class="btn btn-sm btn-primary" id="create-page-btn" onclick="goCreatePage(this);">Create page</button>
  </div>
        
</div>
        
        
    </div>
   </div>
  </div>
  </div>
      
    </div>
  </div>    
 
  
  
  
  <!--ENLARGED PICTURE-->
  
  <div id="go-full-photo-container">
    <div class="u-shadow" onclick="closeFullPhoto();"></div>
  <div id="go-full-photo-child-container" class="go-child-cont">   
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeFullPhoto();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back-red.png">
  </div>
   <div class="col text-right" id="go-save-img-btn-cont" style="padding-top: 8px;">
     
   </div>
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content" id="go-full-photo-div">
    </div>
    </div>
  </div>
    
  <div id="go-full-cover-photo-container">
<div class="u-shadow" onclick="closeFullCoverPhoto();"></div>
  <div id="go-full-photo-child-container" class="go-child-cont">   
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeFullCoverPhoto();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back-red.png">
  </div>
   <div class="col text-right" id="go-save-img-btn-cont" style="padding-top: 8px;">
     
   </div>
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content" id="go-full-cover-photo">
    </div>
    </div>

</div> 
  
   
  <!--DOWNLOADS-->
  
  <div id="go-downloads-container" class="go-cont">
    <div class="u-shadow" onclick="closeDownloadsPage();"></div>
    <div id="go-downloads-child-container" class="go-child-cont">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeDownloadsPage();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <b>Downloads</b>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 p-0">
        <div id="go-running-downloads"></div>
    
    </div>
 
       </div>
      </div>
     </div>
    </div>
  </div>    
 
 
     <!--SETTINGS-->
     	
 <div id="go-settings-container" class="go-cont">
    <div class="u-shadow" onclick="closeSettingsPage();"></div>
    <div class="go-child-cont">
   <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.16);">
    <div class="container-fluid">
 <div class="row">
  <div class="col" onclick="closeSettingsPage();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <img class="icon-medium" style=" margin-right: 16px;" src="<?php echo theme_path();?>/assets/go-icons/back.png">
  </div>
 <div class="col" style="padding-top: 8px;">
   <h4>Settings</h4>
   </div>  
  </div>
  </div>   
  </div><!--end u-header-->
   <div class="u-content">
     <div class="container-fluid">
       <div class="row">
      <div class="col-12 pt-3">
      	      
<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Change password
  </button>
  
  <ul class="dropdown-menu mt-3 p-3" aria-labelledby="dropdownMenuButton1">
	
 <div class="row mb-3">
    <label for="old-password-box" class="col-sm-4 col-form-label">Old Password</label>
    <div class="col-sm-8">
      <input type="email" class="form-control" id="old-password-box">
    </div>
  </div>
  <div class="row mb-3">
    <label for="new-password-box" class="col-sm-4 col-form-label">New Password</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="new-password-box">
    </div>
  </div>
  
  <button onclick="changePassword(this);" class="btn btn-primary">Change</button>
  </ul>
</div>

  </div>
  </div>
  </div>
  </div>
      
    </div>
  </div>    
     
     
     
  <div id="go-video-element-container"></div>
 <input type="hidden" id="current-post-id" value="" /> <!--To be used by posts comment-->
 <input type="hidden" id="single-post-id" value="<?php echo $single_post_id;?>" /> 
 <input type="hidden" id="current-post-by" value="" /> <!--To be used by post comment-->
 <input type="hidden" id="go-next-page-number" value="" /> <!--To be used by page posts-->
 <input type="hidden" id="go-next-sp-page-number" value="" /> <!--To be used by spomsored posts-->
 <input type="hidden" id="go-search-next-page-number" value="" /> <!--To be used by search posts-->
 <input type="hidden" id="go-followers-next-page-number" value="" /> <!---->
 <input type="hidden" id="go-following-next-page-number" value="" /> <!---->
 <input type="hidden" id="go-blocked-followers-next-page-number" value="" /> <!---->
 <input type="hidden" id="go-current-opened-profile" value="" /> <!---->
 <input type="hidden" id="go-stack-order" value="" /> <!---->
 <input type="hidden" id="is-running" /> <!--add a class to #is-running while a function or ajax is running, remove when done-->
 <input type="hidden" id="z-index" value="40" /> <!---->
 <div id="IS-MOBILE"></div> <!---->
  
  
  <button id="show-console-log"><img src="<?php echo theme_path();?>/assets/chat-icons/console.png"></button>    
  
   <div class="console-log">
    <button id="clear-clog" onclick="$('.console-log-data').empty();">clear</button>
    <div class="console-log-data"></div>
  </div>

<div id="bootstrap-loaded" class="d-none"></div>
 <div id="main-css-loaded"></div>
 
 <?php $footer_file=_PROJECT_DIR_ . "/oc-includes/footer-code.html.php";

if( is_readable( $footer_file)){
  include(  $footer_file);
}
?>
 
 <script>    
  document.addEventListener("DOMContentLoaded", function() {
  yall({
    observeChanges: true,
    threshold: 0,
   // delay: 5000,
  });
});  
    
</script>
  </div>
  
  </body>
