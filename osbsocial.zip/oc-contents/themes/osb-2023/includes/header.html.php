<script>
var LIVE__= true;

 var DOM____='<?php echo _SITE_URL_;?>';
 var DOMAIN_=DOM____;  
 var __THEME_PATH__="<?php echo theme_path();?>";

var config_={
  "domain": DOMAIN_,
   "users_path": DOMAIN_ + "/oc-users",
 "APP_VERSION":"<?php echo _SITE_VERSION_;?>",
}

var __TOKEN__=localStorage.getItem('__TOKEN__');

var username=$.trim(localStorage.getItem('username') )||"";

var SITE_UNIQUE__= window.btoa( DOM____);

   var PAGISTS__=true;
   var MS__="ms"; //m, ms //Messenger, Social
 
  var PUBLIC_FOLDER =""; 

  var OFFICIALALIAS__="OSB Social";
  var APPLABEL='OSB Social';
  var APP_TYPE="blog"; //blog, chat
  var _PROJECT_DIR_='/osb'; //Must match server side project directory 
//Leave blank if installed in root directory

var last_app_open=+localStorage.getItem(SITE_UNIQUE__ + '_last_app_open_' + username);
var last_30d=moment(new Date() ).subtract(30, "days").unix();
  localStorage.setItem( SITE_UNIQUE__ + '_last_app_open_' + username, moment().unix() );
  //Check if users last opening of app is 30days
  //If true, logout user, clear groups last message time,

if( last_app_open && last_app_open<last_30d){

   localStorage.removeItem('__TOKEN__');
   localStorage.removeItem( SITE_UNIQUE__ + "_" + username + "_last_private_message_id");
   localStorage.removeItem( SITE_UNIQUE__ + "_" + username + "_last_message_receipt_id");
   localStorage.removeItem( SITE_UNIQUE__ + "_" + username + "_last_notification_check_id");
   
 }

var go_config_={
  "notif_check_freq": 60000,
  "mcl": 2, //Max comment length in kb
  "mpl": 10, //Max post length in kb
  "max_files": 5, //Max files per post
  "contact_us":"cv_contact",
  "page_contact":"cv_contact",//leave blank if you want page to
  //be contacted individually. Remember page is also like a user account.
  "aet": false,
}


function escapeRegExp(text) {
  return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
}

const htmlFormat =[
    { symbol: '*', tag: 'strong',  regex: '(?<=[ >~`\\^_.rbgm-]|^)\\*(?:(?!\\s)).*?[^ ]\\*(?=[\\W_]|$)' },
    { symbol: '_',   tag: 'em',    regex: '(?<=[ >~`\\^\*.rbgm-]|^)_(?:(?!\\s)).*?[^ ]_(?=[\\W_]|$)'},
    { symbol: '~',   tag: 's',     regex: '(?<=[ >`\\^\*_.rbgm-]|^)~(?:(?!\\s)).*?[^ ]~(?=[\\W_]|$)' },
    { symbol: '--',  tag: 'u',     regex: '(?<=[ >~`\\^\*_.rbgm]|^)(?:--)(?:(?!\\s)).*?[^ ](?:--)(?=[\\W_\]|$)' },
    { symbol: '```', tag: 'tt',    regex: '(?<=[\\^> ]|^)(?:```)(?:(?! ))([^]*)[^ ](?:```)(?=[\\W_]|$)' },
    { symbol: '^',   tag: 'code',  regex: '(?<=[`> ]|^)(?:\\^)(?:(?! ))([^]*)[^ ](?:\\^)(?=[\\W_]|$)' },
    { symbol: '?r',  tag: 're',    regex: '(?:\\?r)(?:(?!\\s)).*?[^ ](?:\\?r)' },
    { symbol: '?b',  tag: 'bl',    regex: '(?:\\?b)(?:(?!\\s)).*?[^ ](?:\\?b)' },
    { symbol: '?g',  tag: 'gr',    regex: '(?:\\?g)(?:(?!\\s)).*?[^ ](?:\\?g)' },
    { symbol: '?sm', tag: 'small', regex: '(?:\\?sm)(?:(?!\\s)).*?[^ ](?:\\?sm)' },
    { symbol: '?lg', tag: 'big',   regex: '(?:\\?lg)(?:(?!\\s)).*?[^ ](?:\\?lg)' }
 ]

function parsemd__(string, show_symbol){
 var obj={}
 string=string.replace(/&quot;/g,'"').replace(/<br>/g,"\n");

/*
string=string.replace(/(?<=[ >~`\\^\*_.rbgm]|^)(\b(https?|ftps?|mailto):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.]*[-A-Z0-9+@#\/%=~_|&;])/gi, function(m){
  var v=m.toString();
   var lid=randomString(8) + "?? ";
    obj[lid]= v
    return lid;
 });
*/

 $.each( htmlFormat,function(i,v){
  
  var symbol=v.symbol;
  var tag= v.tag;
  var reg= v.regex;
   
  if( show_symbol && tag=="code"){
    tag="plaincode";
  }
 //const regex = new RegExp(`\\${symbol}([^${symbol}]*)\\${symbol}`, 'g');
   const regex=new RegExp( reg, "gm");
   const match = string.match(regex);
   
   if(!match ) return;
  if( tag!="code" && tag!="tt" && tag!="plaincode" && match.toString().match(/\n/) ) return;
  
  match.forEach(m => {
    let formatted = m;
 
  // `<${i > 0 ? '/' : ''}${tag}>`);
    
 formatted= formatted.replace( new RegExp("(^" + escapeRegExp( symbol) + ")"), function(m,n){
   return `<${tag}>`;
 });    

 formatted= formatted.replace( new RegExp("(" + escapeRegExp( symbol) + "$)"), function(m){
    return `</${tag}>`;
  })
  
   string = string.replace(m, (show_symbol?'<span class="text-format-symbol">' + symbol + '</span>':'') + formatted + ( show_symbol?'<span class="text-format-symbol">' + symbol + '</span>':'') );
    });
 });

string=string.replace(/(?<=[^=\w]|^)((https?|ftps?|mailto):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.]*[-A-Z0-9+@#\/%=~_|&;])/gi, '<a href="$1" target="_blank">$1</a>');


/*
 $.each(obj, function( lid, link){

   string=string.replace( lid, '<a href="' + link + '" target="_blank">' + link + '</a>');

 })
 */
  
return string;  
}



function bbCode(text, show_symbol){
  var string = parsemd__( text, show_symbol );

 string=string.replace(/(?<=\s|^)@([\w_-]+)(?=\s|$)/gi, '<span class="post-chat-user" data-fuser="$1">$1</span>')
     .replace(/\[\[([\w-]+)\]\]/g,'<span class="join-group-btn-2" data-gpin="$1">+ $1</span>')
  
  return string;
}

function removebbCode(text){
 
return text.replace(/<strong>(.*?)<\/strong>/g,'*$1*')
           .replace(/<em>(.*?)<\/em>/g,'_$1_')
           .replace(/<s>(.*?)<\/s>/g,'~$1~')
           .replace(/<u>(.*?)<\/u>/g,'--$1--')
           .replace(/<tt>([\s\S]*)<\/tt>/g,"```$1```")
       .replace(/<code>([\s\S]*)<\/code>/g,"^$1^")      
       .replace(/<a href="(.*?)">(.*?)<\/a>/g,"$1")
  
  .replace(/<re>(.*?)<\/re>/g,  '?r$1?r')
  .replace(/<bl>(.*?)<\/bl>/g,  '?b$1?b')
  .replace(/<gr>(.*?)<\/gr>/g,  '?g$1?g')
  .replace(/<big>(.*?)<\/big>/g,'?lg$1?lg')
  .replace(/<small>(.*?)<\/small>/g,'?sm$1?sm')
  .replace(/<span class="j([^>]*)>(.*?)<\/span>/g,'$2')
  .replace(/<span class="p([^>]*)>(.*?)<\/span>/g,'@$2')

}


function go_textFormatter(text){
  
 text= parsemd__(text);
  text=text.replace(/(?<=\s|^)@([\w_-]+)(?=\s|^)/gi, '<span class="post-chat-user" data-fuser="$1">$1</span>')
     .replace(/\[follow=(.*?)\](.*?)\[\/follow\]/g,'<span class="go-follow-btn go-post-follow-btn" data-pin="$1">$2</span>')
     .replace(/\[\[([\w_-]+):(.*?)\]\]/gi, '<span class="fa fa-lg fa-$1 ext-social-button" data-site="$1" data-account="$2"> $2</span>')
     .replace(/\[img=(.*?)\](.*?)\[\/img\]/g, '<img class="go-post-image go-post-photo" src="$1" alt="$2">')
     .replace(/\[link=(.*?)\](.*?)\[\/link\]/g,'<span class="go-nice-link" data-link="$1">$2</span>')

 return text;
}

function userData(type){
  switch(type){
    case "username": return localStorage.getItem('username'); break;
    case "email": return localStorage.getItem('email'); break;
    case "fullname": return localStorage.getItem('fullname'); break;
    case "phone": return localStorage.setItem('phone');
  }  
}

function logIt(data){
  $('.console-log-data').append('<small>' + moment().format('DD/MMM/YYYY h:mm:sa') + '-' + data + '</small><hr />');
}

//Configure this to alert or toast or log for debugging

var __reports={
      report: "log", //"", "alert", "toast" , "console", "log"
}
 
function report__(title, report_,logOnly){
 
var r_=__reports.report;
 if(!r_) return "";
   
  if(r_=='log' || logOnly){
    $('#show-console-log').show();  
    logIt(title + '--' + report_);
  }
   else if( r_=='alert' ) alert(title + ":\n\n" +report_);
    else if(r_=='toast') toast(title+'--' + report_);
    else if(r_=='console') console.log(title + '--' + report_);    
}

function changeHash( hash_){
	hash_=hash_||"";
 var curr=location.href;
 var reg=new RegExp(hash_);
   if( hash_ && curr.match(reg) ) return;
   if( hash_) hash_="#" + hash_;
window.history.pushState("data",  "null",  window.location.pathname  + hash_ );
 }



$.ajaxSetup({
  async: true,
    timeout: 30000 //Time in milliseconds
});


</script>
