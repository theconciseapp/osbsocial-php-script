<?php header('Content-type:application/json;charset=utf-8');
if (empty($_GET['username'])) 
  {
    die("{}");
  }
require ('oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die("{}");
  }
$username   = test_input(strtolower($_GET['username']));
$settings__ = getSettings();
$app_name   = isset($settings__["app_name"]) ? $settings__["app_name"] : "OSBSocial";
$app_name   = ucfirst(str_replace('uv_', '', $app_name));
require ('oc-includes/server.php');
$message = "";
//CHECK FOR GROUP MESSAGE (RANDOM SINGLE GROUP)
if (!empty($_GET['groups']) && strlen(trim($_GET['groups'])) > 7) 
  {
    $groups  = test_input($_GET['groups']);
    $groups  = explode(' ', $groups);
    if (count($groups) > 0) 
      {
        $key     = array_rand($groups);
        $group   = $groups[$key];
        $group   = explode('|', $group);
        $gpin    = $group[0];
        $gtime   = $group[1];
        $table   = _TABLE_GROUPS_ . '_messages';
        $stmt    = $conn->prepare("SELECT message_preview, message_from FROM {$table} WHERE id>? AND message_to=? AND message_from!=? ORDER BY id ASC LIMIT 3");
        if ($stmt && $stmt->bind_param('iss', $gtime, $gpin, $username) && $stmt->execute()) 
          {
            $res     = $stmt->get_result();
            $stmt->close();
            $total_messages = $res->num_rows;
            if ($total_messages > 0) 
              {
                while ($row            = $res->fetch_assoc()) 
                  {
                    $mfrom          = $row["message_from"];
                    if ($mfrom != "act_act" && $mfrom != "act") 
                      {
                        $msg            = str_replace(array(
                            "<br>",
                            "&nbsp;"
                        ) , array(
                            "\n",
                            " "
                        ) , $row["message_preview"]);
                        $message.= strtoupper($mfrom) . "-" . $msg . "\n";
                      }
                  }
              }
          }
      }
  }
//CHECK FOR PRIVATE MESSAGES
if (!empty($_GET["lpm_check"])) 
  {
    $lmtime = $_GET["lpm_check"]; //Last private message check time
    $table  = _TABLE_PRIVATE_MESSAGES_;
    $stmt   = $conn->prepare("SELECT message_preview , message_from FROM {$table} WHERE id>? AND message_to=?  ORDER BY id ASC LIMIT 3");
    if ($stmt && $stmt->bind_param('is', $lmtime, $username) && $stmt->execute()) 
      {
        $res    = $stmt->get_result();
        $stmt->close();
        $total_messages = $res->num_rows;
        if ($total_messages > 0) 
          {
            while ($row            = $res->fetch_assoc()) 
              {
                $mfrom          = $row["message_from"];
                if ($mfrom != "act_act" && $mfrom != "act") 
                  {
                    $msg            = str_replace(array(
                        "<br>",
                        "&nbsp;"
                    ) , array(
                        "\n",
                        " "
                    ) , $row["message_preview"]);
                    $message.= strtoupper($mfrom) . "-" . $msg . "\n";
                  }
              }
          }
      }
  }
$conn->close();
if (!empty($message)) 
  {
    $last_modified = time();
    $results       = ["title" => "Click to read", "text" => $message, "time" => "$last_modified"];
    die(json_encode($results));
  }
else
  {
    die("{}");
  }
