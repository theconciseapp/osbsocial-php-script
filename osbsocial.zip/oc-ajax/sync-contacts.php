<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token"}');
  }
if (empty($_POST['username']) || empty($_POST["contacts"]) || empty($_POST['version'])) 
  {
    die('{"error":"Parameters missing."}');
  }
$contacts = htmlspecialchars(trim($_POST["contacts"]) , ENT_QUOTES & ~ENT_COMPAT, "UTF-8");
if (empty($datas)) 
  {
    die('{"error":"Nothing to sync"});
}

$username=test_input($_POST["username"]);

$file           = getUserDir($username) . "/contacts.txt";

if( file_put_contents( $contacts, $file)){
die('
      {
        "status":
            "success", "result":
                "deleted"
              }
            ')
}

die('
              {
                "error":
                    "Synch contacts failed"
                  });
                