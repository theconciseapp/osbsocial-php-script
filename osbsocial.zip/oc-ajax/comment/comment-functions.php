<?php function format_comment($post = "") 
  {
    $post = htmlspecialchars(trim($post));
    return preg_replace('#&lt;(/?(?:br))&gt;#', '<\1>', $post);
  }
function add_comment($conn, $gpin, $post_id, $author, $message, $meta    = "", $version = "1.0", $likes   = 0) 
  {
    $table   = _TABLE_GROUPS_COMMENTS_;
    $result  = $error   = 0;
    $likes   = (int)$likes;
    $status  = 1;
    try
      {
        $stmt    = $conn->prepare("INSERT INTO $table( group_pin, post_id, comment_author, message, meta, likes, status, date_time)VALUES(?,?,?,?,?,?,?, NOW() )");
        if ($stmt && $stmt->bind_param('sisssii', $gpin, $post_id, $author, $message, $meta, $likes, $status) && $stmt->execute()) return mysqli_stmt_insert_id($stmt);
        else $result = 0;
        $stmt->close();
        //$conn->close();
        
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
        return 0;
      }
    return $result;;
  }
function delete_comment($conn, $gpin, $cid, $author   = "", $is_admin = "") 
  {
    $table    = _TABLE_GROUPS_COMMENTS_;
    if (!empty($is_admin)) 
      {
        $stmt     = $conn->prepare("DELETE FROM $table WHERE id=? LIMIT 1");
        if ($stmt && $stmt->bind_param('i', $cid) && $stmt->execute()) 
          {
            $stmt->close();
            return true;
          }
      }
    else
      {
        $stmt = $conn->prepare("DELETE FROM $table WHERE id=? AND comment_author=? LIMIT 1");
        if ($stmt && $stmt->bind_param('is', $cid, $author) && $stmt->execute()) 
          {
            $stmt->close();
            return true;
          }
      }
    return false;
  }
function fetch_comments($conn, $gpin, $post_id) 
  {
    $table            = _TABLE_GROUPS_COMMENTS_;
    $result           = $data             = array();
    $fetch_total      = false;
    if (!empty($_GET["page"])) 
      {
        $page_number      = (int)$_GET["page"];
      }
    else
      {
        $page_number      = 1;
        $fetch_total      = true;
      }
    $item_per_page    = 10;
    $item_per_page_ex = $item_per_page + 1;
    $previous_page    = 0;
    $next_page        = 0;
    $page_position    = (($page_number - 1) * $item_per_page);
    $stmt             = $conn->prepare("SELECT id, group_pin, post_id, comment_author, message, meta, likes, date_time FROM $table WHERE    
post_id=? AND status='1' ORDER BY id DESC LIMIT $page_position, $item_per_page_ex");
    if ($stmt && $stmt->bind_param('i', $post_id) && $stmt->execute()) 
      {
        $res              = $stmt->get_result();
        $stmt->close();
        $total         = $res->num_rows;
        $total_to_send = $total;
        if ($total < 1) 
          {
            $result["no_comment"]               = "No comment yet.";
          }
        else
          {
            if ($page_number > 1) 
              {
                $previous_page = $page_number - 1;
              }
            if ($total > $item_per_page) 
              {
                $next_page     = $page_number + 1;
                $total_to_send = $item_per_page;
              }
            $i             = 0;
            while ($row           = $res->fetch_assoc()) 
              {
                $i++;
                if ($i <= $total_to_send) 
                  {
                    $data[]               = $row;
                  }
              }
            $result["result"]               = $data;
            $result["post_id"]               = $post_id;
            $result["group_pin"]               = $gpin;
            $result["prev_page"]               = $previous_page;
            $result["next_page"]               = $next_page;
            $result["item_per_page"]               = $item_per_page;
            $result["status"]               = "success";
          }
      }
    return $result;
  }
