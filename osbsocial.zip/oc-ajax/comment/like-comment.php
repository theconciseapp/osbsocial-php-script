<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid security token."}');
  }
else if (empty($_POST['post_id']) || empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['comment_id']) || empty($_POST['type']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$post_id = test_input($_POST['post_id']);
$gpin    = test_input(strtolower($_POST['group_pin']));
$cid     = test_input($_POST['comment_id']);
$type    = (int)$_POST['type'];
$version = test_input($_POST['version']);
require ('../../oc-includes/server.php');
$table = _TABLE_GROUPS_COMMENTS_;
try
  {
    if ($type == 1) 
      {
        $stmt  = $conn->prepare("UPDATE $table SET likes=likes+1 WHERE id=? LIMIT 1");
      }
    else
      {
        $stmt  = $conn->prepare("UPDATE $table SET likes=likes-1 WHERE id=? LIMIT 1");
      }
    if ($stmt && $stmt->bind_param('i', $cid) && $stmt->execute()) 
      {
        $stmt->close();
        $conn->close();
        die('{"status":"success","type":"' . $type . '"}');
      }
  }
catch(Exception $e) 
  {
    logIt($e->getMessage());
  }
$conn->close();
die('{"error":"Failed to alter."}');
