<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid security token."}');
  }
else if (empty($_POST['post_id']) || empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input(strtolower($_POST['username']));
$post_id  = test_input($_POST['post_id']);
$gpin     = test_input(strtolower($_POST['group_pin']));
$version  = test_input($_POST['version']);
require ('../../oc-includes/server.php');
require ('comment-functions.php');
$result = fetch_comments($conn, $gpin, $post_id);
$conn->close();
die(json_encode($result));
