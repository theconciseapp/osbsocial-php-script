<?php require '../../oc-includes/bootstrap.php';
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}'); //invalid token
    
  }
else if (empty($_POST['username']) || !validUsername($_POST["username"], true)) 
  {
    die('{"error":"Missing parameters","ecode":"52"}');
  }
$username        = test_input($_POST['username']);
$settings__      = getSettings();
$sadmin          = site_admin($username);
$enable_upload   = isset($settings__["enable_file_upload"]) ? $settings__["enable_file_upload"] : "YES";
$max_upload_size = isset($settings__["max_upload_size"]) ? (int)$settings__["max_upload_size"] : 5;
if (!$sadmin && $enable_upload != "YES") 
  {
    die('{"error":"Currently disabled"}');
  }
$enable_vid_doc = isset($settings__["go_allow_video"]) ? $settings__["go_allow_video"] : "YES";
require '../../oc-includes/chat_functions.php';
require 'go-functions.php';
define('__ALLOW__', '1');
define('__COMMENT_UPLOAD__', '1');
if (empty($_POST['file_ext'])) 
  {
    die('{"error":"Unsupported file.","ecode":"2"}'); //Unsupported file
    
  }
$file_type = strtolower($_POST['file_ext']);
if ($file_type == 'jpg') 
  {
    include ('upload-image.php');
  }
else if ($file_type == 'mp4') 
  {
    if (!site_admin($username) && $enable_vid_doc != 'YES') 
      {
        die('{"error":"Video upload currently disabled.","ecode":"54"}');
      }
    include ('upload-video.php');
  }
else
  {
    die('{"error":"Unsupported file.","ecode":"2"}');
  }
