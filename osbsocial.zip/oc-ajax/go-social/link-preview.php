<?php
if (isset($_POST["post"]) && filter_var($_POST["post"], FILTER_VALIDATE_URL)) 
  {
    // Extract HTML using curl
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $_POST["post"]);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    $data = curl_exec($ch);
    curl_close($ch);
    // Load HTML to DOM Object
    $dom = new DOMDocument();
    @$dom->loadHTML($data);
    // Parse DOM to get Title
    $nodes = $dom->getElementsByTagName('title');
    $title = $nodes->item(0)->nodeValue;
    // Parse DOM to get Meta Description
    $metas = $dom->getElementsByTagName('meta');
    $body  = "";
    for ($i     = 0;$i < $metas->length;$i++) 
      {
        $meta       = $metas->item($i);
        if ($meta->getAttribute('name') == 'description') 
          {
            $body       = $meta->getAttribute('content');
          }
      }
    // Parse DOM to get Images
    $image_urls = array();
    $images     = $dom->getElementsByTagName('img');
    for ($i          = 0;$i < $images->length;$i++) 
      {
        $image  = $images->item($i);
        $src    = $image->getAttribute('src');
        if (filter_var($src, FILTER_VALIDATE_URL)) 
          {
            $image_src[]        = $src;
          }
      }
    $output = array(
        'title' => $title,
        'image_src' => $image_src,
        'body' => $body
    );
    echo json_encode($output);
  }
?>






<?php
exit;
if (isset($_POST["post"])) 
  {
    $url         = $_POST["post"];
    $result      = getUrlData($url);
    //echo '<pre>'; print_r($result); echo '</pre>';
    $img_src     = "";
    $description = "";
    if (isset($result["metaTags"]["og:description"]["value"])) $description = $result["metaTags"]["og:description"]["value"];
    if (isset($result["metaTags"]["description"]["value"]) && $description == "") $description = $result["metaTags"]["description"]["value"];
    if (isset($result["metaTags"]["twitter:image"]["value"])) $img_src     = $result["metaTags"]["twitter:image"]["value"];
    if (isset($result["metaTags"]["og:image"]["value"]) && $img_src == "") $img_src     = $result["metaTags"]["og:image"]["value"];
    if ($img_src == "") 
      {
        libxml_use_internal_errors(true);
        $doc    = new DomDocument();
        $header = file_get_contents($url);
        $doc->loadHTML($header);
        $xpath        = new DOMXPath($doc);
        $img_src_temp = $xpath->evaluate("//img");
        foreach ($img_src_temp as $image) 
          {
            $src[]              = $image->getAttribute('src');
          }
        $img_src      = $src[0];
        // else $img_src = $img_src_temp;
        
      } ?>
        <center>
        <div style="max-width: 600px;min-height: 90px;border: 1px solid #ABABAB;padding: 5px;text-align: justify;">
            <img src="<?php echo $img_src; ?>" style="float:left;margin: 5px;width: 100px; height: 80px;">
            <div><a href="<?php echo $url; ?>" target="_blank" style="font-weight: bold;text-decoration: none;"><?php echo $result["title"]; ?></a></div>
            <div><?php //echo $description;
    
?>
            </div>
        </div>
        </center><?php
  }
// All function here
function getUrlData($url) 
  {
    $result   = false;
    $contents = getUrlContents($url);
    if (isset($contents) && is_string($contents)) 
      {
        $title    = null;
        $metaTags = null;
        preg_match('/<title>([^>]*)<\/title>/si', $contents, $match);
        if (isset($match) && is_array($match) && count($match) > 0) 
          {
            $title    = strip_tags($match[1]);
          }
        $metaTags = array();
        preg_match_all('/<[\s]*meta[\s]*name="?' . '([^>"]*)"?[\s]*' . 'content="?([^>"]*)"?[\s]*[\/]?[\s]*>/si', $contents, $match);
        if (isset($match) && is_array($match) && count($match) == 3) 
          {
            $originals = $match[0];
            $names     = $match[1];
            $values    = $match[2];
            if (count($originals) == count($names) && count($names) == count($values)) 
              {
                for ($i         = 0, $limiti    = count($names);$i < $limiti;$i++) 
                  {
                    $metaTags[$names[$i]] = array(
                        'html' => htmlentities($originals[$i]) ,
                        'value' => $values[$i]
                    );
                  }
              }
          }
        preg_match_all('/<[\s]*meta[\s]*property="?' . '([^>"]*)"?[\s]*' . 'content="?([^>"]*)"?[\s]*[\/]?[\s]*>/si', $contents, $match);
        if (isset($match) && is_array($match) && count($match) == 3) 
          {
            $originals = $match[0];
            $names     = $match[1];
            $values    = $match[2];
            if (count($originals) == count($names) && count($names) == count($values)) 
              {
                // if(!isset($i)) $i=0;
                for ($j         = 0, $limiti    = count($names);$j < $limiti;$j++) 
                  {
                    $metaTags[$names[$j]]        = array(
                        'html'        => htmlentities($originals[$j]) ,
                        'value'        => $values[$j]
                    );
                  }
              }
          }
        $result = array(
            'title' => $title,
            'metaTags' => $metaTags
        );
      }
    return $result;
  }
function getUrlContents($url, $maximumRedirections = null, $currentRedirection  = 0) 
  {
    $result              = false;
    $opts                = array(
        'http'                     => array(
            'header'                     => "User-Agent:MyAgent/1.0\r\n"
        )
    );
    $context             = stream_context_create($opts);
    $contents            = @file_get_contents($url, false, $context);
    // $contents = @file_get_contents($url);
    // Check if we need to go somewhere else
    if (isset($contents) && is_string($contents)) 
      {
        preg_match_all('/<[\s]*meta[\s]*http-equiv="?REFRESH"?' . '[\s]*content="?[0-9]*;[\s]*URL[\s]*=[\s]*([^>"]*)"?' . '[\s]*[\/]?[\s]*>/si', $contents, $match);
        if (isset($match) && is_array($match) && count($match) == 2 && count($match[1]) == 1) 
          {
            if (!isset($maximumRedirections) || $currentRedirection < $maximumRedirections) 
              {
                return getUrlContents($match[1][0], $maximumRedirections, ++$currentRedirection);
              }
            $result = false;
          }
        else
          {
            $result = $contents;
          }
      }
    return $contents;
  }
?>
