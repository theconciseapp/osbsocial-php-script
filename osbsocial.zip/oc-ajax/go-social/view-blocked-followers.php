<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['username'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input(strtolower($_POST['username']));
require ('../../oc-includes/server.php');
$result           = $final_result     = array();
if (!empty($_POST["page"])) 
  {
    $page_number      = (int)$_POST["page"];
  }
else
  {
    $page_number      = 1;
  }
$item_per_page    = 15;
$item_per_page_ex = $item_per_page + 1;
$previous_page    = 0;
$next_page        = 0;
$page_position    = (($page_number - 1) * $item_per_page);
$table_users      = _TABLE_USERS_;
$ftable           = _TABLE_SOCIAL_FOLLOWERS_;
$stmt             = $conn->prepare("SELECT F.follower, F.status, U.fullname AS real_name, U.bio FROM $ftable AS F INNER JOIN $table_users AS U ON F.follower=U.username 
 WHERE F.following=? AND status='0' ORDER BY U.fullname ASC LIMIT $page_position, $item_per_page_ex");
if (!$stmt || !$stmt->bind_param('s', $username) || !$stmt->execute()) 
  {
    die('{"error":"Try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
$total_posts   = $total_to_send = $res->num_rows;
if ($total_posts < 1) 
  {
    $conn->close();
    die('{"status":"success","no_blocked":"You have not blocked anyone."}');
  }
if ($total_posts > $item_per_page) 
  {
    $next_page     = $page_number + 1;
    $total_to_send = $item_per_page;
  }
$i             = 0;
while ($row           = $res->fetch_assoc()) 
  {
    $i++;
    if ($i <= $total_to_send) 
      {
        $result[]               = $row;
      }
  }
$final_result["status"]               = "success";
$final_result["total_posts"]               = $total_posts;
$final_result["next_page"]               = $next_page;
$final_result["result"]               = $result;
die(json_encode($final_result));
