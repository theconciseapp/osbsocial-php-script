<?php if (!defined('__ALLOW__')) 
  {
    die('{"error":"Method not allowed.","ecode":"51"}'); //Method not allowed
    
  }
if (!isset($_POST["video_poster"]) || empty($_POST['base64'])) 
  {
    die('{"error":"File rejected","ecode":"52"}');
  }
$base64    = test_input($_POST['base64']);
$bfilesize = strlen($base64) / 1024;
$bfilesize = $bfilesize / 1024;
if ($bfilesize > $max_upload_size) 
  {
    die('{"error":"File too large.","ecode":"3"}'); //File too large
    
  }
$base64         = base64_decode(preg_replace('#^data:video/\w+;base64,#i', '', $base64));
$poster_base64  = "";
if (!empty($_POST['video_poster'])) 
  {
    $poster_base64  = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $_POST['video_poster']));
  }
$vwidth         = 500;
$vheight        = 0;
if (!empty($_POST["video_dimension"])) 
  {
    $vdim           = test_input($_POST["video_dimension"]);
    $dim            = explode(",", $vdim);
    $vwidth         = round((int)$dim[0]);
    $vheight        = round((int)$dim[1]);
  }
$filename       = (microtime(true) * 10000) . randomNumbers(3);
$filename       = "OSB_VID_{$filename}";
$comment_folder = "";
if (defined('__COMMENT_UPLOAD__')) 
  {
    $comment_folder = "comments/";
  }
$folder         = "videos/social/{$comment_folder}" . _CHAT_FILES_STRUCTURE_;
$dir            = _CHAT_FILES_DIR_ . "/{$folder}";
$poster_file    = _CHAT_FILES_PATH_ . '/video-poster-error.png';
if (make_dir($dir)) 
  {
    $file           = "{$dir}/{$filename}.mp4";
    $poster_dir     = "{$dir}/__POSTERS__/";
    if (make_dir($poster_dir)) 
      {
        $save_poster_to = "{$poster_dir}/{$filename}.jpg";
        if (!empty($poster_base64) && saveBase64Image($poster_base64, $save_poster_to, $vwidth)) 
          {
            $poster_file    = _CHAT_FILES_PATH_ . "/{$folder}/__POSTERS__/{$filename}.jpg";
          }
      }
    uploadBase64Video($file, $base64, $folder, $filename, $poster_file, $vwidth, $vheight);
  }
else
  {
    die('{"error":"Server error: dirE","ecode":"53"}'); //Unable to create directory
    
  }
