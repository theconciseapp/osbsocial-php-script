<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES") 
  {
    $_POST["username"] = "anonymous";
  }
require ('../../oc-includes/server.php');
$table   = _TABLE_USERS_;
$iresult = array();
$where   = "role=5";
if (empty($_POST["ignore_static_page"])) 
  {
    $where   = "role IN(2,5,6)";
  }
$stmt    = $conn->prepare("SELECT username, fullname FROM {$table} WHERE $where ORDER BY fullname ASC LIMIT 50");
if ($stmt && $stmt->execute()) 
  {
    $res     = $stmt->get_result();
    $stmt->close();
    $conn->close();
    if ($res->num_rows < 1) 
      {
        die('{"status":"success","no_pages":"No pages created yet."}');
      }
    $result = array();
    while ($row    = $res->fetch_assoc()) 
      {
        $result[]        = $row;
      }
    $iresult["status"]        = "success";
    $iresult["result"]        = $result;
    $iresult["settings"]        = $settings__;
    die(json_encode($iresult));
  }
die(json_encode('{"error":"Not known"}'));
