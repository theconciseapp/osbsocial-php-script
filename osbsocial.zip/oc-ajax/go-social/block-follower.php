<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST["pin"]) || empty($_POST["type"])) 
  {
    die('{"error":"Missing parameters."}');
  }
$result   = array();
$username = test_input(strtolower($_POST["username"]));
$pin      = test_input(strtolower($_POST["pin"]));
$type     = test_input($_POST["type"]);
require ('../../oc-includes/server.php');
$table  = _TABLE_SOCIAL_FOLLOWERS_;
$status = "1";
$text   = "Block";
$info   = "";
if ($type == "block") 
  {
    $status = "0";
    $text   = "Unblock";
    $info   = "This will limit the person's interaction with you";
  }
$stmt   = $conn->prepare("UPDATE $table SET status=? WHERE following=? AND follower=? LIMIT 1");
if ($stmt && $stmt->bind_param('iss', $status, $username, $pin) && $stmt->execute()) 
  {
    $stmt->close();
    $conn->close();
    die('{"status":"success","result":"' . $text . '","info":"' . $info . '"}');
  }
$conn->close();
die('{"error":"Failed to block."}');
