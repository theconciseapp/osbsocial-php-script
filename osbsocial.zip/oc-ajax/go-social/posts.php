<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
require ('go-functions.php');
die(json_encode(home_posts()));
