<?php function sponsored_post($conn) 
  {
    $user         = "cv_sponsoredposts";
    $result       = $final_result = array();
    $table_users  = _TABLE_USERS_;
    $table        = _TABLE_SOCIAL_POSTS_;
    $stmt         = $conn->prepare("SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.added_on AS joined_on, U.birth, U.total_following, U.total_followers, P.*
FROM $table_users AS U 
LEFT JOIN $table AS P ON ( U.username=P.post_by )
WHERE U.username=?
ORDER BY RAND() LIMIT 10");
    if (!$stmt || !$stmt->bind_param('s', $user) || !$stmt->execute()) 
      {
        $final_result["error"]              = "Something went wrong";
        return $final_result;
      }
    $res = $stmt->get_result();
    $stmt->close();
    $total_posts   = $total_to_send = $res->num_rows;
    if ($total_posts < 1) 
      {
        $final_result["no_post"]               = "";
        return $final_result;
      }
    $i   = 0;
    while ($row = $res->fetch_assoc()) 
      {
        $result[]     = $row;
      }
    $final_result["status"]     = "success";
    $final_result["sponsored_post"]     = 1;
    $final_result["total_posts"]     = $total_posts;
    $final_result["result"]     = $result;
    $final_result["settings"]     = $settings__;
    return $final_result;
  }
