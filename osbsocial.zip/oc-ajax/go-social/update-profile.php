<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['username']) || empty($_POST["pin"]) || empty($_POST["name"]) || !isset($_POST["bio"]) || !isset($_POST["phone"]) || !isset($_POST["location"]) || !isset($_POST["birth"])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input(strtolower($_POST['username']));
$bio      = $location = $birth    = $phone    = "";
if (!validName($_POST["name"])) 
  {
    die('{"error":"Enter a valid name."}');
  }
$name = test_input($_POST["name"]);
if (strlen($name) > 50) 
  {
    die('{"error":"Name too long."}');
  }
if (!empty($_POST["bio"])) 
  {
    $bio      = test_input($_POST["bio"]);
  }
if (!empty($_POST["location"])) 
  {
    $location = test_input($_POST["location"]);
    if (strlen($location) > 100) 
      {
        die('{"error":"Location too long"}');
      }
  }
if (!empty($_POST["birth"])) 
  {
    $birth_date = test_input($_POST["birth"]);
    $create     = date_create($birth_date);
    if ($create !== false) 
      {
        $birth      = date_format($create, 'Y-m-d h:i:s');
      }
  }
if (!empty($_POST["phone"])) 
  {
    $phone      = test_input($_POST["phone"]);
  }
if (go_admin($username) && go_page($_POST['pin'])) 
  {
    //Admin can edit page posts. Pages created from admin panel
    $pin        = test_input(strtolower($_POST['pin']));
  }
else
  {
    $pin        = $username;
  }
require ('../../oc-includes/server.php');
$result       = $final_result = array();
$table_users  = _TABLE_USERS_;
$stmt         = $conn->prepare("UPDATE $table_users SET fullname=?, bio=?, phone=?, country=?, birth=? WHERE username=? LIMIT 1");
if ($stmt && $stmt->bind_param('ssssss', $name, $bio, $phone, $location, $birth, $pin) && $stmt->execute()) 
  {
    $stmt->close();
    $conn->close();
    die('{"status":"success","result":"Saved"}');
  }
$conn->close();
die('{"error":"Could not save"}');
