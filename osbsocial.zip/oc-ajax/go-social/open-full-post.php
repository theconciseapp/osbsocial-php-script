<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES" && empty($_POST["username"])) 
  {
    $_POST["username"] = "anonymous";
  }
if (empty($_POST['post_id'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$pid = test_input($_POST['post_id']);
require ('../../oc-includes/server.php');
$table   = _TABLE_SOCIAL_POSTS_;
$iresult = array();
$stmt    = $conn->prepare("SELECT post_title, post, post_files, post_meta FROM {$table} WHERE id=? AND post_status=1 LIMIT 1");
if ($stmt && $stmt->bind_param('i', $pid) && $stmt->execute()) 
  {
    $res     = $stmt->get_result();
    $conn->close();
    $stmt->close();
    if ($res->num_rows < 1) 
      {
        die('{"error":"Post unavailable"}');
      }
    $row = $res->fetch_assoc();
    $row["status"]     = "success";
    $row["settings"]     = $settings__;
    die(json_encode($row));
  }
die(json_encode('{"error":"Not known"}'));
