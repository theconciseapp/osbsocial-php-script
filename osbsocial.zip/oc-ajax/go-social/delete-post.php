<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
else if (empty($_POST['post_by']) || empty($_POST['true_author']) || empty($_POST['post_id']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username    = test_input(strtolower($_POST['username']));
$true_author = test_input(strtolower($_POST['true_author']));
$post_id     = test_input($_POST['post_id']);
$version     = test_input($_POST['version']);
if (go_admin($username) && go_page($_POST['post_by']) && $username == $true_author) 
  {
    //If admin, if is page, if this admin is the author
    $post_by     = test_input(strtolower($_POST['post_by']));
  }
else
  {
    $post_by     = $username;
  }
require ('../../oc-includes/server.php');
$table = _TABLE_SOCIAL_POSTS_;
$stmt  = $conn->prepare("DELETE FROM $table WHERE id=? AND post_by=? LIMIT 1");
if ($stmt && $stmt->bind_param('is', $post_id, $post_by) && $stmt->execute()) 
  {
    $aff   = $stmt->affected_rows;
    $stmt->close();
    $conn->close();
    die('{"status":"success"}');
  }
die('{"error":"Please try again."}');
