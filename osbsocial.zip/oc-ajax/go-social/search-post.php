<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
$settings__  = getSettings();
$force_login = isset($settings__["force_user_login"]) ? $settings__["force_user_login"] : "YES";
if ($force_login != "NO" && !verifyToken()) 
  {
    die('{"error":"Login required","ecode":"-1"}');
  }
if ($force_login != "YES" && empty($_POST["username"])) 
  {
    $_POST["username"] = "anonymous";
  }
if (empty($_POST["username"]) || !validUsername($_POST['username'], true) || empty($_POST["s"])) 
  {
    die('{"error":"Missing parameters."}');
  };
$username    = test_input($_POST['username']);
$search_word = trim($_POST["s"]);
$search_word = preg_replace("/[^A-Za-z0-9_' -]/", '', $search_word);
if (empty($search_word) || strlen($search_word) < 3) 
  {
    die('{"error":"No result found."}');
  };
require '../../oc-includes/server.php';
$table                 = _TABLE_SOCIAL_POSTS_;
$result                = array();
$final_result          = array();
if (!empty($_POST["page"])) 
  {
    $page_number           = (int)$_POST["page"];
  }
else
  {
    $page_number           = 1;
  }
$item_per_page         = isset($settings__["go_ppl"]) ? $settings__["go_ppl"] : "1";
$go_cpost              = isset($settings__["go_can_post"]) ? $settings__["go_can_post"] : "1"; //1: Only admins, 2: Admins & Verified users, 3: Everyone
$go_follow_btn         = isset($settings__["go_enable_follow_btn"]) ? $settings__["go_enable_follow_btn"] : "YES";
$go_homepage           = isset($settings__["go_homepage_posts"]) ? $settings__["go_homepage_posts"] : "1"; //1. User posts
$go_static_page        = isset($settings__["go_static_page"]) ? $settings__["go_static_page"] : "";
if ($go_cpost == "1") 
  {
    $role                  = "U.role=5";
  }
else if ($go_cpost == "2") 
  {
    $role                  = "U.role IN(4,5)";
  }
else
  {
    $role                  = "U.role IN(3,4,5)";
  }
$post_order            = isset($settings__["go_posts_order"]) ? $settings__["go_posts_order"] : "DESC";
if (!empty($_POST['post_order'])) 
  {
    $porder                = preg_replace("/[^A-Z]+$/", "", $_POST['post_order']);
    if ($porder == 'DESC' || $porder == 'ASC') 
      {
        $post_order            = $porder;
      }
  }
$item_per_page_ex      = $item_per_page + 1;
$previous_page         = 0;
$next_page             = 0;
$page_position         = (($page_number - 1) * $item_per_page);
$words                 = array_slice(explode(" ", $search_word, 3) , 0, 2);
$post_preview_         = $post_author_fullname_ = $post_title_           = "";
foreach ($words as $word) 
  {
    $post_preview_.= "P.post_preview LIKE '%" . mysqli_real_escape_string($conn, $word) . "%'  OR ";
    $post_title_.= "P.post_title LIKE '%" . mysqli_real_escape_string($conn, $word) . "%'  OR ";
    $post_author_fullname_.= "U.fullname LIKE '%" . mysqli_real_escape_string($conn, $word) . "%'  OR ";
  }
$search      = $post_preview_ . ' ' . $post_title_ . ' ' . $post_author_fullname_;
$search      = substr($search, 0, -5);
$table_users = _TABLE_USERS_;
$ftable      = _TABLE_SOCIAL_FOLLOWERS_;
if ($go_cpost == "1") 
  {
    $query       = mysqli_query($conn, "SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.birth, U.added_on AS joined_on, P.id, P.post_title, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status FROM {$table} AS P 
INNER JOIN $table_users AS U ON P.post_by=U.username
WHERE

( $search )
AND
 $role AND P.post_status=1

ORDER BY id $post_order LIMIT $page_position, $item_per_page_ex");
  }
else if ($go_follow_btn == "YES") 
  {
    $or          = "";
    if ($go_homepage == "0" && !empty($go_static_page)) 
      {
        $or          = "OR P.post_by='$go_static_page'";
      }
    $query       = mysqli_query($conn, "SELECT F.status AS follow_status, U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.birth, U.added_on AS joined_on, P.id, P.post_title, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status FROM {$table} AS P 
INNER JOIN {$table_users} AS U ON P.post_by=U.username
LEFT JOIN {$ftable} AS F ON ( P.post_by=F.following  AND F.follower='$username' AND F.status!=0 )
WHERE
( $search )
AND
 $role AND ( P.post_by='$username' $or OR 
 F.follower='$username' ) 
AND P.post_status=1  
ORDER BY id $post_order LIMIT $page_position, $item_per_page_ex");
  }
else
  {
    if ($go_homepage == "0" && !empty($go_static_page)) 
      {
        $query       = mysqli_query($conn, "SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.birth, U.added_on AS joined_on, P.id, P.post_title, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status FROM {$table} AS P 
INNER JOIN $table_users AS U ON P.post_by=U.username
WHERE

( $search )
AND
 $role AND P.post_by='$go_static_page' AND P.post_status=1

ORDER BY id $post_order LIMIT $page_position, $item_per_page_ex");
      }
    else
      {
        $query       = mysqli_query($conn, "SELECT U.fullname AS real_name, U.email, U.phone, U.country, U.bio, U.birth, U.added_on AS joined_on, P.id, P.post_title, P.post_date, P.post_by, P.post_preview, P.post_files, P.post_meta, P.total_comments, P.total_shares, P.reactions, P.post_status FROM {$table} AS P 
INNER JOIN $table_users AS U ON P.post_by=U.username
WHERE

( $search )
AND
 $role AND P.post_status=1

ORDER BY id $post_order LIMIT $page_position, $item_per_page_ex");
      }
  }
mysqli_close($conn);
if (!$query) 
  {
    die('{"error":"Please try again"}');
  }
$total_posts   = $total_to_send = mysqli_num_rows($query);
if ($total_posts < 1) 
  {
    die('{"status":"success","no_post":"No result found."}');
  }
if ($total_posts > $item_per_page) 
  {
    $next_page     = $page_number + 1;
    $total_to_send = $item_per_page;
  }
$i             = 0;
while ($row           = mysqli_fetch_assoc($query)) 
  {
    $i++;
    if ($i <= $total_to_send) 
      {
        $result[]               = $row;
      }
  }
$final_result["status"]               = "success";
$final_result["total_posts"]               = $total_posts;
$final_result["next_page"]               = $next_page;
$final_result["result"]               = $result;
$final_result["settings"]               = $settings__;
die(json_encode($final_result));
