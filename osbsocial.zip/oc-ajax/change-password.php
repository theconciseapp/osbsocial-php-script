<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['username'])) 
  {
    die('{"error":"Username is empty."}');
  }
else if (!validUsername($_POST['username'], true)) 
  {
    die('{"error":"Invalid username."}');
  }
else if (empty($_POST['new_password']) || empty($_POST['old_password'])) 
  {
    die('{"error":"Passwords cannot be empty."}');
  }
else if (!validPassword($_POST['new_password'])) 
  {
    die('{"error":"Password can only contain these characters: a-z 0-9 ~@#%_+*?- Min: 6"}');
  }
$username = test_input(strtolower($_POST['username']));
require ("../oc-includes/server.php");
$table = _TABLE_USERS_;
$op    = test_input($_POST['old_password']);
$np    = test_input($_POST['new_password']);
$stmt  = $conn->prepare("SELECT password FROM $table WHERE username=? LIMIT 1");
if (!$stmt || !$stmt->bind_param('s', $username) || !$stmt->execute()) 
  {
    $conn->close();
    die('{"error":"please try again."}');
  }
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    $conn->close();
    die('{"error":"Account not found."}');
  }
$row   = $res->fetch_assoc();
$old_p = $row["password"];
if (!password_verify($op, $old_p)) 
  {
    $conn->close();
    die('{"error":"Invalid old password."}');
  }
$password = password_hash($np, PASSWORD_DEFAULT);
$stmt     = $conn->prepare("UPDATE $table SET password=? WHERE username=? LIMIT 1");
if ($stmt && $stmt->bind_param('ss', $password, $username) && $stmt->execute()) 
  {
    $stmt->close();
    $conn->close();
    die('{"status":"success","result":"Password changed."}');
  }
$conn->close();
die('{"error":"Failed to change"}');
