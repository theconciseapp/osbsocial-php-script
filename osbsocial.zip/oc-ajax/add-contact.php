<?php header('Content-type:application/json;charset=utf-8');
require ('../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['username']) || empty($_POST['friend_username']) || empty($_POST['version'])) 
  {
    die('{"error":"Parameters missing."}');
  }
$settings__        = getSettings();
$enable_addcontact = isset($settings__["enable_add_contact"]) ? $settings__["enable_add_contact"] : 'YES';
if ($enable_addcontact != 'YES') 
  {
    die('{"error":"Sorry, adding contact currently not allowed."}');
  }
$username    = test_input(strtolower($_POST['username']));
$fusername   = test_input(strtolower($_POST['friend_username']));
$app_version = test_input(strtolower($_POST['version']));
if ($username == $fusername) 
  {
    die('{"error":"Sorry, you cannot add yourself."}');
  }
else if ($username == 'uv_private') 
  {
    die('{"error":"This is your private contact. No need to add."}');
  }
$group = false;
if (is_group_page($fusername)) 
  {
    $group = true;
  }
require "../oc-includes/server.php";
if (!$group) 
  {
    $table = _TABLE_USERS_;
    $stmt  = $conn->prepare("SELECT username, fullname, email, phone, country, bio, birth, added_on AS joined FROM $table WHERE ( username=? AND role<5 ) LIMIT 1");
    if (!$stmt || !$stmt->bind_param('s', $fusername) || !$stmt->execute()) 
      {
        $conn->close();
        die('{"error":"Please try again."}');
      }
    $res = $stmt->get_result();
    $stmt->close();
    $conn->close();
    if ($res->num_rows < 1) 
      {
        die('{"error":"Contact not found."}');
      }
    $row      = $res->fetch_assoc();
    $fullname = $row["fullname"];
    $result   = array();
    $result["status"]          = "success";
    $result["contact"]          = $row;
    $result["full_contact"]          = $row;
    die(json_encode($result));
  }
die('{"error":"It\'s a group."}');
