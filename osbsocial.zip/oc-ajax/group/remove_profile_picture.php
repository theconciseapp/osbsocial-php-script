<?php require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Token not valid."}');
  }
if (empty($_POST["username"]) || empty($_POST['group_pin'])) 
  {
    die('{"error":"Missing parameters."}');
  }
require '../../oc-includes/chat_functions.php';
require '../../oc-includes/server.php';
require 'group-functions.php';
$username = test_input(strtolower($_POST['username']));
$gpin     = test_input(strtolower($_POST['group_pin']));
$row      = get_group_data($conn, $gpin, $username);
if ($row === "-1") 
  {
    die('{"error":"Please try again","eno":"-1"}');
  }
else if ($row === "0") 
  {
    die('{"error":"Group pin not found","eno":"0"}');
  }
else if ($row === "00") 
  {
    die('{"error":"Permission denied","eno":"00"}');
  }
$dir   = getGroupDir($gpin);
$file  = $dir . '/profile_picture_full.jpg';
$thumb = $dir . '/profile_picture_small.jpg';
if (!file_exists($file) && !file_exists($thumb)) 
  {
    die('{"status":"success","result":"Deleted successfully."}');
  }
if (file_exists($file)) unlink($file);
if (file_exists($thumb)) unlink($thumb);
die('{"status":"success","result":"Photo removed."}');
