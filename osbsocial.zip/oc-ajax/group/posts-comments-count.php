<?php
/**
 * Class and Function List:
 * Function list:
 * Classes list:
 */
header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid security token."}');
  }
else if (empty($_POST['username']) || empty($_POST['post_ids']) || empty($_POST['version'])) 
  {
    die('{"error":"Missing parameters."}');
  }
$username = test_input(strtolower($_POST['username']));
$post_ids = $_POST['post_ids']; //Array of posts ids
//$post_ids= array("251539483454460", "937596255032433","139897599341344");
require ("../../oc-includes/server.php");
require ("group-functions.php");
$clean_arr = array_filter($post_ids, "ctype_digit");
$total_ids = count($clean_arr);
if ($total_ids < 1) 
  {
    die('{"status":"success","empty_id":"Empty id submitted"}');
  }
if ($total_ids === 1) 
  {
    //If single post id
    die(comment_count($clean_arr[0]));
  }
else
  {
    die(all_post_comments($clean_arr));
  }
