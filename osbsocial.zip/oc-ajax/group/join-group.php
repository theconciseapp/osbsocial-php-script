<?php header('Content-type:application/json;charset=utf-8');
require ('../../oc-includes/bootstrap.php');
if (!verifyToken()) 
  {
    die('{"error":"Invalid token."}');
  }
if (empty($_POST['username']) || empty($_POST['group_pin']) || empty($_POST['version'])) 
  {
    die('{"error":"Parameters missing."}');
  }
$settings__       = getSettings();
$enable_joingroup = isset($settings__["enable_join_group"]) ? $settings__["enable_join_group"] : 'YES';
if ($enable_joingroup != 'YES') 
  {
    die('{"error":"Joining group is currently not allowed."}');
  }
$users_pgroup = isset($settings__["users_per_group"]) ? (int)$settings__["users_per_group"] : 100;
$username     = test_input(strtolower($_POST['username']));
$gpin         = test_input(strtolower($_POST['group_pin']));
$app_version  = test_input(strtolower($_POST['version']));
if ($username == $gpin) 
  {
    die('{"error":"Sorry, not allowed."}');
  }
else if (!validUsername($username, true)) 
  {
    die('{"error":"Sorry, invalid username."}');
  }
else if (!validUsername($gpin, true)) 
  {
    die('{"error":"Sorry, not allowed."}');
  }
$gdir = getGroupDir($gpin);
require "../../oc-includes/server.php";
require "group-functions.php";
$table = _TABLE_GROUPS_;
$stmt  = $conn->prepare("SELECT auto_join, is_admin, username, fullname, group_info, group_admins, group_members, total_members, created_by, created_on FROM $table WHERE username=? LIMIT 1");
$stmt->bind_param('s', $gpin);
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();
if ($res->num_rows < 1) 
  {
    try
      {
        //Remove this group from user account since it doesn't exist again
        $table_users = _TABLE_USERS_;
        $sgpins      = "{$gpin} ";
        mysqli_query($conn, "UPDATE $table_users SET groups=REPLACE( groups, '$sgpins', '') WHERE username='$username' LIMIT 1");
      }
    catch(Exception $e) 
      {
        logIt($e->getMessage());
      }
    $conn->close();
    die('{"error":"Pin not found"}');
  }
$row           = $res->fetch_assoc();
$total_members = (int)$row['total_members'] + 1;
$members       = $row['group_members'];
if (is_group($gpin) && $total_members > $users_pgroup) 
  {
    $conn->close();
    die('{"error":"This group is full"}');
  }
$is_member       = "false";
if (preg_match("/\b{$username}\b,/", $members)) 
  {
    $is_member       = "true";
  }
$table_gmessages = _TABLE_GROUPS_MESSAGES_;
$mresult         = mysqli_query($conn, "SELECT id FROM $table_gmessages ORDER BY id DESC LIMIT 1");
if (!$mresult) 
  {
    //Last group message id error
    die('{"error":"LGMI error"}');
  }
$mrow        = mysqli_fetch_row($mresult);
$lastgmid    = $mrow[0];
$lastmtime   = "" . (microtime(true) * 10000);
$data        = array();
$title       = $row["fullname"];
$info        = $row['group_info'];
$cby         = $row["created_by"];
$con         = $row["created_on"];
$time_       = time();
$row["last_message_time"]             = $lastmtime;
$row["last_message_id"]             = $lastgmid;
$row["app_version"]             = $app_version;
$row["joined"]             = $time_;
$row["total_members"]             = $total_members;
$mem         = $username . ",";
$meta        = array();
if ($is_member == 'true') 
  {
    $query       = true;
  }
else
  {
    if (is_group($gpin)) 
      {
        $query       = mysqli_query($conn, "UPDATE $table SET total_members='$total_members', group_members=CONCAT( group_members,    '$mem' ) WHERE username='$gpin' LIMIT 1");
      }
    else
      {
        $query       = mysqli_query($conn, "UPDATE $table SET total_members='$total_members' WHERE username='$gpin' LIMIT 1");
      }
  }
//Save group to user account
$table_users = _TABLE_USERS_;
$save_group  = "{$gpin} ";
try
  {
    mysqli_query($conn, "UPDATE $table_users SET groups=CONCAT( REPLACE(  groups, '$save_group' , '') , '$save_group') WHERE username='$username' LIMIT 1");
  }
catch(Exception $e) 
  {
    logIt($e->getMessage());
  }
if ($query) 
  {
    if (empty($_POST["auto_join"])) 
      {
        //No need sending message if auto joined
        if (is_group($gpin)) 
          {
            $msg     = '_?sm?g' . ucfirst($username) . ' joined?g?sm_';
            $preview = str_replace('_', '', $msg);
            customGroupMessage($conn, $gpin, $preview, $msg);
          }
        else
          {
            $message = "?smYou followed:?sm *?g" . ucfirst($title) . "?g*\n*About page*\n" . $info;
            $preview = str_replace('_', '', $message);
            inboxUser($conn, $username, $preview, $message);
          }
      }
    $conn->close();
    $lock    = "unlocked";
    if (file_exists($gdir . "/lock.md")) 
      {
        $lock    = "locked";
      }
    $row["status"]         = "success";
    $row["lock_status"]         = $lock;
    if (!empty($members)) 
      {
        $toarray = explode(",", $members);
        sort($toarray);
        $members = implode(" ", $toarray);
        $row["group_members"]         = $members;
      }
    die(json_encode($row));
  }
$conn->close();
die('{"error":"Failed to join group."}');
