<?php if (!defined('__ALLOW__')) 
  {
    die('{"error":"51"}'); //Method not allowed
    
  }
if (empty($_POST['chat_to']) || empty($_POST['chat_id']) || !is_numeric($_POST['chat_id']) && strlen($_POST['chat_id']) > 30) 
  {
    die('{"error":"52"}'); //Parameters missing.
    
  }
$chat_to = test_input(strtolower($_POST['chat_to']));
$dir     = getUserDir($chat_to); //recipient directory
if (!startsWith($chat_to, 'gp_') && !is_dir($dir)) 
  {
    die('{"status":"success","file_size":"1","file_folder":"images"}');
  }
$chat_id   = test_input($_POST['chat_id']);
$base64    = test_input($_POST['base64']);
$bfilesize = strlen($base64) / 1024;
$bfilesize = $bfilesize / 1024;
if ($bfilesize > _MAX_CHAT_FILES_SIZE_) 
  {
    die('{"error":"3"}');
  }
$base64   = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $base64));
$filename = $chat_to . '-' . $chat_id;
$folder   = "images/messenger/" . _CHAT_FILES_STRUCTURE_;
$dir      = _CHAT_FILES_DIR_ . "/{$folder}";
if (!make_dir($dir)) 
  {
    die('{"error":"53"}'); //Unable to create directory
    
  }
$f                    = finfo_open();
$mime_type            = finfo_buffer($f, $base64, FILEINFO_MIME_TYPE);
$file_type            = explode('/', $mime_type) [0];
$extension            = explode('/', $mime_type) [1];
$acceptable_mimetypes = allowedImages();
if (in_array($mime_type, $acceptable_mimetypes)) 
  {
    if ($result               = masterImageUpload($base64, $filename, ["thumb_width"                      => 20, "folder"                      => $folder, "dir"                      => $dir])) 
      {
        $file_size            = filesize($result["saved_to"]);
        $file_path            = $result["file_path"];
        $folder               = $result["folder"];
        $width                = $result["width"];
        $height               = $result["height"];
        die('{"status":"success","file_size":"' . $file_size . '","file_folder":"' . $folder . '","file_path":"' . $file_path . '","ext":"jpg","width":"' . $width . '","height":"' . $height . '"}'); //Successful
        
      }
    else die('{"error":"00"}'); //Failed
    
  }
else
  {
    die('{"error":"2"}'); //Unsupported
    
  }
die('{"error":"00"}'); //Failed
