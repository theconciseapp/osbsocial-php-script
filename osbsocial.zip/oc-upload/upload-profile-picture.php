<?php @ini_set('memory_limit', '32M');
@ini_set('upload_max_filesize', '9M');
@ini_set('post_max_size', '10M');
@ini_set('max_execution_time', 60);
@ini_set('max_input_time', 60);
require '../oc-includes/bootstrap.php';
if (!verifyToken()) 
  {
    die('{"error":"Login required"}');
  }
require '../oc-includes/chat_functions.php';
if (empty($_POST['username']) || empty($_POST['base64'])) 
  {
    die('{"error":"Missing parameters"}');
  }
function uploadBase64Image($dir, $save_to, $file_data, $thumb_dest, $mthumb_dest) 
  {
    $f                    = finfo_open();
    $mime_type            = finfo_buffer($f, $file_data, FILEINFO_MIME_TYPE);
    $file_type            = explode('/', $mime_type) [0];
    $extension            = explode('/', $mime_type) [1];
    $acceptable_mimetypes = ['image/gif', 'image/jpeg', 'image/jpg', 'image/png'];
    if (in_array($mime_type, $acceptable_mimetypes)) 
      {
        if ($result               = masterImageUpload($file_data, "profile_picture_full", ["dir"                      => $dir, "folder"                      => "null", "direct_filename"                      => true, "resiz"                      => 500])) 
          {
            $file_size            = filesize($result["saved_to"]);
            $saved_to             = $result["saved_to"];
            $file_path            = $result["file_path"];
            $width                = $result["width"];
            $height               = $result["height"];
            resizeImage($saved_to, $mthumb_dest, 300); //Medium
            resizeImage($saved_to, $thumb_dest, 100); //Small
            die('{"status":"success","result":"Photo uploaded.","width":"' . $width . '","height":"' . $height . '"}');
          }
        else die('{"error":"Upload failed."}');
      }
    else
      {
        die('{"error":"Photo type not supported."}');
      }
    die('{"error":"Failed to upload."}');
  }
$base64   = test_input($_POST['base64']);
$base64   = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $base64));
$username = test_input(strtolower($_POST['username']));
if (!empty($_POST['pin']) && go_admin($username) && go_page($_POST['pin'])) 
  {
    //Admin can edit page posts. Pages created from admin panel
    $pin      = test_input(strtolower($_POST['pin']));
  }
else
  {
    $pin      = $username;
  }
$dir      = getUserDir($pin);
if (!is_dir($dir)) 
  {
    die('{"error":"Upload not successful."}');
  }
$file        = $dir . '/profile_picture_full.jpg';
$thumb       = $dir . '/profile_picture_small.jpg';
$mediumThumb = $dir . '/profile_picture_medium.jpg';
uploadBase64Image($dir, $file, $base64, $thumb, $mediumThumb);
