<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn();

require ('includes/admin-functions.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>
<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 50px;">

    <form class="d-flex">
      <input id="search-box" class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button id="search-button" class="btn btn-outline-success" data-header-button-item="search-users-container" data-page="search-users" type="submit">Search</button>
<input type="hidden" id="search-box-item"  value="">
    </form>
  
<div class="main-header-container">
 <div class="row text-center">
 <div class="col">
<div data-header-button-item="active-users-container" class="main-header-button main-header-button-selected" data-page="active-users" style="border-radius: 5px 0 0 0;">
    ACTIVE
    </div>
</div>
<div class="col">
<div data-header-button-item="inactive-users-container" data-page="inactive-users" class="main-header-button">
    INACTIVE
    </div>
</div>
   <div class="col">
 <div data-header-button-item="blocked-users-container" class="main-header-button" data-page="blocked-users" style="border-radius: 0 5px 0 0;">
  BLOCKED
    </div>

</div>
 
 </div>
</div>

<div id="pages-containehr">

<div id="active-users-container" class="header-page"></div>

<div id="inactive-users-container" class="d-none header-page"></div>

<div id="blocked-users-container" class="d-none header-page"></div>

<div id="search-users-container" class="d-none header-page"></div>

</div>

</div>
</div>
</div>

<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>

<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>

<script>
loadMain( _ADMIN_URL_ + '/ajax/active-users.php');

$('#backup').on('click',function(e){
 e.preventDefault();
var this_=$(this);

buttonSpinner( this_ );

setTimeout( function(){

document.location = "backup.php";
buttonSpinner( this_,true );

},3000);
});

</script>
</body>
</html>
