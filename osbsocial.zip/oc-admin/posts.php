<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn();

$admin_username = getAdminInfo('username');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
var _USERS_PATH_='<?php echo _CHAT_USER_PATH_; ?>';
</script>
</head>
<body>

<nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> <img src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>" class="logo"> <?php echo _BRAND_NAME_; ?> </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="<?php echo _ADMIN_URL_; ?>">Home</a>

<a class="nav-link" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>">Logout</a>
     
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid">
<div class="row">

<div class="col-12 col-md-4 col-lg-3 first-column">

<h5 class="p-3 text-white">POSTS & COMMENTS
</h5>

<div class="sidebar-container">
Manage group/page messages or posts sent from app or admin panel.
</div>

</div>
 
<div class="col-12 col-md-8 col-lg-9 second-column">

<div class="container-fluid" style="padding: 15px;">
   <!--
 <form class="d-flex">
      <input id="search-box" class="form-control me-2" type="search" placeholder="Search posts" aria-label="Search">
      <button id="search-button" class="btn btn-outline-success" type="submit" data-header-button-item="search-posts-container" data-page="search-posts">Search</button>

<input type="hidden" id="search-box-item" value="">
    </form>
-->
  </div>

<div class="main-header-container">
 <div class="row text-center">
 <div class="col">
<div data-header-button-item="posts-container" class="main-header-button main-header-button-selected" data-page="posts" style="border-radius: 5px 0 0 0;">
 GROUPS POSTS
    </div>
</div>

 </div>
</div>

<div id="pages-container" class="mb-5">

<div id="posts-container" class="header-page" style="background: rgba(0,255,1, 0.03); border:0; border-radius: 5px;"></div>

<div id="search-posts-container" class="d-none header-page"></div>

</div>
</div>
</div>
</div>


<div id="comment-container" style="display: none;">
<input type="hidden" id="current-post-id" value="">
<input type="hidden" id="current-post-group" value="">

<div id="comment-loader-container">
        <div class="loader1">
          <div class="spin"></div>
        </div> 
      </div>
   <div id="post-comment-title-cont">
     <div class="row">
       <div class="col" style="max-width: 90px;">
       <i class="fa fa-2x fa-refresh text-warning" style="margin-left: 10px;" id="comment-refresh-btn"></i>
</div>
       <div class="col">

     <input type="text" class="form-control" id="send-comment-as" value="<?php echo $admin_username; ?>">

       </div>
       <div class="col" style="max-width: 90px; text-align: right; margin-right: 10px;">
         <span id="close-comment-container" class="fa fa-2x fa-close text-danger"></span>
       </div>
       </div>
     </div>
      <div id="post-comments-container">
        <a id="prev-comments" href="javascript:void(0);">Previous comments</a>
        <div id="post-comments"></div>
      <div id="my-comments-container"></div>
        <a id="next-comments" data-value="" href="javascript: void(0);">Next comments</a>
        
      </div>

<div id="comment-input-container">
 <div class="row">
<div class="col">
<textarea id="comment-textarea"></textarea>
</div>
<div class="col" style="max-width: 100px; padding: 10px 0;"> 
<button class="btn btn-sm btn-success" id="send-comment">Send</button>

<button class="mt-2 btn btn-sm btn-primary" id="auto-comment">Smart</button>

 </div>
</div>


</div>

</div>


<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



<link rel="stylesheet" href="assets/css/comments.css?i=<?php echo randomString(2); ?>">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="assets/js/global.js?y=z"></script>
<script src="assets/js/index.js?i=<?php echo randomString(2); ?>"></script>
<script src="assets/js/posts.js?i=<?php echo randomString(2); ?>"></script>

<script>
loadMain( _ADMIN_URL_ + '/ajax/posts.php','#posts-container');
</script>
</body>
</html>
