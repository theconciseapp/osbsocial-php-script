<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn();

$allowedExts = array(

    "mp4"

);

if (!isset($_FILES["video"])) 

  {

    die('{"error":"Go back and select a video"}');

  }

else if (!adminCanChangeSettings()) 

  {

    die('{"error":"Permission denied."}');

  }

$extension = strtolower(pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION));

$videoSize = $_FILES["video"]["size"];

$max       = 1024 * 1024 * 10;

$videoType = strtolower($_FILES["video"]["type"]);

if ($videoType == 'video/mp4' && $videoSize < $max && in_array($extension, $allowedExts)) 

  {

    if ($_FILES["video"]["error"] > 0) 

      {

        echo "Return Code: " . $_FILES["video"]["error"] . "<br />";

      }

    else

      {

        $size = round(($videoSize / 1024) / 1024);

        echo "Size: " . ($size < 1 ? '1' : $size) . " MB<br />";

        $udir     = _CHAT_FILES_DIR_ . "/welcome";

        if (make_dir($udir)) 

          {

            $uploadTo = $udir . "/0123456789.mp4";

            if (move_uploaded_file($_FILES["video"]["tmp_name"], $uploadTo)) 

              {

                echo '<h1 style="color: green;">Saved Successfully!</h1>
 <script> //localStorage.setItem("welcome-message-uploaded","' . rand() . '");
</script>';

              }

            else

              {

                echo '<h1 style="color: #d9534f;">Failed to upload videoh.</h1>';

              }

          }

        else

          {

            echo '<h1 style="color: #d9534f;">Unable to create welcome directory.</h1>';

          }

      }

  }

else

  {

    echo '<h1 style="color: #d9534f;">Invalid file</h1>';

  }

