<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

require ('includes/admin-functions.php');

adminLoggedIn();

$admin_username = getAdminInfo('username');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<link rel="stylesheet" href="assets/css/mediaelementplayer.css">

<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

<link rel="stylesheet" href="assets/css/go-social.css?i=0">
<link rel="stylesheet" href="assets/css/go-comments.css?i=0">
<link rel="stylesheet" href="assets/css/go-reported-contents.css?i=0">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
var _USERS_PATH_='<?php echo _CHAT_USER_PATH_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">

    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div class="container-fluid bg-secondary text-light">

 <div class="row">
 <div class="col-8 pt-2">

  <strong>REPORTED CONTENTS</strong>
</div>
<div class="col text-right">

 <button style="background: none; outline: none; border:0; padding-top: 2px;" onclick="goOpenSearchReportBox();">
     <span class="text-info fa fa-search fa-2x"></span>
     </button>
    </div>

 </div>
</div>

<div id="go-reports-column"></div>

<div class="text-center" id="report-loading-indicator" style="display: none;">

<span style="" class="fa fa-spinner fa-spin fa-4x text-primary"></span>

</div> 

</div>
</div>
</div>

<!--Search container-->

  <div class="container-fluid" id="go-search-report-container">
  <div id="go-search-report-child-container">

<div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">

<div class="row">
<div class="col" style="max-width: 60px;" onclick="goCloseSearchReport();" style="max-width: 60px;">
   <span class="text-danger fa fa-times fa-2x"></span>
</div>

  <div class="col">
   <form action="javascript: void(0);" onsubmit="searchReports(1);">
     <input type="text" id="go-search-box" maxlength="100" placeholder="Search..." />
   <button type="submit" style="background: none; outline: none; border:0; padding-top: 2px;">
     <span class="fa fa-search fa-lg"></span>
     </button>
    </form>
    </div>
 
</div>
</div>
</div>
<div class="u-content" id="go-search-report-contents">
  
  <div id="go-searched-report-posts"></div>

 <div class="text-center">
<span id="search-loading-indicator" style="display: none; margin:0 auto;" class="fa fa-spinner fa-spin fa-4x text-primary"></span>
</div>
</div>
 </div> 
 </div> <!--END Search container-->



<!--SINGLE POST CONTAINER-->
  
  <div class="container-fluid p-0" id="go-single-post-container">    
  <div id="go-single-post-child-container">       
    <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
   <div class="col" onclick="goCloseSinglePost();" style="padding: 10px 0 10px 14px; max-width: 60px;"> 
  <span class="fa fa-times fa-2x text-danger"></span>
  </div>
  <div class="col p-0">
   </div>
    </div>
    </div>
    </div>
    <div class="u-content">
    <div id="go-single-post"></div>
  
<div id="single-post-loading-indicator" style="display: none; margin:0 auto;" class="text-center"><span class="fa fa-spinner fa-spin fa-4x text-primary"></span></div>
    </div>
    </div>
   </div> <!--END Single container--> 
      
<!--COMMENTS-->
     
   <div id="go-comment-container">
     <div id="go-comment-child-container">
      <div id="comment-loader-container">
        <span class="loader1 fa fa-spinner fa-spin fa-3x text-success">
        </span> 
      </div>
   <div id="post-comment-title-cont">

     <div class="container-fluid">
       <div class="row">
     <div class="col" onclick="refreshComment();" style="max-width: 60px;">
      <span class="text-secondary fa fa-refresh fa-2x"></span>
     </div>
    <div class="col">
    <div id="go-comment-title" class="text-left">Comments</div>
    </div>
       <div class="col" style="max-width: 60px;">
         <div id="post-comment-sending-cont"></div>
       </div>

<div class="col" style="max-width: 40px;" onclick="goCloseComment();">
<span class="text-danger fa fa-times fa-2x"></span>
</div>

       </div>
     </div>
     </div>
      <div id="post-comments-container">
        <a id="prev-comments" href="javascript:void(0);">Previous comments</a>
        <div id="post-comments"></div>
      <div id="my-comments-container"></div>
        <a id="next-comments" data-value="" href="javascript: void(0);">Next comments</a>    
      </div>
     <div id="go-comment-upload-preview-container"></div>
     
     <div id="go-comment-box-container" class="d-none container">
      <div class="row">
        <div class="col text-center" style="max-width: 50px;">
       <button id="go-comment-upload-file-btn">
          <img class="icon-medium" src="file:///android_asset/go-icons/gallery.png">
       </button>
        
        </div>
        <div class="col">
          <textarea id="go-comment-box" placeholder="Share your opinion..."></textarea>
        </div>
        <div class="col" style="max-width: 50px; padding-left: 0;">
        <button id="go-send-comment-btn">
          <img class="icon-medium" src="file:///android_asset/go-icons/send.png">
        </button>
        </div>
        
       </div>
     </div>
    </div>  
  </div><!--End comment container-->
  



<!--EDIT POST FORM-->
  
  <div class="container-fluid go-shade p-0" id="go-edit-post-form-container">

  <div class="go-shade-child" id="go-edit-post-form-child-container" style="max-width: 700px;">       
    
  <div class="u-header" style="border-bottom: 1px solid rgba(0,0,0,0.18);">
   <div class="container-fluid">
      <div class="row">
<div class="col pt-2" style="max-width: 60px;">
<div id="edit-post-form-loading-indicator" style="display:none;"> <i class=" fa fa-spinner fa-spin fa-2x text-success"></i></div>
</div>
<div class="col">

<button id="edit-post-btn" class="btn btn-sm btn-primary mt-2" onclick="goUpdatePost(this);">Update</button>

</div>
   <div class="col" onclick="goCloseEditPostForm();" style="padding: 10px 0 10px 14px; max-width: 50px;">
  <span class="text-danger fa fa-times fa-2x"></span>
  </div>
  
    </div>
    </div>
    </div>
    <div class="u-content">
    

<form id="edit-post-form" action="<?php echo _ADMIN_URL_ . '/ajax/go-social/edit-post.php'; ?>" method="post">
<div class="container">

<div class="row">

<div class="col-3">
ID
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-id" name="id" readonly="readonly">
</div>


<div class="col-3">
POST BY
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_by" name="post_by">
</div>


<div class="col-12 d-none">
POST PREVIEW
</div>
<div class="col-12 d-none">
<textarea id="edit-post-post_preview" class="form-control mb-2" style="height: 100px;" name="post_preview"></textarea>
</div>

<div class="col-12">
POST
</div>
<div class="col-12">

<textarea id="edit-post-post" class="form-control mb-3" style="height: 200px;" name="post"></textarea>

</div>

<div class="col-3 d-none">
Post by name
</div>
<div class="col-9 d-none">
<input class="form-control mb-2" id="edit-post-post_by_fullname" name="post_by_fullname">
</div>


<div class="col-12">
POST FILES
</div>
<div class="col-12">
<textarea id="edit-post-post_files" class="form-control mb-2" style="height: 100px;" name="post_files"></textarea>
</div>


<div class="col-3">
Post type
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_type" name="post_type">
</div>

<div class="col-3">
Total comments
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-total_comments" name="total_comments">
</div>

<div class="col-3">
Total shares
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-total_shares" name="total_shares">
</div>


<div class="col-3">
Total reactions
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-reactions" name="reactions">
</div>

<div class="col-3">
Post status
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_status" name="post_status">
</div>

<div class="col-3">
Post date
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-post_date" name="post_date">
</div>

<div class="col-3">
Date time
</div>
<div class="col-9">
<input class="form-control mb-2" id="edit-post-date_time" name="date_time">
</div>

</div>

<input type="hidden" id="edit-post-post_meta" name="post_meta">
</div>
</form>

<div class="container bg-light pt-2">

<div class="row">
<div class="col-3">
<strong>POST META</strong>
</div>
<div class="col-9">

<form id="edit-meta-form"></form>

</div>
</div>
</div>

</div>
    </div>
   </div>
 <!--END edit post form container--> 









<!--ENLARGED PICTURE-->
  
  <div id="go-full-photo-container">
<span id="go-close-full-photo-btn" onclick="goCloseFullPhoto();" class="fa fa-times fa-3x text-danger mt-4"></span>
<div id="go-full-photo-child-container"></div>
</div>
  <div id="go-full-cover-photo-container">
</div>
  

    
 <div id="go-video-element-container"></div>
<input type="hidden" id="current-post-id" value="" /> <!--To be used by posts comment-->
<input type="hidden" id="current-post-by" value="" /> <!--To be used by post comment-->
<input type="hidden" id="go-next-report-page-number" value="" />
<input type="hidden" id="go-next-search-report-page-number" value="" />


<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="assets/js/global.js"></script>
<script src="assets/js/yall.js"></script>
<script src="assets/js/mediaelement-and-player.min.js"></script>
<script src="assets/js/go-social.js?i=<?php echo randomString(2); ?>"></script>
<script src="assets/js/go-comments.js?i=<?php echo randomString(2); ?>"></script>
<script src="assets/js/go-reported-contents.js?i=<?php echo randomString(2); ?>"></script>

<script>

$(function(){
loadReports();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
  yall({
    observeChanges: true,
   // delay: 5000,
  });
});

</script>

</body>
</html>
