<?php require ('../oc-includes/bootstrap.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no,user-scalable=0" />
<meta id="csrf-token" name="csrf-token" content="">
<title>Forgot password</title> 
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" integrity="undefined" crossorigin="anonymous">


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>

<style>
.header{
}

.header img{
width: 60px;
height: 60px;
display: block;
}
</style>

</head>
<body>

<div class="container">

<div class="form-container border" style="margin: 80px auto 0 auto; width: 90%; max-width: 500px; padding: 30px;">

<img src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>" class="d-block logo" style="height: 60px; width: 60px; margin: 0 auto;">

<div class="mb-3">

<label class="form-label">Enter Your Email Address</label>

<input type="email" id="email-box" class="form-control"  placeholder="username@email.com" />
</div>
<div id="forgot-password-result" class="mb-2" style="height: 17px;"></div>

<button id="forgot-password-btn" class="btn btn-sm btn-primary">Reset Password</button>

</form>
</div>
</div>
<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>
<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>
</body>

</html>
