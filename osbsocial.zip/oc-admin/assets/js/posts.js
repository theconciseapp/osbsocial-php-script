var fetchingComment;

$(function(){

//POSTS

//HIDE GROUP/PAGE POST IN APP

$('body').on('click','.hide-post',function(){
  var this_=$(this);
  var pid=$.trim( this_.attr('data-pid') );
 var gpin=$.trim( this_.attr('data-gpin'));
  
 if( !confirm('Hide selected post?') ) return false;

 if( !pid){
  return toast('Post id not found.');
 }
else
if( !gpin){
  return toast('Group pin not found.');
 }

    
    buttonSpinner( this_);
  setTimeout(function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/hide-group-post-in-app.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "group_pin": gpin,
      "post_id": pid,
   
    }
  }).done(function(result){
   // alert(JSON.stringify(result))

buttonSpinner( this_, true);
  if( result.status){

 return toast('Successfully hidden.',{ type:'success'});

  }
else if( result.error){
      toast( result.error);
  }
   else toast('Unknown error');
 }).fail(function(e,txt,xhr){
  buttonSpinner( this_, true);
  toast('Could not hide. ' + xhr);
  
  });
    
  },1000);
});



//DELETE POSTS

$('body').on('click','.delete-post',function(){
  var this_=$(this);
  var pid=$.trim( this_.attr('data-pid') );
 var gpin=$.trim( this_.attr('data-gpin'));
  if(!confirm('Delete selected post?') ) return false;


 if( !pid){
  return toast('Post id not found.');
 }
else
if( !gpin){
  return toast('Group pin not found.');
 }
    
    buttonSpinner( this_);
  setTimeout(function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/delete-group-post.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "group_pin": gpin,
      "post_id": pid,
   
    }
  }).done(function(result){
   // alert(JSON.stringify(result))

buttonSpinner( this_, true);
  if( result.status){

   $('#group-post-' + result.pid).remove();
 
  }
else if(result.error){
      toast(result.error);
  }
   else toast('Unknown error');
 }).fail(function(e,txt,xhr){
  buttonSpinner( this_, true);
  toast('Could not delete. ' + xhr);
  
  });
    
  },1000);
});





//COMMENTS

 $('body').on('click','.view-post-comments', function(){
 var this_= $(this);
var pid= this_.data('pid');
var gpin= this_.data('gpin');

 $('#current-post-id').val(pid);
$('#current-post-group').val(gpin);

$('#my-comments-container,#post-comments').empty();

fetch_comments(  pid,'', this_);

});


$('body').on('click','#comment-refresh-btn',function(){
var this_=$(this);

 if( fetchingComment){
   return toast('Please be patient.');
 }   
  $('#my-comments-container,#post-comments').empty();
   $('#prev-comments,#next-comments').css('display','none');
   fetch_comments("","", this_);   
 });
  
$('body').on('click','#prev-comments',function(){
try{
 if( fetchingComment){
   return toast('Please be patient.');
 }

 var this_=$(this);
  var page=this_.attr('data-value');

  if(!page) return toast('No more comments.',{type:'light',color:'#333'});
 //$('#my-comments-container,#post-comments').empty(); 
   fetch_comments("", page, this_);
}catch(e){
  alert(e);
} 
 });
  


$('body').on('click','#send-comment',function(){

var this_=$(this);
var txt=$('#comment-textarea');

var msg=$.trim( txt.val() );
if( msg.length<1){
 return toast('Comment too short.');
}

var fuser=$.trim( $('#current-post-group').val() );
var mlen= (msg.length/1024);

add_comment( fuser, msg, mlen, this_);
});

$('body').on('click','#auto-comment',function(){

var this_=$(this);

var gpin=$.trim( $('#current-post-group').val() );

auto_comment(gpin, this_);

});





$('body').on('click','#close-comment-container',function(){

 $('#comment-container').hide();
$('#prev-comments').hide();

});


$('body').on('click','.delete-comment',function(){
  var this_=$(this);
  var cid=this_.attr('data-cid');
 
  if(!confirm('Delete selected comment?') ) return false;

 if(!cid){
    return toast('Comment id not found.');
  }
 
 var tb=$('#comment-textarea,.delete-comment');
     
 tb.prop('disabled', true); 
    
var gpin=$.trim($('#current-post-group').val());
 
    buttonSpinner( this_);

  setTimeout(function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/delete-post-comment.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "group_pin": gpin,
      "comment_id": cid,
    //  "post_id": cpiv,
    }
  }).done(function(result){
   // alert(JSON.stringify(result))
tb.prop('disabled', false); 
buttonSpinner( this_, true);
  if( result.status){

   $('#post-comments-container #ccc-' + cid).remove();
   
  }
else if(result.error){
      toast(result.error);
  }
   else toast('Unknown error');
 }).fail(function(e,txt,xhr){
  buttonSpinner( this_, true);
  toast('Could not delete. ' + xhr);

    tb.prop('disabled', false);  
  });
    
  },1000);
});




});


function toDate(UNIX_timestamp,time_){
  var a = new Date(UNIX_timestamp * 1000);
  var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  var year = a.getFullYear();
  var month=a.getMonth();
  var month_ = months[month];
  var date = a.getDate();
  var hour = a.getHours();
  var min = a.getMinutes();
  var sec = a.getSeconds();
  var time= formatTime(hour,min);
  var date_= month_ + ' ' + date + ', ' + year;
  var today=moment().format('MMMM D, YYYY');
  var isToday=false;
 if(strtolower(date_)==strtolower(today) ) isToday=true;

  var result="";
 if(time_ && time_=='last_seen'){
   result='Last seen ' + (isToday?'today ':date_) + ' at ' + time;
 }else if(time_=='chat_date') {
    result= (isToday?'TODAY':date_.toUpperCase() ); 
 } else if(time_=='chat_list_date') {
    result= (isToday?time: date + '/' + ( month +1)+ '/' + year ); 
   }
 else if(time_=='comment_date') {
    result= (isToday?time: date_ )
   //date + '/' + ( month +1)+ '/' + year + '&bull; ' + time); 
   }
  else if(time_) { result= time;  }
  else{ result= date_; }
  return result;
}


function formatTime(hours,minutes) {
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+ minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}



function fetch_comments( pid,page_number,this_){

var ui=$('.view-post-comments');
  buttonSpinner(this_);
  ui.prop('disabled',true);

var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val() );
   
  pid=cpiv||pid;

  page_number=page_number?'?page=' + page_number:'';
  

var cdiv=$('#comment-container');

var gpin=$('#current-post-group').val();

  fetchingComment=true;

try{

$.ajax({
url: _ADMIN_URL_ + '/ajax/post-comments.php' + page_number ,
type:'POST',
dataType:'json',
data: {
  post_id: pid,
 group_pin: gpin,
},

}).done( function(result){
 cdiv.show();
fetchingComment=false;
 buttonSpinner( this_,true);
  ui.prop('disabled', false);

 //alert( JSON.stringify(result))

$('#prev-comments, #next-comments').prop('disabled',false)

    var nextPage=result.next_page;
    var prevPage=result.prev_page;
    
  if( result.no_comment){
    
  $('#post-comments').html('<div class="no-comment-container text-center" id="no-comment-cont-' + pid + '">No Comment Yet</div>');
  }
 else if( result.result){
    
    var rdata=result.result;
    var ipp=+result.item_per_page;
    var total=rdata.length;
 
 $.each( rdata, function(i,v){
 
try{    
    var meta=v["meta"];
    var cid= v["id"];
    var likes=v["likes"];
   var comment=v["message"];    
   var author=v["comment_author"]
  
    display_comment('prepend', cid, comment, author, meta, false, nextPage,likes);
  
  }catch(e){
    //Ignore
  //  toast(e); 
}




  });

    $('#next-comments,#prev-comments').css('display','none');

 if( prevPage ){

}
  if( nextPage ){
    $('#prev-comments').attr('data-value', nextPage).css('display','block');
 }
   
  }
   else if( result.error){
    toast(result.error,{type:'light',color:'#333'});  
  }
    loader.css('display','none');
    tb.prop('disabled', false);

}).fail(function(e, txt, xhr ){
  buttonSpinner( this_, true);
  ui.prop('disabled', false)
fetchingComment=false;
toast('Check your network connection. ' + xhr);
  });

}catch(e){
  alert(e)
}

}

function format_comment(username, gpin, post_id, clen){
 var currentTime=moment().unix();
   var obj_=new Object();
  obj_.pid="" +  post_id;
  obj_.cf="" +   username;
  obj_.ct="" +   gpin;
  obj_.fullname=username;
  obj_.file=""; //video, image
  obj_.lfpath=""; //local file path
  obj_.sfpath=""; //server file path
  obj_.hl=""; //Highlight (text or file highlight)
  obj_.pt=""; //preview text
  obj_.size="" + clen; //txt size or file size  
  obj_.fx="";
  obj_.time="" + currentTime;
  obj_.ver="s";

  return JSON.stringify(obj_); 
  }


function display_comment( type, cid, msg, author_, meta, me, paging,likes){
  type=type||'append';

 if( me){   
   var mccont= $('#my-comments-container');
 }
else{
  var mccont=$('#post-comments');
}
 
 try{
 var meta=JSON.parse( meta);
}catch(e){
  var meta={}
}
 
 var fullname=meta.fullname||author_;

  var v=checkVerified( author_, fullname);

  var icon=v.icon;
  var author= v.name;

 var ctime=meta.time||moment().unix();

  var cdate=toDate( ctime ,'comment_date');
  msg=msg.replace(/</g,'&lt;')
     .replace(/>/g,'&gt;')
    .replace(/(:nl::){3,}/g,':nl:::nl::')
    .replace(/:nl::/g,'<br>')
  
  var isMe=false;
  var username=$.trim($('#send-comment-as').val());

 if( author_==username){ 
    isMe=true;
  }
  
 var data='<div class="comment-child-container ' + (isMe?'my-comment-container':'') + '" id="ccc-' + cid + '">';
  data+='<div class="' + ( isMe?'text-right':'') + '">';
 data+='<span class="d-inline-block friend-picture-bg" style="margin-right: 5px;">' + friendProfilePicture( author_ ,'friend-picture nosave' ) + '</span>';
 data+='<div class="comment-bubble" id="' + cid + '">';
 data+='<span class="highlight comment-author friend friend-' + author_ + '" data-fname="' + author + '" data-type="friend" data-friend="' + author_ + '">' + strtolower( author).replace('vf_','') + '</span> ';
 data+='<span class="d-none friend-name-' + author_ + '">' + author + '</span>';
  data+='<div class="comment-message">' + msg + '</div>';
  data+='</div></div>';
 
  data+='<div class="comment-footer">';
  
   data+='<span class="delete-comment fa fa-lg fa-trash" id="delc-' + cid + '" data-cid="' + cid + '"></span>';
 
  data+='<span class="comment-date">' + cdate + '</span>';
  data+='<span class="like-comment" id="like-comment-' + cid + '" data-cid="' + cid + '" onclick="like_comment(this);">';
 if(author_) data+='<span class="fa fa-thumbs-up"></span><span class="likes" id="likes-' + cid + '">' + (likes||0) + '</span></span>';

  data+='</div>';
  data+='</div>';


  if(type=='append'){
  mccont.append(data)
  }
  else{
  mccont.prepend(data);
  }
}


function add_comment( fuser, comment, mlen, this_){

 if( comment.length<2 ){
    return toast('Too short.');
   }
  else if( mlen>2){
    return toast('Too long.');  
  }

  var rcid=randomString(5);

  comment=sanitizeMessage(comment);
 
  var tb=$('#comment-textarea');
      tb.prop('disabled', true);
   
  var cpi=$('#current-post-id');
  var cpiv=$.trim(cpi.val());

  if( !$('#post-comment-sending-cont #comment-sending-icon').length){
    $('#post-comment-sending-cont').append('<span id="comment-sending-icon fa fa-lg fa-stop"></span>');
  }
  
 var sb=$('#post-comments-container');
     sb.scrollTop( sb.prop("scrollHeight") );
  
var username=$.trim($('#send-comment-as').val());

if( !validUsername( username) ){
 return toast('Enter your valid username');
}

var meta=format_comment(username, fuser, cpiv, mlen);
  
display_comment('append', rcid, comment, username , meta, true);
  
 var cdiv=$('#my-comments-container #ccc-' + rcid);
 var delBtn= $('#my-comments-container #delc-' + rcid);
 var likeBtnCont=$('#my-comments-container #like-comment-' + rcid);
 var likeBtn=$('#my-comments-container #like-img-' + rcid);
  delBtn.css('display','none');
  likeBtnCont.css('display','none');
  
  buttonSpinner( this_);
  setTimeout(function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/add-group-post-comment.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
     "username": username,
      "group_pin": fuser,
      "message": comment,
      "meta": meta,
      "post_id": cpiv,
    }
  }).done(function(result){
   // alert(JSON.stringify(result) );
  $('#comment-sending-icon').remove();
   buttonSpinner( this_,true);
   tb.prop('disabled', false);
 if( result.status){
   sessionStorage.removeItem('temp-text-' + fuser);
   $('#post-comments #no-comment-cont-' + cpiv).remove();
   var id=result.result;
if(id){
  delBtn.attr('data-cid', id).css('display','inline-block');
  cdiv.attr('id','ccc-' + id);
  likeBtnCont.attr('data-cid',id).css('display','inline-block');
  likeBtn.attr('id','like-img-' + id);
}
   tb.val('');
  // tb.autoHeight();
  return;
 }else if(result.error){
    toast( result.error);
   $('#post-comments-container #ccc-' + rcid ).remove();
 
 }

 }).fail(function(e,txt,xhr){
    $('#comment-sending-icon, #post-comments-container #ccc-' + rcid ).remove();
   toast('Not sent. '+ xhr);
    tb.prop('disabled', false);
   buttonSpinner( this_,true);
  });
    
  },1000);

}


function auto_comment(gpin,this_){

 if( !confirm('Confirm')) return;

  buttonSpinner( this_);
 var pid=$('#current-post-id').val();

$.ajax({
    url: _ADMIN_URL_ + '/ajax/auto-comment.php',
    type:'POST',
   timeout: 10000,
     dataType: "json",
    data: {
      "group_pin": gpin,
      "post_id": pid,
    }
  }).done(function(result){
   // alert(JSON.stringify(result) );

   buttonSpinner( this_,true);
   
 if( result.status){  
  return toast('Refresh comment to see changes.',{ type:'success'});

 }else if(result.error){
    toast( result.error);
   $('#post-comments-container #ccc-' + rcid ).remove();
 
 }

 }).fail(function(e,txt,xhr){
   toast('Not sent. '+ xhr);
   buttonSpinner( this_,true);
  });    

}

















