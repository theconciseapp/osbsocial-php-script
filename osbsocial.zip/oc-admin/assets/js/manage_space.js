$(function(){
 $('body').on('click','.load-dir',function(){
var this_=$(this);
var level=this_.data('level');
var ml=this_.data('margin-left');
var load_to=this_.data('load-to');
 buttonSpinner(this_);
 $('.load-dir').prop('disabled',true);

 var resultDiv=$('.load-to-'+ load_to);
$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   level: level,
   margin_left: ml,
   load: 'load',
  }
}).done(function(result){
  buttonSpinner(this_,true);
 $('.load-dir').prop('disabled',false);
   resultDiv.html(result);
}).fail(function(e){
  buttonSpinner(this_,true);
$('.load-dir').prop('disabled', false);
  toast( JSON.stringify(e) );
  });

});


$('body').on('click','.delete-fd',function(){

var this_=$(this);
var path=this_.data('path');
var filename=this_.data('name');
var type=this_.data('type');
var cls=this_.data('class');

if(!confirm('Delete ' + type + ' ' + filename + '?')) return;

 buttonSpinner(this_);
 $('.delete-fd').prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   path: path,
   delete: 'delete',
  }
}).done(function(result){
 
  buttonSpinner(this_,true);
 $('.delete-fd').prop('disabled',false);
  if(result.match(/__SUCCESS__/)){
 $('.' + cls).remove();
 }else if(result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete.');
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
$('.delete-fd').prop('disabled', false);
  toast("Check your connection. " + xhr);
    });
  });

$('body').on('click','#delete-db-messages',function(){
var this_=$(this);
var age=+$('#age').val();
var limit_=+$('#limit').val();

rdiv=$('#db-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'delete_db_messages': 'true',
 'age': age,
'limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });



$('body').on('click','#del-comment-btn',function(){
var this_=$(this);
var age=+$('#del-comment-age').val();
var limit_=+$('#del-comment-limit').val();

rdiv=$('#del-comment-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'delete_comments': 'true',
 'age': age,
'limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });


//DELETE PRIVATE MESSAGES

$('body').on('click','#delete-private-messages-btn',function(){
var this_=$(this);
var age=+$('#private-messages-age').val();
var limit_=+$('#private-messages-limit').val();

rdiv=$('#delete-private-messages-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
 'private_messages': 'true',
 'private_messages_age': age,
'private_messages_limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });



//DELETE PRIVATE MESSAGES RECEIPTS

$('body').on('click','#delete-private-messages-receipts-btn',function(){
var this_=$(this);
var age=+$('#private-messages-receipts-age').val();
var limit_=+$('#private-messages-receipts-limit').val();

rdiv=$('#delete-private-messages-receipts-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.") ) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
 'private_messages_receipts': 'true',
 'private_messages_receipts_age': age,
'private_messages_receipts_limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });




//DELETE GO-SOCIAL POSTS

$('body').on('click','#delete-go-posts-btn',function(){
var this_=$(this);
var age=+$('#go-posts-age').val();
var limit_=+$('#go-posts-limit').val();

rdiv=$('#delete-go-posts-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'go_posts': 'true',
 'go_posts_age': age,
'go_posts_limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });


//DELETE GO-SOCIAL COMMENTS
$('body').on('click','#delete-go-comments-btn',function(){
var this_=$(this);
var age=+$('#go-comments-age').val();
var limit_=+$('#go-comments-limit').val();

rdiv=$('#delete-go-comments-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.")) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'go_comments': 'true',
 'go_comments_age': age,
'go_comments_limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });



//DELETE GO-SOCIAL NOTIFICATIONS
$('body').on('click','#delete-go-notifications-btn',function(){
var this_=$(this);
var age=+$('#go-notifications-age').val();
var limit_=+$('#go-notifications-limit').val();

rdiv=$('#delete-go-notifications-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.") ) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
   'go_notifications': 'true',
 'go_notifications_age': age,
'go_notifications_limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });




//DELETE REPORTED CONTENTS

$('body').on('click','#delete-reported-contents-btn',function(){
var this_=$(this);
var age=+$('#reported-contents-age').val();
var limit_=+$('#reported-contents-limit').val();

rdiv=$('#delete-reported-contents-result');
 rdiv.empty();

if(!confirm("Delete?\nIt's not reversible.") ) return;

 buttonSpinner(this_);
 this_.prop('disabled',true);

$.ajax({
  url: 'ajax/manage_space.php',
  type:'post',
 data:{
 'reported_contents': 'true',
 'reported_contents_age': age,
'reported_contents_limit': limit_
  }
}).done(function(result){
  buttonSpinner(this_,true);
 this_.prop('disabled',false);

if(result.match(/SUCCESS/)){
   rdiv.html(result);
 }else if( result.match(/__PERMISSION_DENIED__/) ){
 return toast('Permission denied.');
}else{
  toast('Failed to delete. ' + result);
}
}).fail(function(e,txt,xhr){
  buttonSpinner( this_,true);
 this_.prop('disabled', false);
  toast( JSON.stringify(e));
    });

  });




});
