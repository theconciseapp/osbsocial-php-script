var loadingPosts=false;
var searchingPosts=false;
var loadingProfilePosts;
var WAIT_FOR_ME=false;
var loadingNotificationsPosts;

function go_user_photo_url(user, type){
return _USERS_PATH_ + '/' + strtolower( user[0]+'/' + user[1] + '/' + user[2] + '/' + user ) + '/profile_picture_' + type + '.jpg';
}

function go_user_icon( user , class_,verified){
  class_=class_||'friend-picture';

var real_path=go_user_photo_url( user, 'small');

var avatar=_ADMIN_URL_ + '/assets/go-icons/avatar-grey.png';

  return '<img class="lazy ' + class_ + '" alt="" onerror="go_imgIconError(this,\'' + user + '\');" src="' + avatar + '" data-src="' + real_path + '" data-verified="' + ( verified?'1':'') + '" data-id="' + strtolower(user ) + '">';
}

function go_user_photo(user, class_){
  class_=class_||'friend-picture';
  var real_path= go_user_photo_url( user,'full');

  var avatar=_ADMIN_URL_ + '/assets/go-icons/avatar-grey.png';
  return '<img class="lazy ' + class_ + '" alt="" onerror="go_imgIconError(this,\'' + user + '\');" src="' + avatar + '" data-src="' + real_path + '" data-id="' + strtolower(user ) + '">';
}


function go_imgIconError(image,fuser) {
  var src= _ADMIN_URL_ + '/assets/go-icons/avatar-grey.png';
  image.src = src;
  image.onerror=null;
}


function go_imgError(image, bg) {
  bg=bg||'white-bg';
  var def= _ADMIN_URL_ + '/assets/go-icons/bg/' + bg + '.png';
  image.src = def;
  image.onerror=null;
}

function go_videoLayout(file, poster, reposted, from_comment){
   var file_id=randomString(10);
 
 var data=go_videoPlayerLayout( {
       "file_id": file_id,
       "sfpath": file,
       "reposted": reposted,
       "poster": poster,
    }, from_comment);
 return data;
}

function go_photoLayout(file_path, reposted, from_comment){

 /*var filename=file_path.split('/').pop();  
  var dim=filename.split("~");
  var width=+dim[1]||1;
  var height=+dim[2]||1;
*/
  var dim=getParameterByName("ocwh",file_path)||"";
      dim=dim.split("_");
  var width=+dim[0]||500;
  var height= +dim[1]||200;

  var dW=$(window).width();
  var maxW=dW<500?dW:500;
  
if( from_comment) maxW=200;

 var size=imageScale(width,height, maxW, 700);
  var imgheight=Math.ceil( size*height);
  var imgwidth= Math.ceil( size*width);
 
  var data='<img height="' + imgheight+ '" alt="" class="lazy go-post-image go-post-photo ' + (reposted?'reposted':'') + '" style="width: ' + imgwidth + 'px;" src="' + _ADMIN_URL_ + '/assets/go-icons/bg/white-bg.png" data-src="' + file_path + '" onerror="go_imgError(this,\'transparent2\');">';

  return '<div class="go-post-image-container go-post-photo-container">' + data + '</div>'; 
 }


function go_formatFiles(data, hasFiles, reposted, from_comment ) {
 if(!data) return "";
 
  try{
    data=JSON.parse( data);
  }catch(e){
    return "";
  }

  var total=data.length;
  var file_result="";
  var cnt=0;
  
 $.each( data, function(i,v){
     cnt++;
   var file  = v.path;
   var ext   = v.ext;
   
   if( ext=='jpg'){
  file_result+= go_photoLayout( file,  reposted,from_comment);
 }else if ( ext=='mp4') {
  var poster=v.poster;
  file_result+= go_videoLayout( file,  poster,reposted, from_comment );
    }
  });

  return file_result; 
  }



function go_bbcodeToHTML(data, hasFiles,reposted, from_comment ) {
  var reg=/\[\s*file=::(.*?)::\]/gi

  if(hasFiles ) {
  //hasFile= total_files

    data=data.replace(reg, function(m,file){
    var file_=file.split('|');
   var  file=file_[0];
    var ext= file_[1];
   
  if( ext=='jpg'){
    
  return go_photoLayout(file,reposted, from_comment);
    }
    else if ( ext=='mp4') {
var poster=file_[2];
  return go_videoLayout(file, poster, reposted, from_comment);
    }
  });
 }
   return data; 
  }

function go_videoPlayerLayout(obj, from_comment){

  var downloadUrl='';
  var dv='';
  
  var fuser="";
  var file_id=obj.file_id;
  var vid=obj.file_id;
  var sfpath=obj.sfpath;
  var reposted=obj.reposted;
  var poster=obj.poster;
  var sourceUrl=sfpath;

if( sourceUrl.match(/localhost:8080/) ){
sourceUrl=sourceUrl.replace("http://localhost:8080", "storage/emulated/0/Icode-Go/data_files/www");
}
  //sourceUrl="http://www.jplayer.org/video/m4v/Big_Buck_Bunny_Trailer.m4v?u=k";

/*
var filename=sourceUrl.split('/').pop();  
  var dim=filename.split("~");
  var width=+dim[1]||500;
  var height=+dim[2]||250;
 */

var dim=getParameterByName("ocwh", sourceUrl)||"";
      dim=dim.split("_");
  var width=+dim[0]||500;
  var height=+dim[1]||300;

  var dW=$(window).width();
  var maxW=dW<500?dW:500;
  
if( from_comment) maxW=200;
 
 var size=imageScale( width, height, maxW, 700);

  var imgheight=Math.ceil( size*height);
  var imgwidth= Math.ceil( size*width);
 
 var data='<div class="go-video-poster-container go-post-photo-container">';
     data+='<img height="' + imgheight + 'px;" class="go-video-poster go-post-photo lazy" style="width: ' + imgwidth + 'px;" src="' + _ADMIN_URL_ + '/assets/go-icons/bg/black-bg.png" data-src="' + poster + '" onerror="go_imgError(this,\'black\');">';

     data+='<span class="go-video-play-icon fa fa-play-circle fa-5x text-white" data-vid="' + vid + '"></span>';
     data+='<div onclick="goOpenVideo(this);" class="' + (reposted?'reposted':'go-open-video') + '" data-vid="' + vid + '" data-source-url="' + sourceUrl + '" data-poster="' + poster + '"></div>';
     data+='</div>';
   
  return data; 

}

function goOpenVideo(t){
  var this_= $(t);
   var vid=this_.data('vid');  
  var sourceUrl=$.trim(this_.data('source-url'));
  var poster=this_.data('poster');
 
 var data='<figure style="display: none;" id="' + vid + '-video-container" class="go-video-container" data-chatid="' + vid + '">';
     data+='<video id="' + vid + '-video" class="video-tag" data-chatid="' + vid + '" poster="' + poster + '" controls preload="true" src="' + sourceUrl + '#t=0.1">';
     data+='</video>';
     data+='</figure>';

 $('.go-video-container').css('display','none');
 
 if( !$('#' + vid + '-video-container').length) {

    $('#go-video-element-container').append(data);

    go_mediaplayer_( $('#' + vid + '-video') );
  }
    
  $('#' + vid + '-video').trigger('play');
  $('#go-video-element-container, #' + vid + '-video-container').css('display','block');
 
 }

//FUNCTION DISPLAY POST

function display_post( post,full){

  var result="";
    $.each( post, function(i,v){
 
      //POSTER INFO
   
    var post_title=v.post_title;
   var post_by=v.post_by;
   var country=v.country;
   var bio=v.bio;
   var birth=v.birth;
   var joined=v.joined_on;
   var fullname=v.real_name||v.post_by_fullname;
   var phone=v.phone;
   var post_status=v.post_status;
   var post_files=v.post_files||"";
     var post_id=v.id;
     
     var highlight= (v.post_preview||"").replace(/</g,'&lt;');
     var time= timeSince( v.post_date); //new Date( +v.post_date * 1000);
      var meta= v.post_meta||"[]";
   //  var total_likes= +(v.total_likes||0);
     var total_comments= +(v.total_comments||0);
     var total_shares= +(v.total_shares||0);
var reactions=v.reactions||"{}";
     var reactions_={};
      try{
      reactions_= JSON.parse( reactions);
      }catch(e){

}; 
    
  var veri=checkVerified(post_by, fullname);
  var verified=veri.icon;
  var fullname_= veri.name;
      fullname=fullname_ + ' ' + verified;
      
  var data=parseJson(meta );
  
  var true_author=data.true_author||"";
  var post_length=+data.plen;
  var can_comment=data.can_comment;
  var shareable= data.shareable;
  var commentable= data.commentable;
  var reposted= data.repost||"";
  var op_by= data.opost_owner||"";
  var optitle=data.optitle||"";
  var op_name= data.opbf||op_by;
  var odeleted= data.odeleted||"";

    if( reposted){

   var op_v=checkVerified( op_by, op_name);
  op_name= op_v.name + ' ' + op_v.icon;
   
   }
    
  var op_time= timeSince( data.opost_time);
  var op_id= data.opost_id||"";
  var op_preview= data.opost_preview||"";
   
  if( op_preview.length>100){
        op_preview=op_preview.substr(0, 100) + '...';
   }

  var version= data.ver;

var hasFile=data.has_files;
  var bsize=data.size||0;
  var size= hasFile?readableFileSize( +bsize, true, 0):'';
  var meta_="";     
  var plink=data.link;
  var plinkText=data.link_title;
      
  var total_files=+(data.total_files||0)
  var post_bg_=data.post_bg||"";
  var opost_bg_=data.opost_bg||"";
  
   var opost_bg="";
   var post_bg="";
      
  if( post_bg_){
      post_bg=post_bg_ + ' go-pbg' + ( post_length<60?' go-pbg-font':'');
    }
       
  if( highlight.length > 190 ){
      highlight='<div data-pid="' + post_id + '" class="go-load-full-post" onclick="goLoadFullPost(this);">' + highlight.substr(0, 190 ) + ' <span class="go-post-more-link">...More</span></div>';
  }
      
  if(!full){
     highlight= '<div class="go-post-preview go-post-preview-' + post_id + ' ' + (highlight?post_bg:'') + '">' + bbCode( highlight) + '</div>';
   }
    else{
     highlight= '<div class="go-post-preview go-post-preview-' + post_id + ' ' + post_bg + ' ">' + bbCode( v.post||"" ) + '</div>'; 
     }
      
var pdata='<div class="go-post-files-container ' + ( total_files>1?'go-post-files-container-m go-multiple-images go-multiple-images-' + total_files:'') + '">' + post_files + '</div>';
  
 var format=go_formatFiles( post_files, hasFile, reposted);

 format='<div class="go-post-files-container ' + ( total_files>1?'go-post-files-container-m go-multiple-images go-multiple-images-' + total_files:'') + '">' + format + '</div>';
   
   var p='<div class="go-post-container go-post-container-' + post_id + '">';
      p+='<button class="post-id-display">' +post_id + '</button>';
      
    p+='<div class="go-post-header">';
    p+='<div class="container-fluid">';
    p+='<div class="row">';
    p+='<div class="col go-post-by-icon-col ps-2" style="max-width: 55px!important;">';
       p+='<div class="go-post-by-icon-container">' + go_user_icon( post_by, 'go-post-author-icon go-enlarge-user-icon') + '</div>';
       p+='</div>';
      p+='<div class="col pt-0" style="overflow-x: hidden;">';
       p+='<div class="go-post-fullname go-open-profile mt-0" data-user="' + post_by + '" data-user-fullname="' + fullname_ + '" onclick="open_profile(this);">' + fullname + '</div><div>&bull; <span style="font-size: 10px;">' + post_by + '</span></div>';
       p+='<div class="go-post-date">' + time  + ' &bull; <span class="fa fa-globe"></span></div>';
       p+='</div>';
    
       p+='<div class="col-4 text-center">';
p+='<div>';
p+='<div class="d-inline-block go-post-options-btn" data-pid="' + post_id + '" data-post-by="' + post_by + '" onclick="goEditPostForm(this);"><span class="fa fa-edit fa-lg text-danger"></span></div>';

       p+='<div class="d-inline-block go-post-options-btn" data-pid="' + post_id + '" data-post-by="' + post_by + '" onclick="goDeletePost(this);" style="margin-left: 20px;"><span class="fa fa-trash fa-lg text-danger"></span></div>';
   p+='</div>';
   p+='<div>';
  p+='<button id="approve-post-btn-' + post_id + '" class="btn btn-sm ' + (post_status=='1'?'btn-success':'btn-secondary') + '" data-post-status="' + post_status+ '" onclick="approvePost(this,\'' + post_id + '\');" style="padding: 0 5px;"><small>' + (post_status=='1'?'Unapprove':'Approve') + '</small></button>';
  p+='</div>';

   p+='</div>';
     p+='</div></div>';
    p+='</div>'; //end post header
    
    
    if(  post_title ){
  
 p+='<div class="go-post-title">' + post_title + '</div>';
	
 }
    
      p+='<div class="go-post-highlight">' + highlight + '</div>';
    
 if ( reposted ){
   
   if( opost_bg_ && op_preview ){
       opost_bg=opost_bg_ + ' go-pbg' + ( op_preview.length<60?' go-pbg-font':'');
     }

       p+='<div class="container-fluid go-opost-container go-open-single-post" onclick="goOpenSinglePost(this);" data-post-by="' + op_by + '" data-pid="' + op_id + '">';
     
if(!odeleted){
  p+='<div class="row">';
       p+='<div class="col go-opost-by-icon-col">';
       p+='<div class="go-opost-by-icon-container">' + go_user_icon( op_by, 'go-opost-by-icon') + '</div>';
       p+='</div><div class="col p-0">';
       p+='<div class="go-opost-fullname">' + op_name + ' <div>&bull; <span style="font-size: 10px;">' + op_by + '</span></div></div>';
       p+='<div class="go-opost-date">' + op_time  + ' &bull; <span class="fa fa-globe"></span></div>';
       p+='</div></div>';
  }
      
  if( optitle) {
  p+='<div class="go-post-title">' + optitle + '</div>';
  }   
      
       p+='<div class="go-opost-preview ' + opost_bg + '">' + bbCode( op_preview) + '</div>';
       
   }
      
       p+='<div class="go-post">' + ( format||"") + '</div>';
    
p+='<div class="go-post-link-container" id="post-link-container-'+ post_id + '">';

if( !odeleted && plink){

 	plinkText=plinkText.split("...");
	
        p+='<a href="' + plink + '" class="go-nice-link" target="blank_">' +  plinkText[0] + '<div class="form-text">' + ( plinkText[1]||"") + '</div></a>';

  }
       
   p+='</div>';
     

  
   if( reposted){
     
      p+='</div>';
     
     }
    var total_r=0;
    var remoji='';
     $.each( reactions_, function(i, rcount){       var rv=+rcount;
        total_r=total_r+ ( +rv);
     if( rv){
       remoji+='<img class="go-like-post-iconx-' + post_id + ' icon-normal w-18 h-18" src="' + _ADMIN_URL_ + '/assets/go-icons/reactions/' + i + '.png">';
     }
      });

//var licon='file:///android_asset/chat-icons/reactions/' + liked + '.png';
     

var total_reactions= abbrNum(total_r, 1);
     var total_likes=+reactions_["like"]||0;
    
       p+='<div class="go-post-footer">';
      
p+='<div style="padding-left: 20px;" class="reacted-icons-container reacted-icons-container-' + post_id + '" data-reactions=\'' + reactions + '\'> ' + remoji + ' <span class="total-likes-' + post_id + '" data-total-reactions="' + total_reactions + '">' + (total_reactions||"") + '</span></div>';
     
 p+='<div class="row">';
      
p+='<div class="col text-center"><span data-reactions=\'' + reactions + '\' data-post-by="' + post_by + '" data-pid="' + post_id + '" class="go-like-post-btn-' + post_id + ' go-like-post-btn"><span class="go-like-post-icon-'+ post_id + ' fa fa-lg fa-thumbs-up"></span> <span class="total-likes-' + post_id + '" data-total-reactions="' + total_reactions + '">' + total_reactions + '</span></span></div>';
 

 if( commentable){
   p+='<div class="col text-center"><button data-pid="' + post_id + '" data-post-by="' + post_by + '" class="go-open-comments-box" onclick="goOpenCommentsBox(this);"><span class="fa fa-comments"></span> <span id="total-comments-' + post_id + '">' + abbrNum(total_comments,1) + '</span></button></div>';

    }
      
   if( shareable){
       p+='<div class="col text-center"><span data-pid="' + post_id + '" data-share-pid="' +(reposted?op_id:post_id) + '" data-notify="' + post_by + '" data-cpid="' + post_id + '" class="go-share-post-btn"><span class="fa fa-share"></span><span id="total-shares-' + post_id + '">' + abbrNum(total_shares,1) + '</span></span></div>';
     }
       p+='</div>';
       p+='</div>';
      
       p+='</div>';

   
    result+=p; 
         
    });
   return result;
}

function no_post(){
  var data='<div class="go-no-post text-center">';
  data+='No post yet!';
  data+='</div>';
 return data;
}

var toast_once=false,connCounts=0, lpFails=0;

function loadPosts(refresh ){
  var pnElem=$('#go-next-page-number');
  var pageNum=pnElem.val();
  
 /*
 if( loadingPosts ){
    return;
  } else  
  */

    if( refresh ){
    toast_once=false;
    pageNum="";
 
if( refresh!="posts_view_changed"){   displayData('<div class="text-center" style="padding-top: 30px; overflow:hidden;"><span class="fa fa-spinner fa-spin fa-3x text-success"></span></div>',{ id:'home_refresh', sclose: false, no_cancel: true});
}

  }
    
  if( !refresh && pageNum=="0"){
   if( !toast_once ){
     toast_once=true;
     toast('That is all for now.',{type: 'info'});
   }
    return;
   }
  
  loadingPosts=true;
 
  var loader=$('#post-loading-indicator');
  loader.css('display','block');
  
  connCounts++;
  var pv_option=+$("#posts-view-option").val();

 setTimeout(  function(){
  $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/posts.php',
    type:'POST',
   timeout: 40000,
     dataType: "json",
    data: {
      "page": pageNum,
      "posts_view_option": pv_option,
    }
  }).done(function(result){
  //alert(JSON.stringify(result));
    connCounts--;
lpFails=0;
      loadingPosts=false;  
      loader.css('display','none');
    if( refresh ){
    closeDisplayData('home_refresh'); 
    }

 if( result.no_post){
   $('#go-the-posts').html( no_post() );
  // toast( result.no_post,{type:'info'});
  } 
    else  
  if( result.status=='success' ){

    var posts= result.result;
    var nextPage=result.next_page;
    pnElem.val( nextPage );
 
try{

var posts=display_post( result.posts);

 if( refresh ){
   $('#go-the-posts').html( posts );            
 }else{
   $('#go-the-posts').append( posts ); 
 }
 }catch(e){
  alert(e);
}
 
 }
   else if(result.error){
      toast(result.error );
  }
   else toast('No more post to load.',{type:'info'});
 
    setTimeout( function(){
      $('#go-initializing-container').css('display','none');
    },1000);
    
 }).fail(function(e,txt,xhr){
  //alert(JSON.stringify(e));

   loadingPosts=false;
    connCounts--;
  //  loader.css('display','none');
  if(!lpFails) toast('Check your connection. ' + xhr);
 
lpFails=1;
    if( refresh ){
     closeDisplayData('home_refresh');
    return;
    }
    
    setTimeout(function(){
       loadPosts(); },8000);
  });
    
  },1000);
}
  

var toast_s_once=false,searchingPosts=false,spTimeout,spAjax;

function searchPosts( fresh){
 var pnElem=$('#go-search-next-page-number');
  var searchDiv=$('#go-searched-posts');
  
  if( fresh){
    toast_s_once=false;
    pnElem.val("");
    searchDiv.empty();
  }
  
  var pageNum=pnElem.val();
 
 // if( searchingPosts ) return;
  
  if(!fresh && pageNum=="0"){
   if( !toast_s_once){
     toast_s_once=true;
     toast('That is all for now.',{type: 'info'});
   } 
    return;
  }
    
  var s=$('#go-search-box');
  var text=$.trim( s.val());
  
  if(!text ||text.length<3){
  return toast('Search term too small.',{ type:'info'});
  }
    
  searchingPosts=true
var loader=$('#search-loading-indicator');
  loader.css('display','block');
  
  connCounts++;

  $('#go-search-container').css('display','block');


spTimeout=setTimeout( function(){  
    spAjax=$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/search-posts.php',
    type:'POST',
   timeout: 40000,
    dataType: "json",
    data: {
      "s": text,
      "page": pageNum,
    }
  }).done(function(result){
   //alert(JSON.stringify(result)) 
      connCounts--;
      searchingPosts=false;
      loader.css('display','none');
  
  if( result.no_post ){
   return toast( result.no_post,{type:'info'});
  }
 else if( result.status=='success' ){
   var nextPage=result.next_page;
   pnElem.val( nextPage);
     var posts= result.result;
    searchDiv.append( display_post( posts) );            
  }
   else if(result.error){
      toast(result.error );
  }
   else toast('No more post.',{type:'info'});
      
 
 }).fail(function(e,txt,xhr){
      connCounts--;
      searchingPosts=false;
      loader.css('display','none');
  //toast('Connection error. ' + xhr, {type:'light',color:'#333'});
     spTimeout=setTimeout(function(){
     searchPosts(); },6000);
  });
  },1000); 

}
 
var ajaxSinglePost,spTimeout;

function fetchSinglePost( pid, pby, callback){
 
  if( ajaxSinglePost) ajaxSinglePost.abort();
   if( spTimeout) clearTimeout( spTimeout);
  
 spTimeout=setTimeout( function(){
   
   ajaxSinglePost=$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/open-single-post.php',
    type:'POST',
  // timeout: 10000,
     dataType: "json",
    data: {
      "post_id": pid,
      "post_by": pby,
    }
  }).done(function(result){
  return callback( result);
 }).fail(function(e,txt,xhr){
   callback(null, true, xhr);
   });
 },1000); 
  
  
}

var loadingFullPost=false;

function goLoadFullPost(t){
  var this_=$(t);
  var pid=this_.data('pid');
    if( loadingFullPost) {
      return toast('Please wait.');
    }
  if( this_.hasClass('full-loaded')) return;
    this_.prop('disabled',true);
  
    loadingFullPost=true;
 setTimeout( function(){
    fetchFullPost( pid, function(s,e,xhr){
    this_.prop('disabled', false);
      loadingFullPost=false;
 if (e){
  toast('Check your connection. ' + xhr, {type:'light',color:'#333'});

 }else if( s && s.status=='success' ){
    this_.html( bbCode(s.post) );
    this_.addClass('full-loaded');
  }
   else if(s.error){
      toast(result.error );
  }
   else toast('Unknown error occured.');
   });
},1000);
   }
  
function fetchFullPost( pid, callback){   
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/open-full-post.php',
    type:'POST',
   timeout: 40000,
     dataType: "json",
    data: {
      "post_id": pid,
    }
  }).done(function(result){
  //alert(JSON.stringify(result))
      
   if(callback) callback( result);  
     
 }).fail(function(e,txt,xhr){
    callback(false,true,xhr);
  });
}    
  
  //APPROVE/ UNAPPROVE POST
  
  function approvePost(t, post_id){
 if(!post_id) return toast("Post is not found");
  	var this_=$(t);
  var curr_post_status=+this_.attr("data-post-status");
  
   var abtn=$("#approve-post-btn-" + post_id)
   buttonSpinner(this_);
   
  spTimeout=setTimeout( function(){  
    spAjax=$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/approve-post.php',
    type:'POST',
   timeout: 40000,
    dataType: "json",
    data: {
      "post_status": curr_post_status,
      "post_id": post_id,
    }
  }).done(function(result){
   //alert(JSON.stringify(result)) 
      buttonSpinner(this_, true);
  
   if( result.status=='success' ){
   	var nstatus=result.result;
   
    abtn.attr("data-post-status", nstatus);
    if( nstatus=="0" ){
    	abtn.removeClass("btn-success").addClass("btn-secondary").html("<small>Approve</small>")
    }else{
    abtn.addClass("btn-success").removeClass("btn-secondary").html("<small>Unapprove</small>"); 	
    }
    
  }
   else if(result.error){
      toast(result.error );
  }
   else toast("Unknown error" ,{type:"info"});
      
 }).fail(function(e,txt,xhr){
       buttonSpinner(this_, true);
      
  });
  },1000); 

}
 
  
//OPEN SEARCH BOX

function goOpenSearchBox(){
    $('#go-search-container').css('display','block');
    $('#go-posts-column').css('display','none');

  }

//OPEN SINGLE POST

function goOpenSinglePost(t){
 var this_= $(t);
  var pid= this_.data('pid');
  var pby= this_.data('post-by');
  
 this_.prop('disabled', true);
  
  var loader=$('#single-post-loading-indicator');
  loader.css('display','block');
 var cont=$('#go-single-post');
  cont.empty();
  $('#go-single-post-container').css({'display':'block','z-index':42});
  
 fetchSinglePost( pid, pby, function( result,error,xhr){
   this_.prop('disabled', false);
   loader.css('display','none');
  // alert( JSON.stringify(result));
 if( error){
   return toast('Check your connection. ' + xhr);
  }else if( result.status=='success'){
   if( result.me_following=="0"){
   return  cont.html('<div class="text-center">Sorry, you are not permitted to view this.</div>');
   }
    cont.html( display_post(result.post,'full'));
 }
  else if(result.error){
    toast( result.error );
  }
   else toast('Unknown error'); 
  });
  
}


/*EDIT POST FORM*/

function goEditPostForm(t){
 var this_=$(t);
var pid=this_.data('pid');

 if(!pid){
   return  toast('Id not found.');
  }

var loader=$("#edit-post-form-loading-indicator");

loader.css("display","block");
$("form#edit-post-form").trigger("reset");
$("form#edit-meta-form").empty();

$('#go-edit-post-form-container').css('display','block');
 
$('#edit-post-btn').prop('disabled',true);

 setTimeout( function(){
   
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/edit-post-form-data.php',
    type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
      "post_id": pid,
    }
  }).done(function(result){
 // alert(JSON.stringify(result))
    loader.css('display','none');

  if( result.status=='success'){
   var post=result.post;
$('#edit-post-btn').prop('disabled', false);

 $.each( post,function(i,v){
  var data=v;

 if(  i=='post_meta'){

  try{
  var meta=JSON.parse(data);
var meta_form='<div class="bg-light">';

 $.each( meta, function(field_title, vm){
 meta_form+= field_title;
 meta_form+='<textarea class="form-control edit-meta-input mb-2" data-key="' + field_title + '"' + (field_title=='true_author'?' readonly=readonly':'') + '>' + vm + '</textarea>';
});
meta_form+='</div>';

$('#edit-meta-form').html(meta_form);

}catch(e){  }
   
}else{
  data= $('<div/>').html( data).text();
   $('#edit-post-' + i).val(data);

   
 }
   
});

 }
  else if(result.error){
      toast( result.error );
  }
   else toast('Unknown error'); 
 }).fail(function(e,txt,xhr){
  loader.css('display','none');
  toast('Please check your network. ' + xhr);
$('#go-edit-post-form-container').css('display','none');

   });
  },1000);
}
 

function goUpdatePost(t){
  var this_=$(t);   

  buttonSpinner(this_);

    var form = $('#edit-post-form');
    var actionUrl = form.attr('action');
var meta=new Object();
var metas=$('.edit-meta-input');

 metas.each( function(i,v){
  meta[$(this).data('key')]=$.trim( $(this).val() );

});

$('#edit-post-post_meta').val( JSON.stringify(  meta) );

var data_= form.serialize();

    $.ajax({
        type: "POST",
        url: actionUrl,
     dataType:'json',
  // timeout: 40000,
        data: data_, // serializes the form's elements.
    }).done(function(result){
 // alert( JSON.stringify(result));

  buttonSpinner( this_, true);

if( result.status=='success'){
var pv=result.post_preview;
var pid=result.id;

  if( pv.length > 200 ){
    pv='<div data-pid="' + pid + '" class="go-load-full-post" onclick="goLoadFullPost(this);">' + pv.substr( 0, 200) + ' <span class="go-post-more-link">...More</span></div>';
  }
 
$('.go-post-preview-'+ pid ).html( bbCode( pv) );

  toast('Updated successfully',{type:'success'});

}
else if (result.error){
  toast(result.error);
}
}).fail(function(e,txt,xhr){
  buttonSpinner(this_,true);
toast('Check network. ' + xhr);
  });
  
}

//OPEN CREATE POST FORM

function goOpenCreatePostForm(){
 $('#go-create-post-form-container').css('display','block');
var elem=$('#go-create-post-by');
elem.html('<option value="">Select page</option>');


 setTimeout( function(){
var draft=localStorage.getItem('go_new_post_draft');
 if( draft) $('#go-new-post').val(draft);
}, 1500);


var loader=$('#go-create-post-by-loading');

loader.addClass('fa-spin');
setTimeout( function(){

 goFetchPages( function( data,status){
loader.removeClass('fa-spin');

if( status=='no_page'){
  toast( data);
}else
  if( status=='success'){
//alert( JSON.stringify(data));
 var o="";
 var static_page='<option value="" disabled>Static pages</option>';

  $.each( data,  function(i, v){
  var puser=v.username;
if(goStaticPage(puser)){
  static_page+='<option value="' + puser + '">' + v.fullname + '</option>';
}
else{
 o+='<option value="' + puser + '">' + v.fullname+ '</option>';
}
    });

 elem.append( o + static_page );

  } else if(status=='error'){
  toast( data);
  }
});
},1000);

}

//PROFILE


function open_profile(t){
   var this_=$(t);
   var post_by=this_.data('user');
   var fullname=this_.attr('data-user-fullname');

 $('#go-current-opened-profile').val( post_by).attr('data-fullname', fullname);
  

setTimeout( function(){
  $('#go-profile-container').css('display','block');
 },200);

$('#go-single-post-container').css('z-index', 35);


 //closeDisplayData('.top-pages-lists');
 
  var ucont= $('#go-profile-page-' + post_by );

if( ucont.length ){
      go_profile( post_by, fullname, 'no-load');   
    return;
  }

   this_.prop('disabled', true);
  
var template=$('#go-profile-template').html();
 
   var ppage=$('<div class="go-profile-page" id="go-profile-page-' + post_by + '" data-t-once="0"></div>')
   .append( template);

   $('#go-profile-container').append( ppage);
    
    go_profile( post_by, fullname, 'load-once');

      this_.addClass('loaded');
      this_.prop('disabled', false);    
  }


var gpAjax,gpTimeout;

function go_profile( user, fullname, type){
  
clearTimeout( gpTimeout);

 fullname=fullname||user;
  $('.go-profile-page').css('display','none');
 var ucont= $('#go-profile-page-' + user);

  var toast_p_once= +ucont.attr('data-t-once');

  var veri=checkVerified(user, fullname);
  var verified=veri.icon;
     fullname= veri.name;
  var fullname_=fullname + ' ' +verified;
  
 var nameCont=ucont.find('.go-profile-fullname');
  nameCont.html( fullname_ ).attr('data-name', fullname);
 ucont.find('.go-profile-user-pin').text( user);
 ucont.find('.go-profile-follow-btn')
   .addClass('go-follow-btn-' + user).attr('data-pin', user);
  
  var me=false;
 
  var fmCont=ucont.find('.go-profile-message-follow-btn-container');
  
  var emailElem=ucont.find('.go-profile-email');
  var countryElem=ucont.find('.go-profile-country');
  var bioElem= ucont.find('.go-profile-bio');
  var joinedElem=ucont.find('.go-profile-joined' );
  var phoneElem=ucont.find('.go-profile-phone');
  var birthElem=ucont.find('.go-profile-birth');  
 
  var totalFgElem=ucont.find('.go-total-following');  
  var totalFwElem=ucont.find('.go-total-followers');  
 
ucont.css('display','block');
var pnElem=ucont.find('.go-profile-next-page-number');
  var pageNum=pnElem.val();

/*  if( loadingProfilePosts ) {
    return;
  }
*/
  
  if( pageNum=="0"){
     if(!toast_p_once){
  ucont.attr('data-t-once','1');
 //  toast('No more posts!',{type: 'info'});
 }
   return;
  }
 
var pimg_path= go_user_photo_url( user, 'full'); 

 //config_.users_path + '/' + strtolower( user[0] + '/' +user[1] +'/' + user[2] + '/' + user )+ '/profile_picture_full.jpg?due=' + randomString(3);
 
  if( type=='load-once') {
   var coverImg=ucont.find('.go-profile-cover-photo');
   var coverImgCont=ucont.find('.go-profile-cover-photo-container');
   
    var img=ucont.find('.go-profile-photo');
    var imgCont=ucont.find('.go-profile-photo-container');
    imgCont.attr('data-user', user);
    
 img.on('load',function(){
   var rgb=getAverageRGB( this);
   coverImg.attr('data-bg', rgb)
    coverImgCont.attr('style','background-color: ' + rgb);
 });
 
 img.attr('src', pimg_path.replace('_full.jpg','_small.jpg') )
            
   coverImg.attr('src', pimg_path);
 }
   
 if ( type=='load'||
     type=='load-once'||
    type=='load-failed-reload'||
    pageNum==""){

   loadingProfilePosts=true;
 
    WAIT_FOR_ME='profile';
 
 var loader=ucont.find('.profile-posts-loading-indicator');
  loader.css('display','block');
   
   if( gpAjax){
     gpAjax.abort();
   }

  var post_order=$('#go-page-post-order').val();

   gpTimeout=setTimeout( function(){  
  gpAjax= $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/profile-user-posts.php',
    type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
      "user": user,
      "page": pageNum,
      "post_order": post_order,
    }
  }).done(function(result){
     //alert(JSON.stringify(result)) 
 loadingProfilePosts= false;
 WAIT_FOR_ME=false;
      loader.css('display','none');
   
 if( result.not_found ){
      pnElem.val("0");
   return toast( result.not_found, {type:'info'});

  }
 else if( result.status=='success' ){
   
   var real_name=result.real_name||"";
   var country=result.country||"";
   var birth= result.birth||"";
   var bio=result.bio||"";
   var email=result.email||"";
   var phone=result.phone||"";
   var joined=result.joined_on||"";
    
  if( country){
    countryElem.text( country ).css('display','block');
  }
 
if( email){
   emailElem.text( email );
  }  
   
 if( bio){
   bioElem.html( bio ).css('display','block');
 }
   
   /*
 if( joined ){
   var date=new Date( joined);
  joinedElem.attr('data-joined', joined).text( date.format("mmmm yyyy") );
     joinedElem.css('display','block');
 }
 */
  if( phone) {
    phoneElem.text(  phone).css('display','block');
  }

/*
   
   if( birth){
    var birth_=new Date( birth);
   birthElem.attr('data-birth', birth).text(  birth_.format("mmmm dd") ).css('display','block');
   }
   
*/

totalFgElem.html('<strong>' + abbrNum( +result.total_following,1) + '</strong><small> following</small>');
 totalFwElem.html('<strong>' + abbrNum( +result.total_followers,1) + '</strong><small> followers</small>');
  
   var posts_stadium=ucont.find('.go-profile-posts');
 
  var has_post=result.has_post;

if( has_post && has_post >0 ){
 
  var nextPage=result.next_page;

   pnElem.val( nextPage);

     var posts= result.result;
     posts_stadium.append( display_post( posts) ); 
   }else{   
   pnElem.val("0");
   return toast('No post yet', {type:'info'});
  }
      
if(type=='load-once' ){
	
  $('#go-profile-page-' + user).on('touchstart mouseover', function() {
 
   var scr=$(this).scrollTop() + $(this).innerHeight();
   if(!loadingProfilePosts &&scr >=  $(this)[0].scrollHeight - 500) {
      loadingProfilePosts=true;
    go_profile( user, fullname, 'load' );
    }
  });
}
 
 }
   else if(result.error){
   toast(result.error );
  }
   else{
     toast('No more post.',{ type:'info'});
   }
      
 
 }).fail(function(e,txt,xhr){
  //alert( JSON.stringify(e))
      loadingProfilePosts =false;
    WAIT_FOR_ME=false;
      loader.css('display','none')
 
    if(txt!='abort'){
  gpTimeout=setTimeout(function(){
       go_profile( user, fullname, 'load-failed-reload' );
     }, 4000);
  }
  });
  
 },1500);
  }
}


function goFetchPages(callback){
 //Load pages when creating posts
  
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/load-pages.php',
    type:'POST',
  // timeout: 30000,
     dataType: "json",
  }).done(function(result){
 // alert( JSON.stringify(result))
 if( result.no_pages){
   callback( result.no_pages,'no_page');
 }   
  else if( result.status=='success'){
    callback( result.result, 'success');
 }
  else if( result.error){
    callback( result.error,'error' );
  }
   else callback('Unknown error','error'); 
 }).fail(function(e,txt,xhr){
    callback('Failed. ' + xhr, 'error');
   });
}


/*VIEW PAGES*/

function goViewPages(){
$('#go-pages-container').fadeIn();
 var elem=$('#go-pages-list');

setTimeout( function(){

goFetchPages( function( data,status){
 //loader.removeClass('fa-spin');
  if( status=='success'){
//alert( JSON.stringify(data))

function vp_(pin, pfullname, static){

return '<div class="row mt-1" id="go-page-'+ pin + '"><div class="col"><div class="first-letter mt-2">' + pfullname + ' ' + ( static?'*':'') + '</div></div><div class="col" style="width: 150px; max-width: 150px;"><i class="fa fa-lg fa-eye" onclick="open_profile(this);" data-user="' + pin + '" data-user-fullname="' + pfullname + '"></i> <i class="fa fa-edit fa-lg text-primary go-edit-page" data-pin="' + pin + '" onclick="goEditPageForm(this);" style="margin-left: 16px;"></i> <i class="fa fa-trash fa-lg text-danger" data-pin="' + pin + '" data-fullname="' + pfullname + '" onclick="goDeletePage(this);" style="margin-left: 16px;"></i></div></div>';
}


var div="";
 var sp='<div class="text-secondary mt-3">STATIC PAGES</div>';

  $.each( data,  function(i, v){
var pin=v.username;
var pfullname=v.fullname;

var static_page=goStaticPage( pin);

if( static_page ){
   sp+=vp_(pin, pfullname, true);
}
else{
  div += vp_(pin,pfullname);
}
  

  

  });

elem.html( div + sp );

  } else if( status=='no_page'){
 elem.text( data);
}
else if(status=='error'){
  toast( data );
  }
});
},1000);

}


/*DELETE POST*/


function goDeletePost(t){
if( !confirm('Delete?') ) return;
 var this_=$(t);
var pid=this_.data('pid');

 if(!pid){
   return  toast('Id not found.');
  }

  buttonSpinner(this_);

 setTimeout( function(){
   
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/delete-post.php',
    type:'POST',
   //timeout: 30000,
     dataType: "json",
    data: {
      "post_id": pid,
    }
  }).done(function(result){
  // alert(JSON.stringify(result))
     buttonSpinner(this_, true);
  if( result.status=='success'){
   $('.go-post-container-' + pid).remove();
 }
  else if(result.error){
      toast( result.error );
  }
   else toast('Unknown error'); 
 }).fail(function(e,txt,xhr){
  buttonSpinner(this_, true);
  toast('Failed. ' + xhr);
   });
  },1000);
}

//EDIT PAGE FORM

function goEditPageForm(t){
	
try{
		
var this_=$(t);
var pin= this_.data('pin');
 if( !pin){
return toast('Pin not found');
}

$('#go-edit-page-form input,#go-edit-page-form textarea').val("");

$("#go-edit-page-pin").val(pin);
$("#reset-page-password-btn").attr("data-username", pin);

$('.gpages').hide();
$('#go-edit-page-form').fadeIn();
 var loader=$('#go-edit-page-data-loading');
  
loader.show();
var ubtn=$('#update-page-btn');
  ubtn.prop('disabled', true);

$('#go-edit-page-icon').attr('src', go_user_photo_url( pin,'small') );

setTimeout( function(){
   
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/load-page-data.php',
    type:'POST',
   //timeout: 30000,
     dataType: "json",
  data:{
   "pin": pin,
}
  }).done(function( data){
  // alert( JSON.stringify( data) )
 
 loader.hide();
if( data.not_found){
  return toast( data.not_found);
}else if( data.status=='success'){
 var result=data.result;
  ubtn.prop('disabled', false);
      $('#go-edit-page-title').val( result.fullname);
      
$('#go-edit-page-phone').val( result.phone);
var bio=$('<div/>').html( (result.bio||"") ).text()

$('#go-edit-page-bio').val( bio );
 $('#go-edit-page-followers').val(result.total_followers);
$('#go-edit-page-following').val(result.total_following );

 }
  else if( data.error){
   toast( data.error);
  }
   else toast('Unknown error'); 
   
 }).fail(function(e,txt,xhr){
   loader.hide();
   toast('Failed. ' + xhr);
   });
  },1000);
  
  
}catch(e){ alert(e); }

}

//UPDATE PAGE INFO

function goUpdatePageInfo(t){
var this_=$(t);

var pin=$.trim( $('#go-edit-page-pin').val());
var fullname= $.trim($('#go-edit-page-title').val());
var bio= $.trim($('#go-edit-page-bio').val() );
var phone=$.trim( $('#go-edit-page-phone').val() );

var tfollowers=+$('#go-edit-page-followers').val();

 if( !fullname || fullname.length<2 || fullname.length>60) {
     return toast('Enter a valid display name or title. Max: 50');
   }
else if( !validName(fullname) ){
     return toast('Enter a good display name or title. Must start and end with a letter.');    
    }
else if( !bio ){
     return toast('About page should not be empty.');    
    }

else if( phone && !phone.match(/^[0-9+() -]{4,50}$/) ) {
     return toast('Enter a valid phone number.');    
  }
else if( tfollowers<0 ){
 return toast('Invalid total followers');
}

 buttonSpinner(this_);

 var elem=$('#go-edit-page-form input, #go-edit-page-form textarea');

    this_.prop('disabled', true );

  $.ajax({
   'url': _ADMIN_URL_ + '/ajax/go-social/update-page-info.php',
   type:'POST',
   dataType: 'json',
      'data':{
    "username": pin,
    "fullname": fullname,
    "bio": bio,
    "phone": phone,
    "total_followers": tfollowers,
   },
     type:'POST'
  }).done(function(result){
 // alert(result)
   buttonSpinner( this_, true);
   this_.prop('disabled', false);
      
if( result.error){
 toast(result.error);
 }
 else if( result.status ){
  //elem.val('');
   toast( result.result ,{type:'success'});
    } else{
    toast('Unknown error occured.');
      }
   }).fail(function(e, txt, xhr){
      this_.prop('disabled',false);
      buttonSpinner(this_,true);   
    toast('Check your connection and try again. ' + xhr);
// alert( JSON.stringify(e) );
   });
}

function goDeletePage(t){
var this_=$(t);
var pin= this_.data('pin');
var fullname=this_.data('fullname');

if( !confirm('Delete ' + fullname + '?\n\nConfirm') ) return;
  buttonSpinner(this_);

 setTimeout( function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/delete-page.php',
  type:'POST',
 //  timeout: 30000,
    // dataType: "json",
    data: {
      "username":  pin
    }
  }).done(function(result){
  //alert( JSON.stringify(result) )
  buttonSpinner(this_, true);
    
  if( result.status=='success'){ 
  	$('#go-page-' + pin).remove();
          }
          else if( result.error){
          	toast( result.error)
          }
         }).fail(function(e,txt,xhr){
         	buttonSpinner(this_, true);
         toast('Failed to delete. ' + xhr);
         });


},1000);

}

function goCreateNewPost(t){
var this_=$(t);

//Check if there are video cover not generated
var vcover=$('#go-upload-previews .generate-cover:visible');
if( vcover.length){

 if( !confirm('You have not generated one or more video covers\n\nIgnore?') ) return;

}

var post_by=$.trim( $('#go-create-post-by').val() );
var fullname=$("#go-create-post-by :selected").text()||post_by;

var box= $('#go-new-post');
var post=$.trim( box.val() );

var tbox=$("#post-title-box");
 
var post_title=$.trim( tbox.val()||"" );

 if( post_title.length>150){
 return toast("Post title exceeded 150 characters");
    }

 var post_bg= box.attr('data-bg')||""; //Post background

 var commentable=""; 
  var shareable="";
 var fdload="";

 if( $('#go-new-post-commentable').is(':checked')){
    commentable="1";
 }
  if( $('#go-new-post-shareable').is(':checked')){
   shareable="1";
 }
if( $('#go-file-downloadable').is(':checked')){
    fdload="1";
 }

if(!post_by|| !validUsername( post_by) ){
 return toast('Select page');
}

var pfiles=$(".file-info");
   var post_files="";
   var total_files= pfiles.length;
   var hasFiles=0;

var POST_FILES=[];

if( post.length<1 && !total_files){
return toast('Nothing to post');
}

if( total_files){

  pfiles.each(function(){
   var this_=$(this);
var file_path=this_.attr("data-filepath");
var file_size=this_.attr("data-filesize")||1;
var ext=this_.attr("data-ext");
var cover=this_.attr("data-cover");
var dimension=this_.attr("data-dimension")||"500_150";

var width=dimension.split("_")[0];
var height=dimension.split("_")[1];

var file_obj=new Object();

    file_obj["path"]=file_path;
    file_obj["ext"]=ext;       
    file_obj["width"]=width;
    file_obj["height"]=height;
    file_obj["poster"]=cover;
    file_obj["size"]=file_size;    

 POST_FILES.push( file_obj);
   });

 post_files=JSON.stringify( POST_FILES);
  hasFiles=1;
}

var link=$.trim( $('#go-new-post-link').val() );
 var linkText=$.trim($('#go-new-post-link-title').val());
  
  if( link &&  link.indexOf("https://")==0)  {
    link=link.replace(/\s+/g,' ').substr(0,100) .replace(/</g,'&lt;').replace(/"/g,'&quot;');
    linkText=( linkText||link).substr(0,100 ).replace(/</g,'&lt;').replace(/"/g,'&quot;');
  }
  else{
 link=""; linkText="";
  }
 
  var post_preview=(post + "").substr(0, 200 );
var post_length=post.length;

  var meta=new Object();
      meta.pbf=fullname; //Fullname of poster
      meta.true_author=_ADMIN_USERNAME_;
      meta.plen=post_length;
      meta.shareable=shareable;
      meta.commentable=commentable;
    //meta.post_files=post_files;
      meta.total_files=total_files;
      meta.has_files=hasFiles;
      meta.post_bg=post_bg;
      meta.link=link;
      meta.link_title=linkText;
      meta.fdload=fdload;
 var meta_string=JSON.stringify( meta);

 buttonSpinner(this_);
this_.prop('disabled',true);

displayData("",{ dummy: true, id:'dummy-dummy', sclose: false});

  setTimeout( function(){
    $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/insert-post.php',
  type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
      "username": post_by,
      "fullname": fullname,
      "post_title": post_title,
      "post": post,
      "post_meta": meta_string,
      "post_files":post_files,
      "has_files": hasFiles,
    }
  }).done(function(result){
  //alert( JSON.stringify(result) )
  buttonSpinner(this_, true);
  GO_UPLOADED_FILE_PATHS=[];
   this_.prop('disabled',false);
 
  closeDisplayData('dummy-dummy');
    
  if( result.status=='success'){ 
    localStorage.removeItem('go_new_post_draft');

  toast( result.result, {type:'success'});
  
  $("#go-new-post,#post-title-box").val("");
  $('#go-upload-previews').empty();
 }
  else if(result.error){
      toast( result.error );
  }
   else toast('Unknown error');
  //  loader.css('display','none');
 }).fail(function(e,txt,xhr){
    //alert( JSON.stringify(e))
this_.prop('disabled',false);
   buttonSpinner(this_, true);
  closeDisplayData('.dummy-dummy');
 });
},1000);

}

function go_mediaplayer_($elem, fuser){
$elem.mediaelementplayer({
  defaultVideoWidth: '100%',
  defaultVideoHeight: '100%',
   videoWidth: 250, /*250,*/
  videoHeight: 230, /*230*/
  hideVideoControlsOnLoad: true,
  clickToPlayPause: true,
  controlsTimeoutDefault: 2000,
  features: ["playpause","current", "progress", "duration"],
  enableKeyboard: false,
  stretching: 'none',
  pauseOtherPlayers: true,
  ignorePauseOtherPlayersOption: false,
  hideVolumeOnTouchDevices:true,
  
  success: function(media, originalNode, instance) {
   var node=$(originalNode);
   var chatid=node.data('chatid');
    
  //go_enableVideoFullScreen( node);   
 media.addEventListener('loadedmetadata',function(){
  go_enableVideoFullScreen( node);
 });   
  media.addEventListener('play',function(e){
  go_enableVideoFullScreen( node, chatid);
  });  
   
 },
  error: function(e){
    exitVideoFullScreen( true);
   toast('Unable to load. Check connection.');
  }
});
}


function go_enableVideoFullScreen(node_,chatid){
  if( node_.hasClass('video-tag') ){
    var cont=node_.parent().closest('.mejs__container');
  // alert(cont.html())
 cont.addClass('mejs__custom-fullscreen go-watching-video watching-video-' + chatid ).append('<div style="position: absolute; z-index: 50; top: 60px; right: 16px;" class="fa fa-times fa-3x text-danger" onclick="goCloseVideo();"></div>');

 cont.removeAttr('style');
 cont.attr('data-wvchatid',chatid);
     cont.find('.mejs__overlay,.mejs__layer').css({width:'100%',height:'100%'});
 }
}


function exitVideoFullScreen( remove_){
  $('video').trigger('pause');
 var fs=$('.mejs__custom-fullscreen');
var vid=fs.attr('data-wvchatid');
 $('#go-video-element-container,.go-video-container').fadeOut(2000, function(){;
  fs.find('.mejs__overlay,.mejs__layer').css( {width: 340,height:160});

  fs.css({height:160}).removeClass('mejs__custom-fullscreen go-watching-video watching-video-' + vid);

if( remove_ ){
 $('#' + vid + '-video-container').remove();
 }
});

}

function goCloseVideo(){
 exitVideoFullScreen();
}

function closeSearch(){
 
  $('#go-posts-column').css('display','block');
  $('#go-search-container').css('display','none');
  $('#go-searched-posts').empty();
  clearTimeout(spTimeout);
  if(spAjax) spAjax.abort();
}

function goCloseFullPhoto(){
$('#go-full-photo-container').css('display','none');
}

function goCloseSinglePost(){
$('#go-single-post-container').css('display','none');
}

function goCloseEditPostForm(){
$('#go-edit-post-form-container').css('display','none');
}

function goCloseCreatePostForm(){
 $('#go-create-post-form-container').css('display','none');

}

function closeProfile(){

  clearTimeout( gpTimeout);

 if(gpAjax) gpAjax.abort(); 

loadingProfilePosts=false;
  if( $('#go-single-post-container').is(':visible') ){
 
 // $('#go-single-post-container').css('z-index');
  return goCloseSinglePost(); 
 }

  var user=$('#go-current-opened-profile').val();

  var ucont=$('#go-profile-page-' + user);
  var loader=ucont.find('.profile-posts-loading-indicator');
  loader.css('display','none');
  return $('#go-profile-container').css('display','none');

}


function goChangePageType(t){
	var this_=$(t);
	var selected=this_.val();
$('#create-page-selected-type').text( selected);
$('.page-type-info').css('display','none');
$('#' + selected + 'info').css('display','block');
	
}

//NOTIFICATION
/*
function openNotifications(){
	
	 var data='<div class="center-header">Notifications</div>';
	data+='<div class="center-text-div">';
	data+='<div class="text-center" style="padding-top: 30px; overflow:hidden;"><span class="fa fa-spinner fa-spin fa-3x text-success"></span></div>';
	data+='</div>';
	
	displayData(data,  { id:'open-notification', sclose: false, no_cancel: true});
	
}

*/

$( function(){
	
//Create page

$('body').on('click','#create-page-btn',function(){   

 try{
  var this_=$(this);
 var rdiv=$('#register-user-result');
 rdiv.empty();
var type= $('#go-create-page-type').val();
if( type.length<3) {
	return toast('Select page type');
	}
   var username=  $.trim( $('#create-page-username').val()||"" );
  var email= randomString( 15) + '@gmail.com';

 var fullname= $.trim($('#create-page-fullname').val());
var bio= $.trim($('#create-page-bio').val() );

var phone=$.trim( $('#create-page-phone').val() );
var password=$.trim($('#create-page-password').val() );
     
  if( !username || username.length<4 || username.length>20) {
    return toast('Page pin too long or short. Max: 20');

   }else if( !validUsername(username) ) {
   return toast('Invalid pin. Alphanumerics, an underscore supported and must start with a letter.');
   }

else if(!fullname || fullname.length<2 || fullname.length>60) {
     return toast('Enter a valid display name or title.');
   }
else if( !validName(fullname) ){
     return toast('Enter a good display name or title. Must start and end with a letter.');    
    }
else if( !bio ){
     return toast('About page should not be empty.');    
    }
  else if( !email || email.length<5 ) {
     return toast('Enter a valid email address.');    
   }
   
else if( phone && !phone.match(/^[0-9+() -]{4,50}$/) ) {
     return toast('Enter a valid phone number.');    
  }

  else if(!password ||password.length<6) {
   return toast('Password should contain at least 6 characters.');    

  }
    else if(password.length>50) {
    return toast('Password too long. Max: 50.');    
    }    
    else if( !validPassword(password) ){
     return toast('Passwords can only contain the following characters: a-z 0-9 ~@#%_+*?-');
    }
    $('input, button').prop('disabled',true);
   buttonSpinner(this_);
 var elem=$('#go-create-page-form input,#bio');

    $.ajax({
      'url': _ADMIN_URL_ + '/ajax/go-social/add-new-page.php',
    type:'POST',
   dataType: 'json',
      'data':
      {
      "type": type,
       "username":username,
       "email": email,
       "fullname": fullname,
    "bio": bio,
       "phone": phone,
       "password": password,
      },
      type:'POST'
    }).done(function(result){
 // alert(result)
   buttonSpinner( this_, true);
   $('input,button').prop('disabled', false);
      
  if(result.error){

 toast(result.error);
}
 else if( result.status ){
  elem.val('');
   toast( result.result ,{type:'success'});
 
   } else{
    toast('Unknown error occured.');
      }
            
    }).fail(function(e, txt, xhr){
      $('input,button').prop('disabled',false);
      buttonSpinner(this_,true);   
    toast('Check your internet connection and try again. ' + xhr);
// alert( JSON.stringify(e) );

    });
}catch(e){ toast(e); }
  
  });

$('body').on('input','#go-new-post',function(){ 
  var this_=$(this);
  var data=$.trim( this_.val() );
  var plen=data.length;
 
  var maxlen = this_.attr("maxlength");
 var span=$('#post-char-count');
  span.removeClass('bg-danger');
var recheck=false;
  if ( plen >= maxlen) {
  this.value = this.value.substring(0, maxlen);
 recheck=true;
  span.addClass('bg-danger');
  }

 if( recheck) plen=this_.val().length;
    span.text( maxlen - plen);
 
 if ( data) {
localStorage.setItem('go_new_post_draft', data);
}

 if(plen>100) {
   this_.removeClass('go-pbg-1 go-pbg-2 go-pbg-3 go-pbg-4 go-pbg-5 go-pbg-6 go-pbg-7 go-pbg-8 go-pbg-9 go-pbg-10');
   this_.attr("data-bg","");
  $('#go-post-bg-container').css('visibility','hidden');
  }
 else{
   $('#go-post-bg-container').css('visibility','visible');
    }   
 });

  $('body').on('click','.go-post-bg',function(){
 var this_=$(this);
  var bg=this_.data('bg');
  var box=$('#go-new-post');
   box.removeClass('go-pbg-1 go-pbg-2 go-pbg-3 go-pbg-4 go-pbg-5 go-pbg-6 go-pbg-7 go-pbg-8 go-pbg-9 go-pbg-10');
  if( bg=='go-pbg-1') {
    return box.attr("data-bg","");
  }
   box.addClass(bg).attr('data-bg', bg); 
 });
  
$('body').on('click','#close-compose-page',function(){
    closeComposePage();
  });

   //POST PHOTO FULL
  
 $('body').on('click','.go-post-image,.go-post-author-image',function(){
 var this_=$(this);
   if( this_.hasClass('reposted') ) {
   //This let original post to load first before any image is viewable
     return;
   }
  var img= this_.attr('src');
     $('#go-full-photo-child-container').html('<img class="lazy go-full-photo" data-src="' + img + '">');
 $('#go-full-photo-container').css('display','block');
  });

$('body').on('click','.go-profile-cover-photo',function(){
 var this_=$(this);

  var img= this_.attr('src');
     $('#go-full-photo-child-container').html('<img class="lazy go-full-photo" data-src="' + img + '">');
 $('#go-full-photo-container').css('display','block');
  });


 
  //SCROLL NOTIFICATION PAGE
  
 $('#go-notifications-container .u-content').on('touchstart mouseover', function() {
   var scr=$(this).scrollTop() +
 $(this).innerHeight();
 
   if(!loadingNotificationsPosts && scr >=  $(this)[0].scrollHeight-500) {
    loadingNotificationsPosts=true;
     openNotifications();
    }
  });


});


function openNotifications(reset_){
 
goCloseComment();
  
  $('#total-new-notifications').attr('data-total',0).text(0).css('display','none');
  
 var mCont=$('#go-notifications-container');
 
  //if( !mCont.is(":visible"))  
 //changeHash("notification");
  
  mCont.fadeIn();
  
  var cont=$('#go-notifications');
 
 var pnumElem=$("#go-notifications-next-page-number");
   var pnum=pnumElem.text();
   
 if( pnum=="0") return;

 var loader=$("#notifications-loader");
 loader.removeClass("d-none");
 loadingNotificationsPosts=true;
 
 $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/show-notifications.php',
    type:'POST',
   timeout: 30000,
    dataType: "json",
    data: {
      "page": pnum,
    }
  }).done(function(result){
  // alert(JSON.stringify(result)  )  
    loadingNotificationsPosts=false;
    loader.addClass("d-none");
    
 if( result.no_noti ){
   return cont.html('<div class="text-center">No sent notifications</div>');
   pnumElem.text(0);
 
}else if ( result.error){

	return cont.html('<div class="text-center">' + result.error + '</div>');
	
	}
else if( result.status=="success"){
pnumElem.text(result.next_page);
  var r='<div class="container-fluid">';
 var d="";
var res=result.result;

  $.each( res,function(i,data){
  var nid=data.id;
 
   var meta= JSON.parse( data.meta);
   var author=meta.author||"";
   var action= meta.action;
   var type= meta.action_type;
   var aid= meta.action_id;
   var aid2=meta.action_id_2||"";
   var post_by=meta.post_by||"";
   
   var status=meta.status;
     
   d+='<div id="go-un-' + nid + '" class="row ' + (status?'go-unread-notification':'') + '">';
     d+='<div class="col" style="max-width: 60px;">';
     d+= go_user_icon( author,'go-notifications-user-icon' );
     d+='</div>';
     d+='<div class="col go-open-notification" onclick="openNotification_(this);" data-post-by="' + post_by + '" data-file="' + nid + '" data-author="' + author + '" data-action="' + action + '" data-action-type="' + type + '" data-action-id="' + aid + '" data-action-id-2="' + aid2 + '">';
     d+= data.message.replace(/\B@([\w- ]+)@/gi,'<span class="go-notification-names">$1</span>');
     d+='<div class="go-notifications-time">' + timeSince( data.message_time) + '</div>';
     d+='</div>';
     d+='<div class="d-non col go-delete-notification text-center" data-nid="' + nid + '" style="max-width: 60px;" onclick="deleteNotification(this);">';
     d+='<img class="icon-normal" src="' + _SITE_URL_ + '/oc-contents/assets/go-icons/delete2.png">';
     d+='</div>';
     d+='</div>';
     
   });
     
 r+=d;
 
  r+='</div>';
  
if( reset_) cont.html(r);
 else  cont.append(r);
  
  }
  else {
  	return cont.html('<div class="text-center">Unknown error occured</div>');
  }
 
 
 }).fail(function(e,txt,xhr){
   // alert( JSON.stringify(e));
   loadingNotificationsPosts=false;
  loader.addClass("d-none");
  toast("Something went wrong " + xhr);
  });
   
 }
 
 function sendNotification(t){
 	var this_=$(t);
 var mbox=$("#notification-message-box");
 
 	var message=$.trim( mbox.val()||"");
 
 var mlen=message.length;
 
 if( !mlen ){
     return toast("Message too short");
 }
 else if ( mlen>250 ){
 	return toast("Message exceeded 250 characters");
 }
 
 buttonSpinner(this_);
 	$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/send-notification.php',
    type:'POST',
    dataType: "json",
    data: {
    "type":"general",
      "message": message,
    }
  }).done(function(result){
 // alert(JSON.stringify(result)  )  
 buttonSpinner(this_, true);
 
 if( result.status){
 	mbox.val("");
 
$("#go-notifications-next-page-number").text("");
 setTimeout(function(){
  openNotifications(true);
  },700)
 	return toast( result.result,{type:'success'});
 }
 else if( result.error){
   return toast( result.error);	
 }
 
else{
	toast("Could not send");
	}
 
 }).fail(function(e,txt,xhr){
   // alert( JSON.stringify(e));
  buttonSpinner(this_, true);
  
  toast("Something went wrong " + xhr);
  });
 
 }
 
 
 function deleteNotification(t){
 	var this_=$(t);
 var nid=this_.data("nid");
 
 if(!nid) return toast("Id not found");
 
 buttonSpinner(this_);
 	$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/delete-notification.php',
    type:'POST',
    dataType: "json",
    data: {
    "type":"general",
      "id": nid,
    }
  }).done(function(result){
 // alert(JSON.stringify(result)  )  
 buttonSpinner(this_, true);
   if( result.status ){
   	
 $("#go-un-" + nid).remove();
 	return toast( result.result, {type:'success'});
 
 }
 else if( result.error){
   return toast( result.error);	
 }
 
else{
	toast("Could not delete");
	}
 
 }).fail(function(e,txt,xhr){
   // alert( JSON.stringify(e));
  buttonSpinner(this_, true);
  
  toast("Something went wrong " + xhr);
  });
 
 }
 
 
 function toggleNotificationPage(page){
 	$(".noti-page").addClass("d-none");
 $("#" + page).removeClass("d-none");
 }
 
 
function closeNotifications(){
  $('#go-notifications-container').css('display','none');  

}