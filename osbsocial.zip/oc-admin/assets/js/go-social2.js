var GO_UPLOADED_FILE_PATHS=[];
var XFROMSERVER=false;
var XQUEUEDFILES=[];


function goUploadPostFiles(){
//General

var data='<div class="file-message-upload-box dropzone text-center" id="goupload-post-files-widget"><div class="dz-message">Upload Photos/Videos</div> </div>';

displayData(data,{id:"general-upload-box", sclose: false});

var myDropzone = new Dropzone("div#goupload-post-files-widget", { url: _ADMIN_URL_ + "/ajax/go-social/upload-post-files.php"});

}


function go_captureVideoPoster(video, dimensions,divide){
 divide=divide||1

  var canvas = document.createElement("canvas");
// scale the canvas accordingly
  var oriWidth=  video.videoWidth;
  var oriHeight= video.videoHeight;

  var width=oriWidth||500;
  var height=oriHeight||250;

var dur=video.duration;

  if( dur<5 ){
    return 'small';
  }
  
  canvas.width = width; 
  canvas.height =height;

// draw the video at that frame
  var ctx=canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);


try{
// convert it to a usable data URL
 var dataURL = canvas.toDataURL("image/jpeg", 0.7);

}catch(e){
 return []
 }

  var data=(dataURL||"").split(',');
  if( data.length>0 ) data=data[1];
  else data=data[0];
 
 if( data){
   return [data,[width,height],];
 }
}

function photo_( resp, ext){
var file_path=resp.file_path;
var dimension=resp.dimension;
var width=resp.width||500;
var height=resp.height||150;
var file_size  =resp.file_size||1;

var data='<img src="' + file_path + '" style="width: 100px; height: 100px; max-height: 150px; margin-right: 5px; border:0; border-radius: 5px;">';
data+='<input class="file-info" type="hidden" data-filepath="' + file_path + '" data-ext="' + ext + '" data-filesize="' + file_size + '" data-dimension="' + dimension + '" />';



$('#go-upload-previews').append( data);

toast('Upload successful.',{type:'success'});
}

function video_( resp, ext, file){

var file_path =resp.file_path;
var cover_path=resp.cover_path;
var filename  =resp.filename;
var folder    =resp.folder;
var width     =resp.width||500;
var height    =resp.height||150;
var file_size =resp.file_size||1;


var filedata= file_path + '|' + ext + '|' + cover_path

//var file_path='http://www.jplayer.org/video/m4v/Big_Buck_Bunny_Trailer.m4v';

//var file_path='https://www.w3schools.com/html/movie.mp4';

var cid= randomString(6);

var data='<div id="uppc-' + cid + '" data-fpath="' + file_path + '" class="go-upload-video-preview-container">';

data+='<div id="uppc-cover-' + cid + '" class="go-video-preview-cover"><span class="fa fa-spinner fa-spin fa-lg"></span></div>';
   data+='<div id="vid-child-cont-' + cid + '">';
   data+='<video id="vid-' + cid + '" class="go-upload-video-preview" preload="auto" muted data-filename="' + filename + '" width="400" style="position: absolute; top: 0; height: 10ppx; width: 100px; object-fit: cover; object-position: 50% 50%;" controls autoplay muted>';
    data+='</video>';
    data+='</div>';

   data+='<span data-fpath="' + file_path + '" data-cid="uppc-' + cid + '" class="go-remove-upload-preview" id="close-upbtn-' + cid + '" data-filename="' + filename + '" onclick="removeUploadPreview(this);">x</span>';
  data+='<button id="gcover-btn-'+ cid + '" data-cid="' + cid + '" class="btn btn-sm btn-success generate-cover" style="display: none; position: absolute; bottom:0; width: 100px;" onclick="goUploadPostVideoCover(this);"><span style="font-size: 10px; font-weight:bold;">Generate cover</span></button>';
   data+='<input class="file-info" type="hidden" id="vid-poster-' + cid + '" data-filename="' + filename + '" data-folder="' + folder + '" data-filepath="' + file_path + '" data-ext="' + ext + '" data-cover="' + cover_path + '" data-filesize="' + file_size + '" data-dimension=""  />';
 data+='</div>';
        $('#go-upload-previews').append( data);

var previewEl = $("#vid-" + cid);
 if ( previewEl[0].canPlayType( file.type) !== "no"){     
 
var fileURL = URL.createObjectURL(file);
  
 previewEl.on('loadeddata', function(){
          URL.revokeObjectURL(fileURL);
var poster_res=go_captureVideoPoster( previewEl[0] );

try{

/*
if( poster_res && poster_res.length ){
  var elem=$('#vid-poster-' + cid);
   var poster=poster_res[0]||"";
   elem.val(poster );
   elem.attr('data-dim', poster_res[1].toString() );

 $('#vid-child-cont-' + cid).html('<img src="data:image/jpeg;base64,' + poster +'" class="go-video-upload-preview-poster" style="width: 100px; min-height: 100px;">');
  }
  else{

  $('#vid-child-cont-' + cid).html('<img src="assets/go-icons/bg/black-bg.png" class="go-video-upload-preview-poster">');

  }
*/
 $('#uppc-cover-' + cid).remove();  
 $('#gcover-btn-'+ cid ).fadeIn();

}catch(e){
 toast(e)
  $('#vid-child-cont-' + cid).html('<img src="assets/go-icons/bg/black-bg.png" class="go-video-upload-preview-poster">');
 $('#uppc-cover-' + cid).remove();
}


 });
    previewEl[0].src = fileURL;
   }

toast('Upload successful.',{type:'success'});
}

var addedFile=[]

Dropzone.options.gouploadPostFilesWidget = {
  paramName: 'file',
  maxFilesize: 30, // MB
  maxFiles: 6,
  resizeWidth: 1000,
 // parallelUploads: 4,
 // uploadMultiple: true,
  dictDefaultMessage: 'Upload Files',
 acceptedFiles: 'video/*,image/*',
  init: function() {
 
  GO_UPLOADED_FILE_PATHS=[];
 $('#go-upload-previews').empty();
 var index=-1;

this.on("addedfile", function(file) {
 
});

this.on("maxfilesexceeded", function(file ) {
  alert("Maximum files allowed is 6");
 this.removeFile(file);
});


this.on("sending", function(file, xhr, formData) {

 //file.width,file.height
 //formData.append("chat_to","");
 });

this.on("complete", function(file) {
  this.removeFile( file);
});

this.on("queuecomplete", function (file){
 closeDisplayData('general-upload-box');
});

this.on('success', function(file, resp){ 

if(resp.error){
   toast(resp.error);

}else if(resp.status ){
 
var ext=resp.ext;
 
if( ext=='jpg'){
photo_( resp, ext);
}
else if (ext=='mp4'){
 video_( resp, ext, file);
}

 }else{
 toast( JSON.stringify( resp) );
}
 });

  }
};


function goUploadPostVideoCover(t){
var this_=$(t);
var cid=this_.data("cid");

var elem=$("#vid-poster-" + cid);
var previewEl = $("#vid-" + cid);

var poster_res=go_captureVideoPoster( previewEl[0] );

if(!poster_res ||poster_res.length<2){

 return toast("Poster could not be generated for this video");

}

var poster=poster_res[0]||"";
var dim= poster_res[1].toString();

var cfilename=elem.attr("data-filename");
var folder=elem.attr("data-folder");

if(  !poster ||!cfilename){

  return toast('Poster could not be generated for this video');

}

//var poster=elem.val();

  this_.prop('disabled',true);

 buttonSpinner(this_);
setTimeout(  function(){
  $.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/upload-video-poster.php',
    type:'POST',
  // timeout: 40000,
     dataType: "json",
    data: {
    "poster": poster,
    "filename": cfilename,
    "folder": folder,
    "video_dimension": dim,
    }
  }).done(function(result){
 // alert(JSON.stringify(result));
this_.prop('disabled', false);
buttonSpinner(this_,true);
if(result.status=='success'){
 var dimension= result.dimension
elem.attr('data-dimension', dimension);
  this_.remove();
}
else if( result.error){
   toast( result.error)
  }
else{
toast('Unknown error occured.');
}
}).fail(function(e,txt,xhr){
  //alert(JSON.stringify(e));
this_.prop('disabled', false);
buttonSpinner(this_,true);
 toast('Failed to generate. ' + xhr);
});
},1000);
}

function removeFromUploadList(cid){
  
}

function removeUploadPreview(t){
 var this_=$(t);
var cid=this_.data('cid');
var index=+this_.data('findex');
 $('#' + cid).remove();
removeFromUploadList(cid);
}


function removeVideoFromServer(){

if( XFROMSERVER ||XQUEUEDFILES.length<1) return;

var XQUEUEDFILES_=XQUEUEDFILES;
XQUEUEDFILES=[];

XFROMSERVER=true;

setTimeout( function(){
$.ajax({
    url: _ADMIN_URL_ + '/ajax/go-social/remove-file-from-server.php',
    type:'POST',
   timeout: 6000,
     dataType: "json",
    data: {
    "filenames": XQUEUEDFILES_,
    }
  }).done(function(result){
  XFROMSERVER=false;
 removeFileVideoServer()

}).fail( function(e, txt,xhr){
  XFROMSERVER=false;
 removeFileVideoServer();

 });
},2000);

}


//UPLOAD PAGE PROFILE PICTURE

Dropzone.options.guploadPagePhotoWidget = {
  paramName: 'file',
  maxFilesize: 5, // MB
  maxFiles: 1,
  resizeWidth: 1000,
 // parallelUploads: 4,
 // uploadMultiple: true,
  dictDefaultMessage: 'Upload File',
 acceptedFiles: 'image/*',
  init: function() {

var pin=$.trim( $('#go-edit-page-pin').val());

this.on("sending", function(file, xhr, formData) {
 var width=file.width;
 var height=file.height;
formData.append("username", pin);
 });

this.on("complete", function(file) {
  this.removeFile( file);
});
  this.on('success', function(file, resp){ 

if(resp.error){
   toast(resp.error);

}else if(resp.status ){
 
toast('Upload successful.',{type:'success'});

$('#go-edit-page-icon').attr('src', go_user_photo_url(pin,'small') + '?i=' + randomString(3) )

closeDisplayData('general-upload-box');

 }else{
 toast( resp);
}
 });

  }
};




function goUploadPagePhoto(){

var data='<div class="file-message-upload-box dropzone text-center" id="gupload-page-photo-widget"><div class="dz-message">Upload picture</div> </div>';

displayData(data,{id:"general-upload-box", sclose: false});

var myDropzone = new Dropzone("div#gupload-page-photo-widget", { url: _ADMIN_URL_ + "/ajax/go-social/upload-page-photo.php"});

}
