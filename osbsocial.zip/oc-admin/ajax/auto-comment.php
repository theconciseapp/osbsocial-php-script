<?php header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

if (empty($_POST['post_id']) || empty($_POST['group_pin'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$post_id = test_input($_POST['post_id']);

$gpin    = test_input(strtolower($_POST['group_pin']));

require ('../../oc-includes/server.php');

require ('../../oc-ajax/comment/comment-functions.php');

function format_comment($username, $gpin, $post_id, $clen, $currentTime = "") 

  {

    if (empty($currentTime)) 

      {

        $currentTime = time();

      }

    $obj_        = array();

    $obj_["pid"]             = "" . $post_id;

    $obj_["cf"]             = "" . $username;

    $obj_["ct"]             = "" . $gpin;

    $obj_["file"]             = ""; //video, image

    $obj_["lfpath"]             = ""; //local file path

    $obj_["sfpath"]             = ""; //server file path

    $obj_["hl"]             = ""; //Highlight (text or file highlight)

    $obj_["pt"]             = ""; //preview text

    $obj_["size"]             = "" . $clen; //txt size or file size

    $obj_["fx"]             = "";

    $obj_["time"]             = "" . $currentTime;

    $obj_["ver"]             = "a";

    return json_encode($obj_);

  }

function readable_random_name($length     = 6) 

  {

    $string     = '';

    $vowels     = array(

        "a",

        "e",

        "i",

        "o",

        "u"

    );

    $consonants = array(

        'b',

        'c',

        'd',

        'f',

        'g',

        'h',

        'j',

        'k',

        'l',

        'm',

        'n',

        'p',

        'r',

        's',

        't',

        'v',

        'w',

        'x',

        'y',

        'z'

    );

    $max        = $length / 2;

    for ($i          = 1;$i <= $max;$i++) 

      {

        $string.= $consonants[rand(0, 19) ];

        $string.= $vowels[rand(0, 4) ];

      }

    return $string;

  }

$comments  = array(

    "hahahahah",

    "😂😂😂",

    "Omg",

    "😁😁😁😁",

    "I can't stop laughing..",

    "first to comment.",

    "😘",

    "😊",

    "mummy G.O is coming for you",

    "🙄",

    "💃",

    "😎",

    "😱",

    "vawulence",

    "love"

);

$comments2 = array(

    "funny",

    "..hilarious😁😁",

    "uno well",

    ".",

    "..",

    "...",

    ".....",

    "💛",

    "😁😁😁😁",

    "💖",

    "😅",

    "🤐",

    "🤗🤗",

    "you made my day..",

    "😋",

    "😘",

    "😍",

    "💃",

    "aswear",

    "😫",

    "😱",

    "shaker..",

    "tueh"

);

$comments3 = array(

    "..",

    ".",

    "looolz",

    "abeg getat",

    "breaker",

    "you well?",

    "😁😁😁😁",

    "hahahha",

    "🤓🤓",

    "🤐",

    "😬",

    "😊",

    "😍",

    "😫",

    "😱",

    "aswear",

    "ha"

);

for ($i         = 0;$i < 10;$i++) 

  {

    $random_comment  = array_rand($comments);

    $random_comment2 = array_rand($comments2);

    $random_comment3 = array_rand($comments3);

    $comment         = "";

    $comment         = $comments[$random_comment] . " " . $comments2[$random_comment2] . " " . $comments3[$random_comment3];

    $time            = time() + rand(1, 20) + ($i * 20);

    $author          = readable_random_name(rand(6, 10));

    $nid             = array(

        "",

        "",

        rand(1, 600)

    );

    $rnid            = array_rand($nid);

    $author          = $author . $nid[$rnid];

    $meta            = format_comment($author, $gpin, $post_id, "50", $time);

    $likes           = rand(0, 17);

    $result          = add_comment($conn, $gpin, $post_id, $author, $comment, $meta, _SITE_VERSION_, $likes);

  }

if ($result) 

  {

    $conn->close();

    die('{"status":"success","result":"' . $result . '"}');

  }

$conn->close();

die('{"error":"Failed."}');

