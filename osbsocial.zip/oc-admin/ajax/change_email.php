<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['new_email'])) 

  {

    die('{"error":"Email address cannot be empty."}');

  }

else if (!filter_var($_POST['new_email'], FILTER_VALIDATE_EMAIL)) 

  {

    die('{"error":"Invalid email address."}');

  }

require "../../oc-includes/server.php";

$table    = _TABLE_ADMINS_;

$username = test_input(getAdminInfo('username'));

if (strtolower($username) == 'admin123') 

  {

    die('{"error":"Permission denied"}');

  }

$new_email = mysqli_real_escape_string($conn, $_POST['new_email']);

$query     = mysqli_query($conn, "SELECT id FROM $table WHERE email='$new_email' LIMIT 1");

if (mysqli_num_rows($query) > 0) 

  {

    die('{"error":"Email address is already in use. Use another one."}');

  }

if (mysqli_query($conn, "UPDATE $table SET email='$new_email' WHERE username='$username' LIMIT 1")) 

  {

    if (mysqli_affected_rows($conn) > 0) 

      {

        mysqli_close($conn);

        $_SESSION["ADMIN___EMAIL"] = $new_email;

        die('{"status":"success","result":"Email saved successfully."}');

      }

  }

mysqli_close($conn);

die('{"error":"Failed to save."}');



