<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

$admin_username = getAdminInfo('username');

if (!adminCanAddAdmin()) 

  {

    die('{"error":"Sorry, you are not permitted to perform this task."}');

  }

if (empty($_POST['user'])) 

  {

    die('{"error":"One or more fields are empty."}');

  }

$username = strtolower($_POST['user']);

if (!validUsername($username, true)) 

  {

    die('{"error":"Username can contain alphanumerics, underscore and must start with a letter. Min: 4, Max: 30"}');

  }

/*
else if (preg_match("/_/", $username) && !startsWith($username, "uv_") ) 

  {

    die('{"error":"Verified account should start with uv_"}');

  }
*/

require "../../oc-includes/server.php";

$username     = mysqli_real_escape_string($conn, $username);

$new_password = password_hash("123456", PASSWORD_DEFAULT);

$table        = _TABLE_USERS_;

$stmt         = $conn->prepare("UPDATE {$table} SET password=? WHERE username=? LIMIT 1");

if ($stmt && $stmt->bind_param('ss', $new_password, $username) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    $data = array();

    $data["status"]      = "success";

    $data["result"]      = "Password reset successful";

    die(json_encode($data));

  }

$conn->close();

die('{"error":"No changes made."}');


