<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require '../../oc-includes/bootstrap.php';

adminLoggedIn(false, 'die', 'json');

if ( !adminCanMessageUser()) 

  {

    die('{"error":"Permission denied"}');

  }

use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\SMTP;

use PHPMailer\PHPMailer\Exception;

if (empty(  $_POST["user"])
 || empty($_POST["message"])
 || empty( $_POST["subject"] )
 || empty( $_POST["email"] ) )

  {

    die('{"error":"One or more parameters missing"}');

  }

$admin_username = getAdminInfo('username');

   $subject       = htmlspecialchars( $_POST['subject']);

    $message        = htmlspecialchars( $_POST['message']);
  $email        = htmlspecialchars( $_POST['email']);

$message= preg_replace('#&lt;(/?(?:pre|b|em|u|ul|li|ol)(?:.*?)?)&gt;#', '<\1>', $message);

if( Emailer( $email, $subject, $message)){

die('{"status":"success","result":"Sent successfully."}');

      }

    else

      {

        die('{"error":"Not sent."}');

}
