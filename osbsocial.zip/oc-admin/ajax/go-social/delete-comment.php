<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['comment_id']) || empty($_POST['post_id'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$post_id = test_input($_POST['post_id']);

$cid     = test_input($_POST['comment_id']);

require ('../../../oc-includes/server.php');

require ('comment-functions.php');

if (delete_comment($conn, $cid, $post_id)) 

  {

    $conn->close();

    die('{"status":"success","result":"Succesful."}');

  }

$conn->close();

die('{"error":"Please try again."}');

