<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

@ini_set('max_execution_time', 60);

require '../../../oc-includes/bootstrap.php';

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

else if (empty($_POST["poster"]) || empty($_POST['filename']) || empty($_POST["folder"])) 

  {

    die('{"error":"Missing parameters.","ecode":"52"}');

  }

$poster_base64 = test_input($_POST['poster']);

$bfilesize     = strlen($poster_base64) / 1024;

$bfilesize     = $bfilesize / 1024;

if ($bfilesize > 5) 

  {

    die('{"error":"Cover too large.","ecode":"3"}'); //File too large

    

  }

$folder        = test_input($_POST["folder"]);

$poster_base64 = base64_decode($poster_base64);

$vwidth        = 500;

$vheight       = 300;

$vdim          = "500,300";

if (!empty($_POST["video_dimension"])) 

  {

    $vdim          = test_input($_POST["video_dimension"]);

    $dim           = explode(",", $vdim);

    if (count($dim) < 2) 

      {

        die('{"error":"invalid video dimensions","ecode":"4"}');

      }

    $vw          = (int)$dim[0];

    if ($vw > 50) 

      {

        $vwidth      = round($vw);

      }

    $vh          = (int)$dim[1];

    if ($vh > 50) 

      {

        $vheight     = round($vh);

      }

  }

if ($vwidth > 500) 

  {

    $vwidth      = 500;

    $vheight     = 500;

  }

$filename_   = test_input($_POST["filename"]);

$filename    = "{$filename_}";

//~{$vwidth}~{$vheight}~";

$dir         = _CHAT_FILES_DIR_ . "/{$folder}";

$video       = "{$dir}/{$filename_}.mp4";

$rename_to   = "{$dir}/{$filename}.mp4";

//rename( $video, $rename_to);

//$poster_file=_CHAT_FILES_PATH_.'/video-poster-error.png';

$poster_file = _CHAT_FILES_PATH_ . "/{$folder}/__POSTERS__/{$filename}.jpg";

if (make_dir($dir)) 

  {

    require '../../../oc-includes/chat_functions.php';

    $poster_dir     = "{$dir}/__POSTERS__/";

    if (make_dir($poster_dir)) 

      {

        $save_poster_to = "{$poster_dir}/{$filename}.jpg";

        if (!empty($poster_base64) && saveBase64Image($poster_base64, $save_poster_to, $vwidth)) 

          {

            $dimension      = "{$vwidth}_{$vheight}";

            die('{"status":"success","result":"Generated","poster_file":"' . $poster_file . '","filename":"' . $filename . '","width":"' . $vwidth . '","height":"' . $vheight . '","dimension":"' . $dimension . '"}');

          }

      }

  }

die('{"error":"Server error: dirE","ecode":"53"}'); //Unable to create directory

