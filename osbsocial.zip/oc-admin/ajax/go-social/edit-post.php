<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['id'])) 

  {

    die('{"error":"Missing ID."}');

  }

function format_post($post = "") 

  {

    $post = htmlspecialchars(trim($post));

    return preg_replace("/(\r?\n){2,}/", "\n\n", $post);

  }



$post_files = $post_title="";

$id           = test_input($_POST["id"]);

$post_by      = test_input($_POST["post_by"]);

$post         = format_post($_POST["post"]);

$post_preview = mb_substr($post, 0, 250, 'utf-8');

$post_meta    = htmlspecialchars(trim($_POST['post_meta']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');

$post_meta    = str_replace('&amp;', '&', $post_meta);

$test_meta    = json_decode($post_meta);

if (!$test_meta) 

  {

    die('{"error":"Error occured in your post meta."}');

  }

if( !empty( $_POST["post_files"] ) && 
$_POST["post_files"]!="[]"
){

$post_files    = htmlspecialchars(trim($_POST['post_files']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');

$post_files    = str_replace('&amp;', '&', $post_files);

$test_files    = json_decode($post_files);

if (!$test_files) 

  {

    die('{"error":"Error occured in your post files"}');

  }
}


if( !empty( $_POST["post_title"] ) ){
  $post_title=test_input( $_POST["post_title"] );

}

$post_type      = test_input($_POST["post_type"]);

$total_comments = test_input($_POST["total_comments"]);

$total_shares   = test_input($_POST["total_shares"]);

$reactions      = htmlspecialchars(trim($_POST['reactions']) , ENT_QUOTES & ~ENT_COMPAT, 'UTF-8');



$test_reactions    = json_decode($reactions);

if (!$test_reactions) 

  {

    die('{"error":"Error occured in your post reactions"}');

  }


$post_status    = test_input($_POST["post_status"]);

$post_date      = (int)$_POST["post_date"];

$date_time      = test_input($_POST["date_time"]);

require ('../../../oc-includes/server.php');

$ptable = _TABLE_SOCIAL_POSTS_;

$stmt   = $conn->prepare("UPDATE $ptable SET post_by=?, post_title=?, post_preview=?, post=?, post_files=?, post_meta=?, post_type=?, total_comments=?, total_shares=?, reactions=?, post_status=?, post_date=?, date_time=? WHERE id=? LIMIT 1");

if ($stmt && $stmt->bind_param('ssssssssssssss', $post_by, $post_title, $post_preview, $post, $post_files, $post_meta, $post_type, $total_comments, $total_shares, $reactions, $post_status, $post_date, $date_time, $id) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    $result = array();

    $result["status"]        = "success";

    $result["id"]        = $id;

    $result["post_preview"]        = $post_preview;

    $result["result"]        = "Updated successfully";

    die(json_encode($result));

  }

$conn->close();

die('{"error":"Failed to update."}');





