<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (empty($_POST['post_id'])

//||empty( $_POST['post_by'] )

) 

  {

    die('{"error":"Missing parameters."}');

  }

$pid = test_input($_POST['post_id']);

//$post_by=test_input( $_POST['post_by'] );

require ('../../../oc-includes/server.php');

$table       = _TABLE_SOCIAL_POSTS_;

$table_users = _TABLE_USERS_;

$ftable      = _TABLE_PREFIX_ . "go_followers";

$result      = array();

$stmt        = $conn->prepare("SELECT U.fullname AS real_name, U.country, U.bio, U.phone, U.birth, U.added_on AS joined_on, P.* FROM {$table} AS P 
INNER JOIN {$table_users} AS U ON U.username=P.post_by WHERE P.id=? LIMIT 1");

if ($stmt && $stmt->bind_param('i', $pid) && $stmt->execute()) 

  {

    $res         = $stmt->get_result();

    $conn->close();

    $stmt->close();

    if ($res->num_rows < 1) 

      {

        die('{"error":"Post might have been deleted."}');

      }

    $row = $res->fetch_assoc();

    $result["status"]     = "success";

    $result["me_following"]     = null;

    $result["post"][]     = $row;

    die(json_encode($result));

  }

$conn->close();

die(json_encode('{"error":"Not known"}'));

