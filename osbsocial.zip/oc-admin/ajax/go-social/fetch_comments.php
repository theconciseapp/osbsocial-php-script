<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['post_id'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$post_id = test_input($_POST['post_id']);

require ('../../../oc-includes/server.php');

require ('comment-functions.php');

$result = fetch_comments($conn, $post_id);

$conn->close();

die(json_encode($result));

