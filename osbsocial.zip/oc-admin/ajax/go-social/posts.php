<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

require '../../../oc-includes/server.php';

$sJson            = getSettings();

$item_per_page    = 10; //isset($sJson["users_per_page"]) ? $sJson["users_per_page"] : "20";

$table            = _TABLE_SOCIAL_POSTS_;

if (!empty($_POST["page"])) 

  {

    $page_number      = (int)$_POST["page"];

  }

else

  {

    $page_number      = 1;

  }

$pv_option=1;

if( !empty( $_POST["posts_view_option"] )){

 $pv_option=(int)$_POST["posts_view_option"];

}


$where="U.role IN(3,5)";

if( $pv_option=="2"){

 $where.=" AND P.post_status='1'";

 }
 else if( $pv_option=="3"){

  $where.=" AND P.post_status='0'";
 
}

$item_per_page_ex = $item_per_page + 1;

$previous_page    = 0;

$next_page        = 0;

$page_position    = (($page_number - 1) * $item_per_page);

$table_users      = _TABLE_USERS_;

$stmt             = $conn->prepare("SELECT P.*, U.fullname AS real_name FROM $table AS P
INNER JOIN $table_users AS U ON(U.username=P.post_by ) WHERE $where ORDER BY id DESC LIMIT $page_position, $item_per_page_ex");

if (!$stmt || !$stmt->execute()) 

  {

    $conn->close();

    die('{"error":"Please try again."}');

  }

$res = $stmt->get_result();

$stmt->close();

$conn->close();

$final_result  = $result        = array();

$total_posts   = $total_to_send = $res->num_rows;

if ($total_posts < 1) 

  {

    die('{"no_post":"No post yet."}');

  }

if ($total_posts > $item_per_page) 

  {

    $next_page     = $page_number + 1;

    $total_to_send = $item_per_page;

  }

$i             = 0;

while ($row           = $res->fetch_assoc()) 

  {

    $i++;

    if ($i <= $total_to_send) 

      {

        $result[]               = $row;

      }

  }

$final_result["status"]               = "success";

$final_result["total_posts"]               = $total_posts;

$final_result["next_page"]               = $next_page;

$final_result["posts"]               = $result;

//$pagination= paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url, 'admin');

die(json_encode($final_result));





