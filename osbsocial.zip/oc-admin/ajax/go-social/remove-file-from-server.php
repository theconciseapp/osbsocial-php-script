<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['filenames'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$filenames = $_POST['filenames'];

foreach ($filenames AS $file) 

  {

  }

