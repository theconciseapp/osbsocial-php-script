<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST["s"])) 

  {

    die('{"error":"Search term not found."}');

  };

$search_word = $_POST["s"];

$search_word = preg_replace("/[^A-Za-z0-9_ -]/", '', $search_word);

if (empty($search_word) || strlen($search_word) < 3) 

  {

    die('{"error":"No post found."}');

  };

require '../../../oc-includes/server.php';

$table            = _TABLE_REPORTS_;

$result           = array();

$final_result     = array();

if (!empty($_POST["page"])) 

  {

    $page_number      = (int)$_POST["page"];

  }

else

  {

    $page_number      = 1;

  }

$item_per_page    = 20;

$item_per_page_ex = $item_per_page + 1;

$previous_page    = 0;

$next_page        = 0;

$page_position    = (($page_number - 1) * $item_per_page);

$words            = array_slice(explode(" ", $search_word, 3) , 0, 2);

$report_by_       = $report_          = $report_section_  = "";

foreach ($words as $word) 

  {

    if (strlen($word) > 1) 

      {

        $report_by_.= "report_by LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

        $report_.= "report LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

        $report_section_.= "report_section LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

      }

  }

if (empty($report_by_) && empty($report_) && empty($report_section_)) 

  {

    die('{"error":"No result found."}');

  }

$report_by_      = substr($report_by_, 0, -4);

$report_         = substr($report_, 0, -4);

$report_section_ = substr($report_section_, 0, -4);

$table_users     = _TABLE_USERS_;

$ftable          = _TABLE_SOCIAL_FOLLOWERS_;

$sql             = "SELECT*FROM {$table} WHERE ( ($report_by_) OR ( $report_) OR ($report_section_ ) ) ORDER BY id DESC LIMIT $page_position, $item_per_page_ex";

$query           = mysqli_query($conn, $sql);

mysqli_close($conn);

$total_posts   = $total_to_send = mysqli_num_rows($query);

if ($total_posts < 1) 

  {

    die('{"status":"success","no_report":"No reports found"}');

  }

if ($total_posts > $item_per_page) 

  {

    $next_page     = $page_number + 1;

    $total_to_send = $item_per_page;

  }

$i             = 0;

while ($row           = mysqli_fetch_assoc($query)) 

  {

    $i++;

    if ($i <= $total_to_send) 

      {

        $result[]               = $row;

      }

  }

$final_result["status"]               = "success";

$final_result["total_posts"]               = $total_posts;

$final_result["next_page"]               = $next_page;

$final_result["reports"]               = $result;

die(json_encode($final_result));

