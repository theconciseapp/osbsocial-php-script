<?php function add_comment($conn, $fullname, $post_id, $author, $message, $meta       = "", $version    = "1.0", $likes      = 0) 

  {

    $table      = _TABLE_PREFIX_ . "go_social_comments";

    $table_post = _TABLE_SOCIAL_POSTS_;

    $result     = $error      = 0;

    $likes      = (int)$likes;

    try

      {

        $stmt       = $conn->prepare("INSERT INTO $table( fullname, post_id, comment_author, message,meta,likes, date_time)VALUES(?,?,?,?,?,?, NOW() )");

        if ($stmt && $stmt->bind_param('sisssi', $fullname, $post_id, $author, $message, $meta, $likes) && $stmt->execute()) 

          {

            $result     = mysqli_stmt_insert_id($stmt);

            $stmt->close();

            if ($stmt = $conn->prepare("UPDATE $table_post SET total_comments=total_comments+1 WHERE id=? LIMIT 1")) 

              {

                $stmt->bind_param('i', $post_id);

                $stmt->execute();

                $stmt->close();

              }

          }

        else

          {

            $result = 0;

          }

      }

    catch(Exception $e) 

      {

        logIt($e->getMessage());

        return 0;

      }

    return $result;

  }

function delete_comment($conn, $cid, $post_id) 

  {

    $table = _TABLE_PREFIX_ . "go_social_comments";

    $stmt  = $conn->prepare("DELETE FROM $table WHERE id=? LIMIT 1");

    if ($stmt && $stmt->bind_param('i', $cid) && $stmt->execute()) 

      {

        $stmt->close();

        $table_post = _TABLE_SOCIAL_POSTS_;

        try

          {

            if ($stmt       = $conn->prepare("UPDATE $table_post SET total_comments=total_comments-1 WHERE id=? LIMIT 1")) 

              {

                $stmt->bind_param('i', $post_id);

                $stmt->execute();

                $stmt->close();

              }

          }

        catch(Exception $e) 

          {

            logIt($e->getMessage());

          }

        return true;

      }

    return false;

  }

function fetch_comments($conn, $post_id) 

  {

    $table            = _TABLE_PREFIX_ . "go_social_comments";

    $result           = $data             = array();

    if (!empty($_GET["page"])) 

      {

        $page_number      = (int)$_GET["page"];

      }

    else

      {

        $page_number      = 1;

      }

    $item_per_page    = 10;

    $item_per_page_ex = $item_per_page + 1;

    $previous_page    = 0;

    $next_page        = 0;

    $page_position    = (($page_number - 1) * $item_per_page);

    $stmt             = $conn->prepare("SELECT P.id, P.post_id, P.comment_author, P.message, P.post_files, P.meta, P.likes, P.date_time FROM $table AS P WHERE 
P.post_id=? AND P.parent_id='0'  ORDER BY id DESC LIMIT $page_position, $item_per_page_ex");

    if ($stmt && $stmt->bind_param('i', $post_id) && $stmt->execute()) 

      {

        $res              = $stmt->get_result();

        $stmt->close();

        $total         = $res->num_rows;

        $total_to_send = $total;

        if ($total < 1) 

          {

            $result["no_comment"]               = "No comment yet.";

          }

        else

          {

            if ($page_number > 1) 

              {

                $previous_page = $page_number - 1;

              }

            if ($total > $item_per_page) 

              {

                $next_page     = $page_number + 1;

                $total_to_send = $item_per_page;

              }

            $i             = 0;

            while ($row           = $res->fetch_assoc()) 

              {

                $i++;

                if ($i <= $total_to_send) 

                  {

                    $data[]               = $row;

                  }

              }

            $result["result"]               = $data;

            $result["post_id"]               = $post_id;

            $result["prev_page"]               = $previous_page;

            $result["next_page"]               = $next_page;

            $result["item_per_page"]               = $item_per_page;

            $result["status"]               = "success";

          }

      }

    return $result;

  }


