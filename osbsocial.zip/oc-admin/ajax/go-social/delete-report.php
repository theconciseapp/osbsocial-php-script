<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['id'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$id = test_input($_POST['id']);

require ('../../../oc-includes/server.php');

$table = _TABLE_REPORTS_;

$stmt  = $conn->prepare("DELETE FROM $table WHERE id=? LIMIT 1");

if ($stmt && $stmt->bind_param('i', $id) && $stmt->execute()) 

  {

    $stmt->close();

    $conn->close();

    die('{"status":"success"}');

  }

$conn->close();

die('{"error":"Please try again."}');

