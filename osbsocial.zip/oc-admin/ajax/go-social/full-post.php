<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanManageSocial()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['post_id'])) 

  {

    die('{"error":"Missing parameters."}');

  }

$pid = test_input($_POST['post_id']);

require ('../../../oc-includes/server.php');

$table   = _TABLE_SOCIAL_POSTS_;

$iresult = array();

$stmt    = $conn->prepare("SELECT post FROM {$table} WHERE id=? LIMIT 1");

if ($stmt && $stmt->bind_param('i', $pid) && $stmt->execute()) 

  {

    $res     = $stmt->get_result();

    $conn->close();

    $stmt->close();

    if ($res->num_rows < 1) 

      {

        die('{"status":"0"}');

      }

    $row = $res->fetch_assoc();

    $row["status"]     = "success";

    die(json_encode($row));

  }

die(json_encode('{"error":"Not known"}'));

