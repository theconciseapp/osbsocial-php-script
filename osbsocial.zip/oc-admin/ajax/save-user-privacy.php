<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanChangeSettings()) 

  {

    die('{"error":"Permission denied"}');

  }

else if (!isset($_POST['message'])) 

  {

    die('{"error":"Missing parameters"}');

  }

$file    = _PROJECT_DIR_ . "/oc-privacy.txt";

//clearstatcache();

$message = $_POST['message'];

if (file_put_contents($file, $message)) 

  {

    die('{"status":"success","result":"Saved successfully."}');

  }

