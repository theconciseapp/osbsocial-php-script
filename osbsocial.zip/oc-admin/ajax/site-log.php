<?php

/**

 * Class and Function List:

 * Function list:

 * - checkUserEmailExist()

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

//logIt( randomString(9));

adminLoggedIn(false, 'die', 'json');

$admin_username = getAdminInfo('username');

if (!adminCanAddAdmin()) 

  {

    die('{"error":"Sorry, you are not permitted to perform this task."}');

  }

if (empty($_POST['type'])) 

  {

    die('{"error":"One or more fields are empty."}');

  }

$type     = (int)$_POST['type'];

$action   = $_POST['action'];

function site_log($type, $action   = "show") 

  {

    $log      = array();

    if ($type == 1) 

      {

        $log_file = _ERROR_DIR_ . "/oc-errors.php";

      }

    else if ($type == 2) 

      {

        $log_file = _ERROR_DIR_ . "/log.php";

      }

    else

      {

        $log["error"]          = "Type not found.";

        return json_encode($log);

      }

    if (!file_exists($log_file)) 

      {

        $log["error"] = "File not found.";

        return json_encode($log);

      }

    if ($action == 'clear') 

      {

        if (file_put_contents($log_file, "<?php die('Life is sweet!');?>")) 

          {

            $log["status"] = "success";

            $log["result"] = "Log emptied!";

            return json_encode($log);

          }

        else

          {

            $log["error"] = "Could not clear.";

            return json_encode($log);

          }

      }

    $data = file_get_contents($log_file);

    if ($data === false) 

      {

        $log["error"]      = "Could not fetch data.";

        return json_encode($log);

      }

    $data = mb_substr(trim($data) , 30);

    if (empty($data)) 

      {

        $log["status"]      = "success";

        $log["result"]      = "Log is empty.";

        return json_encode($log);

      }

    $log["status"] = "success";

    $log["result"] = $data;

    return json_encode($log);

  }

die(site_log($type, $action));

