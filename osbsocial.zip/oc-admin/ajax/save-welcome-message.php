<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanChangeSettings()) 

  {

    die('{"error":"Permission denied"}');

  }

$udir = _CHAT_FILES_DIR_ . "/welcome";

//clearstatcache();

if (!make_dir($udir)) 

  {

    die('{"error":"Failed to create dir."}');

  }

$wvideo   = $udir . "/0123456789.mp4";

$wmessage = $udir . "/welcome.txt";

if (empty($_POST['message'])) 

  {

    if (is_file($wmessage)) 

      {

        unlink($wmessage);

      }

    die('{"status":"success","result":"Saved successfully."}');

  }

$message = htmlspecialchars(trim($_POST['message']) , ENT_QUOTES);

if (file_put_contents($wmessage, $message)) 

  {

    die('{"status":"success","result":"Saved successfully."}');

  }

