<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

header('Content-type:application/json;charset=utf-8');

if (empty($_POST["email"]) || empty($_POST["token"]) || empty($_POST["password"])) 

  {

    die('{"error":"Expected parameters not found."}');

  }

require ('../../oc-includes/bootstrap.php');

$password = test_input($_POST["password"]);

$email    = $_POST["email"];

$token    = test_input($_POST["token"]);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 

  {

    die('{"error":"Invalid email address or link."}');

  }

else if (!validPassword($password)) 

  {

    die('{"error":"Password can only contain: a-z 0-9 ~@#%_+*?-, Min 6 chars, Max 40 chars."}');

  }

require ('../../oc-includes/server.php');

$table        = _TABLE_ADMINS_;

$table_tokens = _TABLE_TOKENS_;

$time         = time();

if (!$query        = mysqli_query($conn, "SELECT expiry_time FROM $table_tokens WHERE email='$email' AND expiry_time>'$time' AND token='$token' LIMIT 1")) 

  {

    die('{"error":"Site error occured. Please try again."}');

  }

if (mysqli_num_rows($query) < 1) 

  {

    die('{"error":"Invalid code or expired."}');

  }

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

if ($conn->query("UPDATE $table SET password='$hashed_password'
WHERE email='$email'")) 

  {

    if ($conn->affected_rows > 0) 

      {

        $conn->query("DELETE FROM $table_tokens WHERE token='$token'");

        die('{"status":"success","result":"Your password has been updated successfully."}');

      }

  }

die('{"error":"Unable to reset. Please try again."}');

