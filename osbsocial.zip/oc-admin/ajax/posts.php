<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die');

if (isset($_POST['sort_by'])) 

  {

    $sort_by = test_input($_POST['sort_by']);

    if (empty($sort_by)) $sort_by = 'verified_asc';

    $_SESSION['sort_by']         = $sort_by;

    die('__SUCCESS__');

  }

require '../../oc-includes/server.php';

$sJson          = getSettings();

$users_per_page = isset($sJson["users_per_page"]) ? $sJson["users_per_page"] : "20";

$table          = _TABLE_GROUPS_MESSAGES_;

if (!isset($page_url)) $page_url       = "";

$item_per_page  = $users_per_page;

$param          = !empty($_POST['param']) ? test_input($_POST['param']) : '';

$sort_by        = 'id';

$desc           = 'DESC';

if (!empty($_SESSION['sort_by'])) 

  {

    $sby            = $_SESSION['sort_by'];

    if ($sby == 'fullname_desc') 

      {

        $sort_by        = 'group_title';

        $desc           = 'DESC';

      }

    else if ($sby == 'fullname_asc') 

      {

        $sort_by        = 'group_title';

        $desc           = 'ASC';

      }

    else if ($sby == 'id_desc') 

      {

        $sort_by        = 'id';

        $desc           = 'DESC';

      }

    else if ($sby == 'id_asc') 

      {

        $sort_by        = 'id';

        $desc           = 'ASC';

      }

  }

if (isset($_GET["page"])) 

  {

    $page_number    = (int)$_GET["page"];

  }

else

  {

    $page_number    = 1;

  }

$results        = mysqli_query($conn, "SELECT COUNT(id ) FROM $table");

//get total number of records from database

$get_total_rows = $results->fetch_row();

//hold total records in variable

$total_groups   = $get_total_rows[0];

if ($total_groups < 1) 

  {

    mysqli_close($conn);

    die('<div class="alert alert-primary text-center">
<span class="fa fa-arrow-down"></span> No a
post yet.
   </div>');

  }

$total_pages   = ceil($total_groups / $item_per_page);

$page_position = (($page_number - 1) * $item_per_page);

echo '<div><strong>Total posts: ' . $total_groups . '</strong></div>';

$query = mysqli_query($conn, "SELECT message_id, message_from, message_to, message_preview, meta, date_time FROM $table WHERE message_from!='act'ORDER BY $sort_by $desc LIMIT $page_position, $item_per_page");

mysqli_close($conn);

echo '<div class="container-fluid">';

while ($row     = mysqli_fetch_assoc($query)) 

  {

    $mto     = $row["message_to"];

    $mby     = ucfirst($row["message_from"]);

    $message = ucfirst($row["message_preview"]);

    $mdt     = $row["date_time"];

    $mid     = $row["message_id"];

    $meta    = json_decode($row["meta"], true);

?>
 <div class="user-panel border-bottom" id="group-post-<?php echo $mid; ?>">

  <div class="row">
<div class="col-3">

<div class="user-photo-icon-container"> <img src="<?php echo user_photo_icon(strtolower($mby) , "g"); ?>" onerror="imgError( this, 50);" class="user-photo-icon">
</div>

</div>

<div class="col" style="overflow-x: hidden;">

<div class="users-list-container">
 <?php echo "<strong><span class='user-fullname-text'>{$mby}</span>, To: <strong><small>[ " . strtoupper(str_replace('gp_', '', $mto)) . "</strong></small> ]</strong>"; ?>

<?php echo '<div><b>ID:' . $mid . '</b></div>';

    echo $message;

?>

<div class="mt-2" style="white-space: nowrap; overflow-x: auto;">

<button class="btn btn-sm btn-success view-post-comments fa fa-book" data-pid="<?php echo $mid; ?>" data-gpin="<?php echo $mto; ?>">Comments</button>

<button class="btn btn-sm btn-warning hide-post fa fa-ban" data-pid="<?php echo $mid; ?>" data-gpin="<?php echo $mto; ?>">Hide in app</button>

<button class="btn btn-sm btn-danger delete-post fa fa-trash" data-pid="<?php echo $mid; ?>" data-gpin="<?php echo $mto; ?>"> Delete</button> 

</div>

<div id="user-info-result-?php echo $username; ?>"></div>

</div>
 </div>
</div>
</div>

<?php

  } ?>


<div class="pagination">
 
<?php echo paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url, 'admin'); ?>

</div>

<?php echo '</div>';

?>
