<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die');

if (empty($_GET["search"])) 

  {

    die('<div class="alert alert-warning text-center">
<span class="far fa-arrow-up"></span> Search string is empty.
   </div>');

  };

$search_word = $_GET["search"];

$search_word = preg_replace("/[^A-Za-z0-9_ -]/", '', $search_word);

if (empty($search_word) || strlen($search_word) < 3) 

  {

    die('<div class="alert alert-warning text-center">
<span class="far fa-arrow-up"></span>No result found.
   </div>');

  };

if (!isset($page_url)) $page_url       = "search-admins.php";

$settings_file  = _ADMIN_DIR_ . '/settings-files/settings.txt';

$settings       = "";

if (is_file($settings_file)) 

  {

    $settings       = "" . (file_get_contents($settings_file));

  }

$sJson          = json_decode($settings);

$users_per_page = 1;

isset($sJson->users_per_page) ? $sJson->users_per_page : "10";

$item_per_page = $users_per_page;

$param         = !empty($_POST['param']) ? test_input($_POST['param']) : '';

$sort_by       = 'fullname';

$desc          = 'ASC';

if (!empty($_SESSION['sort_by'])) 

  {

    $sby           = $_SESSION['sort_by'];

    if ($sby == 'fullname_desc') 

      {

        $sort_by       = 'fullname';

        $desc          = 'DESC';

      }

    else if ($sby == 'fullname_asc') 

      {

        $sort_by       = 'fullname';

        $desc          = 'ASC';

      }

    else if ($sby == 'id_desc') 

      {

        $sort_by       = 'id';

        $desc          = 'DESC';

      }

    else if ($sby == 'id_asc') 

      {

        $sort_by       = 'id';

        $desc          = 'ASC';

      }

  }

if (isset($_GET["page"])) 

  {

    //Get page number from $_GET["page"]

    $page_number   = (int)$_GET["page"];

  }

else

  {

    $page_number   = 1;

    //if there's no page number, set it to 1

    

  }

require '../../oc-includes/server.php';

$table          = _TABLE_ADMINS_;

$results        = mysqli_query($conn, "SELECT COUNT(id) FROM $table");

//get total number of records from database

$get_total_rows = $results->fetch_row();

//hold total records in variable

if ($get_total_rows[0] < 1) 

  {

    $conn->close();

    die('<div class="alert alert-primary text-center">
<span class="far fa-arrow-up"></span> No active user yet.
   </div>');

  }

$total_pages   = ceil($get_total_rows[0] / $item_per_page);

$page_position = (($page_number - 1) * $item_per_page);

//get starting position to fetch the records

$words         = array_slice(explode(" ", $search_word, 3) , 0, 2);

$fullname_     = "";

$username_     = "";

foreach ($words as $word) 

  {

    $fullname_.= "fullname LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

    $username_.= "username LIKE '%" . mysqli_real_escape_string($conn, $word) . "%' OR ";

  }

$fullname_ = substr($fullname_, 0, -4);

$username_ = substr($username_, 0, -4);

$sql       = "SELECT username, fullname, role FROM $table WHERE ( ($fullname_) OR ($username_) ) ORDER BY {$sort_by} {$desc} LIMIT {$page_position}, {$item_per_page} ";

$query     = mysqli_query($conn, $sql);

mysqli_close($conn);

if (mysqli_num_rows($query) < 1) 

  {

    die('<div class="alert alert-primary text-center">
<span class="fa fa-arrow-down"></span>No result found.
   </div>');

  }

echo '<div class="container">';

echo "<div>Searched: {$search_word}</div>";

while ($row      = mysqli_fetch_assoc($query)) 

  {

    $username = $row["username"];

    $fullname = ucfirst($row["fullname"]);

?>
 <div class="user-panel border-bottom">

  <div class="row">
<div class="col-3">

<div class="user-photo-icon-container"> <img src="<?php echo user_photo_icon($username, ''); ?>"  onerror="imgError( this, 50);" class="user-photo-icon">
</div>

</div>
<div class="col-9">
<div class="users-list-container ellipsis">
 <?php echo "<span class='user-fullname-text'>{$fullname}</span> [ " . ucfirst($username) . " ]"; ?>


<div style="overflow-x: auto;" class="pb-2">

<button class="btn btn-sm btn-primary" onclick="messageUserForm(this);" data-username="<?php echo $username; ?>">Message</button> 

<button class="btn btn-sm btn-secondary user-info fa fa-info" data-username="<?php echo $username; ?>"> Info</button> 

<button class="btn btn-sm btn-danger delete-user" data-username="<?php echo $username; ?>">Delete</button> 

</div>
</div>
 </div>
</div>
</div>

<?php

  } ?>


<div class="pagination">
 
<?php echo paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url, 'admin'); ?>

</div>

<?php echo '</div>'; ?>
