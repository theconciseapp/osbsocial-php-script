<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die');

if (isset($_POST['sort_by'])) 

  {

    $sort_by = test_input($_POST['sort_by']);

    if (empty($sort_by)) $sort_by = 'verified_asc';

    $_SESSION['sort_by']         = $sort_by;

    die('__SUCCESS__');

  }

require '../../oc-includes/server.php';

$sJson          = getSettings();

$users_per_page = isset($sJson["users_per_page"]) ? $sJson["users_per_page"] : "20";

$table          = _TABLE_GROUPS_;

if (!isset($page_url)) $page_url       = "";

$item_per_page  = $users_per_page;

$param          = !empty($_POST['param']) ? test_input($_POST['param']) : '';

$sort_by        = 'fullname';

$desc           = 'ASC';

if (!empty($_SESSION['sort_by'])) 

  {

    $sby            = $_SESSION['sort_by'];

    if ($sby == 'fullname_desc') 

      {

        $sort_by        = 'group_title';

        $desc           = 'DESC';

      }

    else if ($sby == 'fullname_asc') 

      {

        $sort_by        = 'group_title';

        $desc           = 'ASC';

      }

    else if ($sby == 'id_desc') 

      {

        $sort_by        = 'id';

        $desc           = 'DESC';

      }

    else if ($sby == 'id_asc') 

      {

        $sort_by        = 'id';

        $desc           = 'ASC';

      }

  }

if (isset($_GET["page"])) 

  {

    $page_number    = (int)$_GET["page"];

  }

else

  {

    $page_number    = 1;

  }

$results        = mysqli_query($conn, "SELECT COUNT(id ) FROM $table");

//get total number of records from database

$get_total_rows = $results->fetch_row();

//hold total records in variable

$total_groups   = $get_total_rows[0];

if ($total_groups < 1) 

  {

    mysqli_close($conn);

    die('<div class="alert alert-primary text-center">
<span class="fa fa-arrow-down"></span> No active groups yet.
   </div>');

  }

$total_pages   = ceil($total_groups / $item_per_page);

$page_position = ( ($page_number - 1) * $item_per_page);

echo '<div><strong>Total groups: ' . $total_groups . '</strong></div>';

$query = mysqli_query($conn, "SELECT username, fullname, total_members FROM $table ORDER BY auto_join DESC, is_admin DESC, $sort_by $desc LIMIT $page_position, $item_per_page");

mysqli_close( $conn);

echo '<div class="container-fluid">';

while ($row           = mysqli_fetch_assoc($query)) 

  {

    $username      = $row["username"];

    //makeGroupDir($username);

    $fullname      = ucfirst($row["fullname"]);

    $total_members = $row["total_members"];

?>
 <div class="user-panel border-bottom">

  <div class="row">
<div class="col-3">

<div class="user-photo-icon-container"> <img src="<?php echo user_photo_icon( $username, "g"); ?>" onerror="imgError( this, 50);" class="user-photo-icon">
</div>

</div>
<div class="col" style="overflow-x: hidden;">
<div class="users-list-container ellipsis">
 <?php echo "[ {$total_members} ]  <b>" . strtoupper($username) . "</b> ";

if (userVerified($username)) 

      {

        echo '<i class="fa fa-lg fa-check-circle text-warning"></i>';

      }

echo " [ <span class='user-fullname-text'>{$fullname}</span> ]"; ?>

<div style="overflow-x: auto;" class="pb-2">

<button class="btn btn-sm btn-primary fa fa-inbox" onclick="messageUserForm(this);" data-username="<?php echo $username; ?>"> Message</button> 

<button class="btn btn-sm btn-secondary group-info fa fa-info" data-username="<?php echo $username; ?>"> Info</button> 

<!--
<button class="btn btn-sm btn-warning block-user fa fa-ban" data-username="<?php echo $username; ?>" data-type="Block"> Block</button>
-->

<button class="btn btn-sm btn-danger delete-group fa fa-trash" data-username="<?php echo $username; ?>"> Delete</button> 

</div>
<div id="user-info-result-<?php echo $username; ?>"></div>
</div>
 </div>
</div>
</div>

<?php

  } ?>


<div class="pagination">
 
<?php echo paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url, 'admin-groups'); ?>

</div>

<?php echo '</div>';



