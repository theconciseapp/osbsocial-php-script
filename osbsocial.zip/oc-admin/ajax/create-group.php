<?php

/**

 * Class and Function List:

 * Function list:

 * Classes list:

 */

if (!isset($_SESSION)) 

  {

    session_start();

  }

header('Content-type:application/json;charset=utf-8');

require ('../../oc-includes/bootstrap.php');

adminLoggedIn(false, 'die', 'json');

if (!adminCanAddUser()) 

  {

    die('{"error":"Permission denied"}');

  }

if (empty($_POST['group_setting']) 
|| empty($_POST['group_pin']) 
|| empty($_POST['group_title']) 
||empty($_POST['group_info'])
|| !isset( $_POST["auto_join"] ) ) 

  {

    die('{"error":"Parameters missing."}');

  }

$admin_username = getAdminInfo('username');

$gpin           = test_input(strtolower($_POST['group_pin']));

if (!preg_match("/^[a-z0-9]{7}$/i", $gpin) ) 

  {

    die('{"error":"Pin must contain exactly 11 alphanumeric characters, one underscore"}');

  }

$gsetting = test_input(strtolower($_POST['group_setting']));

$gtitle   = test_input($_POST['group_title']);

$ginfo    = test_input( $_POST['group_info'] );

if (strlen($gtitle) > 50) 

  {

    die('{"error":"Title too long. Max: 50 characters."}');

  }

else if (strlen($ginfo) > 500) 

  {

    die('{"error":"Description too long. Max: 500 characters."}');

  }

$gpin = $gsetting . $gpin;

$gdir = getGroupDir(  $gpin);

if ($gpin == 'gv_pofficials' || is_dir($gdir)) 

  {

    die('{"error":"Pin is already in use"}');

  }

$auto_join=0; 

//If auto_join is 1, then app users are automatically added to the group or page

$gtype=1;

if( is_page( $gpin) ){

 $gtype=2;

}

if( !empty( $_POST["auto_join"] ) ){
 $auto_join=1;
}

require "../../oc-includes/server.php";

require "../../oc-ajax/group/group-functions.php";

$gtitle  = preg_replace("/(\s+|\|)/", " ", $gtitle);

$gtitle  = mysqli_real_escape_string($conn, $gtitle);

$ginfo   = mysqli_real_escape_string($conn, $ginfo);

$gpin    = mysqli_real_escape_string($conn, $gpin);

$gadmins = test_input(str_replace(' ', '', $_POST['group_admins']));

if (!empty($gadmins)) 

  {

    $gadmins = trim(preg_replace("/,+/", ",", $gadmins) , ",");

    if (!preg_match("/^[a-z0-9,_]{4,200}$/i", $gadmins)) 

      {

        die('{"error":"Admins has some unwanted characters or length."}');

      }

    $gadmins = $gadmins . ',';

  }

$table   = _TABLE_GROUPS_;

$time    = time();

$gadmins = "{$admin_username},{$gadmins}";

$mem     = $gadmins;

/*

  if (is_page( $gpin) ){

 $mem="";

}

*/

$gac     = explode(",", $gadmins);

$gac     = count($gac) - 1;

$iquery  = mysqli_query($conn, "INSERT INTO {$table}( group_type, auto_join, username, fullname, group_info, group_admins, group_members, total_members, created_by, is_admin, created_on) VALUES ('$gtype','$auto_join','$gpin','$gtitle','$ginfo','$gadmins','$mem','$gac','$admin_username', '1', '$time')");

if (!$iquery || mysqli_affected_rows($conn) < 1) 

  {

    die('{"error":"Could not create. ErrIns"}');

  }


  $aj=true;

if( $auto_join==1) {

$auto_join_groups = _ADMIN_DIR_ . '/settings-files/auto-join-groups.txt';

$sanitized_ginfo= str_replace("|","&#124;", $ginfo);

if ( file_put_contents( $auto_join_groups, "{$gpin}|{$gtitle}|{$sanitized_ginfo}|{$admin_username}\n", FILE_APPEND  ) === false) 
  {
     $aj=false;
  }
}

$lastmtime = "" . ( (microtime(true) * 10000 ) - 1); //last msg time

if (!$aj ||!makeGroupDir( $gpin, '755')) 

  {

    //Reverse, if group folder could not be created

    mysqli_query($conn, "DELETE FROM $table WHERE username='$gpin'");

    die('{"error":"Could not create! Please try again."}');

  }

file_put_contents(  $gdir . '/lastseen.txt', $time  );

if (   is_page($gpin) ) 

  {

    file_put_contents($gdir . "/lock.md", $mem);

  }

$data = array();

$data["status"]      = "success";
$data["result"]      = "Successfully created";


die(json_encode($data));
