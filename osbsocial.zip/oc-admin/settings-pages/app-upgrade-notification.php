<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn();
require ('../includes/admin-functions.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="../assets/css/index.css?i=<?php echo randomString(3); ?>">

<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; } 
.string { color: green; }
.number { color: darkorange; }
.boolean { color: blue; } 
.null { color: magenta; } 
.key { color: red; }
</style>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 50px;">

       <div class="">
<h5>App upgrade data</h5>
</div>

<div id="app-upgrade-data-container" class="app-upgrade-data-container mb-5">

<div class="form-text">Alter these only if you want to prompt users to upgrade to latest version of your app. Version code must be incremental i.e must be greater than the previous version code.</div>

<?php $sJson = appUpgradeData();

$vcode = isset($sJson["version_code"]) ? $sJson["version_code"] : "1.0";

$vinfo = isset($sJson["version_info"]) ? $sJson["version_info"] : "New version info";

$vurl  = isset($sJson["version_url"]) ? $sJson["version_url"] : "https://link to new app";

?>

<div class="mb-2">
<label class="d-block mt-2">New version code (Number only)</label>
 <input type="number" class="form-control mb-2" id="upgrade-version-code" placeholder="New version code" value="<?php echo $vcode; ?>">
</div>

<div class="mb-3">
<label class="form-label">New version info</label>
<div class="form-text">Enter what changes in the old version or new features introduced.</div>

 <textarea class="form-control mb-2" id="upgrade-version-info" placeholder="New version info"><?php echo str_replace(":nl::", "\n", $vinfo); ?></textarea>
</div>

<div class="mb-2">
<label class="d-block mt-2">Download location</label>
<div class="form-text">Url of where new version of app can be downloaded</div>

 <input type="url" class="form-control mb-2" id="upgrade-version-location" placeholder="Download location" value="<?php echo $vurl; ?>">
</div>


<button id="upgrade-version-btn" class="btn btn-sm btn-primary mt-1">Save</button>

</div>
</div>
</div>
</div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="../assets/js/global.js?i=1"></script>
<script src="../assets/js/index.js?i=1"></script>
<script src="../assets/js/settings.js?y=<?php echo rand(); ?>"></script>

</body>
</html>
