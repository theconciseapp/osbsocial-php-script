<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../../oc-includes/bootstrap.php');

adminLoggedIn();
require ('../includes/admin-functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="../assets/css/index.css?i=<?php echo randomString(3); ?>">

<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; } 
.string { color: green; }
.number { color: darkorange; }
.boolean { color: blue; } 
.null { color: magenta; } 
.key { color: red; }
</style>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
    <?php leftSidebar(); ?>
</div>
<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 50px;">

       <div class="">
<h5>User data privacy terms</h5>
</div>
   
<div id="user-privacy-container">

<div class="mb-2">
<label class="form-label"><b>Edit user data privacy terms</b></label>

<div class="form-text text-danger fa fa-warning"> Always backup your user privacy data elsewhere</div>

<textarea class="form-control" style="height: 150px;" id="user-privacy-box" row="3">
<?php

$privacy_path = _PROJECT_DIR_ . '/oc-privacy.txt';

if (is_readable($privacy_path)) 

  {

    echo @file_get_contents($privacy_path);

  }

?></textarea>

</div>

<button id="save-user-privacy-btn" class="btn btn-sm btn-primary mt-1">Save</button>

</div>


<hr />

<div class="">
<h5>Actions</h5>
</div>
  
<div id="actions-container">
<div class="mb-2">
<label class="form-label">Logout all user </label>
<div class="form-text">This action can only be performed once per day</div>
<button id="logout-all-users" class="btn btn-sm btn-primary mt-1 send-action-messages" data-action="auto-logout" data-message_to="gv_pofficials">Logout all users</button>
</div>
</div>

</div>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="../assets/js/global.js?i=1"></script>
<script src="../assets/js/index.js?i=1"></script>
<script src="../assets/js/settings.js?y=<?php echo rand(); ?>"></script>

</body>
</html>






