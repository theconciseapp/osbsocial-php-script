<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn(); ?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 
<script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> <img src="<?php echo _SITE_URL_ . '/oc-logo.png'; ?>" class="logo"> <?php echo _BRAND_NAME_; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="<?php echo _ADMIN_URL_; ?>">Home</a>

<a class="nav-link" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>">Logout</a>
     
     </div>
    </div>
  </div>
</nav>

<div class="container-fluid mb-5">
<div class="row">
 <div class="col-12 col-sm-7">

<button class="btn btn-sm btn-primary d-block mb-2 site-log" data-action="show" data-type="1">Show error logs</button>
 
<div class="alert alert-danger mt-2" id="site-log1-result"></div>

<button class="btn btn-sm btn-warning site-log" data-action="clear" data-type="1">Empty log file</button>

<hr>

</div>

<div class="col-12 col-sm-5">

<button class="btn btn-sm btn-primary d-block mb-2 site-log" data-action="show" data-type="2">Show other logs</button>

<div class="alert alert-danger mt-2" id="site-log2-result"></div>

<button class="btn btn-sm btn-warning site-log" data-action="clear" data-type="2">Empty log file</button>


</div>

</div>
</div>



<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>
<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>
<script src="assets/js/manage_space.js?i=<?php echo randomString(3); ?>"></script>
</body>
</html>
