<?php if (!isset($_SESSION)) 

  {

    session_start();

  }

require ('../oc-includes/bootstrap.php');

adminLoggedIn(); 
require ('includes/admin-functions.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


<link rel="stylesheet" href="assets/css/index.css?i=<?php echo randomString(3); ?>">

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
var _ADMIN_URL_='<?php echo _ADMIN_URL_; ?>';
</script>
</head>
<body>

<?php site_header();?>

<div class="container-fluid" style="height: calc(100vh - 65px); overflow: hidden;">

<div style="white-space: nowrap;">

<div class="side-bar-container hide-left-sidebar">
 
<a class="side-bar-btn bg-secondary" aria-current="page" href="<?php echo _ADMIN_URL_; ?>"><i class="fa fa-lg fa-home text-light"> </i> Home</a>
	

 <a href="groups.php" class="side-bar-btn"><i class="fa fa-users"></i> Groups/Pages</a>


<a class="side-bar-btn mt-3" href="<?php echo _ADMIN_URL_ . '/logout.php'; ?>"><i class="fa fa-lg fa-sign-out text-light"></i> Logout</a>


</div>

<div class="main-content-container">

<div style="height: calc(100vh - 65px); overflow-y: auto; padding-bottom: 100px;">


<div class="row">
<div class="col-12 col-md-6 p-4">
<h2>
SEND BROADCAST</h2>
<br>
<div class="alert alert-info">
Send message to all users or to a specific group or page. Kindly know that message sent cannot be undone. Therefore, construct your message with care.</div>

<div class="mb-2">Send to: 

<div class="form-check form-check-inline">
  <input class="form-check-input" type="checkbox" value="gv_pofficials" id="is-official">
  <label class="form-check-label" for="is-official">
   All users
  </label>
</div>


<div class="form-check form-check-inline">

<input type="checkbox" class="form-check-input" id="send-as" value="act_act" />

<label class="form-check-label" for="send-as"> Action or alert</label>

</div>

<input id="send-message-to" type="text" class="form-control mt-1" maxlength="15" placeholder="Enter group or page pin" />

</div>
 
<div class="mb-1">Message: <button class="btn btn-sm btn-light mb-1" onclick="if( confirm('Clear message?') ){$('#broadcast-message-textbox').val('');}">      
<i class="fa fa-trash"></i> Clear</button>
<textarea class="message-textbox form-control" style="height: 130px;"  id="broadcast-message-textbox"></textarea></div>

<div class="mt-3 mb-3">
<div class="form-check form-check-inline">
  <input class="form-check-input" type="checkbox" value="1" id="can-comment">
  <label class="form-check-label" for="can-comment">
 Viewers can comment
  </label>
</div>
</div>

<input type="text" class="d-block mb-2" id="file-name" style="outline: none; border: 0; width: 100%; color: red; text-transform: capitalize; font-weight: bold;" readonly>

<input type="hidden" id="meta" />
<input type="hidden" id="file-preview" />
<input type="hidden" id="file-message" />

</div>

<div class="col-12 col-md-6">
 
 <div class="row">
  <div class="col-4">

<strong>Attach file (Optional-Max: 100MB)</strong>
 <button class="d-block btn btn-small btn-secondary m-2" id="attach-file" style="max-width: 100px;">Upload</button>

</div> 

<div class="col" style="border-left: 2px solid #444;">

<strong>OR enter file url instead (Optional)</strong>
<div class="alert alert-warning">It's recommended to use this if your file is large e.g above 10MB. Upload the file outside your server and paste the url here. This method saves your server storage and bandwidth.</div>

<input type="url" id="ext-file-url" class="d-block form-control m-2" placeholder="Enter file url">

<strong>File caption (Optional)</strong>

<input type="text" id="file-caption" class="d-block form-control m-2" placeholder="File caption">

<strong>Select file type</strong>

<select id="ext-file-type" class="d-block form-control m-2">
<option selected disabled>Choose file type</option>
<option>Video</option>
<option>Image</option>
<option>Audio</option>
<option>Document</option>
</select>

<strong>File size in Megabytes. e.g 5 (Means 5 megabytes)</strong>

<input type="number" id="ext-file-size" class="d-block form-control m-2" placeholder="">

</div>
</div>
</div>
</div>

<div class="alert alert-primary">
<button id="send-broadcast-btn" class="btn btn-md btn-primary">Send</button>
</div>


</div>
</div>
</div>
</div>

<div class="fixed-bottom footer bg-light">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-5 footer-col">

    </div>
    <div class="col-12 col-sm-3 footer-col">
            
    </div>
    <div class="col-12 col-sm-4 footer-col">
      
    </div>
  </div>

  <div class="row">
    <div class="col text-center copyright">
      <p class=""><small class="fs-6">© <?php echo date('Y'); ?>. All Rights Reserved.</small></p>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropzone@5.7.1/dist/dropzone.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/dropzone.min.js"></script>

<script src="assets/js/global.js?i=<?php echo randomString(3); ?>"></script>

<script src="assets/js/index.js?i=<?php echo randomString(3); ?>"></script>

<script>
Dropzone.options.guploadFileMessageWidget = {
  paramName: 'file',
  maxFilesize: 100, // MB
  maxFiles: 1,
 resizeWidth: 1000,
  dictDefaultMessage: 'Upload File',
 // acceptedFiles: 'image/*',
  init: function() {

this.on("sending", function(file, xhr, formData) {
  formData.append("chat_to","");
  formData.append("send_as","");
 });

this.on("complete", function(file) {
  this.removeFile(file);
});
  this.on('success', function(file, resp){
if(resp.error){
   toast(resp.error);
}else if(resp.status ){
 
 $('#file-name').val( resp.file_name);
 $('#file-message').val( resp.file_message);
 $('#file-preview').val( resp.file_preview );
$('#meta').val( resp.meta );

toast('Upload successful.',{type:'success'});
closeDisplayData('general-upload-box');

 }else{
 toast( resp);
}
 });

  }
};


var bmbTimer;

$(function(){

$('body').on('click','#is-official',function(){
  var value=$(this).is(':checked');
 var sbox=$('#send-message-to');
if(value){
  sbox.val('gv_pofficials').hide();
}
else{
  sbox.val('').slideDown();
}
});


$('body').on('click','#attach-file',function(){

var data='<div class="file-message-upload-box dropzone text-center" id="gupload-file-message-widget"><div class="dz-message">Upload file</div> </div>';

displayData(data,{id:"general-upload-box",sclose: false});

var myDropzone = new Dropzone("div#gupload-file-message-widget", { url: _ADMIN_URL_ + "/ajax/upload_general_file.php"});
});

$('body').on('input','#broadcast-message-textbox',function(){

var this_=$(this);
 clearTimeout( bmbTimer);
  bmbTimer=setTimeout(function(){
var value= this_.val();
localStorage.setItem('broadcast_message_draft', value);
 },1800);

 });

$('body').on('click','#send-broadcast-btn',function(){
  var this_=$(this);
  
var textbox=$('#broadcast-message-textbox');

var sendAs=$('#send-as');

var send_to=$.trim( $('#send-message-to').val());

 var send_as="";

if( sendAs.is(':checked')){

  send_as=$.trim( sendAs.val() );
}

var file_name=$.trim( $('#file-name').val() );
var meta=$.trim( $('#meta').val() );
var ext_file_url=$.trim( $('#ext-file-url').val() );
var ext_file_size=$.trim( $('#ext-file-size').val() );
var ext_file_type=$.trim( $('#ext-file-type').val() );


var caption=$.trim($('#file-caption').val());
var file_preview=$.trim($('#file-preview').val() );
var file_message=$.trim($('#file-message').val() );
var can_comment="";
if($('#can-comment').is(':checked')){
 can_comment="1";
}

var message=$.trim(textbox.val());

if( send_to.length<6|| send_to.length>50){
 return toast('Enter a valid group pin.');
}
else if(send_as && send_as.length>20){
return toast('"Send as" too long. Max: 30');
}
else if(!message || message.length>10000){
 return toast('Message too long or short.');
 }

localStorage.setItem('send_message_as',send_as);

message=sanitizeMessage( message );
  //message=escape(message);

  buttonSpinner(this_);
 var btn=$('.send-broadcast-btn');
     btn.prop('disabled',true);

$.ajax({
url: _ADMIN_URL_ + '/ajax/send_broadcast_message.php',
type:'POST',
dataType:'json',
data: {
 send_as: send_as,
 send_to: send_to,
 message:message,
 can_comment: can_comment,
 file_preview: file_preview,
file_message: file_message,
 meta: meta,
ext_file_url: ext_file_url,
file_size: ext_file_size,
file_type: ext_file_type,
file_caption: caption,
},

}).done(function(result){
  buttonSpinner(this_,true);
  btn.prop('disabled', false);
  if( result.error){
 toast(result.error);
} else if(result.status){
  toast(result.result, { type: 'success'});
this_.addClass('btn-danger');
}else{
 toast('Unknown error occured.');
}
 
}).fail(function(e,txt,xhr){
  buttonSpinner( this_, true);
  btn.prop('disabled', false)
 toast('Check your internet connection. ' + xhr);
});

});

var sa=localStorage.getItem('send_message_as')||"";

$('#send-message-as').val( $.trim(sa) );
$('#broadcast-message-textbox').val(localStorage.getItem('broadcast_message_draft')||"");
});

</script>

</body>
</html>
